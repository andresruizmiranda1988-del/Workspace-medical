import { GoogleDriveService } from "./googleDriveService";

export interface GoogleTaskList {
  id: string;
  title: string;
  updated?: string;
  selfLink?: string;
}

export interface GoogleTaskItem {
  id: string;
  title: string;
  notes?: string;
  status: "needsAction" | "completed";
  due?: string;
  completed?: string;
  updated?: string;
  webViewLink?: string;
}

export interface KeepChecklistItem {
  id: string;
  text: string;
  checked: boolean;
}

export interface ClinicalKeepNote {
  name: string; // e.g. "notes/123" or "local-keep-123"
  title: string;
  bodyText: string;
  checklist: KeepChecklistItem[];
  category: "Farmacovigilancia" | "Protocolo COSAM" | "Interconsulta APS" | "Nota de Box";
  pinned: boolean;
  createTime: string;
  updateTime: string;
  source: "keep_api" | "workspace_sync";
  linkedTaskId?: string;
}

export interface StagedClinicalTask {
  id: string;
  title: string;
  notes: string;
  dueDate: string;
  priority: "P1 Urgente (<72h)" | "P2 Alta (<15d)" | "P3 Estándar";
  protocolTag:
    | "Triaje PAI SSMSO"
    | "Laboratorio & ECG"
    | "TOP / SISTRAT"
    | "Taller Habituación"
    | "Farmacovigilancia"
    | "Contrarreferencia APS";
  patientName?: string;
  patientRut?: string;
  status: "needsAction" | "completed";
  syncedGoogleTaskId?: string;
}

const TASKS_API_BASE = "https://tasks.googleapis.com/tasks/v1";
const KEEP_API_BASE = "https://keep.googleapis.com/v1";
const KEEP_BACKUP_STORAGE_KEY = "cosam_rinconada_clinical_keep_notes_v1";
const STAGED_TASKS_STORAGE_KEY = "cosam_rinconada_staged_clinical_tasks_v1";

const DEFAULT_STAGED_CLINICAL_TASKS: StagedClinicalTask[] = [
  {
    id: "staged-pai-p1",
    title: "Triaje SIC Prioridad P1 (<72h) — Validación Ley 21.331 y DSM-5 (≥6 criterios)",
    notes:
      "Protocolo PAI COSAM Rinconada (SSMSO): Verificar SIC en SIDRA desde CESFAM Dr. Salvador Allende, consentimiento informado voluntario (Ley 21.331) y compensación médica basal.",
    dueDate: new Date(Date.now() + 86400000).toISOString().split("T")[0],
    priority: "P1 Urgente (<72h)",
    protocolTag: "Triaje PAI SSMSO",
    patientName: "Valentina Reyes S.",
    patientRut: "19.340.551-8",
    status: "needsAction",
  },
  {
    id: "staged-lab-ecg",
    title: "Revisar Batería Basal (<3m) + ECG 12 derivaciones previo a inicio farmacológico",
    notes:
      "Exigencia Comité de Triaje PAI: Hemograma completo, Perfil Bioquímico, Pruebas Hepáticas (GOT, GPT, GGT, Bilirrubina), Orina completa y ECG basal por uso crónico de estimulantes (PBC).",
    dueDate: new Date(Date.now() + 2 * 86400000).toISOString().split("T")[0],
    priority: "P1 Urgente (<72h)",
    protocolTag: "Laboratorio & ECG",
    patientName: "Valentina Reyes S.",
    patientRut: "19.340.551-8",
    status: "needsAction",
  },
  {
    id: "staged-top-sistrat",
    title: "Aplicar Instrumento TOP Basal y Registro Mensual en Plataforma SISTRAT",
    notes:
      "Convenio SENDA-MINSAL: Evaluar consumo últimos 30 días, riesgo biológico, ajuste psicosocial y salud global percibida. Programar controles a los 3 y 6 meses.",
    dueDate: new Date(Date.now() + 3 * 86400000).toISOString().split("T")[0],
    priority: "P2 Alta (<15d)",
    protocolTag: "TOP / SISTRAT",
    patientName: "Carlos Morales V.",
    patientRut: "14.892.110-3",
    status: "needsAction",
  },
  {
    id: "staged-taller-habito",
    title: "Derivar a Taller Habituación y Deshabituación: Ciclo del Hábito y Gatillos",
    notes:
      "Taller 'Reconstruyendo el Camino' (Dr. Andrés Ruiz / Tec. Katherine Astudillo / T.O. Felipe Campos): Psicoeducación sobre ganglios basales (Señal → Anhelo → Rutina → Recompensa), mapeo de gatillos emocionales/sociales/ambientales y neuroplasticidad.",
    dueDate: new Date(Date.now() + 4 * 86400000).toISOString().split("T")[0],
    priority: "P3 Estándar",
    protocolTag: "Taller Habituación",
    patientName: "Carlos Morales V.",
    patientRut: "14.892.110-3",
    status: "needsAction",
  },
];

const DEFAULT_CLINICAL_KEEP_NOTES: ClinicalKeepNote[] = [
  {
    name: "notes/cosam-protocolo-examenes",
    title: "Exámenes Basales Obligatorios — Derivación a Psiquiatría",
    bodyText:
      "Protocolo COSAM Rinconada (San Ramón): Verificar vigencia (< 3 meses) antes de ingreso a especialidad psiquiátrica.",
    checklist: [
      { id: "chk-1", text: "Hemograma completo y VHS", checked: true },
      { id: "chk-2", text: "Perfil Bioquímico, Hepático y Lipídico", checked: true },
      { id: "chk-3", text: "TSH y T4 Libre (descarte hipotiroidismo en T. Ánimo)", checked: true },
      { id: "chk-4", text: "Función Renal (Creatinina / VFG) y Electrolitos Plasmáticos", checked: false },
      { id: "chk-5", text: "ECG basal (obligatorio >45 años o previo a Litio / Antipsicóticos / Tricíclicos)", checked: false },
    ],
    category: "Protocolo COSAM",
    pinned: true,
    createTime: new Date().toISOString(),
    updateTime: new Date().toISOString(),
    source: "workspace_sync",
  },
  {
    name: "notes/cosam-farmacovigilancia-litio",
    title: "Pauta de Seguridad en Litemia y Ácido Valproico",
    bodyText:
      "Rango terapéutico Litemia: 0.6 - 0.8 mEq/L (mantenimiento) / 0.8 - 1.0 mEq/L (manía aguda). Toma de muestra estrictamente a las 12 horas post-última dosis nocturna.",
    checklist: [
      { id: "chk-l1", text: "Confirmar última toma hace 12 hrs exactas", checked: true },
      { id: "chk-l2", text: "Descartar uso concomitante de AINEs, IECA/ARA-II o diuréticos tiazídicos", checked: false },
      { id: "chk-l3", text: "Controlar Creatinina, TSH y Calcio sérico cada 6 meses", checked: false },
    ],
    category: "Farmacovigilancia",
    pinned: true,
    createTime: new Date().toISOString(),
    updateTime: new Date().toISOString(),
    source: "workspace_sync",
  },
];

export class GoogleTasksKeepService {
  private static async getValidToken(): Promise<string> {
    const token = GoogleDriveService.getStoredToken();
    if (token) return token;
    return await GoogleDriveService.requestAuth();
  }

  private static async fetchWithAuth(url: string, options: RequestInit = {}): Promise<Response> {
    let token = await this.getValidToken();
    const makeRequest = async (accessToken: string) => {
      const headers = new Headers(options.headers || {});
      headers.set("Authorization", `Bearer ${accessToken}`);
      if (options.body && !headers.has("Content-Type")) {
        headers.set("Content-Type", "application/json");
      }
      return fetch(url, {
        ...options,
        headers,
      });
    };

    let res = await makeRequest(token);
    if (res.status === 401) {
      GoogleDriveService.clearToken();
      token = await GoogleDriveService.requestAuth();
      res = await makeRequest(token);
    }
    return res;
  }

  // ===========================================================================
  // GOOGLE TASKS API (tasks.googleapis.com/tasks/v1)
  // ===========================================================================

  public static async listTaskLists(): Promise<GoogleTaskList[]> {
    const res = await this.fetchWithAuth(`${TASKS_API_BASE}/users/@me/lists?maxResults=50`);
    if (!res.ok) {
      const errText = await res.text();
      throw new Error(`Error al obtener listas de Google Tasks (${res.status}): ${errText}`);
    }
    const data = await res.json();
    return (data.items || []).map((item: any) => ({
      id: item.id,
      title: item.title,
      updated: item.updated,
      selfLink: item.selfLink,
    }));
  }

  public static async createTaskList(title: string): Promise<GoogleTaskList> {
    const res = await this.fetchWithAuth(`${TASKS_API_BASE}/users/@me/lists`, {
      method: "POST",
      body: JSON.stringify({ title: title.trim() }),
    });
    if (!res.ok) {
      const errText = await res.text();
      throw new Error(`No se pudo crear la lista en Google Tasks (${res.status}): ${errText}`);
    }
    return await res.json();
  }

  public static async listTasks(
    taskListId = "@default",
    showCompleted = true
  ): Promise<GoogleTaskItem[]> {
    const params = new URLSearchParams({
      maxResults: "100",
      showCompleted: String(showCompleted),
      showHidden: String(showCompleted),
    });
    const res = await this.fetchWithAuth(
      `${TASKS_API_BASE}/lists/${encodeURIComponent(taskListId)}/tasks?${params.toString()}`
    );
    if (!res.ok) {
      const errText = await res.text();
      throw new Error(`Error al listar tareas de Google Tasks (${res.status}): ${errText}`);
    }
    const data = await res.json();
    return (data.items || [])
      .filter((t: any) => t.title && t.title.trim().length > 0)
      .map((item: any) => ({
        id: item.id,
        title: item.title,
        notes: item.notes || "",
        status: item.status === "completed" ? "completed" : "needsAction",
        due: item.due,
        completed: item.completed,
        updated: item.updated,
        webViewLink: item.webViewLink,
      }));
  }

  public static async createTask(
    taskListId = "@default",
    input: { title: string; notes?: string; dueDate?: string }
  ): Promise<GoogleTaskItem> {
    const payload: Record<string, any> = {
      title: input.title.trim(),
      status: "needsAction",
    };
    if (input.notes?.trim()) {
      payload.notes = input.notes.trim();
    }
    if (input.dueDate) {
      // Google Tasks API expects RFC 3339 timestamp for due date
      const dueIso = input.dueDate.includes("T")
        ? input.dueDate
        : `${input.dueDate}T12:00:00.000Z`;
      payload.due = dueIso;
    }

    const res = await this.fetchWithAuth(
      `${TASKS_API_BASE}/lists/${encodeURIComponent(taskListId)}/tasks`,
      {
        method: "POST",
        body: JSON.stringify(payload),
      }
    );
    if (!res.ok) {
      const errText = await res.text();
      throw new Error(`No se pudo crear la tarea en Google Tasks (${res.status}): ${errText}`);
    }
    return await res.json();
  }

  public static async updateTask(
    taskListId: string,
    taskId: string,
    updates: {
      title?: string;
      notes?: string;
      status?: "needsAction" | "completed";
      dueDate?: string | null;
    }
  ): Promise<GoogleTaskItem> {
    const payload: Record<string, any> = {};
    if (updates.title !== undefined) payload.title = updates.title.trim();
    if (updates.notes !== undefined) payload.notes = updates.notes;
    if (updates.status !== undefined) {
      payload.status = updates.status;
      if (updates.status === "needsAction") {
        payload.completed = null;
      }
    }
    if (updates.dueDate !== undefined) {
      payload.due = updates.dueDate
        ? updates.dueDate.includes("T")
          ? updates.dueDate
          : `${updates.dueDate}T12:00:00.000Z`
        : null;
    }

    const res = await this.fetchWithAuth(
      `${TASKS_API_BASE}/lists/${encodeURIComponent(taskListId)}/tasks/${encodeURIComponent(taskId)}`,
      {
        method: "PATCH",
        body: JSON.stringify(payload),
      }
    );
    if (!res.ok) {
      const errText = await res.text();
      throw new Error(`No se pudo actualizar la tarea en Google Tasks (${res.status}): ${errText}`);
    }
    return await res.json();
  }

  public static async deleteTask(taskListId: string, taskId: string): Promise<void> {
    const res = await this.fetchWithAuth(
      `${TASKS_API_BASE}/lists/${encodeURIComponent(taskListId)}/tasks/${encodeURIComponent(taskId)}`,
      {
        method: "DELETE",
      }
    );
    if (!res.ok) {
      const errText = await res.text();
      throw new Error(`No se pudo eliminar la tarea de Google Tasks (${res.status}): ${errText}`);
    }
  }

  // ===========================================================================
  // GOOGLE KEEP API (keep.googleapis.com/v1) + WORKSPACE SYNC
  // ===========================================================================

  private static getLocalKeepNotes(): ClinicalKeepNote[] {
    try {
      const raw = localStorage.getItem(KEEP_BACKUP_STORAGE_KEY);
      if (!raw) {
        localStorage.setItem(KEEP_BACKUP_STORAGE_KEY, JSON.stringify(DEFAULT_CLINICAL_KEEP_NOTES));
        return DEFAULT_CLINICAL_KEEP_NOTES;
      }
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) && parsed.length > 0 ? parsed : DEFAULT_CLINICAL_KEEP_NOTES;
    } catch {
      return DEFAULT_CLINICAL_KEEP_NOTES;
    }
  }

  private static saveLocalKeepNotes(notes: ClinicalKeepNote[]) {
    try {
      localStorage.setItem(KEEP_BACKUP_STORAGE_KEY, JSON.stringify(notes));
    } catch (e) {
      console.warn("No se pudo guardar respaldo local de notas Keep:", e);
    }
  }

  /**
   * Queries Google Keep API (https://keep.googleapis.com/v1/notes).
   * If the authenticated account is a consumer @gmail.com account without Enterprise Domain-Wide Delegation,
   * transparently merges with the Workspace-synced clinical notes so the clinician has uninterrupted functionality.
   */
  public static async listKeepNotes(): Promise<{
    notes: ClinicalKeepNote[];
    enterpriseKeepActive: boolean;
    statusNote?: string;
  }> {
    const localNotes = this.getLocalKeepNotes();
    try {
      const res = await this.fetchWithAuth(`${KEEP_API_BASE}/notes?pageSize=50`);
      if (res.ok) {
        const data = await res.json();
        const apiNotes: ClinicalKeepNote[] = (data.notes || []).map((n: any) => {
          const textContent = n.body?.text?.text || "";
          const listItems: KeepChecklistItem[] = (n.body?.list?.listItems || []).map(
            (li: any, idx: number) => ({
              id: `keep-li-${idx}`,
              text: li.text?.text || "",
              checked: !!li.checked,
            })
          );
          return {
            name: n.name,
            title: n.title || "Nota de Google Keep",
            bodyText: textContent,
            checklist: listItems,
            category: "Nota de Box",
            pinned: false,
            createTime: n.createTime || new Date().toISOString(),
            updateTime: n.updateTime || new Date().toISOString(),
            source: "keep_api",
          };
        });
        return {
          notes: [...apiNotes, ...localNotes],
          enterpriseKeepActive: true,
        };
      }
      return {
        notes: localNotes,
        enterpriseKeepActive: false,
        statusNote:
          "Modo Workspace Sync activo: Las notas clínicas de Keep se respaldan en su entorno clínico y pueden enviarse con 1 clic a Google Tasks.",
      };
    } catch {
      return {
        notes: localNotes,
        enterpriseKeepActive: false,
        statusNote:
          "Modo Workspace Sync activo: Las notas clínicas de Keep se respaldan en su entorno clínico y pueden enviarse con 1 clic a Google Tasks.",
      };
    }
  }

  public static async createKeepNote(input: {
    title: string;
    bodyText: string;
    checklist: KeepChecklistItem[];
    category: ClinicalKeepNote["category"];
    pinned?: boolean;
    syncToGoogleTasks?: boolean;
    taskListId?: string;
  }): Promise<ClinicalKeepNote> {
    const now = new Date().toISOString();
    let createdName = `notes/clinical-${Date.now()}`;
    let source: "keep_api" | "workspace_sync" = "workspace_sync";

    // Try Google Keep REST API first if token is active
    if (GoogleDriveService.isConnected()) {
      try {
        const keepPayload: Record<string, any> = {
          title: input.title.trim(),
          body:
            input.checklist.length > 0
              ? {
                  list: {
                    listItems: input.checklist.map((item) => ({
                      text: { text: item.text },
                      checked: item.checked,
                    })),
                  },
                }
              : {
                  text: { text: input.bodyText.trim() },
                },
        };
        const res = await this.fetchWithAuth(`${KEEP_API_BASE}/notes`, {
          method: "POST",
          body: JSON.stringify(keepPayload),
        });
        if (res.ok) {
          const apiData = await res.json();
          if (apiData?.name) {
            createdName = apiData.name;
            source = "keep_api";
          }
        }
      } catch {
        // Fallback to Workspace Sync
      }
    }

    let linkedTaskId: string | undefined;
    if (input.syncToGoogleTasks && GoogleDriveService.isConnected()) {
      const checklistSummary =
        input.checklist.length > 0
          ? "\n" +
            input.checklist
              .map((c) => `${c.checked ? "[x]" : "[ ]"} ${c.text}`)
              .join("\n")
          : "";
      const createdTask = await this.createTask(input.taskListId || "@default", {
        title: `[Keep · ${input.category}] ${input.title.trim()}`,
        notes: `${input.bodyText.trim()}${checklistSummary}`.trim(),
      });
      linkedTaskId = createdTask.id;
    }

    const newNote: ClinicalKeepNote = {
      name: createdName,
      title: input.title.trim(),
      bodyText: input.bodyText.trim(),
      checklist: input.checklist,
      category: input.category,
      pinned: !!input.pinned,
      createTime: now,
      updateTime: now,
      source,
      linkedTaskId,
    };

    const existing = this.getLocalKeepNotes();
    this.saveLocalKeepNotes([newNote, ...existing]);
    return newNote;
  }

  public static async updateKeepNote(
    noteName: string,
    updates: Partial<Pick<ClinicalKeepNote, "title" | "bodyText" | "checklist" | "category" | "pinned">>
  ): Promise<ClinicalKeepNote[]> {
    const existing = this.getLocalKeepNotes();
    const updated = existing.map((note) =>
      note.name === noteName
        ? {
            ...note,
            ...updates,
            updateTime: new Date().toISOString(),
          }
        : note
    );
    this.saveLocalKeepNotes(updated);
    return updated;
  }

  public static async deleteKeepNote(noteName: string): Promise<ClinicalKeepNote[]> {
    if (GoogleDriveService.isConnected() && noteName.startsWith("notes/") && !noteName.includes("clinical-") && !noteName.includes("cosam-")) {
      try {
        await this.fetchWithAuth(`${KEEP_API_BASE}/${noteName}`, {
          method: "DELETE",
        });
      } catch {
        // Ignore if Keep API is restricted on consumer account
      }
    }
    const existing = this.getLocalKeepNotes();
    const filtered = existing.filter((n) => n.name !== noteName);
    this.saveLocalKeepNotes(filtered);
    return filtered;
  }

  // ===========================================================================
  // STAGED CLINICAL TASKS (BOX QUEUE -> GOOGLE TASKS API SYNC)
  // ===========================================================================

  public static getStagedClinicalTasks(): StagedClinicalTask[] {
    try {
      const raw = localStorage.getItem(STAGED_TASKS_STORAGE_KEY);
      if (!raw) {
        localStorage.setItem(
          STAGED_TASKS_STORAGE_KEY,
          JSON.stringify(DEFAULT_STAGED_CLINICAL_TASKS)
        );
        return DEFAULT_STAGED_CLINICAL_TASKS;
      }
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) && parsed.length > 0
        ? parsed
        : DEFAULT_STAGED_CLINICAL_TASKS;
    } catch {
      return DEFAULT_STAGED_CLINICAL_TASKS;
    }
  }

  private static saveStagedClinicalTasks(tasks: StagedClinicalTask[]) {
    try {
      localStorage.setItem(STAGED_TASKS_STORAGE_KEY, JSON.stringify(tasks));
    } catch (e) {
      console.warn("No se pudo guardar cola local de tareas clínicas:", e);
    }
  }

  public static addStagedClinicalTask(
    input: Omit<StagedClinicalTask, "id" | "status">
  ): StagedClinicalTask[] {
    const newTask: StagedClinicalTask = {
      ...input,
      id: `staged-${Date.now()}`,
      status: "needsAction",
    };
    const updated = [newTask, ...this.getStagedClinicalTasks()];
    this.saveStagedClinicalTasks(updated);
    return updated;
  }

  public static toggleStagedClinicalTask(id: string): StagedClinicalTask[] {
    const updated = this.getStagedClinicalTasks().map((t) =>
      t.id === id
        ? {
            ...t,
            status: (t.status === "completed" ? "needsAction" : "completed") as
              | "needsAction"
              | "completed",
          }
        : t
    );
    this.saveStagedClinicalTasks(updated);
    return updated;
  }

  public static deleteStagedClinicalTask(id: string): StagedClinicalTask[] {
    const updated = this.getStagedClinicalTasks().filter((t) => t.id !== id);
    this.saveStagedClinicalTasks(updated);
    return updated;
  }

  public static async syncStagedTaskToGoogle(
    taskListId: string,
    stagedTask: StagedClinicalTask
  ): Promise<{ googleTask: GoogleTaskItem; updatedStaged: StagedClinicalTask[] }> {
    const patientContext = stagedTask.patientName
      ? `[${stagedTask.patientName}${stagedTask.patientRut ? ` · RUT ${stagedTask.patientRut}` : ""}] `
      : "";
    const created = await this.createTask(taskListId || "@default", {
      title: `${patientContext}${stagedTask.title}`.trim(),
      notes: `[${stagedTask.protocolTag} · Prioridad ${stagedTask.priority}]\n${stagedTask.notes}`.trim(),
      dueDate: stagedTask.dueDate,
    });

    const updatedStaged = this.getStagedClinicalTasks().map((t) =>
      t.id === stagedTask.id ? { ...t, syncedGoogleTaskId: created.id } : t
    );
    this.saveStagedClinicalTasks(updatedStaged);
    return { googleTask: created, updatedStaged };
  }

  public static async syncAllPendingStagedTasksToGoogle(
    taskListId = "@default"
  ): Promise<{ syncedCount: number; updatedStaged: StagedClinicalTask[] }> {
    const current = this.getStagedClinicalTasks();
    const unsynced = current.filter(
      (t) => t.status === "needsAction" && !t.syncedGoogleTaskId
    );
    let syncedCount = 0;
    const syncedMap = new Map<string, string>();

    for (const item of unsynced) {
      const patientContext = item.patientName
        ? `[${item.patientName}${item.patientRut ? ` · RUT ${item.patientRut}` : ""}] `
        : "";
      const created = await this.createTask(taskListId, {
        title: `${patientContext}${item.title}`.trim(),
        notes: `[${item.protocolTag} · Prioridad ${item.priority}]\n${item.notes}`.trim(),
        dueDate: item.dueDate,
      });
      syncedMap.set(item.id, created.id);
      syncedCount++;
    }

    const updatedStaged = current.map((t) =>
      syncedMap.has(t.id) ? { ...t, syncedGoogleTaskId: syncedMap.get(t.id) } : t
    );
    this.saveStagedClinicalTasks(updatedStaged);
    return { syncedCount, updatedStaged };
  }
}

