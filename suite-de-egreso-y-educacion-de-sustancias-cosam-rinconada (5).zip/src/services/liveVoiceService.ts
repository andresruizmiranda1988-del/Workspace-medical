export interface VoiceTurnMessage {
  role: "user" | "model";
  text: string;
}

export class LiveVoiceClient {
  private ws: WebSocket | null = null;
  private inputAudioCtx: AudioContext | null = null;
  private outputAudioCtx: AudioContext | null = null;
  private mediaStream: MediaStream | null = null;
  private scriptProcessor: ScriptProcessorNode | null = null;
  private sourceNode: MediaStreamAudioSourceNode | null = null;
  private nextStartTime = 0;
  private isConnected = false;
  private isListening = false;
  private isHttpMode = false;
  private activeSourceNodes: AudioBufferSourceNode[] = [];

  // Buffer para captura de voz en modo HTTP / Turnos
  private pcmChunks: Int16Array[] = [];
  private isUserSpeaking = false;
  private silenceTimer: any = null;
  private isProcessingTurn = false;
  private conversationHistory: VoiceTurnMessage[] = [];

  public onStatusChange?: (status: "disconnected" | "connecting" | "connected" | "error", error?: string) => void;
  public onVolumeChange?: (vol: number) => void;
  public onAiSpeaking?: (speaking: boolean) => void;
  public onTranscript?: (userText: string, modelText: string) => void;
  public onModeChange?: (mode: "websocket" | "http") => void;

  constructor() {}

  public async connect(): Promise<void> {
    if (this.isConnected) return;
    this.onStatusChange?.("connecting");

    // 1. Inicializar audio input y output primero
    try {
      await this.initMicrophone();
      this.initAudioOutput();
    } catch (err: any) {
      console.warn("Microphone access error:", err);
      this.onStatusChange?.("error", "No se pudo acceder al micrófono. Por favor verifica los permisos del navegador.");
      this.disconnect();
      return;
    }

    // 2. Intentar canal WebSocket con degradación suave a HTTP Voice Engine
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const host = window.location.host;
    const wsUrl = `${protocol}//${host}/ws/live`;

    let wsEstablished = false;

    try {
      this.ws = new WebSocket(wsUrl);

      this.ws.onopen = () => {
        wsEstablished = true;
        this.isConnected = true;
        this.isHttpMode = false;
        this.onModeChange?.("websocket");
        this.onStatusChange?.("connected");
      };

      this.ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          if (data.type === "audio" && data.audio) {
            this.onAiSpeaking?.(true);
            this.playAudioChunk(data.audio);
          } else if (data.type === "interrupted") {
            this.stopAllAudio();
            this.onAiSpeaking?.(false);
          } else if (data.type === "turnComplete") {
            // Fin de turno del modelo en WebSocket
          } else if (data.type === "error") {
            console.warn("Live WebSocket warning:", data.error);
          }
        } catch (e) {
          console.warn("Error parsing WS message:", e);
        }
      };

      this.ws.onerror = () => {
        // En entornos iframed o con proxy inverso, WebSocket suele responder 302 o estar restringido.
        // Se conmuta a HTTP Voice Engine de manera silenciosa y resiliente sin romper la experiencia del usuario.
        if (!wsEstablished) {
          this.fallbackToHttpEngine();
        }
      };

      this.ws.onclose = () => {
        if (!wsEstablished) {
          this.fallbackToHttpEngine();
        } else {
          this.isConnected = false;
          this.onStatusChange?.("disconnected");
          this.cleanup();
        }
      };
    } catch (wsErr) {
      this.fallbackToHttpEngine();
    }

    // Timeout de seguridad: si en 1.5s WebSocket no conectó, usar motor HTTP
    setTimeout(() => {
      if (!this.isConnected && !this.isHttpMode) {
        this.fallbackToHttpEngine();
      }
    }, 1500);
  }

  private fallbackToHttpEngine() {
    if (this.isHttpMode && this.isConnected) return;
    this.isHttpMode = true;
    this.isConnected = true;
    if (this.ws) {
      try {
        this.ws.close();
      } catch (e) {}
      this.ws = null;
    }
    this.onModeChange?.("http");
    this.onStatusChange?.("connected");
  }

  private async initMicrophone() {
    this.inputAudioCtx = new (window.AudioContext || (window as any).webkitAudioContext)({
      sampleRate: 16000,
    });
    this.mediaStream = await navigator.mediaDevices.getUserMedia({
      audio: {
        channelCount: 1,
        sampleRate: 16000,
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true,
      },
    });
    this.sourceNode = this.inputAudioCtx.createMediaStreamSource(this.mediaStream);
    this.scriptProcessor = this.inputAudioCtx.createScriptProcessor(2048, 1, 1);
    this.sourceNode.connect(this.scriptProcessor);
    this.scriptProcessor.connect(this.inputAudioCtx.destination);

    this.scriptProcessor.onaudioprocess = (e) => {
      if (!this.isConnected) return;
      const inputData = e.inputBuffer.getChannelData(0);

      // Calcular volumen para feedback visual
      let sum = 0;
      for (let i = 0; i < inputData.length; i++) {
        sum += inputData[i] * inputData[i];
      }
      const rms = Math.sqrt(sum / inputData.length);
      this.onVolumeChange?.(Math.min(1, rms * 6));

      // Conversión Float32 a PCM 16-bit
      const pcm16 = new Int16Array(inputData.length);
      for (let i = 0; i < inputData.length; i++) {
        const s = Math.max(-1, Math.min(1, inputData[i]));
        pcm16[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
      }

      if (!this.isHttpMode && this.ws && this.ws.readyState === WebSocket.OPEN) {
        // En modo WebSocket directo, transmitir chunks de audio en tiempo real
        const bytes = new Uint8Array(pcm16.buffer);
        let binary = "";
        const len = bytes.byteLength;
        for (let i = 0; i < len; i++) {
          binary += String.fromCharCode(bytes[i]);
        }
        const base64Audio = btoa(binary);
        this.ws.send(JSON.stringify({ audio: base64Audio }));
      } else if (this.isHttpMode) {
        // En modo HTTP Voice Engine: Detección de actividad de voz (VAD) y buffering
        this.handleHttpAudioBuffer(pcm16, rms);
      }
    };

    this.isListening = true;
  }

  private handleHttpAudioBuffer(pcm16: Int16Array, rms: number) {
    if (this.isProcessingTurn) return;

    // Umbral de detección de habla
    const speechThreshold = 0.035;

    if (rms > speechThreshold) {
      if (!this.isUserSpeaking) {
        this.isUserSpeaking = true;
        this.pcmChunks = [];
      }
      this.pcmChunks.push(pcm16);

      // Reiniciar timer de silencio
      if (this.silenceTimer) {
        clearTimeout(this.silenceTimer);
        this.silenceTimer = null;
      }
    } else if (this.isUserSpeaking) {
      this.pcmChunks.push(pcm16);

      if (!this.silenceTimer) {
        // Si hay silencio continuo durante 1.4s, procesar el turno de voz
        this.silenceTimer = setTimeout(() => {
          this.commitVoiceTurn();
        }, 1400);
      }
    }
  }

  public async commitVoiceTurn(): Promise<void> {
    if (this.silenceTimer) {
      clearTimeout(this.silenceTimer);
      this.silenceTimer = null;
    }

    if (this.pcmChunks.length === 0 || this.isProcessingTurn) {
      this.isUserSpeaking = false;
      return;
    }

    this.isUserSpeaking = false;
    this.isProcessingTurn = true;
    this.onAiSpeaking?.(true);

    try {
      // Calcular tamaño total y concatenar todos los chunks PCM16
      let totalLen = 0;
      for (const chunk of this.pcmChunks) {
        totalLen += chunk.length;
      }
      const fullPcm = new Int16Array(totalLen);
      let offset = 0;
      for (const chunk of this.pcmChunks) {
        fullPcm.set(chunk, offset);
        offset += chunk.length;
      }
      this.pcmChunks = [];

      // Convertir PCM16 a WAV buffer en cliente para máxima fidelidad de transcripción
      const wavBuffer = this.encodeWAV(fullPcm, 16000);
      const bytes = new Uint8Array(wavBuffer);
      let binary = "";
      const len = bytes.byteLength;
      for (let i = 0; i < len; i++) {
        binary += String.fromCharCode(bytes[i]);
      }
      const base64Audio = btoa(binary);

      const res = await fetch("/api/ai/live-voice-turn", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          audioData: base64Audio,
          mimeType: "audio/wav",
          history: this.conversationHistory,
        }),
      });

      if (!res.ok) {
        throw new Error(`HTTP error ${res.status}`);
      }

      const data = await res.json();
      if (data.userText && data.modelText) {
        this.conversationHistory.push({ role: "user", text: data.userText });
        this.conversationHistory.push({ role: "model", text: data.modelText });
        this.onTranscript?.(data.userText, data.modelText);
      }

      if (data.audio) {
        this.playAudioChunk(data.audio);
      } else {
        this.onAiSpeaking?.(false);
      }
    } catch (error) {
      console.warn("Voice turn processing notice:", error);
      this.onAiSpeaking?.(false);
    } finally {
      this.isProcessingTurn = false;
    }
  }

  private encodeWAV(samples: Int16Array, sampleRate: number): ArrayBuffer {
    const buffer = new ArrayBuffer(44 + samples.length * 2);
    const view = new DataView(buffer);

    const writeString = (view: DataView, offset: number, string: string) => {
      for (let i = 0; i < string.length; i++) {
        view.setUint8(offset + i, string.charCodeAt(i));
      }
    };

    /* RIFF identifier */
    writeString(view, 0, "RIFF");
    /* file length */
    view.setUint32(4, 36 + samples.length * 2, true);
    /* RIFF type */
    writeString(view, 8, "WAVE");
    /* format chunk identifier */
    writeString(view, 12, "fmt ");
    /* format chunk length */
    view.setUint32(16, 16, true);
    /* sample format (raw) */
    view.setUint16(20, 1, true);
    /* channel count */
    view.setUint16(22, 1, true);
    /* sample rate */
    view.setUint32(24, sampleRate, true);
    /* byte rate (sample rate * block align) */
    view.setUint32(28, sampleRate * 2, true);
    /* block align (channel count * bytes per sample) */
    view.setUint16(32, 2, true);
    /* bits per sample */
    view.setUint16(34, 16, true);
    /* data chunk identifier */
    writeString(view, 36, "data");
    /* data chunk length */
    view.setUint32(40, samples.length * 2, true);

    // Escribir muestras PCM
    let offset = 44;
    for (let i = 0; i < samples.length; i++, offset += 2) {
      view.setInt16(offset, samples[i], true);
    }

    return buffer;
  }

  private initAudioOutput() {
    this.outputAudioCtx = new (window.AudioContext || (window as any).webkitAudioContext)({
      sampleRate: 24000,
    });
    this.nextStartTime = this.outputAudioCtx.currentTime;
  }

  public playAudioChunk(base64Audio: string) {
    if (!this.outputAudioCtx) return;
    if (this.outputAudioCtx.state === "suspended") {
      this.outputAudioCtx.resume();
    }
    try {
      const binary = atob(base64Audio);
      const len = binary.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binary.charCodeAt(i);
      }
      const pcm16 = new Int16Array(bytes.buffer);
      const float32 = new Float32Array(pcm16.length);
      for (let i = 0; i < pcm16.length; i++) {
        float32[i] = pcm16[i] / 32768.0;
      }

      const audioBuffer = this.outputAudioCtx.createBuffer(1, float32.length, 24000);
      audioBuffer.copyToChannel(float32, 0);

      const source = this.outputAudioCtx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(this.outputAudioCtx.destination);

      const currentTime = this.outputAudioCtx.currentTime;
      const startTime = Math.max(currentTime, this.nextStartTime);
      source.start(startTime);
      this.nextStartTime = startTime + audioBuffer.duration;

      this.activeSourceNodes.push(source);
      source.onended = () => {
        const idx = this.activeSourceNodes.indexOf(source);
        if (idx > -1) this.activeSourceNodes.splice(idx, 1);
        if (this.activeSourceNodes.length === 0) {
          this.onAiSpeaking?.(false);
        }
      };
    } catch (err) {
      console.warn("Error playing audio:", err);
      this.onAiSpeaking?.(false);
    }
  }

  public async sendTextMessage(text: string): Promise<void> {
    if (!text.trim()) return;

    if (!this.isHttpMode && this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ text }));
      return;
    }

    // Modo HTTP Voice
    this.isProcessingTurn = true;
    this.onAiSpeaking?.(true);

    try {
      const res = await fetch("/api/ai/live-voice-turn", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text,
          history: this.conversationHistory,
        }),
      });

      if (!res.ok) throw new Error(`HTTP error ${res.status}`);
      const data = await res.json();

      if (data.userText && data.modelText) {
        this.conversationHistory.push({ role: "user", text: data.userText });
        this.conversationHistory.push({ role: "model", text: data.modelText });
        this.onTranscript?.(data.userText, data.modelText);
      }

      if (data.audio) {
        this.playAudioChunk(data.audio);
      } else {
        this.onAiSpeaking?.(false);
      }
    } catch (e) {
      console.warn("Text message voice turn error:", e);
      this.onAiSpeaking?.(false);
    } finally {
      this.isProcessingTurn = false;
    }
  }

  private stopAllAudio() {
    this.activeSourceNodes.forEach((s) => {
      try {
        s.stop();
      } catch (e) {}
    });
    this.activeSourceNodes = [];
    if (this.outputAudioCtx) {
      this.nextStartTime = this.outputAudioCtx.currentTime;
    }
  }

  public disconnect() {
    this.cleanup();
    if (this.ws) {
      try {
        this.ws.close();
      } catch (e) {}
      this.ws = null;
    }
    this.isConnected = false;
    this.onStatusChange?.("disconnected");
  }

  private cleanup() {
    this.stopAllAudio();
    if (this.silenceTimer) {
      clearTimeout(this.silenceTimer);
      this.silenceTimer = null;
    }
    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach((t) => t.stop());
      this.mediaStream = null;
    }
    if (this.sourceNode) {
      this.sourceNode.disconnect();
      this.sourceNode = null;
    }
    if (this.scriptProcessor) {
      this.scriptProcessor.disconnect();
      this.scriptProcessor = null;
    }
    if (this.inputAudioCtx) {
      this.inputAudioCtx.close().catch(() => {});
      this.inputAudioCtx = null;
    }
    if (this.outputAudioCtx) {
      this.outputAudioCtx.close().catch(() => {});
      this.outputAudioCtx = null;
    }
    this.isListening = false;
  }
}
