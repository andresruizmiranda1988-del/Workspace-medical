import { GoogleDriveService, DEFAULT_SLIDES_FOLDER } from "./googleDriveService";

export interface SlideSectionInput {
  title: string;
  subtitle?: string;
  body: string;
  badge?: string;
}

export interface SlidesPresentationSummary {
  id: string;
  name: string;
  webViewLink: string;
  createdTime?: string;
  modifiedTime?: string;
}

export interface ParsedSlideInfo {
  objectId: string;
  index: number;
  title: string;
  bodyText: string;
}

export interface SlidesPresentationDetail {
  presentationId: string;
  title: string;
  slides: ParsedSlideInfo[];
  webViewLink: string;
  embedLink: string;
}

export class GoogleSlidesService {
  private static async getValidToken(): Promise<string> {
    const existing = GoogleDriveService.getStoredToken();
    if (existing) return existing;
    return await GoogleDriveService.requestAuth();
  }

  /**
   * Lists Google Slides presentations from the user's Google Drive.
   */
  public static async listPresentations(pageSize = 24): Promise<SlidesPresentationSummary[]> {
    const token = GoogleDriveService.getStoredToken();
    if (!token) return [];

    const query = encodeURIComponent(
      "mimeType='application/vnd.google-apps.presentation' and trashed=false"
    );
    const url = `https://www.googleapis.com/drive/v3/files?q=${query}&fields=files(id,name,webViewLink,createdTime,modifiedTime)&orderBy=modifiedTime desc&pageSize=${pageSize}`;

    const res = await fetch(url, {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (!res.ok) {
      if (res.status === 401) {
        GoogleDriveService.clearToken();
        throw new Error("La sesión de Google ha expirado. Vuelva a conectar su cuenta.");
      }
      throw new Error("No se pudieron listar las presentaciones de Google Slides.");
    }

    const data = await res.json();
    return (data.files || []).map((f: any) => ({
      id: f.id,
      name: f.name,
      webViewLink: f.webViewLink || `https://docs.google.com/presentation/d/${f.id}/edit`,
      createdTime: f.createdTime,
      modifiedTime: f.modifiedTime,
    }));
  }

  /**
   * Fetches full presentation details from Google Slides API v1 and extracts readable text from each slide.
   */
  public static async getPresentation(presentationId: string): Promise<SlidesPresentationDetail> {
    const token = await this.getValidToken();
    const res = await fetch(`https://slides.googleapis.com/v1/presentations/${presentationId}`, {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (!res.ok) {
      if (res.status === 401) {
        GoogleDriveService.clearToken();
        throw new Error("Sesión expirada. Reconecte su cuenta de Google.");
      }
      const errData = await res.json().catch(() => ({}));
      throw new Error(
        errData.error?.message || "No se pudo obtener la presentación desde Google Slides."
      );
    }

    const data = await res.json();
    const rawSlides: any[] = data.slides || [];

    const parsedSlides: ParsedSlideInfo[] = rawSlides.map((slide, idx) => {
      const texts: string[] = [];
      for (const el of slide.pageElements || []) {
        const textElements = el.shape?.text?.textElements || [];
        let shapeText = "";
        for (const te of textElements) {
          if (te.textRun?.content) {
            shapeText += te.textRun.content;
          }
        }
        const cleaned = shapeText.trim();
        if (cleaned) {
          texts.push(cleaned);
        }
      }

      const title = texts[0] || `Diapositiva ${idx + 1}`;
      const bodyText = texts.slice(1).join("\n\n");

      return {
        objectId: slide.objectId,
        index: idx + 1,
        title,
        bodyText,
      };
    });

    return {
      presentationId: data.presentationId,
      title: data.title || "Presentación sin título",
      slides: parsedSlides,
      webViewLink: `https://docs.google.com/presentation/d/${data.presentationId}/edit`,
      embedLink: `https://docs.google.com/presentation/d/${data.presentationId}/embed?start=false&loop=false&delayms=5000`,
    };
  }

  /**
   * Creates a clinical presentation in Google Slides and populates it with formatted slides via batchUpdate.
   */
  public static async createClinicalPresentation({
    title,
    subtitle,
    slides,
    organizeInCosamFolder = true,
  }: {
    title: string;
    subtitle?: string;
    slides: SlideSectionInput[];
    organizeInCosamFolder?: boolean;
  }): Promise<SlidesPresentationDetail> {
    const token = await this.getValidToken();

    // 1. Create presentation via Google Slides API
    const createRes = await fetch("https://slides.googleapis.com/v1/presentations", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ title }),
    });

    if (!createRes.ok) {
      if (createRes.status === 401) {
        GoogleDriveService.clearToken();
        throw new Error("Sesión expirada. Reconecte su cuenta de Google.");
      }
      const err = await createRes.json().catch(() => ({}));
      throw new Error(
        err.error?.message ||
          "Error al crear la presentación en Google Slides. Verifique los permisos OAuth."
      );
    }

    const createdPresentation = await createRes.json();
    const presentationId: string = createdPresentation.presentationId;
    const defaultSlideId: string | undefined = createdPresentation.slides?.[0]?.objectId;

    // 2. Build batchUpdate requests for cover slide + content slides
    const requests: any[] = [];
    const uid = () => Math.random().toString(36).substring(2, 9);

    // Create Cover Slide (BLANK layout with custom institutional styling)
    const coverSlideId = `cover_${uid()}`;
    const coverBadgeId = `cover_badge_${uid()}`;
    const coverTitleId = `cover_title_${uid()}`;
    const coverSubId = `cover_sub_${uid()}`;

    requests.push({
      createSlide: {
        objectId: coverSlideId,
        insertionIndex: 0,
        slideLayoutReference: { predefinedLayout: "BLANK" },
      },
    });

    // Cover institutional tag
    requests.push(
      {
        createShape: {
          objectId: coverBadgeId,
          shapeType: "TEXT_BOX",
          elementProperties: {
            pageObjectId: coverSlideId,
            size: {
              width: { magnitude: 620, unit: "PT" },
              height: { magnitude: 32, unit: "PT" },
            },
            transform: {
              scaleX: 1,
              scaleY: 1,
              translateX: 50,
              translateY: 65,
              unit: "PT",
            },
          },
        },
      },
      {
        insertText: {
          objectId: coverBadgeId,
          insertionIndex: 0,
          text: "COSAM RINCONADA · SAN RAMÓN · SALUD MENTAL COMUNITARIA",
        },
      },
      {
        updateTextStyle: {
          objectId: coverBadgeId,
          style: {
            bold: true,
            fontSize: { magnitude: 10, unit: "PT" },
            foregroundColor: {
              opaqueColor: { rgbColor: { red: 0.22, green: 0.35, blue: 0.75 } },
            },
          },
          fields: "bold,fontSize,foregroundColor",
        },
      }
    );

    // Cover Main Title
    requests.push(
      {
        createShape: {
          objectId: coverTitleId,
          shapeType: "TEXT_BOX",
          elementProperties: {
            pageObjectId: coverSlideId,
            size: {
              width: { magnitude: 620, unit: "PT" },
              height: { magnitude: 130, unit: "PT" },
            },
            transform: {
              scaleX: 1,
              scaleY: 1,
              translateX: 50,
              translateY: 110,
              unit: "PT",
            },
          },
        },
      },
      {
        insertText: {
          objectId: coverTitleId,
          insertionIndex: 0,
          text: title,
        },
      },
      {
        updateTextStyle: {
          objectId: coverTitleId,
          style: {
            bold: true,
            fontSize: { magnitude: 28, unit: "PT" },
            foregroundColor: {
              opaqueColor: { rgbColor: { red: 0.08, green: 0.11, blue: 0.18 } },
            },
          },
          fields: "bold,fontSize,foregroundColor",
        },
      }
    );

    // Cover Subtitle
    const coverSubtitleText =
      subtitle ||
      `Generado desde Ecosistema Clínico COSAM · ${new Date().toLocaleDateString("es-CL")}`;
    requests.push(
      {
        createShape: {
          objectId: coverSubId,
          shapeType: "TEXT_BOX",
          elementProperties: {
            pageObjectId: coverSlideId,
            size: {
              width: { magnitude: 620, unit: "PT" },
              height: { magnitude: 90, unit: "PT" },
            },
            transform: {
              scaleX: 1,
              scaleY: 1,
              translateX: 50,
              translateY: 250,
              unit: "PT",
            },
          },
        },
      },
      {
        insertText: {
          objectId: coverSubId,
          insertionIndex: 0,
          text: coverSubtitleText,
        },
      },
      {
        updateTextStyle: {
          objectId: coverSubId,
          style: {
            fontSize: { magnitude: 14, unit: "PT" },
            foregroundColor: {
              opaqueColor: { rgbColor: { red: 0.35, green: 0.4, blue: 0.48 } },
            },
          },
          fields: "fontSize,foregroundColor",
        },
      }
    );

    // Content Slides
    slides.forEach((slide, idx) => {
      const sId = `slide_${idx}_${uid()}`;
      const headerId = `hdr_${idx}_${uid()}`;
      const bodyId = `bdy_${idx}_${uid()}`;

      requests.push({
        createSlide: {
          objectId: sId,
          insertionIndex: idx + 1,
          slideLayoutReference: { predefinedLayout: "BLANK" },
        },
      });

      const slideHeaderText = slide.badge
        ? `[${slide.badge.toUpperCase()}]  ${slide.title}`
        : slide.title;

      requests.push(
        {
          createShape: {
            objectId: headerId,
            shapeType: "TEXT_BOX",
            elementProperties: {
              pageObjectId: sId,
              size: {
                width: { magnitude: 640, unit: "PT" },
                height: { magnitude: 55, unit: "PT" },
              },
              transform: {
                scaleX: 1,
                scaleY: 1,
                translateX: 40,
                translateY: 30,
                unit: "PT",
              },
            },
          },
        },
        {
          insertText: {
            objectId: headerId,
            insertionIndex: 0,
            text: slideHeaderText,
          },
        },
        {
          updateTextStyle: {
            objectId: headerId,
            style: {
              bold: true,
              fontSize: { magnitude: 20, unit: "PT" },
              foregroundColor: {
                opaqueColor: { rgbColor: { red: 0.1, green: 0.15, blue: 0.28 } },
              },
            },
            fields: "bold,fontSize,foregroundColor",
          },
        }
      );

      const cleanBody = (slide.body || "Sin contenido especificado.").slice(0, 2600);
      requests.push(
        {
          createShape: {
            objectId: bodyId,
            shapeType: "TEXT_BOX",
            elementProperties: {
              pageObjectId: sId,
              size: {
                width: { magnitude: 640, unit: "PT" },
                height: { magnitude: 295, unit: "PT" },
              },
              transform: {
                scaleX: 1,
                scaleY: 1,
                translateX: 40,
                translateY: 92,
                unit: "PT",
              },
            },
          },
        },
        {
          insertText: {
            objectId: bodyId,
            insertionIndex: 0,
            text: cleanBody,
          },
        },
        {
          updateTextStyle: {
            objectId: bodyId,
            style: {
              fontSize: { magnitude: 13, unit: "PT" },
              foregroundColor: {
                opaqueColor: { rgbColor: { red: 0.18, green: 0.22, blue: 0.28 } },
              },
            },
            fields: "fontSize,foregroundColor",
          },
        }
      );
    });

    // Remove the initial blank default slide if we created our own slides
    if (defaultSlideId) {
      requests.push({
        deleteObject: {
          objectId: defaultSlideId,
        },
      });
    }

    if (requests.length > 0) {
      const batchRes = await fetch(
        `https://slides.googleapis.com/v1/presentations/${presentationId}:batchUpdate`,
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ requests }),
        }
      );

      if (!batchRes.ok) {
        const err = await batchRes.json().catch(() => ({}));
        console.warn("BatchUpdate warning:", err);
      }
    }

    // Optionally place presentation inside the COSAM Presentations folder in Drive
    if (organizeInCosamFolder) {
      try {
        const folderId = await GoogleDriveService.getOrCreateFolder(DEFAULT_SLIDES_FOLDER);
        await fetch(
          `https://www.googleapis.com/drive/v3/files/${presentationId}?addParents=${folderId}&fields=id,parents`,
          {
            method: "PATCH",
            headers: { Authorization: `Bearer ${token}` },
          }
        );
      } catch (e) {
        console.warn("Could not move presentation to COSAM folder:", e);
      }
    }

    return await this.getPresentation(presentationId);
  }

  /**
   * Appends a single new slide to an existing Google Slides presentation.
   */
  public static async appendSlideToPresentation(
    presentationId: string,
    slide: SlideSectionInput
  ): Promise<SlidesPresentationDetail> {
    const token = await this.getValidToken();
    const uid = Math.random().toString(36).substring(2, 9);
    const sId = `slide_add_${uid}`;
    const headerId = `hdr_add_${uid}`;
    const bodyId = `bdy_add_${uid}`;

    const requests: any[] = [
      {
        createSlide: {
          objectId: sId,
          slideLayoutReference: { predefinedLayout: "BLANK" },
        },
      },
      {
        createShape: {
          objectId: headerId,
          shapeType: "TEXT_BOX",
          elementProperties: {
            pageObjectId: sId,
            size: {
              width: { magnitude: 640, unit: "PT" },
              height: { magnitude: 55, unit: "PT" },
            },
            transform: {
              scaleX: 1,
              scaleY: 1,
              translateX: 40,
              translateY: 30,
              unit: "PT",
            },
          },
        },
      },
      {
        insertText: {
          objectId: headerId,
          insertionIndex: 0,
          text: slide.badge ? `[${slide.badge.toUpperCase()}]  ${slide.title}` : slide.title,
        },
      },
      {
        updateTextStyle: {
          objectId: headerId,
          style: {
            bold: true,
            fontSize: { magnitude: 20, unit: "PT" },
            foregroundColor: {
              opaqueColor: { rgbColor: { red: 0.1, green: 0.15, blue: 0.28 } },
            },
          },
          fields: "bold,fontSize,foregroundColor",
        },
      },
      {
        createShape: {
          objectId: bodyId,
          shapeType: "TEXT_BOX",
          elementProperties: {
            pageObjectId: sId,
            size: {
              width: { magnitude: 640, unit: "PT" },
              height: { magnitude: 295, unit: "PT" },
            },
            transform: {
              scaleX: 1,
              scaleY: 1,
              translateX: 40,
              translateY: 92,
              unit: "PT",
            },
          },
        },
      },
      {
        insertText: {
          objectId: bodyId,
          insertionIndex: 0,
          text: (slide.body || "Sin contenido.").slice(0, 2600),
        },
      },
      {
        updateTextStyle: {
          objectId: bodyId,
          style: {
            fontSize: { magnitude: 13, unit: "PT" },
            foregroundColor: {
              opaqueColor: { rgbColor: { red: 0.18, green: 0.22, blue: 0.28 } },
            },
          },
          fields: "fontSize,foregroundColor",
        },
      },
    ];

    const res = await fetch(
      `https://slides.googleapis.com/v1/presentations/${presentationId}:batchUpdate`,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ requests }),
      }
    );

    if (!res.ok) {
      if (res.status === 401) {
        GoogleDriveService.clearToken();
        throw new Error("Sesión expirada. Reconecte su cuenta de Google.");
      }
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error?.message || "No se pudo agregar la diapositiva.");
    }

    return await this.getPresentation(presentationId);
  }
}
