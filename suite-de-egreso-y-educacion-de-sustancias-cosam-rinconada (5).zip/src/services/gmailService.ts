import { GoogleDriveService } from "./googleDriveService";

export interface GmailMessageSummary {
  id: string;
  threadId: string;
  subject: string;
  from: string;
  to: string;
  date: string;
  snippet: string;
  bodyText: string;
  labelIds: string[];
  isUnread: boolean;
}

export interface GmailProfileInfo {
  emailAddress: string;
  messagesTotal: number;
  threadsTotal: number;
}

export class GmailService {
  private static async getValidToken(): Promise<string> {
    let token = GoogleDriveService.getStoredToken();
    if (!token) {
      token = await GoogleDriveService.requestAuth();
    }
    return token;
  }

  private static encodeBase64Url(str: string): string {
    const utf8Bytes = new TextEncoder().encode(str);
    let binary = "";
    for (let i = 0; i < utf8Bytes.length; i++) {
      binary += String.fromCharCode(utf8Bytes[i]);
    }
    return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  }

  private static decodeBase64Url(base64Url: string): string {
    try {
      const base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/");
      const padded = base64 + "===".slice((base64.length + 3) % 4);
      const binary = atob(padded);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) {
        bytes[i] = binary.charCodeAt(i);
      }
      return new TextDecoder("utf-8").decode(bytes);
    } catch {
      return "";
    }
  }

  private static encodeMimeHeader(text: string): string {
    // Check if ASCII only
    if (/^[\x00-\x7F]*$/.test(text)) {
      return text;
    }
    const utf8Bytes = new TextEncoder().encode(text);
    let binary = "";
    for (let i = 0; i < utf8Bytes.length; i++) {
      binary += String.fromCharCode(utf8Bytes[i]);
    }
    return `=?UTF-8?B?${btoa(binary)}?=`;
  }

  private static extractBodyFromPayload(payload: any): string {
    if (!payload) return "";

    if (payload.mimeType === "text/plain" && payload.body?.data) {
      return this.decodeBase64Url(payload.body.data);
    }

    if (payload.parts && Array.isArray(payload.parts)) {
      // Prefer text/plain first
      for (const part of payload.parts) {
        if (part.mimeType === "text/plain" && part.body?.data) {
          return this.decodeBase64Url(part.body.data);
        }
      }
      // Fallback to nested parts or text/html stripped
      for (const part of payload.parts) {
        const nested = this.extractBodyFromPayload(part);
        if (nested) return nested;
      }
      for (const part of payload.parts) {
        if (part.mimeType === "text/html" && part.body?.data) {
          const html = this.decodeBase64Url(part.body.data);
          return html.replace(/<style[^>]*>[\s\S]*?<\/style>/gi, "")
            .replace(/<[^>]+>/g, " ")
            .replace(/\s+/g, " ")
            .trim();
        }
      }
    }

    if (payload.body?.data) {
      return this.decodeBase64Url(payload.body.data);
    }

    return "";
  }

  public static async getProfile(): Promise<GmailProfileInfo | null> {
    const token = GoogleDriveService.getStoredToken();
    if (!token) return null;

    const res = await fetch("https://gmail.googleapis.com/gmail/v1/users/me/profile", {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (!res.ok) {
      if (res.status === 401) {
        GoogleDriveService.clearToken();
      }
      return null;
    }

    const data = await res.json();
    return {
      emailAddress: data.emailAddress || "",
      messagesTotal: data.messagesTotal || 0,
      threadsTotal: data.threadsTotal || 0,
    };
  }

  /**
   * Lista mensajes de Gmail filtrados por búsqueda opcional
   */
  public static async listMessages(query = "", maxResults = 15): Promise<GmailMessageSummary[]> {
    const token = GoogleDriveService.getStoredToken();
    if (!token) return [];

    const qParam = query.trim() ? `&q=${encodeURIComponent(query.trim())}` : "";
    const listUrl = `https://gmail.googleapis.com/gmail/v1/users/me/messages?maxResults=${maxResults}${qParam}`;

    const listRes = await fetch(listUrl, {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (!listRes.ok) {
      if (listRes.status === 401) {
        GoogleDriveService.clearToken();
        throw new Error("La sesión de Google ha expirado. Vuelva a conectar su cuenta.");
      }
      const err = await listRes.json().catch(() => ({}));
      throw new Error(err.error?.message || "No se pudieron obtener los correos de Gmail.");
    }

    const listData = await listRes.json();
    const messageRefs: { id: string; threadId: string }[] = listData.messages || [];

    if (messageRefs.length === 0) return [];

    const detailedPromises = messageRefs.slice(0, maxResults).map(async (ref) => {
      try {
        const msgRes = await fetch(
          `https://gmail.googleapis.com/gmail/v1/users/me/messages/${ref.id}?format=full`,
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );
        if (!msgRes.ok) return null;
        const msg = await msgRes.json();
        const headers: { name: string; value: string }[] = msg.payload?.headers || [];
        const getHeader = (name: string) =>
          headers.find((h) => h.name.toLowerCase() === name.toLowerCase())?.value || "";

        const bodyText = this.extractBodyFromPayload(msg.payload) || msg.snippet || "";
        const labelIds: string[] = msg.labelIds || [];

        return {
          id: msg.id,
          threadId: msg.threadId,
          subject: getHeader("Subject") || "(Sin asunto)",
          from: getHeader("From") || "Desconocido",
          to: getHeader("To") || "",
          date: getHeader("Date") || "",
          snippet: msg.snippet || "",
          bodyText,
          labelIds,
          isUnread: labelIds.includes("UNREAD"),
        } as GmailMessageSummary;
      } catch {
        return null;
      }
    });

    const results = await Promise.all(detailedPromises);
    return results.filter((m): m is GmailMessageSummary => m !== null);
  }

  /**
   * Envía un correo electrónico desde la cuenta del usuario
   */
  public static async sendEmail({
    to,
    cc,
    subject,
    body,
  }: {
    to: string;
    cc?: string;
    subject: string;
    body: string;
  }): Promise<{ id: string; threadId: string }> {
    const token = await this.getValidToken();

    const headers = [
      `To: ${to.trim()}`,
      ...(cc && cc.trim() ? [`Cc: ${cc.trim()}`] : []),
      `Subject: ${this.encodeMimeHeader(subject.trim())}`,
      "MIME-Version: 1.0",
      'Content-Type: text/plain; charset="UTF-8"',
      "Content-Transfer-Encoding: 8bit",
    ];

    const rawMime = `${headers.join("\r\n")}\r\n\r\n${body}`;
    const rawEncoded = this.encodeBase64Url(rawMime);

    const res = await fetch("https://gmail.googleapis.com/gmail/v1/users/me/messages/send", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ raw: rawEncoded }),
    });

    if (!res.ok) {
      if (res.status === 401) {
        GoogleDriveService.clearToken();
        throw new Error("Sesión expirada. Reconecte su cuenta de Google.");
      }
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error?.message || "No se pudo enviar el correo mediante Gmail.");
    }

    return await res.json();
  }

  /**
   * Guarda un borrador en la cuenta de Gmail del usuario
   */
  public static async createDraft({
    to,
    cc,
    subject,
    body,
  }: {
    to: string;
    cc?: string;
    subject: string;
    body: string;
  }): Promise<{ id: string }> {
    const token = await this.getValidToken();

    const headers = [
      ...(to.trim() ? [`To: ${to.trim()}`] : []),
      ...(cc && cc.trim() ? [`Cc: ${cc.trim()}`] : []),
      `Subject: ${this.encodeMimeHeader(subject.trim() || "Borrador Clínico COSAM")}`,
      "MIME-Version: 1.0",
      'Content-Type: text/plain; charset="UTF-8"',
    ];

    const rawMime = `${headers.join("\r\n")}\r\n\r\n${body}`;
    const rawEncoded = this.encodeBase64Url(rawMime);

    const res = await fetch("https://gmail.googleapis.com/gmail/v1/users/me/drafts", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        message: { raw: rawEncoded },
      }),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error?.message || "No se pudo guardar el borrador en Gmail.");
    }

    return await res.json();
  }

  /**
   * Envía un mensaje a la papelera de Gmail
   */
  public static async trashMessage(messageId: string): Promise<void> {
    const token = await this.getValidToken();
    const res = await fetch(
      `https://gmail.googleapis.com/gmail/v1/users/me/messages/${messageId}/trash`,
      {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
      }
    );

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error?.message || "No se pudo mover el correo a la papelera.");
    }
  }
}
