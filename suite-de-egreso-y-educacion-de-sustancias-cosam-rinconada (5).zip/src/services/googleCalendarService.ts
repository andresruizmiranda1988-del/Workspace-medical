import { GoogleDriveService } from "./googleDriveService";

export interface CalendarListItem {
  id: string;
  summary: string;
  description?: string;
  primary?: boolean;
  backgroundColor?: string;
  accessRole?: string;
  timeZone?: string;
}

export interface CalendarEventAttendee {
  email: string;
  displayName?: string;
  responseStatus?: string;
}

export interface CalendarEventItem {
  id: string;
  summary: string;
  description?: string;
  location?: string;
  htmlLink?: string;
  status?: string;
  start: {
    dateTime?: string;
    date?: string;
    timeZone?: string;
  };
  end: {
    dateTime?: string;
    date?: string;
    timeZone?: string;
  };
  attendees?: CalendarEventAttendee[];
  organizer?: {
    email?: string;
    displayName?: string;
  };
}

export interface CreateCalendarEventInput {
  calendarId?: string;
  summary: string;
  description?: string;
  location?: string;
  startDateTime: string; // ISO string
  endDateTime: string; // ISO string
  attendeeEmails?: string[];
  timeZone?: string;
}

export interface UpdateCalendarEventInput {
  calendarId?: string;
  eventId: string;
  summary?: string;
  description?: string;
  location?: string;
  startDateTime?: string;
  endDateTime?: string;
  attendeeEmails?: string[];
}

export interface BusySlot {
  start: string;
  end: string;
}

export class GoogleCalendarService {
  private static async getValidToken(): Promise<string> {
    const existing = GoogleDriveService.getStoredToken();
    if (existing) return existing;
    return await GoogleDriveService.requestAuth();
  }

  /**
   * Lists the user's subscribed and primary Google Calendars.
   */
  public static async listCalendars(): Promise<CalendarListItem[]> {
    let token = await this.getValidToken();
    const url = "https://www.googleapis.com/calendar/v3/users/me/calendarList?minAccessRole=reader";

    let res = await fetch(url, {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (res.status === 401 || res.status === 403) {
      GoogleDriveService.disconnect();
      token = await GoogleDriveService.requestAuth();
      res = await fetch(url, {
        headers: { Authorization: `Bearer ${token}` },
      });
    }

    if (!res.ok) {
      const errText = await res.text();
      throw new Error(`Error al listar calendarios (${res.status}): ${errText}`);
    }

    const data = await res.json();
    return (data.items || []).map((item: any) => ({
      id: item.id,
      summary: item.summaryOverride || item.summary || "Calendario",
      description: item.description,
      primary: !!item.primary,
      backgroundColor: item.backgroundColor || "#2563eb",
      accessRole: item.accessRole,
      timeZone: item.timeZone,
    }));
  }

  /**
   * Creates a secondary clinical calendar in Google Calendar (e.g., "COSAM Rinconada - Box Médico").
   */
  public static async createSecondaryCalendar(
    summary: string,
    description = "Agenda clínica de controles psiquiátricos, ingresos PAI y comités multiprofesionales — COSAM Rinconada"
  ): Promise<CalendarListItem> {
    let token = await this.getValidToken();
    const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone || "America/Santiago";

    const res = await fetch("https://www.googleapis.com/calendar/v3/calendars", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        summary: summary.trim(),
        description,
        timeZone,
      }),
    });

    if (!res.ok) {
      const errText = await res.text();
      throw new Error(`Error al crear calendario secundario (${res.status}): ${errText}`);
    }

    const data = await res.json();
    return {
      id: data.id,
      summary: data.summary,
      description: data.description,
      primary: false,
      timeZone: data.timeZone,
    };
  }

  /**
   * Lists events from the specified Google Calendar.
   */
  public static async listEvents(options?: {
    calendarId?: string;
    timeMin?: string;
    timeMax?: string;
    query?: string;
    maxResults?: number;
  }): Promise<CalendarEventItem[]> {
    let token = await this.getValidToken();
    const calendarId = encodeURIComponent(options?.calendarId || "primary");
    const params = new URLSearchParams({
      singleEvents: "true",
      orderBy: "startTime",
      maxResults: String(options?.maxResults || 30),
    });

    if (options?.timeMin) {
      params.set("timeMin", options.timeMin);
    } else {
      const startOfToday = new Date();
      startOfToday.setHours(0, 0, 0, 0);
      params.set("timeMin", startOfToday.toISOString());
    }

    if (options?.timeMax) {
      params.set("timeMax", options.timeMax);
    }

    if (options?.query && options.query.trim()) {
      params.set("q", options.query.trim());
    }

    const url = `https://www.googleapis.com/calendar/v3/calendars/${calendarId}/events?${params.toString()}`;

    let res = await fetch(url, {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (res.status === 401 || res.status === 403) {
      GoogleDriveService.disconnect();
      token = await GoogleDriveService.requestAuth();
      res = await fetch(url, {
        headers: { Authorization: `Bearer ${token}` },
      });
    }

    if (!res.ok) {
      const errText = await res.text();
      throw new Error(`Error al consultar eventos de Google Calendar (${res.status}): ${errText}`);
    }

    const data = await res.json();
    return (data.items || []).map((item: any) => ({
      id: item.id,
      summary: item.summary || "(Sin título)",
      description: item.description || "",
      location: item.location || "",
      htmlLink: item.htmlLink,
      status: item.status,
      start: item.start || {},
      end: item.end || {},
      attendees: item.attendees || [],
      organizer: item.organizer,
    }));
  }

  /**
   * Queries Free/Busy availability for a specific date window.
   */
  public static async getFreeBusy(
    calendarId = "primary",
    timeMin: string,
    timeMax: string
  ): Promise<BusySlot[]> {
    const token = await this.getValidToken();
    const res = await fetch("https://www.googleapis.com/calendar/v3/freeBusy", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        timeMin,
        timeMax,
        items: [{ id: calendarId }],
      }),
    });

    if (!res.ok) {
      const errText = await res.text();
      throw new Error(`Error al verificar disponibilidad FreeBusy (${res.status}): ${errText}`);
    }

    const data = await res.json();
    const calBusy = data?.calendars?.[calendarId]?.busy || [];
    return calBusy.map((b: any) => ({
      start: b.start,
      end: b.end,
    }));
  }

  /**
   * Creates a new clinical appointment or meeting event in Google Calendar.
   */
  public static async createEvent(input: CreateCalendarEventInput): Promise<CalendarEventItem> {
    let token = await this.getValidToken();
    const calendarId = encodeURIComponent(input.calendarId || "primary");
    const timeZone =
      input.timeZone || Intl.DateTimeFormat().resolvedOptions().timeZone || "America/Santiago";

    const attendees = (input.attendeeEmails || [])
      .map((e) => e.trim())
      .filter((e) => e.includes("@"))
      .map((email) => ({ email }));

    const payload: Record<string, any> = {
      summary: input.summary.trim(),
      description: input.description || "",
      location: input.location || "COSAM Rinconada — Box Médico",
      start: {
        dateTime: input.startDateTime,
        timeZone,
      },
      end: {
        dateTime: input.endDateTime,
        timeZone,
      },
    };

    if (attendees.length > 0) {
      payload.attendees = attendees;
    }

    let res = await fetch(
      `https://www.googleapis.com/calendar/v3/calendars/${calendarId}/events`,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      }
    );

    if (res.status === 401 || res.status === 403) {
      GoogleDriveService.disconnect();
      token = await GoogleDriveService.requestAuth();
      res = await fetch(
        `https://www.googleapis.com/calendar/v3/calendars/${calendarId}/events`,
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify(payload),
        }
      );
    }

    if (!res.ok) {
      const errText = await res.text();
      throw new Error(`Error al agendar evento en Google Calendar (${res.status}): ${errText}`);
    }

    return await res.json();
  }

  /**
   * Updates an existing event in Google Calendar.
   */
  public static async updateEvent(input: UpdateCalendarEventInput): Promise<CalendarEventItem> {
    const token = await this.getValidToken();
    const calendarId = encodeURIComponent(input.calendarId || "primary");
    const eventId = encodeURIComponent(input.eventId);
    const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone || "America/Santiago";

    const patchBody: Record<string, any> = {};
    if (input.summary !== undefined) patchBody.summary = input.summary.trim();
    if (input.description !== undefined) patchBody.description = input.description;
    if (input.location !== undefined) patchBody.location = input.location;
    if (input.startDateTime) {
      patchBody.start = { dateTime: input.startDateTime, timeZone };
    }
    if (input.endDateTime) {
      patchBody.end = { dateTime: input.endDateTime, timeZone };
    }
    if (input.attendeeEmails) {
      patchBody.attendees = input.attendeeEmails
        .map((e) => e.trim())
        .filter((e) => e.includes("@"))
        .map((email) => ({ email }));
    }

    const res = await fetch(
      `https://www.googleapis.com/calendar/v3/calendars/${calendarId}/events/${eventId}`,
      {
        method: "PATCH",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify(patchBody),
      }
    );

    if (!res.ok) {
      const errText = await res.text();
      throw new Error(`Error al actualizar evento en Google Calendar (${res.status}): ${errText}`);
    }

    return await res.json();
  }

  /**
   * Deletes an event from Google Calendar.
   */
  public static async deleteEvent(calendarId = "primary", eventId: string): Promise<void> {
    const token = await this.getValidToken();
    const calId = encodeURIComponent(calendarId);
    const evId = encodeURIComponent(eventId);

    const res = await fetch(
      `https://www.googleapis.com/calendar/v3/calendars/${calId}/events/${evId}`,
      {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (!res.ok && res.status !== 204) {
      const errText = await res.text();
      throw new Error(`Error al eliminar evento de Google Calendar (${res.status}): ${errText}`);
    }
  }
}
