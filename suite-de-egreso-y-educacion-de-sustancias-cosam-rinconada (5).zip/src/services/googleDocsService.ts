import { GoogleDriveService, DEFAULT_DOCS_FOLDER } from "./googleDriveService";

export const DEFAULT_PERSONAL_PHYSICIAN_DOC_TITLE =
  "Bitácora Clínica Personal - Dr. Andrés Ruiz Miranda (COSAM Rinconada)";

export interface DocsDocumentSummary {
  id: string;
  name: string;
  webViewLink: string;
  createdTime?: string;
  modifiedTime?: string;
}

export interface DocsSectionInput {
  heading: string;
  body: string;
}

export interface DocsDocumentDetails {
  documentId: string;
  title: string;
  webViewLink: string;
  plainText: string;
  paragraphCount: number;
}

export type PersonalDocExportMode = "new_doc_per_report" | "append_master_doc";

export interface PersonalDocExportRecord {
  id: string;
  documentId: string;
  documentTitle: string;
  webViewLink: string;
  reportType: string;
  patientName: string;
  patientRut?: string;
  exportedAt: string;
  mode: PersonalDocExportMode;
}

const PERSONAL_DOC_AUTO_EXPORT_KEY = "cosam_gdocs_auto_export_enabled";
const PERSONAL_DOC_MODE_KEY = "cosam_gdocs_export_mode";
const PERSONAL_DOC_MASTER_TITLE_KEY = "cosam_gdocs_master_doc_title";
const PERSONAL_DOC_MASTER_ID_KEY = "cosam_gdocs_master_doc_id";
const PERSONAL_DOC_HISTORY_KEY = "cosam_gdocs_export_history";

export class GoogleDocsService {
  private static async getValidToken(): Promise<string> {
    let token = GoogleDriveService.getStoredToken();
    if (!token) {
      token = await GoogleDriveService.requestAuth();
    }
    return token;
  }

  public static getEditUrl(documentId: string): string {
    return `https://docs.google.com/document/d/${documentId}/edit`;
  }

  public static getPreviewUrl(documentId: string): string {
    return `https://docs.google.com/document/d/${documentId}/preview`;
  }

  public static isAutoExportEnabled(): boolean {
    try {
      const val = localStorage.getItem(PERSONAL_DOC_AUTO_EXPORT_KEY);
      // Habilitado por defecto para que los informes generados se exporten automáticamente al documento personal del médico
      return val === null ? true : val === "true";
    } catch {
      return true;
    }
  }

  public static setAutoExportEnabled(enabled: boolean): void {
    try {
      localStorage.setItem(PERSONAL_DOC_AUTO_EXPORT_KEY, String(enabled));
      if (typeof window !== "undefined") {
        window.dispatchEvent(new CustomEvent("cosam:gdocs-settings-changed"));
      }
    } catch {
      // Ignore storage errors
    }
  }

  public static getExportMode(): PersonalDocExportMode {
    try {
      const val = localStorage.getItem(PERSONAL_DOC_MODE_KEY);
      if (val === "append_master_doc" || val === "new_doc_per_report") {
        return val;
      }
      return "new_doc_per_report";
    } catch {
      return "new_doc_per_report";
    }
  }

  public static setExportMode(mode: PersonalDocExportMode): void {
    try {
      localStorage.setItem(PERSONAL_DOC_MODE_KEY, mode);
      if (typeof window !== "undefined") {
        window.dispatchEvent(new CustomEvent("cosam:gdocs-settings-changed"));
      }
    } catch {
      // Ignore storage errors
    }
  }

  public static getMasterDocTitle(): string {
    try {
      const val = localStorage.getItem(PERSONAL_DOC_MASTER_TITLE_KEY);
      return val && val.trim() ? val.trim() : DEFAULT_PERSONAL_PHYSICIAN_DOC_TITLE;
    } catch {
      return DEFAULT_PERSONAL_PHYSICIAN_DOC_TITLE;
    }
  }

  public static setMasterDocTitle(title: string): void {
    try {
      const clean = title.trim() || DEFAULT_PERSONAL_PHYSICIAN_DOC_TITLE;
      localStorage.setItem(PERSONAL_DOC_MASTER_TITLE_KEY, clean);
      localStorage.removeItem(PERSONAL_DOC_MASTER_ID_KEY);
      if (typeof window !== "undefined") {
        window.dispatchEvent(new CustomEvent("cosam:gdocs-settings-changed"));
      }
    } catch {
      // Ignore storage errors
    }
  }

  public static getExportHistory(): PersonalDocExportRecord[] {
    try {
      const raw = localStorage.getItem(PERSONAL_DOC_HISTORY_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  }

  private static addExportHistoryRecord(record: PersonalDocExportRecord): void {
    try {
      const current = this.getExportHistory();
      const updated = [record, ...current].slice(0, 30);
      localStorage.setItem(PERSONAL_DOC_HISTORY_KEY, JSON.stringify(updated));
      if (typeof window !== "undefined") {
        window.dispatchEvent(
          new CustomEvent("cosam:gdocs-export-completed", { detail: record })
        );
      }
    } catch {
      // Ignore storage errors
    }
  }

  /**
   * Obtiene o crea el Documento Personal Maestro del Médico en Google Docs
   */
  public static async getOrCreatePersonalMasterDoc(): Promise<{
    documentId: string;
    title: string;
    webViewLink: string;
  }> {
    const token = await this.getValidToken();
    const targetTitle = this.getMasterDocTitle();

    // 1. Verificar si ya existe en Drive un Google Doc con ese título
    try {
      const escapedTitle = targetTitle.replace(/'/g, "\\'");
      const q = encodeURIComponent(
        `mimeType='application/vnd.google-apps.document' and name='${escapedTitle}' and trashed=false`
      );
      const searchRes = await fetch(
        `https://www.googleapis.com/drive/v3/files?q=${q}&fields=files(id,name,webViewLink)&pageSize=5`,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      if (searchRes.ok) {
        const searchData = await searchRes.json();
        if (searchData.files && searchData.files.length > 0) {
          const found = searchData.files[0];
          try {
            localStorage.setItem(PERSONAL_DOC_MASTER_ID_KEY, found.id);
          } catch {
            // ignore
          }
          return {
            documentId: found.id,
            title: found.name,
            webViewLink: found.webViewLink || this.getEditUrl(found.id),
          };
        }
      }
    } catch (e) {
      console.warn("Error searching existing personal master Google Doc:", e);
    }

    // 2. Si no existe, crearlo e inicializar su encabezado institucional
    const userInfo = GoogleDriveService.getAuthenticatedUserInfo();
    const doctorDisplay = userInfo?.displayName || "Dr. Andrés Ruiz Miranda";
    const doctorEmail = userInfo?.email ? ` (${userInfo.email})` : "";

    const created = await this.createClinicalDocument({
      title: targetTitle,
      subtitle: `Documento Personal del Médico · ${doctorDisplay}${doctorEmail}`,
      metadataHeader: `Creado automáticamente mediante Firebase Auth + Google Docs API v1 · COSAM Rinconada`,
      sections: [
        {
          heading: "Registro Centralizado de Informes Clínicos Generados",
          body: "Este documento personal almacena de forma estructurada y cronológica las evoluciones SOAP, formulaciones PAI 4P, contra-derivaciones, altas y actas clínicas generadas en el Box de Psiquiatría Adultos y Adicciones del COSAM Rinconada.",
        },
      ],
      folderName: DEFAULT_DOCS_FOLDER,
    });

    try {
      localStorage.setItem(PERSONAL_DOC_MASTER_ID_KEY, created.documentId);
    } catch {
      // ignore
    }

    return created;
  }

  /**
   * Exporta un informe clínico generado (SOAP, PAI, Derivación, Egreso, etc.) al Documento Personal del Médico en Google Docs.
   * Si mode === 'new_doc_per_report', crea un Google Doc personal individual en la carpeta del médico (operación no destructiva).
   * Si mode === 'append_master_doc', anexa el informe al final de la Bitácora Clínica Personal del médico.
   */
  public static async exportClinicalReportToPersonalDoc({
    reportType,
    patientName,
    patientRut,
    content,
    modeOverride,
  }: {
    reportType: string;
    patientName: string;
    patientRut?: string;
    content: string;
    modeOverride?: PersonalDocExportMode;
  }): Promise<PersonalDocExportRecord> {
    const mode = modeOverride || this.getExportMode();
    const userInfo = GoogleDriveService.getAuthenticatedUserInfo();
    const doctorName = userInfo?.displayName || "Dr. Andrés Ruiz Miranda";
    const doctorEmail = userInfo?.email || "Médico Tratante COSAM Rinconada";
    const nowStr = new Date().toLocaleString("es-CL");
    const dateShort = new Date().toLocaleDateString("es-CL");
    const cleanPatient = patientName.trim() || "Paciente en Control";
    const cleanRut = patientRut?.trim() || "Sin RUT";

    if (mode === "append_master_doc") {
      const masterDoc = await this.getOrCreatePersonalMasterDoc();
      await this.appendSectionToDocument(masterDoc.documentId, {
        heading: `${reportType.toUpperCase()} · PACIENTE: ${cleanPatient} (RUT: ${cleanRut}) · ${nowStr}`,
        body: `Médico: ${doctorName} (${doctorEmail})\n──────────────────────────────────────────────────\n${content.trim()}\n──────────────────────────────────────────────────`,
      });

      const record: PersonalDocExportRecord = {
        id: `exp_${Date.now()}`,
        documentId: masterDoc.documentId,
        documentTitle: masterDoc.title,
        webViewLink: masterDoc.webViewLink,
        reportType,
        patientName: cleanPatient,
        patientRut: cleanRut,
        exportedAt: nowStr,
        mode: "append_master_doc",
      };
      this.addExportHistoryRecord(record);
      return record;
    }

    // Modo por defecto: crear un Documento Personal de Google Docs dedicado para el informe generado
    const docTitle = `${reportType} - ${cleanPatient} (${dateShort}) - ${doctorName}`;
    const created = await this.createClinicalDocument({
      title: docTitle,
      subtitle: `Documento Personal del Médico: ${doctorName} (${doctorEmail})`,
      metadataHeader: `Paciente: ${cleanPatient} | RUT: ${cleanRut} | Fecha de emisión: ${nowStr}`,
      sections: [
        {
          heading: `Informe Clínico: ${reportType}`,
          body: content.trim(),
        },
      ],
      folderName: DEFAULT_DOCS_FOLDER,
    });

    const record: PersonalDocExportRecord = {
      id: `exp_${Date.now()}`,
      documentId: created.documentId,
      documentTitle: created.title,
      webViewLink: created.webViewLink,
      reportType,
      patientName: cleanPatient,
      patientRut: cleanRut,
      exportedAt: nowStr,
      mode: "new_doc_per_report",
    };
    this.addExportHistoryRecord(record);
    return record;
  }

  /**
   * Lista los documentos de Google Docs recientes del usuario en Drive
   */
  public static async listDocuments(maxResults = 25): Promise<DocsDocumentSummary[]> {
    const token = GoogleDriveService.getStoredToken();
    if (!token) return [];

    const q = encodeURIComponent(
      "mimeType='application/vnd.google-apps.document' and trashed=false"
    );
    const url = `https://www.googleapis.com/drive/v3/files?q=${q}&fields=files(id,name,webViewLink,createdTime,modifiedTime)&orderBy=modifiedTime desc&pageSize=${maxResults}`;

    const res = await fetch(url, {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (!res.ok) {
      if (res.status === 401) {
        GoogleDriveService.clearToken();
        throw new Error(
          "La sesión de Google Workspace expiró. Vuelva a iniciar sesión con Firebase Auth."
        );
      }
      throw new Error("No se pudieron listar los documentos de Google Docs.");
    }

    const data = await res.json();
    return (data.files || []).map((f: any) => ({
      id: f.id,
      name: f.name,
      webViewLink: f.webViewLink || this.getEditUrl(f.id),
      createdTime: f.createdTime,
      modifiedTime: f.modifiedTime,
    }));
  }

  /**
   * Obtiene el contenido y texto plano de un documento de Google Docs por ID
   */
  public static async getDocumentDetails(documentId: string): Promise<DocsDocumentDetails> {
    const token = await this.getValidToken();
    const res = await fetch(`https://docs.googleapis.com/v1/documents/${documentId}`, {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (!res.ok) {
      if (res.status === 401) {
        GoogleDriveService.clearToken();
        throw new Error("Sesión expirada. Reconecte su cuenta con Firebase Auth.");
      }
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error?.message || "No se pudo leer el documento en Google Docs.");
    }

    const doc = await res.json();
    const content = doc.body?.content || [];
    const lines: string[] = [];
    let paragraphCount = 0;

    for (const structuralEl of content) {
      if (structuralEl.paragraph?.elements) {
        paragraphCount++;
        const paraText = structuralEl.paragraph.elements
          .map((e: any) => e.textRun?.content || "")
          .join("");
        if (paraText) {
          lines.push(paraText);
        }
      } else if (structuralEl.table?.tableRows) {
        for (const row of structuralEl.table.tableRows) {
          const rowCells: string[] = [];
          for (const cell of row.tableCells || []) {
            const cellText = (cell.content || [])
              .map((c: any) =>
                (c.paragraph?.elements || [])
                  .map((e: any) => (e.textRun?.content || "").trim())
                  .join(" ")
              )
              .join(" ")
              .trim();
            if (cellText) rowCells.push(cellText);
          }
          if (rowCells.length > 0) {
            lines.push(rowCells.join(" | ") + "\n");
          }
        }
      }
    }

    return {
      documentId: doc.documentId,
      title: doc.title || "Documento sin título",
      webViewLink: this.getEditUrl(doc.documentId),
      plainText: lines.join("").trim(),
      paragraphCount,
    };
  }

  /**
   * Crea un documento clínico estructurado en Google Docs y lo organiza en la carpeta del COSAM
   */
  public static async createClinicalDocument({
    title,
    subtitle,
    metadataHeader,
    sections,
    folderName = DEFAULT_DOCS_FOLDER,
  }: {
    title: string;
    subtitle?: string;
    metadataHeader?: string;
    sections: DocsSectionInput[];
    folderName?: string;
  }): Promise<{ documentId: string; title: string; webViewLink: string }> {
    const token = await this.getValidToken();

    // 1. Crear el documento en Google Docs API v1
    const createRes = await fetch("https://docs.googleapis.com/v1/documents", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        title: title.trim() || "Informe Clínico COSAM Rinconada",
      }),
    });

    if (!createRes.ok) {
      if (createRes.status === 401) {
        GoogleDriveService.clearToken();
        throw new Error("Sesión expirada. Reconecte su cuenta de Google.");
      }
      const err = await createRes.json().catch(() => ({}));
      throw new Error(
        err.error?.message ||
          "Error al crear el documento en Google Docs. Verifique los permisos OAuth."
      );
    }

    const createdDoc = await createRes.json();
    const documentId: string = createdDoc.documentId;

    // 2. Construir el contenido estructurado e insertarlo mediante batchUpdate
    const fullBlocks: string[] = [];
    fullBlocks.push("SERVICIO DE SALUD METROPOLITANO SUR · COSAM RINCONADA (SAN RAMÓN)\n");
    fullBlocks.push(`${title.toUpperCase()}\n`);
    if (subtitle && subtitle.trim()) {
      fullBlocks.push(`${subtitle.trim()}\n`);
    }
    if (metadataHeader && metadataHeader.trim()) {
      fullBlocks.push(`${metadataHeader.trim()}\n`);
    }
    fullBlocks.push("──────────────────────────────────────────────────────────────────\n\n");

    for (const sec of sections) {
      if (sec.heading && sec.heading.trim()) {
        fullBlocks.push(`■ ${sec.heading.trim().toUpperCase()}\n`);
      }
      if (sec.body && sec.body.trim()) {
        fullBlocks.push(`${sec.body.trim()}\n\n`);
      }
    }

    fullBlocks.push(
      `──────────────────────────────────────────────────────────────────\nDocumento emitido desde Ecosistema Clínico COSAM Rinconada · Fecha: ${new Date().toLocaleString("es-CL")}\n`
    );

    const combinedText = fullBlocks.join("");

    const batchRes = await fetch(
      `https://docs.googleapis.com/v1/documents/${documentId}:batchUpdate`,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          requests: [
            {
              insertText: {
                location: { index: 1 },
                text: combinedText,
              },
            },
          ],
        }),
      }
    );

    if (!batchRes.ok) {
      const err = await batchRes.json().catch(() => ({}));
      console.warn("Advertencia en formato batchUpdate de Google Docs:", err);
    }

    // 3. Mover a la carpeta institucional de Google Drive si está disponible
    try {
      const folderId = await GoogleDriveService.getOrCreateFolder(folderName);
      const fileMetaRes = await fetch(
        `https://www.googleapis.com/drive/v3/files/${documentId}?fields=parents`,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      if (fileMetaRes.ok) {
        const fileMeta = await fileMetaRes.json();
        const previousParents = (fileMeta.parents || []).join(",");
        await fetch(
          `https://www.googleapis.com/drive/v3/files/${documentId}?addParents=${folderId}&removeParents=${previousParents}&fields=id,parents`,
          {
            method: "PATCH",
            headers: { Authorization: `Bearer ${token}` },
          }
        );
      }
    } catch (moveErr) {
      console.warn("No se pudo mover el Google Doc a la carpeta dedicada:", moveErr);
    }

    return {
      documentId,
      title: createdDoc.title || title,
      webViewLink: this.getEditUrl(documentId),
    };
  }

  /**
   * Añade una nueva sección o anexo al final de un documento existente en Google Docs
   */
  public static async appendSectionToDocument(
    documentId: string,
    section: DocsSectionInput
  ): Promise<void> {
    const token = await this.getValidToken();

    const textToAppend = `\n\n■ ${section.heading.trim().toUpperCase()}\n${section.body.trim()}\n(Actualizado: ${new Date().toLocaleString("es-CL")})\n`;

    const res = await fetch(
      `https://docs.googleapis.com/v1/documents/${documentId}:batchUpdate`,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          requests: [
            {
              insertText: {
                endOfSegmentLocation: { segmentId: "" },
                text: textToAppend,
              },
            },
          ],
        }),
      }
    );

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(
        err.error?.message || "No se pudo anexar el texto al documento en Google Docs."
      );
    }
  }

  /**
   * Elimina (envía a la papelera de Drive) un documento de Google Docs
   */
  public static async trashDocument(documentId: string): Promise<void> {
    const token = await this.getValidToken();
    const res = await fetch(`https://www.googleapis.com/drive/v3/files/${documentId}`, {
      method: "PATCH",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ trashed: true }),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error?.message || "No se pudo mover el documento a la papelera.");
    }
  }
}
