import { DriveUploadedFile, DriveUploadProgress } from "../types";
import {
  GOOGLE_WORKSPACE_SCOPES_LIST,
  googleSignIn,
  getAccessTokenSync,
  setMemoryAccessToken,
  getCurrentAuthUser,
  logout,
} from "./firebaseAuthService";

export const DEFAULT_ROOT_FOLDER = "COSAM Rinconada - Fichas Clínicas";
export const DEFAULT_SOAP_FOLDER = "COSAM Rinconada - Evoluciones SOAP";
export const DEFAULT_PAI_FOLDER = "COSAM Rinconada - Ingreso PAI";
export const DEFAULT_SLIDES_FOLDER = "COSAM Rinconada - Presentaciones Clínicas";
export const DEFAULT_DOCS_FOLDER = "COSAM Rinconada - Documentos Google Docs";

export const GOOGLE_WORKSPACE_SCOPES = GOOGLE_WORKSPACE_SCOPES_LIST.join(" ");

export class GoogleDriveService {
  private static folderCache: Map<string, string> = new Map();

  public static async ensureGsiLoaded(): Promise<void> {
    // Authentication is now handled via Firebase Auth (signInWithPopup)
    return Promise.resolve();
  }

  public static getStoredToken(): string | null {
    return getAccessTokenSync();
  }

  public static setToken(token: string, _expiresInSeconds = 3500) {
    setMemoryAccessToken(token);
  }

  public static clearToken() {
    this.folderCache.clear();
    setMemoryAccessToken(null);
  }

  public static async disconnect() {
    this.folderCache.clear();
    await logout();
  }

  public static getAuthenticatedUserInfo(): {
    uid: string;
    displayName: string;
    email: string;
    photoURL: string | null;
  } | null {
    const user = getCurrentAuthUser();
    if (!user) return null;
    return {
      uid: user.uid,
      displayName: user.displayName || "Dr. Andrés Ruiz Miranda",
      email: user.email || "",
      photoURL: user.photoURL || null,
    };
  }

  public static async initiateAuth(_clientId?: string): Promise<string> {
    return this.requestAuth();
  }

  public static isConnected(): boolean {
    return !!this.getStoredToken();
  }

  public static getAutoSync(moduleKey: "soap" | "pai"): boolean {
    try {
      const val = localStorage.getItem(`cosam_auto_sync_gdrive_${moduleKey}`);
      return val === "true";
    } catch {
      return false;
    }
  }

  public static setAutoSync(moduleKey: "soap" | "pai", enabled: boolean) {
    try {
      localStorage.setItem(`cosam_auto_sync_gdrive_${moduleKey}`, String(enabled));
    } catch (e) {
      console.warn("Failed to save auto sync state:", e);
    }
  }

  public static getModuleFolder(moduleKey: "soap" | "pai", defaultFolder?: string): string {
    try {
      const fallback =
        defaultFolder || (moduleKey === "soap" ? DEFAULT_SOAP_FOLDER : DEFAULT_PAI_FOLDER);
      const val = localStorage.getItem(`cosam_gdrive_folder_${moduleKey}`);
      return val && val.trim() ? val.trim() : fallback;
    } catch {
      return moduleKey === "soap" ? DEFAULT_SOAP_FOLDER : DEFAULT_PAI_FOLDER;
    }
  }

  public static setModuleFolder(moduleKey: "soap" | "pai", folderName: string) {
    try {
      localStorage.setItem(`cosam_gdrive_folder_${moduleKey}`, folderName.trim());
      this.folderCache.delete(folderName.trim());
    } catch (e) {
      console.warn("Failed to save folder name:", e);
    }
  }

  public static async requestAuth(_clientId?: string): Promise<string> {
    const result = await googleSignIn();
    if (!result?.accessToken) {
      throw new Error("No se recibió token de acceso de Firebase Auth.");
    }
    return result.accessToken;
  }

  public static async getOrCreateFolder(folderName = DEFAULT_ROOT_FOLDER): Promise<string> {
    const token = this.getStoredToken();
    if (!token)
      throw new Error(
        "No hay sesión activa en Google Workspace. Inicie sesión con Google (Firebase Auth)."
      );
    const normalizedName = folderName.trim() || DEFAULT_ROOT_FOLDER;
    if (this.folderCache.has(normalizedName)) {
      return this.folderCache.get(normalizedName)!;
    }
    const escapedName = normalizedName.replace(/'/g, "\\'");
    const searchUrl = `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(
      `mimeType='application/vnd.google-apps.folder' and name='${escapedName}' and trashed=false`
    )}&fields=files(id,name)`;
    const searchRes = await fetch(searchUrl, {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!searchRes.ok) {
      if (searchRes.status === 401) {
        this.clearToken();
        throw new Error(
          "La sesión de Google Workspace ha expirado. Por favor vuelva a autenticarse con Firebase Auth."
        );
      }
      throw new Error("Error al consultar carpetas en Google Drive.");
    }
    const searchData = await searchRes.json();
    if (searchData.files && searchData.files.length > 0) {
      const folderId = searchData.files[0].id;
      this.folderCache.set(normalizedName, folderId);
      return folderId;
    }
    const createRes = await fetch("https://www.googleapis.com/drive/v3/files", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        name: normalizedName,
        mimeType: "application/vnd.google-apps.folder",
      }),
    });
    if (!createRes.ok) {
      throw new Error(`Error al crear la carpeta "${normalizedName}" en Google Drive.`);
    }
    const createData = await createRes.json();
    this.folderCache.set(normalizedName, createData.id);
    return createData.id;
  }

  public static async saveClinicalDocument({
    fileName,
    content,
    mimeType = "text/plain",
    folderName = DEFAULT_ROOT_FOLDER,
    onProgress,
  }: {
    fileName: string;
    content: string;
    mimeType?: string;
    folderName?: string;
    onProgress?: (progress: DriveUploadProgress) => void;
  }): Promise<DriveUploadedFile> {
    const targetFolder = folderName || DEFAULT_ROOT_FOLDER;
    const reportProgress = (
      percent: number,
      stage: DriveUploadProgress["stage"],
      message: string,
      extras?: Partial<DriveUploadProgress>
    ) => {
      if (onProgress) {
        onProgress({
          percent,
          stage,
          message,
          fileName,
          folderName: targetFolder,
          ...extras,
        });
      }
    };
    try {
      reportProgress(10, "preparing", "Iniciando preparación del documento clínico...");
      const token = this.getStoredToken();
      if (!token) {
        throw new Error(
          "No hay sesión activa en Google Workspace. Inicie sesión con Google (Firebase Auth)."
        );
      }
      await new Promise((r) => setTimeout(r, 120));
      reportProgress(
        30,
        "checking_folder",
        `Localizando carpeta de destino "${targetFolder}" en Drive...`
      );
      const folderId = await this.getOrCreateFolder(targetFolder);
      reportProgress(55, "uploading", "Empaquetando metadatos y contenido seguro...");
      const cleanFileName =
        fileName.endsWith(".txt") || fileName.endsWith(".doc") || fileName.endsWith(".html")
          ? fileName
          : `${fileName}.txt`;
      const metadata = {
        name: cleanFileName,
        parents: [folderId],
        mimeType,
      };
      const boundary = "-------314159265358979323846";
      const delimiter = `\r\n--${boundary}\r\n`;
      const closeDelimiter = `\r\n--${boundary}--`;
      const multipartRequestBody =
        delimiter +
        "Content-Type: application/json; charset=UTF-8\r\n\r\n" +
        JSON.stringify(metadata) +
        delimiter +
        `Content-Type: ${mimeType}; charset=UTF-8\r\n\r\n` +
        content +
        closeDelimiter;
      reportProgress(
        75,
        "uploading",
        `Transfiriendo archivo cifrado a Google Drive (${(content.length / 1024).toFixed(1)} KB)...`
      );
      const res = await fetch(
        "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,mimeType,webViewLink,createdTime,size",
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": `multipart/related; boundary=${boundary}`,
          },
          body: multipartRequestBody,
        }
      );
      if (!res.ok) {
        if (res.status === 401) {
          this.clearToken();
          throw new Error(
            "Sesión de Google Workspace expirada. Reconecte su cuenta con Firebase Auth."
          );
        }
        const err = await res.json().catch(() => ({}));
        throw new Error(
          err.error?.message || "Error en el servidor al subir archivo a Google Drive."
        );
      }
      reportProgress(92, "uploading", "Validando confirmación de almacenamiento...");
      const fileData = await res.json();
      const result: DriveUploadedFile = {
        id: fileData.id,
        name: fileData.name,
        mimeType: fileData.mimeType,
        webViewLink: fileData.webViewLink,
        createdTime: fileData.createdTime,
        size: fileData.size,
      };
      reportProgress(100, "completed", `¡Archivo respaldado exitosamente en Google Drive!`, {
        fileUrl: result.webViewLink,
        fileId: result.id,
      });
      return result;
    } catch (error: any) {
      reportProgress(0, "error", error.message || "Error al enviar documento a Google Drive", {
        error: error.message || "Fallo en la carga",
      });
      throw error;
    }
  }

  public static async listCosamDocuments(
    folderName = DEFAULT_ROOT_FOLDER
  ): Promise<DriveUploadedFile[]> {
    const token = this.getStoredToken();
    if (!token) return [];
    try {
      const folderId = await this.getOrCreateFolder(folderName);
      const url = `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(
        `'${folderId}' in parents and trashed=false`
      )}&fields=files(id,name,mimeType,webViewLink,createdTime,size)&orderBy=createdTime desc&pageSize=30`;
      const res = await fetch(url, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) return [];
      const data = await res.json();
      return (data.files || []).map((f: any) => ({
        id: f.id,
        name: f.name,
        mimeType: f.mimeType,
        webViewLink: f.webViewLink,
        createdTime: f.createdTime,
        size: f.size,
      }));
    } catch (e) {
      console.warn("Failed to list Google Drive files:", e);
      return [];
    }
  }
}
