interface GenerateOptions {
  prompt: string;
  systemInstruction?: string;
  temperature?: number;
  model?: string;
}

export interface ChatMessage {
  role: "user" | "model";
  text: string;
}

export interface GroundingChunk {
  web?: {
    uri: string;
    title: string;
  };
}

export interface SearchGroundingResult {
  text: string;
  groundingChunks: GroundingChunk[];
  webSearchQueries?: string[];
}

async function safeParseResponse(res: Response): Promise<{ ok: boolean; data: any; rawText: string }> {
  const rawText = await res.text();
  let data: any = null;
  try {
    data = JSON.parse(rawText);
  } catch {
    data = null;
  }
  return { ok: res.ok, data, rawText };
}

function parseErrorMessage(data: any, rawText: string, status: number): string {
  if (data) {
    let msg = data.error || data.message || data.details;
    if (typeof msg === "string") {
      try {
        const parsed = JSON.parse(msg);
        if (parsed?.error?.message) {
          msg = parsed.error.message;
        }
      } catch {}
      return msg;
    }
  }
  if (rawText && !rawText.trim().startsWith("<")) {
    return rawText.slice(0, 200);
  }
  if (status === 429) {
    return "Límite de cuota alcanzado o créditos prepagados agotados en la API de Gemini. Por favor gestiona la facturación en Google AI Studio (https://ai.studio/projects).";
  }
  if (status === 503) {
    return "Servicio de IA temporalmente no disponible o sobrecargado. Por favor intenta de nuevo en unos momentos.";
  }
  return `Error en el servidor de IA (${status}).`;
}

export async function generateClinicalAI({
  prompt,
  systemInstruction,
  temperature = 0.2,
  model = "gemini-3.8-flash",
}: GenerateOptions): Promise<string> {
  try {
    const res = await fetch("/api/ai/generate", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        prompt,
        systemInstruction,
        temperature,
        model,
      }),
    });
    const { ok, data, rawText } = await safeParseResponse(res);
    if (!ok) {
      throw new Error(parseErrorMessage(data, rawText, res.status));
    }
    return data?.text || "";
  } catch (error: any) {
    console.error("Clinical AI Generation Error:", error);
    throw error;
  }
}

export async function chatClinicalAI({
  messages,
  systemInstruction,
  temperature = 0.2,
  model = "gemini-3.8-flash",
}: {
  messages: ChatMessage[];
  systemInstruction?: string;
  temperature?: number;
  model?: string;
}): Promise<string> {
  try {
    const res = await fetch("/api/ai/chat", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        messages,
        systemInstruction,
        temperature,
        model,
      }),
    });
    const { ok, data, rawText } = await safeParseResponse(res);
    if (!ok) {
      throw new Error(parseErrorMessage(data, rawText, res.status));
    }
    return data?.text || "";
  } catch (error: any) {
    console.error("Clinical AI Chat Error:", error);
    throw error;
  }
}

export async function transcribeClinicalAudio({
  audioData,
  mimeType = "audio/webm",
  prompt,
}: {
  audioData: string;
  mimeType?: string;
  prompt?: string;
}): Promise<string> {
  try {
    const res = await fetch("/api/ai/transcribe", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        audioData,
        mimeType,
        prompt,
      }),
    });
    const { ok, data, rawText } = await safeParseResponse(res);
    if (!ok) {
      throw new Error(parseErrorMessage(data, rawText, res.status));
    }
    return data?.text || "";
  } catch (error: any) {
    console.error("Clinical AI Audio Transcription Error:", error);
    throw error;
  }
}

export async function searchGroundingClinicalAI({
  prompt,
  systemInstruction,
  model = "gemini-3.8-flash",
}: {
  prompt: string;
  systemInstruction?: string;
  model?: string;
}): Promise<SearchGroundingResult> {
  try {
    const res = await fetch("/api/ai/search", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        prompt,
        systemInstruction,
        model,
      }),
    });
    const { ok, data, rawText } = await safeParseResponse(res);
    if (!ok) {
      throw new Error(parseErrorMessage(data, rawText, res.status));
    }
    return {
      text: data?.text || "",
      groundingChunks: data?.groundingChunks || [],
      webSearchQueries: data?.webSearchQueries || [],
    };
  } catch (error: any) {
    console.error("Clinical AI Search Grounding Error:", error);
    throw error;
  }
}
