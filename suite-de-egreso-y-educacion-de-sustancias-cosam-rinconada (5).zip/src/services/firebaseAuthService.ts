import { initializeApp, getApps, getApp } from "firebase/app";
import {
  getAuth,
  signInWithPopup,
  GoogleAuthProvider,
  onAuthStateChanged,
  User,
} from "firebase/auth";
import firebaseConfig from "../../firebase-applet-config.json";

export const GOOGLE_WORKSPACE_SCOPES_LIST = [
  "https://mail.google.com/",
  "https://www.googleapis.com/auth/gmail.addons.current.action.compose",
  "https://www.googleapis.com/auth/gmail.addons.current.message.action",
  "https://www.googleapis.com/auth/gmail.addons.current.message.metadata",
  "https://www.googleapis.com/auth/gmail.addons.current.message.readonly",
  "https://www.googleapis.com/auth/gmail.compose",
  "https://www.googleapis.com/auth/gmail.insert",
  "https://www.googleapis.com/auth/gmail.labels",
  "https://www.googleapis.com/auth/gmail.metadata",
  "https://www.googleapis.com/auth/gmail.modify",
  "https://www.googleapis.com/auth/gmail.readonly",
  "https://www.googleapis.com/auth/gmail.send",
  "https://www.googleapis.com/auth/gmail.settings.basic",
  "https://www.googleapis.com/auth/gmail.settings.sharing",
  "https://www.googleapis.com/auth/documents",
  "https://www.googleapis.com/auth/documents.readonly",
  "https://www.googleapis.com/auth/drive",
  "https://www.googleapis.com/auth/drive.file",
  "https://www.googleapis.com/auth/drive.readonly",
  "https://www.googleapis.com/auth/presentations",
  "https://www.googleapis.com/auth/presentations.readonly",
  "https://www.googleapis.com/auth/spreadsheets",
  "https://www.googleapis.com/auth/spreadsheets.readonly",
  "https://www.googleapis.com/auth/calendar",
  "https://www.googleapis.com/auth/calendar.acls",
  "https://www.googleapis.com/auth/calendar.acls.readonly",
  "https://www.googleapis.com/auth/calendar.app.created",
  "https://www.googleapis.com/auth/calendar.calendarlist",
  "https://www.googleapis.com/auth/calendar.calendarlist.readonly",
  "https://www.googleapis.com/auth/calendar.calendars",
  "https://www.googleapis.com/auth/calendar.calendars.readonly",
  "https://www.googleapis.com/auth/calendar.events",
  "https://www.googleapis.com/auth/calendar.events.freebusy",
  "https://www.googleapis.com/auth/calendar.events.owned",
  "https://www.googleapis.com/auth/calendar.events.owned.readonly",
  "https://www.googleapis.com/auth/calendar.events.public.readonly",
  "https://www.googleapis.com/auth/calendar.events.readonly",
  "https://www.googleapis.com/auth/calendar.freebusy",
  "https://www.googleapis.com/auth/calendar.readonly",
  "https://www.googleapis.com/auth/calendar.settings.readonly",
  "https://www.googleapis.com/auth/tasks",
  "https://www.googleapis.com/auth/tasks.readonly",
  "https://www.googleapis.com/auth/keep",
  "https://www.googleapis.com/auth/keep.readonly",
];

// Reuse existing app instance if already initialized
const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
export const auth = getAuth(app);

const provider = new GoogleAuthProvider();
for (const scope of GOOGLE_WORKSPACE_SCOPES_LIST) {
  provider.addScope(scope);
}
provider.setCustomParameters({
  prompt: "consent",
});

// Flag to indicate if we are in the middle of a sign-in flow.
let isSigningIn = false;
// Cache the OAuth access token strictly in memory (never in localStorage or sessionStorage).
let cachedAccessToken: string | null = null;
let cachedUser: User | null = null;

function dispatchWorkspaceAuthEvent() {
  if (typeof window !== "undefined") {
    window.dispatchEvent(
      new CustomEvent("cosam:gdrive-auth-changed", {
        detail: {
          connected: !!cachedAccessToken,
          user: cachedUser
            ? {
                uid: cachedUser.uid,
                displayName: cachedUser.displayName,
                email: cachedUser.email,
                photoURL: cachedUser.photoURL,
              }
            : null,
        },
      })
    );
  }
}

// Subscribe globally so cachedAccessToken is cleared whenever Firebase user signs out
onAuthStateChanged(auth, (user: User | null) => {
  cachedUser = user;
  if (!user && !isSigningIn) {
    cachedAccessToken = null;
  }
  dispatchWorkspaceAuthEvent();
});

/**
 * Initialize auth state listener on component load.
 */
export const initAuth = (
  onAuthSuccess?: (user: User, token: string) => void,
  onAuthFailure?: () => void
) => {
  return onAuthStateChanged(auth, async (user: User | null) => {
    cachedUser = user;
    if (user) {
      if (cachedAccessToken) {
        if (onAuthSuccess) onAuthSuccess(user, cachedAccessToken);
      } else if (!isSigningIn) {
        cachedAccessToken = null;
        if (onAuthFailure) onAuthFailure();
      }
    } else {
      cachedAccessToken = null;
      if (onAuthFailure) onAuthFailure();
    }
  });
};

/**
 * Initiates Firebase Auth Google Sign-In with Popup and retrieves the Workspace OAuth access token.
 * Must be called from a button click or user interaction.
 */
export const googleSignIn = async (): Promise<{
  user: User;
  accessToken: string;
} | null> => {
  try {
    isSigningIn = true;
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error(
        "No se pudo obtener el token de acceso OAuth desde Firebase Auth."
      );
    }

    cachedAccessToken = credential.accessToken;
    cachedUser = result.user;
    dispatchWorkspaceAuthEvent();
    return { user: result.user, accessToken: cachedAccessToken };
  } catch (error: any) {
    console.error("Firebase Google Sign-In error:", error);
    const code = error?.code || "";
    if (code === "auth/popup-closed-by-user") {
      throw new Error(
        "Ventana de inicio de sesión cerrada antes de completar la autenticación con Google."
      );
    }
    if (code === "auth/popup-blocked") {
      throw new Error(
        "El navegador bloqueó la ventana emergente de autenticación. Permita ventanas emergentes e intente nuevamente."
      );
    }
    throw new Error(
      error?.message || "Error al autenticar con Google mediante Firebase Auth."
    );
  } finally {
    isSigningIn = false;
  }
};

export const getAccessToken = async (): Promise<string | null> => {
  return cachedAccessToken;
};

export const getAccessTokenSync = (): string | null => {
  return cachedAccessToken;
};

export const setMemoryAccessToken = (token: string | null) => {
  cachedAccessToken = token;
  dispatchWorkspaceAuthEvent();
};

export const getCurrentAuthUser = (): User | null => {
  return cachedUser || auth.currentUser;
};

export const logout = async () => {
  await auth.signOut();
  cachedAccessToken = null;
  cachedUser = null;
  dispatchWorkspaceAuthEvent();
};
