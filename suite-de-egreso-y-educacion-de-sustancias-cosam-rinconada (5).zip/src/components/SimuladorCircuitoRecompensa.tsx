import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Brain,
  Zap,
  Activity,
  Shield,
  Sliders,
  Play,
  RotateCcw,
  Sparkles,
  AlertTriangle,
  ArrowRight,
  Flame,
  Layers,
  Heart,
  CheckCircle2,
  Stethoscope,
  Info,
  ChevronRight,
  Gauge,
  Dna,
  RefreshCw,
  Eye,
  SlidersHorizontal,
  Lightbulb
} from "lucide-react";

export type EstadoCircuito =
  | "basal"
  | "cocaina"
  | "pasta_base"
  | "alcohol_gaba"
  | "downregulation"
  | "recuperacion_cosam";

interface ControlPointInfo {
  id: EstadoCircuito;
  titulo: string;
  subtitulo: string;
  categoria: "Fisiológico" | "Agresión Aguda" | "Deterioro Crónico" | "Tratamiento COSAM";
  dopaminaRelativa: number; // Porcentaje relativo al basal (100)
  datBloqueo: number; // % bloqueo de recaptación DAT
  d2Densidad: number; // % densidad de receptores D2
  frenoFrontal: number; // % eficacia del control prefrontal
  color: string;
  badgeBg: string;
  metaforaPaciente: string;
  explicacionMedica: string;
  dianasFarmaco: string[];
  efectoClinico: string;
}

const PUNTOS_CONTROL: ControlPointInfo[] = [
  {
    id: "basal",
    titulo: "1. Estado Fisiológico Basal (Recompensa Natural)",
    subtitulo: "Disparo Tónico de VTA y Homeostasis Sináptica",
    categoria: "Fisiológico",
    dopaminaRelativa: 100,
    datBloqueo: 0,
    d2Densidad: 100,
    frenoFrontal: 95,
    color: "from-emerald-600 to-teal-700",
    badgeBg: "bg-emerald-100 text-emerald-800 border-emerald-300",
    metaforaPaciente:
      "Imagine un río tranquilo con un caudal regulado y una bomba de retorno (DAT) que limpia el agua de forma continua. La comida rica o el ejercicio liberan unas gotas más, pero el sistema vuelve rápidamente a su equilibrio.",
    explicacionMedica:
      "Disparo fásico y tónico normal (1-5 Hz a 20 Hz transitorio) de neuronas dopaminérgicas del Área Tegmental Ventral hacia el Núcleo Accumbens. Los transportadores DAT recaptan activamente la DA a la presinapsis y la MAO/COMT degradan el exceso, manteniendo el umbral de placer.",
    dianasFarmaco: ["Transportador DAT íntegro", "VMAT-2 equilibrado", "Autorreceptores D2 presinápticos activos"],
    efectoClinico: "Motivación fisiológica, disfrute de actividades cotidianas y control ejecutivo conservado."
  },
  {
    id: "cocaina",
    titulo: "2. Agresión por Cocaína (Inhibición de Recaptación DAT)",
    subtitulo: "Inundación Masiva de Dopamina en la Hendidura",
    categoria: "Agresión Aguda",
    dopaminaRelativa: 450,
    datBloqueo: 85,
    d2Densidad: 85,
    frenoFrontal: 35,
    color: "from-purple-600 to-indigo-700",
    badgeBg: "bg-purple-100 text-purple-800 border-purple-300",
    metaforaPaciente:
      "La cocaína actúa como un tapón gigante en el desagüe (DAT). La dopamina se acumula sin poder limpiarse, inundando los sensores cerebrales con 4 a 5 veces más intensidad que cualquier placer natural.",
    explicacionMedica:
      "Fijación competitiva al transportador DAT presináptico (con menor afinidad por SERT y NET). Al bloquearse la recaptación, la DA permanece en el espacio sináptico sobreactivando receptores postsinápticos D1 (vía directa) e induciendo cascadas hiperactivas de PKA y CREB.",
    dianasFarmaco: ["Bloqueo de DAT >80%", "Sobrestimulación D1/D5", "Desincronización córtico-estriatal"],
    efectoClinico: "Euforia artificial desmedida, taquicardia, hipervigilancia motora y anulación del freno frontal."
  },
  {
    id: "pasta_base",
    titulo: "3. Agresión por Pasta Base / Crack (Pico Ultrarrápido & Trombosis Sináptica)",
    subtitulo: "Biodisponibilidad Pulmonar Flash y Daño Oxidativo",
    categoria: "Agresión Aguda",
    dopaminaRelativa: 850,
    datBloqueo: 95,
    d2Densidad: 60,
    frenoFrontal: 15,
    color: "from-rose-600 to-purple-900",
    badgeBg: "bg-rose-100 text-rose-800 border-rose-300",
    metaforaPaciente:
      "Es una explosión volcánica inmediata que llega al cerebro en 6 segundos. El río se convierte en un tsunami violento que arranca los receptores y deja el terreno quemado y seco en menos de 10 minutos.",
    explicacionMedica:
      "Paso alveolar inmediato que alcanza concentraciones cerebrales peak en segundos. Genera una liberación masiva unida a inhibición total de DAT, acompañada de hipoxia sináptica local, toxicidad por adulterantes (plomo, carbonatos) y microangiopatía.",
    dianasFarmaco: ["Saturación de DAT al 95%", "Toxicidad mitocondrial y radical libre", "Descenso abrupto post-disparo"],
    efectoClinico: "Flash eufórico fugaz (3-5 min) seguido de disforia aplastante, ideación paranoide y craving convulsivo."
  },
  {
    id: "alcohol_gaba",
    titulo: "4. Alcohol & Benzodiacepinas (Desinhibición de VTA por Freno GABA)",
    subtitulo: "Modulación Alostérica GABA-A y Tormenta Glutamatérgica",
    categoria: "Agresión Aguda",
    dopaminaRelativa: 220,
    datBloqueo: 10,
    d2Densidad: 75,
    frenoFrontal: 25,
    color: "from-amber-600 to-slate-900",
    badgeBg: "bg-amber-100 text-amber-900 border-amber-300",
    metaforaPaciente:
      "El cerebro tiene vigilantes nocturnos (GABA) que impiden que el motor de dopamina se acelere de más. El alcohol apaga a los vigilantes, permitiendo que el motor suelte dopamina sin freno mientras adormece la corteza frontal.",
    explicacionMedica:
      "El etanol potencia alostéricamente a los receptores GABA-A en las interneuronas inhibitorias del ATV, suprimiendo la inhibición tónica sobre las neuronas dopaminérgicas (desinhibición). Concomitantemente antagoniza NMDA. En abstinencia, la hiperexcitabilidad por rebote glutamatérgico es neurotóxica.",
    dianasFarmaco: ["Canal Cl- acoplado a GABA-A", "Receptor NMDA/AMPA (Glutamato)", "Desinhibición indirecta de DA"],
    efectoClinico: "Desinhibición conductual, ataxia, amnesia anterógrada (blackouts) y riesgo de delirium en supresión."
  },
  {
    id: "downregulation",
    titulo: "5. Tolerancia Crónica & Down-Regulation (El Cerebro Agotado)",
    subtitulo: "Internalización de Receptores D2 y Desconexión Prefrontal",
    categoria: "Deterioro Crónico",
    dopaminaRelativa: 35,
    datBloqueo: 20,
    d2Densidad: 30,
    frenoFrontal: 20,
    color: "from-slate-700 to-purple-950",
    badgeBg: "bg-slate-200 text-slate-800 border-slate-400",
    metaforaPaciente:
      "Para defenderse de tantas inundaciones, las neuronas 'esconden' sus antenas receptoras (down-regulation). El cerebro queda sordo a la dopamina: las actividades normales ya no producen placer, y la persona consume no para sentirse bien, sino para no sentirse miserable.",
    explicacionMedica:
      "Pérdida de densidad de receptores D2/D3 estriatales documentada en PET scan. Aumento del factor de transcripción persistente $\\Delta$FosB y producción de dinorfina que inhibe la liberación presináptica. El tono dopaminérgico basal se desploma, generando anhedonia grave.",
    dianasFarmaco: ["Pérdida de receptores D2 (>60%)", "Acumulación de $\\Delta$FosB", "Déficit funcional de dopamina"],
    efectoClinico: "Anhedonia profunda, apatía, craving persistente por memoria de recompensa y síndrome motivacional bajo."
  },
  {
    id: "recuperacion_cosam",
    titulo: "6. Regeneración & Soporte Terapéutico en COSAM",
    subtitulo: "Neuroplasticidad, Cofactores Nutricionales y Freno Frontal",
    categoria: "Tratamiento COSAM",
    dopaminaRelativa: 90,
    datBloqueo: 0,
    d2Densidad: 85,
    frenoFrontal: 80,
    color: "from-purple-700 via-indigo-600 to-teal-700",
    badgeBg: "bg-purple-100 text-purple-900 border-purple-300",
    metaforaPaciente:
      "Con semanas de abstinencia, buena nutrición y herramientas de respiración SOS, el cerebro vuelve a sembrar sus antenas receptoras. El puente entre el freno frontal y el deseo se repara paso a paso.",
    explicacionMedica:
      "Re-expresión progresiva de receptores D2 estriatales (demostrada a partir de los 90-120 días de abstinencia). Soporte con N-acetilcisteína (restaura transportador GLT-1 de glutamato), micronutrientes (Tirosina, Complejo B, Magnesio) y re-entrenamiento del freno cortical.",
    dianasFarmaco: ["Restauración de D2", "Regulación de GLT-1 (NAC)", "Cofactores B6/B9/B12 para síntesis de DA"],
    efectoClinico: "Recuperación del placer por estímulos naturales, control del craving y reconexión afectiva familiar."
  }
];

export default function SimuladorCircuitoRecompensa() {
  const [selectedState, setSelectedState] = useState<EstadoCircuito>("basal");
  const [explicacionMode, setExplicacionMode] = useState<"paciente" | "medico">("paciente");
  const [isPlayingFlow, setIsPlayingFlow] = useState(true);
  const [activeSynapseZone, setActiveSynapseZone] = useState<"pre" | "cleft" | "post">("cleft");
  const [manualDatOverride, setManualDatOverride] = useState<number | null>(null);
  const [manualD2Override, setManualD2Override] = useState<number | null>(null);

  const currentInfo = PUNTOS_CONTROL.find((p) => p.id === selectedState) || PUNTOS_CONTROL[0];

  const currentDat = manualDatOverride !== null ? manualDatOverride : currentInfo.datBloqueo;
  const currentD2 = manualD2Override !== null ? manualD2Override : currentInfo.d2Densidad;

  // Calculo dinámico de dopamina libre y alerta
  const calculatedDopamine = Math.round(
    currentInfo.dopaminaRelativa * (1 + (currentDat / 100) * 0.8)
  );

  const resetManualOverrides = () => {
    setManualDatOverride(null);
    setManualD2Override(null);
  };

  return (
    <div className="space-y-8 animate-fadeIn pb-10">
      {/* HEADER BANNER CON IDENTIDAD INSTITUCIONAL */}
      <section className="liquid-glass rounded-3xl p-6 md:p-8 border border-purple-200/80 shadow-md relative overflow-hidden">
        <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-purple-600 via-indigo-600 to-teal-500 led-glow-purple"></div>

        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
          <div className="space-y-2 max-w-3xl">
            <div className="flex flex-wrap items-center gap-2">
              <span className="bg-purple-100 text-purple-900 border border-purple-200 text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-lg">
                Laboratorio Interactivo de Neurobiología
              </span>
              <span className="text-slate-500 text-xs font-semibold flex items-center gap-1">
                <Stethoscope size={13} className="text-purple-600" /> Dr. Andrés Felipe Ruiz Miranda • COSAM Rinconada de San Ramón
              </span>
              <span className="bg-emerald-100 text-emerald-800 text-[10px] font-extrabold px-2.5 py-0.5 rounded-md border border-emerald-200">
                Simulador Dinámico de Sinapsis
              </span>
            </div>

            <h2 className="text-2xl md:text-3xl font-black text-slate-900 tracking-tight">
              Simulador del <span className="bg-gradient-to-r from-purple-700 via-indigo-600 to-purple-900 bg-clip-text text-transparent">Circuito de Recompensa</span> &amp; Flujo de Dopamina
            </h2>

            <p className="text-xs md:text-sm text-slate-700 font-medium leading-relaxed">
              Herramienta de precisión visual para box clínico: active los puntos de control fisiopatológicos para mostrar en tiempo real cómo las distintas sustancias alteran la hendidura sináptica, bloquean la recaptación y secuestran el freno prefrontal.
            </p>
          </div>

          {/* SELECTOR DE MODO DE EXPLICACIÓN */}
          <div className="liquid-glass-dark p-4 rounded-2xl border border-slate-700/80 shrink-0 space-y-3 w-full sm:w-auto shadow-lg">
            <div className="flex items-center justify-between gap-4">
              <span className="text-xs font-black uppercase tracking-wider text-slate-200 flex items-center gap-1.5">
                <Eye size={14} className="text-purple-400" /> Modo de Psicoeducación:
              </span>
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => setExplicacionMode("paciente")}
                className={`px-3.5 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center gap-1.5 ${
                  explicacionMode === "paciente"
                    ? "bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-md led-pulse-purple"
                    : "bg-slate-800 text-slate-300 hover:bg-slate-700"
                }`}
              >
                <Sparkles size={13} />
                <span>Diálogo Paciente (Metáfora)</span>
              </button>

              <button
                onClick={() => setExplicacionMode("medico")}
                className={`px-3.5 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center gap-1.5 ${
                  explicacionMode === "medico"
                    ? "bg-gradient-to-r from-indigo-600 to-slate-900 text-white shadow-md led-pulse-indigo border border-indigo-400/40"
                    : "bg-slate-800 text-slate-300 hover:bg-slate-700"
                }`}
              >
                <Dna size={13} />
                <span>Rigor Médico / Neuropsiquiatría</span>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* PUNTOS DE CONTROL FISIOPATOLÓGICOS (SELECTOR RÁPIDO PARA EL DR. RUIZ MIRANDA) */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-black uppercase tracking-wider text-slate-800 flex items-center gap-2">
            <SlidersHorizontal size={16} className="text-purple-700" />
            Puntos de Control &amp; Agresiones Sinápticas (Seleccione para activar):
          </h3>
          {(manualDatOverride !== null || manualD2Override !== null) && (
            <button
              onClick={resetManualOverrides}
              className="text-xs font-bold text-purple-700 hover:text-purple-900 flex items-center gap-1 bg-purple-50 px-2.5 py-1 rounded-lg border border-purple-200"
            >
              <RefreshCw size={12} /> Restablecer parámetros predeterminados
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {PUNTOS_CONTROL.map((punto) => {
            const isSelected = selectedState === punto.id;
            return (
              <button
                key={punto.id}
                onClick={() => {
                  setSelectedState(punto.id);
                  resetManualOverrides();
                }}
                className={`p-4 rounded-2xl border text-left transition-all relative overflow-hidden flex flex-col justify-between group cursor-pointer active:scale-95 ${
                  isSelected
                    ? "bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white dark:from-white dark:via-slate-100 dark:to-slate-200 dark:text-slate-900 border-indigo-400/50 shadow-lg led-glow-indigo scale-[1.01]"
                    : "liquid-glass hover:bg-black/[0.04] dark:hover:bg-white/[0.06] border-indigo-500/20 dark:border-indigo-400/20"
                }`}
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className={`text-[9px] font-black uppercase tracking-wider px-2 py-0.5 rounded-md border ${punto.badgeBg}`}>
                      {punto.categoria}
                    </span>
                    <span className={`text-[10px] font-black ${isSelected ? "text-indigo-300 dark:text-indigo-600" : "text-slate-500 dark:text-slate-400"}`}>
                      DA: ~{punto.dopaminaRelativa}%
                    </span>
                  </div>

                  <div>
                    <h4 className={`text-xs md:text-sm font-black leading-snug transition-colors ${
                      isSelected ? "text-white dark:text-slate-900" : "text-slate-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-300"
                    }`}>
                      {punto.titulo}
                    </h4>
                    <p className={`text-[11px] font-medium leading-tight mt-1 line-clamp-2 ${
                      isSelected ? "text-slate-300 dark:text-slate-600" : "text-slate-600 dark:text-slate-400"
                    }`}>
                      {punto.subtitulo}
                    </p>
                  </div>
                </div>

                <div className={`mt-3 pt-2.5 border-t flex items-center justify-between text-xs font-bold ${
                  isSelected ? "border-white/15 dark:border-slate-300/30" : "border-indigo-500/10 dark:border-indigo-400/10"
                }`}>
                  <span className={`text-[10px] ${isSelected ? "text-indigo-300 dark:text-indigo-600 font-black" : "text-slate-400"}`}>
                    {isSelected ? "Activo en Simulador" : "Activar punto"}
                  </span>
                  <ArrowRight size={13} className={isSelected ? "text-indigo-300 dark:text-indigo-600" : "text-slate-400 group-hover:translate-x-1 transition-transform"} />
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* STAGE PRINCIPAL: SIMULADOR VISUAL DE LA SINAPSIS DOPAMINÉRGICA */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* PANEL IZQUIERDO: VISUALIZACIÓN DINÁMICA DE LA SINAPSIS (8 COLUMNAS) */}
        <div className="lg:col-span-8 liquid-glass rounded-3xl p-6 md:p-8 border border-purple-200/80 shadow-md space-y-6">
          {/* BARRA SUPERIOR DEL SIMULADOR */}
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-purple-100 pb-4">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-xl bg-purple-700 text-white flex items-center justify-center shadow-sm led-glow-purple">
                <Brain size={18} />
              </div>
              <div>
                <h4 className="text-sm font-black text-slate-900">
                  Espacio Sináptico: VTA (Mesencéfalo) → NAc (Estriado Ventral)
                </h4>
                <span className="text-[11px] font-bold text-purple-700">
                  Estado Activo: {currentInfo.titulo}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsPlayingFlow(!isPlayingFlow)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all ${
                  isPlayingFlow
                    ? "bg-purple-100 text-purple-800 border border-purple-300"
                    : "bg-slate-100 text-slate-600"
                }`}
              >
                <Activity size={13} className={isPlayingFlow ? "animate-pulse text-purple-700" : ""} />
                <span>{isPlayingFlow ? "Flujo Dinámico Activo" : "Pausar Animación"}</span>
              </button>
            </div>
          </div>

          {/* DIAGRAMA ILUSTRADO DEL ESPACIO SINÁPTICO CON ELEMENTOS CLÍNICOS */}
          <div className="relative rounded-3xl bg-gradient-to-b from-slate-950 via-slate-900 to-indigo-950 p-6 md:p-8 text-white overflow-hidden border border-slate-800 shadow-xl led-glow-purple">
            {/* AMBIENTE DE FONDO / RAYOS LUMINOSOS */}
            <div className="absolute top-0 left-1/4 w-72 h-72 bg-purple-600/15 rounded-full blur-3xl pointer-events-none"></div>
            <div className="absolute bottom-0 right-1/4 w-72 h-72 bg-indigo-600/15 rounded-full blur-3xl pointer-events-none"></div>

            {/* SECCIÓN 1: TERMINAL AXÓNICA PRESINÁPTICA (VTA) */}
            <div className="relative z-10 bg-slate-900/90 backdrop-blur-md rounded-2xl p-5 border border-purple-500/40 space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-1 rounded-lg bg-purple-600/30 border border-purple-400/40 text-[10px] font-black uppercase tracking-wider text-purple-300">
                    1. Neurona Presináptica (Área Tegmental Ventral)
                  </span>
                </div>
                <div className="text-[11px] font-mono text-purple-300 font-bold">
                  Recaptación DAT: {100 - currentDat}% Operativa
                </div>
              </div>

              {/* VESÍCULAS DE DOPAMINA & TRANSPORTADORES DAT */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
                <div className="p-3 bg-slate-800/80 rounded-xl border border-slate-700 space-y-1.5">
                  <span className="text-[10px] font-black text-purple-300 uppercase block">
                    Vesículas Sinápticas (VMAT-2)
                  </span>
                  <div className="flex items-center gap-1.5">
                    {Array.from({ length: 6 }).map((_, i) => (
                      <motion.div
                        key={i}
                        animate={
                          isPlayingFlow
                            ? {
                                scale: [1, 1.2, 1],
                                opacity: [0.7, 1, 0.7]
                              }
                            : {}
                        }
                        transition={{
                          duration: 1.8,
                          repeat: Infinity,
                          delay: i * 0.25
                        }}
                        className="w-4 h-4 rounded-full bg-gradient-to-tr from-purple-500 to-indigo-400 border border-purple-200 shadow-xs flex items-center justify-center text-[7px] font-black text-white"
                      >
                        DA
                      </motion.div>
                    ))}
                  </div>
                  <p className="text-[10px] text-slate-400">
                    Almacenamiento de dopamina sintetizada a partir de L-Tirosina.
                  </p>
                </div>

                <div className={`p-3 rounded-xl border transition-all ${
                  currentDat > 50
                    ? "bg-rose-950/40 border-rose-500/70 led-pulse-purple"
                    : "bg-slate-800/80 border-slate-700"
                }`}>
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black text-slate-200 uppercase">
                      Transportador DAT
                    </span>
                    <span className={`text-[9px] font-black px-1.5 py-0.5 rounded ${
                      currentDat > 50 ? "bg-rose-500 text-white" : "bg-emerald-500/30 text-emerald-300"
                    }`}>
                      {currentDat > 50 ? "BLOQUEADO" : "LIMPIANDO"}
                    </span>
                  </div>
                  <div className="mt-2 text-[11px] font-bold text-purple-200">
                    Bloqueo por sustancia: {currentDat}%
                  </div>
                  <p className="text-[10px] text-slate-400 mt-1">
                    {currentDat > 50
                      ? "La sustancia impide que la dopamina regrese a la neurona, atrapándola en la hendidura."
                      : "Recapta dopamina hacia el citosol para reutilizarla."}
                  </p>
                </div>

                <div className="p-3 bg-slate-800/80 rounded-xl border border-slate-700 space-y-1">
                  <span className="text-[10px] font-black text-slate-300 uppercase block">
                    Autorreceptores D2 (Freno)
                  </span>
                  <div className="text-[11px] font-bold text-emerald-300">
                    {selectedState === "downregulation" ? "Inhibición Atorada" : "Retroalimentación Negativa"}
                  </div>
                  <p className="text-[10px] text-slate-400">
                    Regulan la velocidad de disparo para no agotar la reserva celular.
                  </p>
                </div>
              </div>
            </div>

            {/* SECCIÓN 2: HENDIDURA SINÁPTICA (ESPACIO INTERSINÁPTICO) */}
            <div className="my-5 p-4 rounded-2xl bg-gradient-to-r from-purple-950/80 via-slate-900/90 to-indigo-950/80 border border-purple-500/50 relative overflow-hidden">
              <div className="flex items-center justify-between mb-3">
                <span className="text-[10px] font-black uppercase tracking-wider text-purple-300 flex items-center gap-1.5">
                  <Flame size={13} className="text-amber-400" />
                  2. Hendidura Sináptica (Nivel de Dopamina Libre en Tiempo Real)
                </span>
                <span className={`text-xs font-black px-2.5 py-0.5 rounded-md border ${
                  calculatedDopamine > 300
                    ? "bg-rose-600 text-white border-rose-400 animate-pulse"
                    : calculatedDopamine < 60
                    ? "bg-slate-700 text-slate-200 border-slate-500"
                    : "bg-emerald-600 text-white border-emerald-400"
                }`}>
                  Concentración: ~{calculatedDopamine}% vs. Basal
                </span>
              </div>

              {/* SIMULACIÓN DE MOLÉCULAS DE DOPAMINA EN TRÁNSITO */}
              <div className="h-20 bg-slate-950/90 rounded-xl border border-purple-900/60 relative overflow-hidden flex items-center justify-around px-4">
                {Array.from({ length: Math.min(24, Math.max(4, Math.round(calculatedDopamine / 35))) }).map((_, idx) => (
                  <motion.div
                    key={idx}
                    animate={
                      isPlayingFlow
                        ? {
                            y: [-(Math.random() * 15), Math.random() * 15, -(Math.random() * 15)],
                            x: [-(Math.random() * 10), Math.random() * 10, -(Math.random() * 10)],
                            scale: [0.9, 1.15, 0.9]
                          }
                        : {}
                    }
                    transition={{
                      duration: 1.5 + (idx % 4) * 0.3,
                      repeat: Infinity,
                      ease: "easeInOut"
                    }}
                    className={`w-3.5 h-3.5 rounded-full flex items-center justify-center text-[7px] font-black shadow-sm ${
                      calculatedDopamine > 300
                        ? "bg-rose-500 text-white border border-rose-200 shadow-rose-500/50"
                        : "bg-gradient-to-tr from-purple-400 to-indigo-300 text-slate-950 border border-purple-100"
                    }`}
                  >
                    DA
                  </motion.div>
                ))}
              </div>

              <div className="flex justify-between items-center text-[10px] text-slate-400 mt-2 px-1">
                <span>Degradación por COMT / MAO</span>
                <span className="text-purple-300 font-semibold">
                  {calculatedDopamine > 400 ? "⚠️ Sobrecarga Hiperactivadora" : "Equilibrio Metabólico"}
                </span>
              </div>
            </div>

            {/* SECCIÓN 3: MEMBRANA POSTSINÁPTICA (NÚCLEO ACCUMBENS) */}
            <div className="relative z-10 bg-slate-900/90 backdrop-blur-md rounded-2xl p-5 border border-indigo-500/40 space-y-4">
              <div className="flex items-center justify-between">
                <span className="px-2.5 py-1 rounded-lg bg-indigo-600/30 border border-indigo-400/40 text-[10px] font-black uppercase tracking-wider text-indigo-300">
                  3. Neurona Postsináptica (Núcleo Accumbens - Receptor de Recompensa)
                </span>
                <div className="text-[11px] font-mono text-indigo-300 font-bold">
                  Densidad Receptores D2: {currentD2}%
                </div>
              </div>

              {/* RECEPTORES D1 & D2 */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-3 bg-slate-800/80 rounded-xl border border-slate-700 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black text-amber-300 uppercase">
                      Receptor D1 (Vía Directa / Deseo)
                    </span>
                    <span className="text-[9px] font-bold text-slate-400">Excitatorio (Gs)</span>
                  </div>
                  <div className="w-full bg-slate-700 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-gradient-to-r from-amber-400 to-rose-500 h-full rounded-full transition-all duration-500"
                      style={{ width: `${Math.min(100, (calculatedDopamine / 450) * 100)}%` }}
                    ></div>
                  </div>
                  <p className="text-[10px] text-slate-400">
                    Activa la cascada de adenilato ciclasa y promueve la búsqueda impulsiva de la recompensa.
                  </p>
                </div>

                <div className="p-3 bg-slate-800/80 rounded-xl border border-slate-700 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black text-purple-300 uppercase">
                      Receptor D2 (Vía Indirecta / Freno)
                    </span>
                    <span className="text-[9px] font-bold text-slate-400">Inhibitorio (Gi)</span>
                  </div>
                  <div className="w-full bg-slate-700 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-gradient-to-r from-purple-400 to-indigo-500 h-full rounded-full transition-all duration-500"
                      style={{ width: `${currentD2}%` }}
                    ></div>
                  </div>
                  <p className="text-[10px] text-slate-400">
                    En consumo crónico, los receptores D2 disminuyen (down-regulation), apagando la capacidad de sentir placer con cosas simples.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* CAJA DE EXPLICACIÓN DINÁMICA (ADAPTADA AL MODO SELECCIONADO) */}
          <div className="p-5 rounded-2xl bg-gradient-to-br from-purple-50 via-white to-indigo-50 border border-purple-200/80 shadow-2xs space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Lightbulb size={16} className="text-purple-700" />
                <h4 className="text-xs font-black uppercase tracking-wider text-purple-900">
                  {explicacionMode === "paciente"
                    ? "Metáfora de Diálogo en Box para el Paciente:"
                    : "Fundamento Neurobiológico & Fisiopatológico:"}
                </h4>
              </div>
              <span className="text-[10px] font-bold text-slate-500">
                Dr. Andrés Felipe Ruiz Miranda
              </span>
            </div>

            <p className="text-xs md:text-sm text-slate-800 font-medium leading-relaxed">
              {explicacionMode === "paciente"
                ? currentInfo.metaforaPaciente
                : currentInfo.explicacionMedica}
            </p>

            <div className="pt-2 border-t border-purple-100 flex flex-wrap items-center gap-2">
              <span className="text-[10px] font-bold text-slate-500">Efecto Clínico Observado:</span>
              <span className="text-xs font-bold text-purple-900 bg-purple-100/80 px-2.5 py-0.5 rounded-lg border border-purple-200">
                {currentInfo.efectoClinico}
              </span>
            </div>
          </div>
        </div>

        {/* PANEL DERECHO: DIANAS FARMACOLÓGICAS & CONTROLES MANUALES (4 COLUMNAS) */}
        <div className="lg:col-span-4 space-y-5">
          {/* TARJETA DE CONTROL MANUAL DE PARÁMETROS EN VIVO */}
          <div className="liquid-glass rounded-3xl p-5 md:p-6 border border-purple-200/80 shadow-sm space-y-5">
            <div className="flex items-center justify-between border-b border-purple-100 pb-3">
              <div className="flex items-center gap-2">
                <Sliders size={16} className="text-purple-700" />
                <h4 className="text-xs font-black uppercase tracking-wider text-slate-900">
                  Moduladores Manuales en Vivo
                </h4>
              </div>
              <span className="text-[9px] font-black uppercase px-2 py-0.5 bg-purple-100 text-purple-800 rounded">
                Ajuste Box
              </span>
            </div>

            {/* SLIDER 1: BLOQUEO DE DAT */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs font-bold">
                <span className="text-slate-700">Bloqueo de Recaptador DAT:</span>
                <span className="text-purple-700 font-black">{currentDat}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={currentDat}
                onChange={(e) => setManualDatOverride(Number(e.target.value))}
                className="w-full h-2 bg-purple-100 rounded-lg appearance-none cursor-pointer accent-purple-600"
              />
              <div className="flex justify-between text-[9px] font-semibold text-slate-400">
                <span>0% (Limpio)</span>
                <span>50%</span>
                <span>100% (Bloqueo Total)</span>
              </div>
            </div>

            {/* SLIDER 2: DENSIDAD DE RECEPTORES D2 */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs font-bold">
                <span className="text-slate-700">Densidad Receptores D2:</span>
                <span className="text-indigo-700 font-black">{currentD2}%</span>
              </div>
              <input
                type="range"
                min="10"
                max="100"
                value={currentD2}
                onChange={(e) => setManualD2Override(Number(e.target.value))}
                className="w-full h-2 bg-indigo-100 rounded-lg appearance-none cursor-pointer accent-indigo-600"
              />
              <div className="flex justify-between text-[9px] font-semibold text-slate-400">
                <span>10% (Tolerancia Extrema)</span>
                <span>50%</span>
                <span>100% (Íntegro)</span>
              </div>
            </div>

            {/* INDICADOR DE FRENO PREFRONTAL */}
            <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-[11px] font-bold text-slate-700 flex items-center gap-1.5">
                  <Shield size={13} className="text-purple-600" /> Freno Ejecutivo Frontal:
                </span>
                <span className={`text-xs font-black ${
                  currentInfo.frenoFrontal < 40 ? "text-rose-600" : "text-emerald-700"
                }`}>
                  {currentInfo.frenoFrontal}% Operativo
                </span>
              </div>
              <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${
                    currentInfo.frenoFrontal < 40 ? "bg-rose-500" : "bg-emerald-500"
                  }`}
                  style={{ width: `${currentInfo.frenoFrontal}%` }}
                ></div>
              </div>
              <p className="text-[10px] text-slate-500 leading-tight">
                {currentInfo.frenoFrontal < 40
                  ? "La corteza prefrontal pierde control sobre el núcleo accumbens (impulsividad)."
                  : "Capacidad de postergar la gratificación y evaluar consecuencias conservada."}
              </p>
            </div>
          </div>

          {/* TARJETA DE DIANAS FARMACOLÓGICAS & TRATAMIENTO */}
          <div className="liquid-glass rounded-3xl p-5 md:p-6 border border-purple-200/80 shadow-sm space-y-3.5">
            <div className="flex items-center gap-2 border-b border-purple-100 pb-3">
              <Dna size={16} className="text-purple-700" />
              <h4 className="text-xs font-black uppercase tracking-wider text-slate-900">
                Dianas Moleculares &amp; Fármacos
              </h4>
            </div>

            <div className="space-y-2">
              {currentInfo.dianasFarmaco.map((diana, idx) => (
                <div
                  key={idx}
                  className="flex items-start gap-2 p-2.5 bg-white/90 rounded-xl border border-purple-100 text-xs text-slate-700"
                >
                  <CheckCircle2 size={14} className="text-purple-600 shrink-0 mt-0.5" />
                  <span className="font-semibold">{diana}</span>
                </div>
              ))}
            </div>

            <div className="p-3 bg-purple-50/80 rounded-2xl border border-purple-200/70 text-[11px] text-purple-950 font-medium">
              <strong>Intervención Integral COSAM:</strong> El tratamiento combina estabilización de receptores, microrrehabilitación de neurotransmisores y entrenamiento metacognitivo continuo.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
