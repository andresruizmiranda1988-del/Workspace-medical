import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Flame,
  ShieldCheck,
  Timer,
  ClipboardList,
  AlertTriangle,
  HeartPulse,
  Brain,
  Wind,
  PhoneCall,
  CheckCircle2,
  Copy,
  Trash2,
  RotateCcw,
  Play,
  Pause,
  Info,
  Sparkles,
  Layers,
  Activity,
  Droplets,
  Eye,
  MessageSquare,
  Building2,
  Share2,
  Sliders,
  Compass,
  ArrowRight,
  ExternalLink,
  ChevronRight,
  UserCheck,
  Check,
  X,
  Volume2,
  VolumeX,
  Mic,
  Utensils,
  Moon,
  Users,
  UserX,
  Banknote,
  Clock,
  MapPin,
  Smile,
  Frown,
  Meh,
  Zap,
  Radio,
  QrCode,
  Smartphone,
  Send,
  Lock
} from "lucide-react";
import { RegistroDiarioItem } from "../types";
import {
  playTherapeuticTone,
  speakTherapeuticVoice,
  stopTherapeuticVoice,
  unlockAudioEngine
} from "../utils/audioGuide";

export default function GatillantesYAfrontamiento({
  isStandalonePatientView = false
}: {
  isStandalonePatientView?: boolean;
}) {
  // ==========================================
  // ESTADO DE NAVEGACIÓN Y VISTA
  // ==========================================
  const [viewMode, setViewMode] = useState<"dual" | "gatillantes" | "afrontamiento" | "registro">(
    isStandalonePatientView ? "afrontamiento" : "dual"
  );
  const [activeAfrontamientoTab, setActiveAfrontamientoTab] = useState<"respiracion" | "surfeo" | "protocolo">("respiracion");
  const [activeGatillanteCategory, setActiveGatillanteCategory] = useState<"todos" | "internos" | "externos">("todos");

  // Configuración de audio y accesibilidad
  const [isVoiceGuideEnabled, setIsVoiceGuideEnabled] = useState<boolean>(true);
  const [isSoundEffectEnabled, setIsSoundEffectEnabled] = useState<boolean>(true);
  const [audioStatusNotice, setAudioStatusNotice] = useState<string | null>(null);

  // Modal para compartir con el paciente
  const [isShareModalOpen, setIsShareModalOpen] = useState<boolean>(false);
  const [copiedLink, setCopiedLink] = useState<boolean>(false);

  // Visualizador respiratorio: "bio_orb" (Orbe de alta gama) vs "anatomico" (Silueta)
  const [breathingVisualMode, setBreathingVisualMode] = useState<"bio_orb" | "anatomico">("bio_orb");

  // ==========================================
  // ESTADO: GATILLANTES INTERACTIVOS (H.A.L.T. Y AMBIENTALES)
  // ==========================================
  const [activeTriggers, setActiveTriggers] = useState<{ [key: string]: boolean }>({
    // Internos Fisiológicos y Emocionales (H.A.L.T.)
    hambre: false,
    enojo: false,
    soledad: false,
    cansancio: false,
    pensamiento_trampa: false,
    // Externos Sociales y Ambientales
    efectivo: false,
    horario_critico: false,
    amigos_consumo: false,
    rutas_riesgo: false,
    parafernalia: false
  });

  const toggleTrigger = (key: string) => {
    unlockAudioEngine();
    setActiveTriggers((prev) => {
      const nextState = !prev[key];
      if (nextState && isSoundEffectEnabled) {
        playTherapeuticTone("ding");
      }
      return { ...prev, [key]: nextState };
    });
  };

  const clearAllTriggers = () => {
    setActiveTriggers((prev) => {
      const reseted: { [key: string]: boolean } = {};
      Object.keys(prev).forEach((k) => (reseted[k] = false));
      return reseted;
    });
  };

  const activeTriggersCount = Object.values(activeTriggers).filter(Boolean).length;

  const riskAssessment =
    activeTriggersCount >= 5
      ? {
          level: "Riesgo Muy Alto (Zona Crítica)",
          color: "text-rose-600 dark:text-rose-400",
          bgColor: "bg-rose-500/10 dark:bg-rose-950/30",
          borderColor: "border-rose-300 dark:border-rose-800",
          badge: "ALERTA ROJA",
          action: "Activar Protocolo SOS de 5 pasos y contactar a persona de confianza o al COSAM de inmediato."
        }
      : activeTriggersCount >= 3
      ? {
          level: "Riesgo Moderado (Zona de Alerta)",
          color: "text-amber-600 dark:text-amber-400",
          bgColor: "bg-amber-500/10 dark:bg-amber-950/30",
          borderColor: "border-amber-300 dark:border-amber-800",
          badge: "ALERTA AMARILLA",
          action: "Iniciar Respiración Diafragmática 4-2-6 y neutralizar necesidades básicas (Comer, descansar o alejarse)."
        }
      : activeTriggersCount >= 1
      ? {
          level: "Riesgo Bajo (Zona de Vigilancia)",
          color: "text-blue-600 dark:text-blue-400",
          bgColor: "bg-blue-500/10 dark:bg-blue-950/30",
          borderColor: "border-blue-300 dark:border-blue-800",
          badge: "MONITOREO",
          action: "Mantener calma, beber agua y evitar exponerse a personas o lugares de consumo."
        }
      : {
          level: "Zona Estable / Control y Freno Activo",
          color: "text-emerald-600 dark:text-emerald-400",
          bgColor: "bg-emerald-500/10 dark:bg-emerald-950/30",
          borderColor: "border-emerald-300 dark:border-emerald-800",
          badge: "ESTABLE",
          action: "Tu mente está protegida. Continúa con tus actividades del día con tranquilidad."
        };

  // ==========================================
  // ESTADO: RESPIRADOR DIAFRAGMÁTICO CON ORBE BIOACÚSTICO Y VOZ
  // ==========================================
  const [breathingPattern, setBreathingPattern] = useState<"4-2-6" | "4-4-8">("4-2-6");
  const [isBreathingActive, setIsBreathingActive] = useState<boolean>(false);
  const [breathingPhase, setBreathingPhase] = useState<"inactivo" | "inhala" | "manten" | "exhala">("inactivo");
  const [breathingSecondsLeft, setBreathingSecondsLeft] = useState<number>(0);
  const [breathingTotalPhaseSeconds, setBreathingTotalPhaseSeconds] = useState<number>(4);
  const [breathingCycleCount, setBreathingCycleCount] = useState<number>(0);
  const [currentSpeechSubtitle, setCurrentSpeechSubtitle] = useState<string>("");

  const breathingTimerRef = useRef<any>(null);
  const countdownIntervalRef = useRef<any>(null);

  // Probar audio en el dispositivo
  const handleTestAudio = () => {
    unlockAudioEngine();
    playTherapeuticTone("bell");
    speakTherapeuticVoice("Audio verificado correctamente. Listo para guiar los ejercicios en este dispositivo.");
    setAudioStatusNotice("🔊 Audio y voz activados en este dispositivo.");
    setTimeout(() => setAudioStatusNotice(null), 3500);
  };

  useEffect(() => {
    return () => {
      stopTherapeuticVoice();
      if (breathingTimerRef.current) clearTimeout(breathingTimerRef.current);
      if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current);
    };
  }, []);

  const startBreathing = () => {
    unlockAudioEngine();
    setIsBreathingActive(true);
    setBreathingCycleCount(0);
    if (isSoundEffectEnabled) playTherapeuticTone("bell");
    runBreathingCycle(1);
  };

  const stopBreathing = () => {
    if (breathingTimerRef.current) clearTimeout(breathingTimerRef.current);
    if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current);
    stopTherapeuticVoice();
    setIsBreathingActive(false);
    setBreathingPhase("inactivo");
    setBreathingSecondsLeft(0);
    setCurrentSpeechSubtitle("");
  };

  const runBreathingCycle = (currentCycle: number) => {
    const inhaleTime = 4;
    const holdTime = breathingPattern === "4-2-6" ? 2 : 4;
    const exhaleTime = breathingPattern === "4-2-6" ? 6 : 8;

    // --- FASE 1: INHALA POR LA NARIZ (4s) ---
    setBreathingPhase("inhala");
    setBreathingSecondsLeft(inhaleTime);
    setBreathingTotalPhaseSeconds(inhaleTime);
    const inhalePhrase = "Toma aire por la nariz inflando la guatita suavemente.";
    setCurrentSpeechSubtitle(inhalePhrase);

    if (isSoundEffectEnabled) playTherapeuticTone("inhale");
    if (isVoiceGuideEnabled) {
      speakTherapeuticVoice(inhalePhrase);
    }

    if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current);
    countdownIntervalRef.current = setInterval(() => {
      setBreathingSecondsLeft((prev) => {
        if (prev <= 1) {
          clearInterval(countdownIntervalRef.current);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    breathingTimerRef.current = setTimeout(() => {
      // --- FASE 2: MANTÉN EL AIRE (2s o 4s) ---
      setBreathingPhase("manten");
      setBreathingSecondsLeft(holdTime);
      setBreathingTotalPhaseSeconds(holdTime);
      const holdPhrase = "Mantén el aire con calma.";
      setCurrentSpeechSubtitle(holdPhrase);

      if (isSoundEffectEnabled) playTherapeuticTone("hold");
      if (isVoiceGuideEnabled) {
        speakTherapeuticVoice(holdPhrase);
      }

      if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current);
      countdownIntervalRef.current = setInterval(() => {
        setBreathingSecondsLeft((prev) => {
          if (prev <= 1) {
            clearInterval(countdownIntervalRef.current);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);

      breathingTimerRef.current = setTimeout(() => {
        // --- FASE 3: BOTA EL AIRE DESPACIO POR LA BOCA (6s o 8s) ---
        setBreathingPhase("exhala");
        setBreathingSecondsLeft(exhaleTime);
        setBreathingTotalPhaseSeconds(exhaleTime);
        const exhalePhrase = "Bota el aire despacio por la boca, como apagando una vela.";
        setCurrentSpeechSubtitle(exhalePhrase);

        if (isSoundEffectEnabled) playTherapeuticTone("exhale");
        if (isVoiceGuideEnabled) {
          speakTherapeuticVoice(exhalePhrase);
        }

        if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current);
        countdownIntervalRef.current = setInterval(() => {
          setBreathingSecondsLeft((prev) => {
            if (prev <= 1) {
              clearInterval(countdownIntervalRef.current);
              return 0;
            }
            return prev - 1;
          });
        }, 1000);

        breathingTimerRef.current = setTimeout(() => {
          setBreathingCycleCount(currentCycle);
          // Reiniciar ciclo automáticamente
          runBreathingCycle(currentCycle + 1);
        }, exhaleTime * 1000);
      }, holdTime * 1000);
    }, inhaleTime * 1000);
  };

  // ==========================================
  // ESTADO: SURFEO DE LA OLA (15 MINUTOS) CON GUÍA AUDITIVA
  // ==========================================
  const [surfSecondsLeft, setSurfSecondsLeft] = useState<number>(15 * 60);
  const [isSurfRunning, setIsSurfRunning] = useState<boolean>(false);
  const [surfInitialCraving, setSurfInitialCraving] = useState<number>(8);
  const [surfFinalCraving, setSurfFinalCraving] = useState<number>(2);
  const surfTimerRef = useRef<any>(null);

  const toggleSurfTimer = () => {
    unlockAudioEngine();
    if (isSurfRunning) {
      if (surfTimerRef.current) clearInterval(surfTimerRef.current);
      setIsSurfRunning(false);
      stopTherapeuticVoice();
    } else {
      setIsSurfRunning(true);
      if (isSoundEffectEnabled) playTherapeuticTone("bell");
      if (isVoiceGuideEnabled) {
        speakTherapeuticVoice("Iniciamos los quince minutos. Recuerda: las ganas son como una ola en el mar, suben y luego bajan solas.");
      }
    }
  };

  const resetSurfTimer = () => {
    if (surfTimerRef.current) clearInterval(surfTimerRef.current);
    setIsSurfRunning(false);
    setSurfSecondsLeft(15 * 60);
    stopTherapeuticVoice();
  };

  useEffect(() => {
    if (isSurfRunning) {
      surfTimerRef.current = setInterval(() => {
        setSurfSecondsLeft((prev) => {
          if (prev <= 1) {
            clearInterval(surfTimerRef.current);
            setIsSurfRunning(false);
            if (isSoundEffectEnabled) playTherapeuticTone("success");
            if (isVoiceGuideEnabled) {
              speakTherapeuticVoice("¡Felicitaciones! Has completado los quince minutos y surfeado la ola con éxito. Tu cerebro está a salvo.");
            }
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (surfTimerRef.current) clearInterval(surfTimerRef.current);
    }
    return () => {
      if (surfTimerRef.current) clearInterval(surfTimerRef.current);
    };
  }, [isSurfRunning, isSoundEffectEnabled, isVoiceGuideEnabled]);

  const formatTime = (totalSec: number) => {
    const min = Math.floor(totalSec / 60);
    const sec = totalSec % 60;
    return `${min.toString().padStart(2, "0")}:${sec.toString().padStart(2, "0")}`;
  };

  const currentSurfElapsedMinutes = Math.floor((15 * 60 - surfSecondsLeft) / 60);

  const getSurfPhaseInfo = () => {
    if (currentSurfElapsedMinutes < 4) {
      return {
        title: "Fase 1: La Ola está Creciendo (Minutos 0 al 3)",
        advice: "El impulso empieza a subir. Quédate sentado, no salgas de casa y toma un vaso de agua fría.",
        color: "text-blue-400",
        barColor: "bg-blue-500",
        simpleExplanation: "Las ganas se sienten intensas en el pecho o la cabeza, pero recién están comenzando a subir.",
        actionText: "Bebe un sorbo de agua fría y no tomes ninguna decisión ahora."
      };
    } else if (currentSurfElapsedMinutes < 9) {
      return {
        title: "Fase 2: El Pico de la Ola (Minutos 4 al 8 - ¡Momento Clave!)",
        advice: "Estás en la parte más alta de la ola. Es el momento donde más ganas dan, pero solo dura unos minutos. ¡Aguanta, ya casi empieza a bajar!",
        color: "text-amber-400",
        barColor: "bg-amber-500",
        simpleExplanation: "Aquí es donde la mente engaña diciendo que no aguantarás. Recuerda: es solo un pico biológico de dopamina que cae solo.",
        actionText: "Haz 5 respiraciones profundas (4-2-6) y lávate la cara con agua fría."
      };
    } else {
      return {
        title: "Fase 3: La Ola está Bajando (Minutos 9 al 15 - Zona de Alivio)",
        advice: "La ola perdió fuerza. Tu cerebro ya está recuperando el control y las ganas se están apagando.",
        color: "text-emerald-400",
        barColor: "bg-emerald-500",
        simpleExplanation: "El cuerpo ya se está relajando. Felicítate por no haber cedido al impulso.",
        actionText: "Ponte a hacer algo entretenido (ordenar, escuchar música o comer algo rico)."
      };
    }
  };

  const currentSurfPhase = getSurfPhaseInfo();

  const playPhaseAudioAdvice = () => {
    unlockAudioEngine();
    playTherapeuticTone("ding");
    speakTherapeuticVoice(currentSurfPhase.advice);
  };

  // ==========================================
  // ESTADO: AUTORREGISTRO Y EXPORTACIÓN FICHA RAYEN
  // ==========================================
  const [animo, setAnimo] = useState<string>("Tranquilo");
  const [ansiedad, setAnsiedad] = useState<number>(3);
  const [craving, setCraving] = useState<number>(2);
  const [gatillante, setGatillante] = useState<string>("Ninguno");
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const [history, setHistory] = useState<RegistroDiarioItem[]>(() => {
    try {
      const saved = localStorage.getItem("cosam_registro_diario");
      return saved
        ? JSON.parse(saved)
        : [
            {
              id: "1",
              fecha: new Date().toLocaleDateString("es-CL"),
              animo: "Tranquilo",
              ansiedad: 2,
              craving: 1,
              gatillante: "Ninguno",
              herramientaUsada: "Respiración 4-2-6"
            }
          ];
    } catch {
      return [];
    }
  });

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3500);
  };

  const handleSaveRegistro = () => {
    const newItem: RegistroDiarioItem = {
      id: Date.now().toString(),
      fecha: new Date().toLocaleDateString("es-CL") + " " + new Date().toLocaleTimeString("es-CL", { hour: "2-digit", minute: "2-digit" }),
      animo,
      ansiedad,
      craving,
      gatillante,
      herramientaUsada: activeAfrontamientoTab === "respiracion" ? "Respiración Diafragmática" : activeAfrontamientoTab === "surfeo" ? "Surfeo de Ola 15m" : "Protocolo SOS"
    };

    const updated = [newItem, ...history];
    setHistory(updated);
    try {
      localStorage.setItem("cosam_registro_diario", JSON.stringify(updated));
    } catch (e) {}

    playTherapeuticTone("ding");
    showToast("✅ Registro guardado en la memoria clínica.");
  };

  const handleDeleteRegistro = (id: string | number) => {
    const updated = history.filter((h) => h.id !== id);
    setHistory(updated);
    try {
      localStorage.setItem("cosam_registro_diario", JSON.stringify(updated));
    } catch (e) {}
    showToast("🗑️ Registro eliminado.");
  };

  const copyRayenFormat = () => {
    let text = `AUTORREGISTRO & EVALUACIÓN DE GATILLANTES - COSAM RINCONADA (APS)\n`;
    text += `Fecha de Evaluación: ${new Date().toLocaleDateString("es-CL")} ${new Date().toLocaleTimeString("es-CL")}\n`;
    text += `• Estado de Ánimo: ${animo}\n`;
    text += `• Nivel de Ansiedad (EVA 0-10): ${ansiedad}/10\n`;
    text += `• Intensidad de Craving (EVA 0-10): ${craving}/10\n`;
    text += `• Gatillante Principal: ${gatillante}\n`;
    text += `• Herramienta Entrenada: ${activeAfrontamientoTab === "respiracion" ? "Respiración Diafragmática 4-2-6" : activeAfrontamientoTab === "surfeo" ? "Surfeo de la Ola (15 min)" : "Protocolo SOS 5 Pasos"}\n`;
    text += `• Gatillantes Activos Identificados: ${Object.keys(activeTriggers).filter((k) => activeTriggers[k]).join(", ") || "Ninguno"}\n`;
    text += `• Nivel de Riesgo Evaluado: ${riskAssessment.level}\n`;
    text += `• Plan de Afrontamiento: Se refuerza hidratación, técnica de respiración y red de apoyo familiar.\n`;

    navigator.clipboard.writeText(text);
    playTherapeuticTone("ding");
    showToast(
      isStandalonePatientView
        ? "📋 Resumen copiado para compartir con tu médico o equipo de salud."
        : "📋 Formato clínico copiado para pegar directo en Ficha Rayen."
    );
  };

  // Enlace para compartir con paciente
  const getPatientShareUrl = () => {
    if (typeof window === "undefined") return "";
    return `${window.location.origin}/paciente?modulo=afrontamiento`;
  };

  const copyPatientLink = () => {
    const url = getPatientShareUrl();
    navigator.clipboard.writeText(url);
    setCopiedLink(true);
    playTherapeuticTone("ding");
    showToast("📲 Enlace directo para el paciente copiado al portapapeles.");
    setTimeout(() => setCopiedLink(false), 3000);
  };

  const shareViaWhatsApp = () => {
    const url = getPatientShareUrl();
    const message = encodeURIComponent(
      `Hola, te comparto tu Guía Móvil de Bolsillo para momentos de ansiedad o ganas de consumir (Gatillantes & Respiración SOS de COSAM Rinconada). Guárdala en tus favoritos:\n${url}`
    );
    window.open(`https://api.whatsapp.com/send?text=${message}`, "_blank");
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* =========================================================================
          BANNER INSTITUCIONAL: ESTILO iOS 18 (LIQUID GLASS & SQUIRCLE CARD)
         ========================================================================= */}
      <div className="ios-card rounded-3xl p-5 md:p-6 border border-black/[0.04] dark:border-white/[0.06] shadow-sm relative overflow-hidden">
        {/* Glow ambient sutil */}
        <div className="absolute top-0 right-0 w-80 h-full bg-indigo-500/5 dark:bg-indigo-400/5 pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-start sm:items-center gap-3.5">
            <div className="w-11 h-11 rounded-2xl bg-slate-900 dark:bg-white text-white dark:text-slate-900 flex items-center justify-center shadow-xs shrink-0">
              <ShieldCheck size={22} strokeWidth={2} />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2 mb-1">
                <span className="text-[10px] font-semibold tracking-tight text-slate-700 dark:text-slate-300 bg-black/[0.04] dark:bg-white/[0.08] px-2.5 py-0.5 rounded-full">
                  COSAM Rinconada
                </span>
                <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
                  {isStandalonePatientView
                    ? "Guía Móvil Personal de Afrontamiento"
                    : "Suite Psicoeducativa de Afrontamiento"}
                </span>
              </div>
              <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white tracking-tight">
                Gatillantes &amp; Técnicas de Afrontamiento SOS
              </h1>
              <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 font-normal max-w-3xl mt-0.5 leading-relaxed">
                {isStandalonePatientView
                  ? "Identifica qué te detona, respira con el bio-orbe guiado por voz y surfea las ganas de consumir hasta que pasen."
                  : "Identificación de disparadores biológicos y ambientales, respirador bioacústico guiado por voz y surfeo del craving."}
              </p>
            </div>
          </div>

          {/* ACCIONES RÁPIDAS: PROBAR AUDIO & ENTREGAR A PACIENTE */}
          <div className="flex flex-wrap items-center gap-2 shrink-0">
            {/* BOTÓN PROBAR AUDIO */}
            <button
              onClick={handleTestAudio}
              className="px-3.5 py-2 rounded-2xl bg-black/[0.04] hover:bg-black/[0.07] dark:bg-white/[0.08] dark:hover:bg-white/[0.12] text-slate-800 dark:text-slate-200 text-xs font-semibold transition-all flex items-center gap-1.5 border border-black/[0.04] dark:border-white/[0.06] cursor-pointer active:scale-95"
              title="Probar sonido y voz en este dispositivo (Tablets/Móviles)"
            >
              <Volume2 size={14} className="text-slate-600 dark:text-slate-400" />
              <span>Probar Audio</span>
            </button>

            {/* BOTÓN LLEVAR EN EL CELULAR O GUARDAR */}
            {!isStandalonePatientView ? (
              <button
                onClick={() => setIsShareModalOpen(true)}
                className="px-4 py-2 rounded-2xl bg-slate-900 hover:bg-slate-800 dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-900 text-xs font-semibold shadow-xs transition-all flex items-center gap-2 cursor-pointer active:scale-95"
                title="Generar QR y enlace para que el paciente lo use en su celular"
              >
                <Smartphone size={14} />
                <span>Llevar en el Celular</span>
              </button>
            ) : (
              <a
                href="tel:1412"
                className="px-3.5 py-2 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold shadow-xs transition-all flex items-center gap-1.5"
                title="Llamada gratuita a Fono Drogas 1412"
              >
                <PhoneCall size={14} />
                <span>Fono SENDA 1412</span>
              </a>
            )}
          </div>
        </div>

        {/* Notificación temporal de audio */}
        {audioStatusNotice && (
          <motion.div
            initial={{ opacity: 0, y: -6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="mt-3 p-2 rounded-xl bg-purple-100 dark:bg-purple-950/60 border border-purple-300 dark:border-purple-800 text-purple-900 dark:text-purple-200 text-xs font-bold flex items-center gap-2"
          >
            <Sparkles size={14} className="text-purple-600 dark:text-purple-400" />
            <span>{audioStatusNotice}</span>
          </motion.div>
        )}
      </div>

      {/* =========================================================================
          MODAL PARA COMPARTIR CON EL PACIENTE (CÓDIGO QR + WHATSAPP)
         ========================================================================= */}
      <AnimatePresence>
        {isShareModalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/70 backdrop-blur-md flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-slate-900 rounded-3xl p-6 md:p-8 max-w-md w-full border border-purple-200 dark:border-purple-800 shadow-2xl space-y-5"
            >
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300 flex items-center justify-center font-bold">
                    <Smartphone size={20} />
                  </div>
                  <div>
                    <h3 className="text-base font-black text-slate-900 dark:text-white">
                      Guía Móvil para el Paciente
                    </h3>
                    <p className="text-[11px] font-semibold text-slate-500">
                      Módulo de Bolsillo (Solo Gatillantes &amp; SOS)
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setIsShareModalOpen(false)}
                  className="p-1.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500"
                >
                  <X size={18} />
                </button>
              </div>

              {/* CÓDIGO QR INTERACTIVO EN SVG */}
              <div className="flex flex-col items-center justify-center p-4 rounded-2xl bg-slate-50 dark:bg-slate-950/80 border border-slate-200 dark:border-slate-800 text-center space-y-3">
                <div className="p-3 bg-white rounded-2xl shadow-sm border border-slate-200">
                  {/* SVG QR Code Estilizado y Nítido */}
                  <svg viewBox="0 0 160 160" className="w-36 h-36">
                    <rect width="160" height="160" fill="white" />
                    {/* Marcadores de esquina */}
                    <rect x="10" y="10" width="40" height="40" fill="#4338ca" rx="6" />
                    <rect x="18" y="18" width="24" height="24" fill="white" rx="3" />
                    <rect x="24" y="24" width="12" height="12" fill="#4338ca" rx="2" />

                    <rect x="110" y="10" width="40" height="40" fill="#4338ca" rx="6" />
                    <rect x="118" y="18" width="24" height="24" fill="white" rx="3" />
                    <rect x="124" y="24" width="12" height="12" fill="#4338ca" rx="2" />

                    <rect x="10" y="110" width="40" height="40" fill="#4338ca" rx="6" />
                    <rect x="18" y="118" width="24" height="24" fill="white" rx="3" />
                    <rect x="24" y="124" width="12" height="12" fill="#4338ca" rx="2" />

                    {/* Patrón de puntos clínicos */}
                    <circle cx="65" cy="20" r="4" fill="#6366f1" />
                    <circle cx="80" cy="20" r="4" fill="#1e1b4b" />
                    <circle cx="95" cy="20" r="4" fill="#6366f1" />
                    <circle cx="65" cy="35" r="4" fill="#1e1b4b" />
                    <circle cx="80" cy="35" r="4" fill="#6366f1" />
                    <circle cx="95" cy="35" r="4" fill="#1e1b4b" />

                    <circle cx="20" cy="65" r="4" fill="#6366f1" />
                    <circle cx="35" cy="65" r="4" fill="#1e1b4b" />
                    <circle cx="20" cy="80" r="4" fill="#1e1b4b" />
                    <circle cx="35" cy="80" r="4" fill="#6366f1" />
                    <circle cx="20" cy="95" r="4" fill="#6366f1" />
                    <circle cx="35" cy="95" r="4" fill="#1e1b4b" />

                    {/* Centro con logo */}
                    <rect x="60" y="60" width="40" height="40" fill="#f5f3ff" rx="10" stroke="#c4b5fd" strokeWidth="2" />
                    <circle cx="80" cy="80" r="10" fill="#6366f1" />

                    {/* Parte inferior derecha */}
                    <circle cx="65" cy="120" r="4" fill="#1e1b4b" />
                    <circle cx="80" cy="120" r="4" fill="#6366f1" />
                    <circle cx="95" cy="120" r="4" fill="#1e1b4b" />
                    <circle cx="120" cy="65" r="4" fill="#6366f1" />
                    <circle cx="135" cy="65" r="4" fill="#1e1b4b" />
                    <circle cx="120" cy="80" r="4" fill="#1e1b4b" />
                    <circle cx="135" cy="80" r="4" fill="#6366f1" />
                    <circle cx="120" cy="95" r="4" fill="#6366f1" />
                    <circle cx="135" cy="95" r="4" fill="#1e1b4b" />
                    <circle cx="120" cy="120" r="4" fill="#6366f1" />
                    <circle cx="135" cy="135" r="4" fill="#1e1b4b" />
                  </svg>
                </div>

                <div>
                  <h4 className="text-xs font-black text-slate-800 dark:text-slate-200">
                    Escanea con la cámara del celular
                  </h4>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 max-w-xs mt-0.5">
                    El paciente abrirá directamente este módulo limpio, sin barras ni fichas médicas, listo para usar cuando sienta ansiedad.
                  </p>
                </div>
              </div>

              {/* BOTONES DE COMPARTIR */}
              <div className="space-y-2">
                <button
                  onClick={copyPatientLink}
                  className="w-full py-2.5 px-4 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-sm"
                >
                  <Copy size={14} />
                  <span>{copiedLink ? "¡Enlace Copiado!" : "Copiar Enlace Directo"}</span>
                </button>

                <button
                  onClick={shareViaWhatsApp}
                  className="w-full py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-sm"
                >
                  <Send size={14} />
                  <span>Enviar por WhatsApp a Paciente</span>
                </button>
              </div>

              <div className="text-center pt-1 border-t border-slate-100 dark:border-slate-800">
                <span className="text-[10px] text-slate-400 font-semibold">
                  COSAM Rinconada • Centro de Salud Mental Comunitario
                </span>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* =========================================================================
          SELECTOR DE VISTAS PRINCIPALES (ESTILO iOS SEGMENTED CONTROL)
         ========================================================================= */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-black/[0.04] dark:border-white/[0.06] pb-3">
        <div className="ios-segmented flex items-center shadow-3xs">
          <button
            onClick={() => setViewMode("dual")}
            className={`px-3.5 py-1.5 rounded-xl transition-all flex items-center gap-1.5 text-xs font-semibold cursor-pointer ${
              viewMode === "dual"
                ? "bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-2xs"
                : "text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
            }`}
          >
            <Compass size={13} />
            <span>Vista Integrada</span>
          </button>

          <button
            onClick={() => setViewMode("gatillantes")}
            className={`px-3.5 py-1.5 rounded-xl transition-all flex items-center gap-1.5 text-xs font-semibold cursor-pointer ${
              viewMode === "gatillantes"
                ? "bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-2xs"
                : "text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
            }`}
          >
            <Flame size={13} />
            <span>Gatillantes ({activeTriggersCount})</span>
          </button>

          <button
            onClick={() => setViewMode("afrontamiento")}
            className={`px-3.5 py-1.5 rounded-xl transition-all flex items-center gap-1.5 text-xs font-semibold cursor-pointer ${
              viewMode === "afrontamiento"
                ? "bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-2xs"
                : "text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
            }`}
          >
            <ShieldCheck size={13} />
            <span>Técnicas SOS</span>
          </button>

          <button
            onClick={() => setViewMode("registro")}
            className={`px-3.5 py-1.5 rounded-xl transition-all flex items-center gap-1.5 text-xs font-semibold cursor-pointer ${
              viewMode === "registro"
                ? "bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-2xs"
                : "text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
            }`}
          >
            <ClipboardList size={13} />
            <span>Autorregistro ({history.length})</span>
          </button>
        </div>

        {/* SEMÁFORO DE RIESGO RESUMIDO (iOS PILL) */}
        <div className={`px-3.5 py-1.5 rounded-full border ${riskAssessment.bgColor} ${riskAssessment.borderColor} flex items-center gap-2 shadow-3xs`}>
          <span className="relative flex h-2 w-2">
            <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${activeTriggersCount >= 3 ? "bg-rose-400" : "bg-emerald-400"}`} />
            <span className={`relative inline-flex rounded-full h-2 w-2 ${activeTriggersCount >= 5 ? "bg-rose-500" : activeTriggersCount >= 3 ? "bg-amber-500" : "bg-emerald-500"}`} />
          </span>
          <span className={`text-xs font-semibold ${riskAssessment.color}`}>
            {riskAssessment.badge}: {riskAssessment.level}
          </span>
        </div>
      </div>

      {/* =========================================================================
          CONTENEDOR PRINCIPAL: GATILLANTES + TÉCNICAS DE AFRONTAMIENTO
         ========================================================================= */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
        {/* -----------------------------------------------------------------------
            SECCIÓN 1: GATILLANTES DE CONSUMO (INTERNOS H.A.L.T. Y EXTERNOS)
           ----------------------------------------------------------------------- */}
        {(viewMode === "dual" || viewMode === "gatillantes") && (
          <div
            className={`space-y-5 rounded-3xl p-6 backdrop-blur-xl bg-white/70 dark:bg-slate-900/80 border border-purple-200/70 dark:border-purple-900/40 shadow-sm ${
              viewMode === "dual" ? "xl:col-span-6" : "w-full"
            }`}
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-purple-100 dark:border-purple-900/40 pb-4">
              <div className="flex items-center gap-2.5">
                <div className="p-2.5 rounded-2xl bg-amber-500/10 dark:bg-amber-500/20 text-amber-600 dark:text-amber-400 border border-amber-500/20">
                  <Flame size={20} />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-black uppercase tracking-wider text-amber-600 dark:text-amber-400">
                      Paso 1
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.2 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                      Identificar el Disparador
                    </span>
                  </div>
                  <h2 className="text-lg font-black text-slate-900 dark:text-white">
                    Gatillantes de Consumo
                  </h2>
                </div>
              </div>

              {/* FILTRO CATEGORIAL */}
              <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-100 dark:bg-slate-950/80 border border-slate-200 dark:border-slate-800 text-xs">
                <button
                  onClick={() => setActiveGatillanteCategory("todos")}
                  className={`px-2.5 py-1 rounded-lg font-bold transition-all ${
                    activeGatillanteCategory === "todos"
                      ? "bg-white dark:bg-slate-800 text-purple-700 dark:text-purple-300 shadow-xs"
                      : "text-slate-500 hover:text-slate-900 dark:hover:text-white"
                  }`}
                >
                  Todos
                </button>
                <button
                  onClick={() => setActiveGatillanteCategory("internos")}
                  className={`px-2.5 py-1 rounded-lg font-bold transition-all ${
                    activeGatillanteCategory === "internos"
                      ? "bg-white dark:bg-slate-800 text-purple-700 dark:text-purple-300 shadow-xs"
                      : "text-slate-500 hover:text-slate-900 dark:hover:text-white"
                  }`}
                >
                  Cuerpo / Emociones
                </button>
                <button
                  onClick={() => setActiveGatillanteCategory("externos")}
                  className={`px-2.5 py-1 rounded-lg font-bold transition-all ${
                    activeGatillanteCategory === "externos"
                      ? "bg-white dark:bg-slate-800 text-purple-700 dark:text-purple-300 shadow-xs"
                      : "text-slate-500 hover:text-slate-900 dark:hover:text-white"
                  }`}
                >
                  Calle / Entorno
                </button>
              </div>
            </div>

            {/* --- SUBSECCIÓN A: GATILLANTES INTERNOS (H.A.L.T.) --- */}
            {(activeGatillanteCategory === "todos" || activeGatillanteCategory === "internos") && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Brain size={16} className="text-purple-600 dark:text-purple-400" />
                    <h3 className="text-xs font-black uppercase tracking-wider text-slate-800 dark:text-slate-200">
                      Gatillantes Internos (El Cuerpo y las Emociones)
                    </h3>
                  </div>
                  <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400">
                    Regla H.A.L.T.
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {/* HUNGRY (Hambre / Guatita vacía) */}
                  <div
                    onClick={() => toggleTrigger("hambre")}
                    className={`p-4 rounded-2xl border transition-all cursor-pointer select-none space-y-2.5 ${
                      activeTriggers.hambre
                        ? "bg-amber-500/15 border-amber-500/60 shadow-sm"
                        : "bg-white/80 dark:bg-slate-900/60 border-slate-200 dark:border-slate-800 hover:border-amber-400/50"
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <div className="w-7 h-7 rounded-xl bg-amber-100 dark:bg-amber-950/80 text-amber-700 dark:text-amber-300 flex items-center justify-center font-black">
                          <Utensils size={15} />
                        </div>
                        <div>
                          <h4 className="text-xs font-black text-slate-900 dark:text-white">
                            Hambre / Guatita Vacía
                          </h4>
                          <span className="text-[10px] text-amber-700 dark:text-amber-300 font-bold">
                            (H - Hungry)
                          </span>
                        </div>
                      </div>
                      <div
                        className={`w-5 h-5 rounded-lg border flex items-center justify-center ${
                          activeTriggers.hambre
                            ? "bg-amber-600 border-amber-600 text-white"
                            : "border-slate-300 dark:border-slate-600"
                        }`}
                      >
                        {activeTriggers.hambre && <Check size={14} strokeWidth={3} />}
                      </div>
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-300 font-medium leading-relaxed">
                      Cuando pasa mucho rato sin comer, el cerebro se queda sin energía y confunde el hambre con ganas de consumir.
                    </p>
                    <div className="p-2 rounded-xl bg-amber-500/10 dark:bg-amber-950/40 text-[11px] font-bold text-amber-800 dark:text-amber-200 flex items-center gap-1.5">
                      <span>🍎 <strong>Qué hacer ya:</strong> Comer una fruta, pan o tomar un vaso de leche.</span>
                    </div>
                  </div>

                  {/* ANGRY (Enojo / Rabia / Discusión) */}
                  <div
                    onClick={() => toggleTrigger("enojo")}
                    className={`p-4 rounded-2xl border transition-all cursor-pointer select-none space-y-2.5 ${
                      activeTriggers.enojo
                        ? "bg-rose-500/15 border-rose-500/60 shadow-sm"
                        : "bg-white/80 dark:bg-slate-900/60 border-slate-200 dark:border-slate-800 hover:border-rose-400/50"
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <div className="w-7 h-7 rounded-xl bg-rose-100 dark:bg-rose-950/80 text-rose-700 dark:text-rose-300 flex items-center justify-center font-black">
                          <Flame size={15} />
                        </div>
                        <div>
                          <h4 className="text-xs font-black text-slate-900 dark:text-white">
                            Rabia / Discusión Familiar
                          </h4>
                          <span className="text-[10px] text-rose-700 dark:text-rose-300 font-bold">
                            (A - Angry)
                          </span>
                        </div>
                      </div>
                      <div
                        className={`w-5 h-5 rounded-lg border flex items-center justify-center ${
                          activeTriggers.enojo
                            ? "bg-rose-600 border-rose-600 text-white"
                            : "border-slate-300 dark:border-slate-600"
                        }`}
                      >
                        {activeTriggers.enojo && <Check size={14} strokeWidth={3} />}
                      </div>
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-300 font-medium leading-relaxed">
                      El enojo o la pelea acelera el corazón e impulsa a buscar la sustancia para "apagar" la emoción de golpe.
                    </p>
                    <div className="p-2 rounded-xl bg-rose-500/10 dark:bg-rose-950/40 text-[11px] font-bold text-rose-800 dark:text-rose-200 flex items-center gap-1.5">
                      <span>❄️ <strong>Qué hacer ya:</strong> Lavarse la cara con agua fría y salir de la pieza 5 minutos.</span>
                    </div>
                  </div>

                  {/* LONELY (Soledad / Sentirse Aislado) */}
                  <div
                    onClick={() => toggleTrigger("soledad")}
                    className={`p-4 rounded-2xl border transition-all cursor-pointer select-none space-y-2.5 ${
                      activeTriggers.soledad
                        ? "bg-indigo-500/15 border-indigo-500/60 shadow-sm"
                        : "bg-white/80 dark:bg-slate-900/60 border-slate-200 dark:border-slate-800 hover:border-indigo-400/50"
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <div className="w-7 h-7 rounded-xl bg-indigo-100 dark:bg-indigo-950/80 text-indigo-700 dark:text-indigo-300 flex items-center justify-center font-black">
                          <Users size={15} />
                        </div>
                        <div>
                          <h4 className="text-xs font-black text-slate-900 dark:text-white">
                            Soledad / Sentirse Solo/a
                          </h4>
                          <span className="text-[10px] text-indigo-700 dark:text-indigo-300 font-bold">
                            (L - Lonely)
                          </span>
                        </div>
                      </div>
                      <div
                        className={`w-5 h-5 rounded-lg border flex items-center justify-center ${
                          activeTriggers.soledad
                            ? "bg-indigo-600 border-indigo-600 text-white"
                            : "border-slate-300 dark:border-slate-600"
                        }`}
                      >
                        {activeTriggers.soledad && <Check size={14} strokeWidth={3} />}
                      </div>
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-300 font-medium leading-relaxed">
                      El aburrimiento o el vacío afectivo hace que el cerebro extrañe la compañía falsa de la sustancia.
                    </p>
                    <div className="p-2 rounded-xl bg-indigo-500/10 dark:bg-indigo-950/40 text-[11px] font-bold text-indigo-800 dark:text-indigo-200 flex items-center gap-1.5">
                      <span>📞 <strong>Qué hacer ya:</strong> Llamar a alguien de confianza o mandar un audio de WhatsApp.</span>
                    </div>
                  </div>

                  {/* TIRED (Cansancio / Sueño Acumulado) */}
                  <div
                    onClick={() => toggleTrigger("cansancio")}
                    className={`p-4 rounded-2xl border transition-all cursor-pointer select-none space-y-2.5 ${
                      activeTriggers.cansancio
                        ? "bg-teal-500/15 border-teal-500/60 shadow-sm"
                        : "bg-white/80 dark:bg-slate-900/60 border-slate-200 dark:border-slate-800 hover:border-teal-400/50"
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <div className="w-7 h-7 rounded-xl bg-teal-100 dark:bg-teal-950/80 text-teal-700 dark:text-teal-300 flex items-center justify-center font-black">
                          <Moon size={15} />
                        </div>
                        <div>
                          <h4 className="text-xs font-black text-slate-900 dark:text-white">
                            Cansancio / Sueño Acumulado
                          </h4>
                          <span className="text-[10px] text-teal-700 dark:text-teal-300 font-bold">
                            (T - Tired)
                          </span>
                        </div>
                      </div>
                      <div
                        className={`w-5 h-5 rounded-lg border flex items-center justify-center ${
                          activeTriggers.cansancio
                            ? "bg-teal-600 border-teal-600 text-white"
                            : "border-slate-300 dark:border-slate-600"
                        }`}
                      >
                        {activeTriggers.cansancio && <Check size={14} strokeWidth={3} />}
                      </div>
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-300 font-medium leading-relaxed">
                      Estar agotado quita la fuerza de voluntad. La mayoría de las recaídas nocturnas ocurren por falta de sueño.
                    </p>
                    <div className="p-2 rounded-xl bg-teal-500/10 dark:bg-teal-950/40 text-[11px] font-bold text-teal-800 dark:text-teal-200 flex items-center gap-1.5">
                      <span>🛏️ <strong>Qué hacer ya:</strong> Acostarse de inmediato y tomar un té de manzanilla o agua tibia.</span>
                    </div>
                  </div>

                  {/* PENSAMIENTO TRAMPA */}
                  <div
                    onClick={() => toggleTrigger("pensamiento_trampa")}
                    className={`p-4 rounded-2xl border transition-all cursor-pointer select-none space-y-2.5 sm:col-span-2 ${
                      activeTriggers.pensamiento_trampa
                        ? "bg-purple-500/15 border-purple-500/60 shadow-sm"
                        : "bg-white/80 dark:bg-slate-900/60 border-slate-200 dark:border-slate-800 hover:border-purple-400/50"
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <div className="w-7 h-7 rounded-xl bg-purple-100 dark:bg-purple-950/80 text-purple-700 dark:text-purple-300 flex items-center justify-center font-black">
                          <Zap size={15} />
                        </div>
                        <div>
                          <h4 className="text-xs font-black text-slate-900 dark:text-white">
                            Pensamiento Engañoso («Solo un trago o una pitada, ya me curé»)
                          </h4>
                          <span className="text-[10px] text-purple-700 dark:text-purple-300 font-bold">
                            Trampa de la Dopamina
                          </span>
                        </div>
                      </div>
                      <div
                        className={`w-5 h-5 rounded-lg border flex items-center justify-center ${
                          activeTriggers.pensamiento_trampa
                            ? "bg-purple-600 border-purple-600 text-white"
                            : "border-slate-300 dark:border-slate-600"
                        }`}
                      >
                        {activeTriggers.pensamiento_trampa && <Check size={14} strokeWidth={3} />}
                      </div>
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-300 font-medium leading-relaxed">
                      El cerebro en abstinencia intenta negociar para obtener placer inmediato. Es una ilusión química.
                    </p>
                    <div className="p-2 rounded-xl bg-purple-500/10 dark:bg-purple-950/40 text-[11px] font-bold text-purple-800 dark:text-purple-200 flex items-center gap-1.5">
                      <span>🎬 <strong>Qué hacer ya:</strong> Mirar la película completa: recordar cómo terminó la última vez.</span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* --- SUBSECCIÓN B: GATILLANTES EXTERNOS --- */}
            {(activeGatillanteCategory === "todos" || activeGatillanteCategory === "externos") && (
              <div className="space-y-3 pt-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <MapPin size={16} className="text-indigo-600 dark:text-indigo-400" />
                    <h3 className="text-xs font-black uppercase tracking-wider text-slate-800 dark:text-slate-200">
                      Gatillantes Externos (La Calle, el Bolsillo y las Personas)
                    </h3>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {/* DINERO EN EFECTIVO */}
                  <div
                    onClick={() => toggleTrigger("efectivo")}
                    className={`p-3.5 rounded-2xl border transition-all cursor-pointer select-none space-y-1.5 ${
                      activeTriggers.efectivo
                        ? "bg-emerald-500/15 border-emerald-500/60 shadow-sm"
                        : "bg-white/80 dark:bg-slate-900/60 border-slate-200 dark:border-slate-800 hover:border-emerald-400/50"
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Banknote size={16} className="text-emerald-600 dark:text-emerald-400" />
                        <span className="text-xs font-black text-slate-900 dark:text-white">
                          Plata en Mano (Efectivo en el Bolsillo)
                        </span>
                      </div>
                      <div
                        className={`w-4 h-4 rounded-md border flex items-center justify-center ${
                          activeTriggers.efectivo
                            ? "bg-emerald-600 border-emerald-600 text-white"
                            : "border-slate-300 dark:border-slate-600"
                        }`}
                      >
                        {activeTriggers.efectivo && <Check size={12} strokeWidth={3} />}
                      </div>
                    </div>
                    <p className="text-[11px] text-slate-600 dark:text-slate-300 font-medium">
                      Tener billetes sueltos reduce el tiempo de freno entre el impulso y la compra.
                    </p>
                    <span className="text-[10px] font-bold text-emerald-800 dark:text-emerald-300 block">
                      🛡️ Solución: Entregar la plata a familiar o pagar cuentas de inmediato por internet.
                    </span>
                  </div>

                  {/* AMIGOS DE CONSUMO */}
                  <div
                    onClick={() => toggleTrigger("amigos_consumo")}
                    className={`p-3.5 rounded-2xl border transition-all cursor-pointer select-none space-y-1.5 ${
                      activeTriggers.amigos_consumo
                        ? "bg-rose-500/15 border-rose-500/60 shadow-sm"
                        : "bg-white/80 dark:bg-slate-900/60 border-slate-200 dark:border-slate-800 hover:border-rose-400/50"
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <UserX size={16} className="text-rose-600 dark:text-rose-400" />
                        <span className="text-xs font-black text-slate-900 dark:text-white">
                          Contacto con "Amigos" de Consumo
                        </span>
                      </div>
                      <div
                        className={`w-4 h-4 rounded-md border flex items-center justify-center ${
                          activeTriggers.amigos_consumo
                            ? "bg-rose-600 border-rose-600 text-white"
                            : "border-slate-300 dark:border-slate-600"
                        }`}
                      >
                        {activeTriggers.amigos_consumo && <Check size={12} strokeWidth={3} />}
                      </div>
                    </div>
                    <p className="text-[11px] text-slate-600 dark:text-slate-300 font-medium">
                      El cerebro asocia su presencia inmediatamente con la recompensa artificial.
                    </p>
                    <span className="text-[10px] font-bold text-rose-800 dark:text-rose-300 block">
                      🛡️ Solución: Bloquear números en WhatsApp y no responder llamadas de riesgo.
                    </span>
                  </div>

                  {/* HORARIOS CRÍTICOS */}
                  <div
                    onClick={() => toggleTrigger("horario_critico")}
                    className={`p-3.5 rounded-2xl border transition-all cursor-pointer select-none space-y-1.5 ${
                      activeTriggers.horario_critico
                        ? "bg-amber-500/15 border-amber-500/60 shadow-sm"
                        : "bg-white/80 dark:bg-slate-900/60 border-slate-200 dark:border-slate-800 hover:border-amber-400/50"
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Clock size={16} className="text-amber-600 dark:text-amber-400" />
                        <span className="text-xs font-black text-slate-900 dark:text-white">
                          Viernes por la Tarde / Noche de Pago
                        </span>
                      </div>
                      <div
                        className={`w-4 h-4 rounded-md border flex items-center justify-center ${
                          activeTriggers.horario_critico
                            ? "bg-amber-600 border-amber-600 text-white"
                            : "border-slate-300 dark:border-slate-600"
                        }`}
                      >
                        {activeTriggers.horario_critico && <Check size={12} strokeWidth={3} />}
                      </div>
                    </div>
                    <p className="text-[11px] text-slate-600 dark:text-slate-300 font-medium">
                      El fin de semana es el momento de mayor vulnerabilidad social y desconexión.
                    </p>
                    <span className="text-[10px] font-bold text-amber-800 dark:text-amber-300 block">
                      🛡️ Solución: Planificar panorama familiar temprano o cena en casa antes de las 20:00.
                    </span>
                  </div>

                  {/* RUTAS DE RIESGO */}
                  <div
                    onClick={() => toggleTrigger("rutas_riesgo")}
                    className={`p-3.5 rounded-2xl border transition-all cursor-pointer select-none space-y-1.5 ${
                      activeTriggers.rutas_riesgo
                        ? "bg-purple-500/15 border-purple-500/60 shadow-sm"
                        : "bg-white/80 dark:bg-slate-900/60 border-slate-200 dark:border-slate-800 hover:border-purple-400/50"
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <MapPin size={16} className="text-purple-600 dark:text-purple-400" />
                        <span className="text-xs font-black text-slate-900 dark:text-white">
                          Pasar por Botillería o Esquina de Riesgo
                        </span>
                      </div>
                      <div
                        className={`w-4 h-4 rounded-md border flex items-center justify-center ${
                          activeTriggers.rutas_riesgo
                            ? "bg-purple-600 border-purple-600 text-white"
                            : "border-slate-300 dark:border-slate-600"
                        }`}
                      >
                        {activeTriggers.rutas_riesgo && <Check size={12} strokeWidth={3} />}
                      </div>
                    </div>
                    <p className="text-[11px] text-slate-600 dark:text-slate-300 font-medium">
                      El camino de siempre tiene recuerdos grabados que despiertan el impulso.
                    </p>
                    <span className="text-[10px] font-bold text-purple-800 dark:text-purple-300 block">
                      🛡️ Solución: Tomar otra calle para volver a la casa, aunque camines 5 minutos más.
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* -----------------------------------------------------------------------
            SECCIÓN 2: TÉCNICAS DE AFRONTAMIENTO (CON ORBE BIO-RESPIRATORIO DE ALTA GAMA)
           ----------------------------------------------------------------------- */}
        {(viewMode === "dual" || viewMode === "afrontamiento") && (
          <div
            className={`space-y-5 rounded-3xl p-6 backdrop-blur-xl bg-white/70 dark:bg-slate-900/80 border border-indigo-200/70 dark:border-indigo-900/40 shadow-sm ${
              viewMode === "dual" ? "xl:col-span-6" : "w-full"
            }`}
          >
            {/* ENCABEZADO DE SECCIÓN 2 */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-indigo-100 dark:border-indigo-900/40 pb-4">
              <div className="flex items-center gap-2.5">
                <div className="p-2.5 rounded-2xl bg-indigo-500/10 dark:bg-indigo-500/20 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20">
                  <ShieldCheck size={20} />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-black uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
                      Paso 2
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.2 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                      Herramientas Prácticas
                    </span>
                  </div>
                  <h2 className="text-lg font-black text-slate-900 dark:text-white">
                    Técnicas de Afrontamiento
                  </h2>
                </div>
              </div>

              {/* NAVEGADOR DE TÉCNICAS */}
              <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-100 dark:bg-slate-950/80 border border-slate-200 dark:border-slate-800 text-xs">
                <button
                  onClick={() => {
                    stopBreathing();
                    setActiveAfrontamientoTab("respiracion");
                  }}
                  className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center gap-1.5 ${
                    activeAfrontamientoTab === "respiracion"
                      ? "bg-indigo-600 text-white shadow-xs"
                      : "text-slate-500 hover:text-slate-900 dark:hover:text-white"
                  }`}
                >
                  <Wind size={14} />
                  <span>1. Respiración</span>
                </button>

                <button
                  onClick={() => {
                    stopBreathing();
                    setActiveAfrontamientoTab("surfeo");
                  }}
                  className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center gap-1.5 ${
                    activeAfrontamientoTab === "surfeo"
                      ? "bg-indigo-600 text-white shadow-xs"
                      : "text-slate-500 hover:text-slate-900 dark:hover:text-white"
                  }`}
                >
                  <Timer size={14} />
                  <span>2. Surfeo (15m)</span>
                </button>

                <button
                  onClick={() => {
                    stopBreathing();
                    setActiveAfrontamientoTab("protocolo");
                  }}
                  className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center gap-1.5 ${
                    activeAfrontamientoTab === "protocolo"
                      ? "bg-indigo-600 text-white shadow-xs"
                      : "text-slate-500 hover:text-slate-900 dark:hover:text-white"
                  }`}
                >
                  <ShieldCheck size={14} />
                  <span>3. SOS 5 Pasos</span>
                </button>
              </div>
            </div>

            {/* ===================================================================
                TÉCNICA 1: ORBE BIO-RESPIRATORIO DE ALTA GAMA (APPLE HEALTH STYLE)
               =================================================================== */}
            {activeAfrontamientoTab === "respiracion" && (
              <div className="space-y-5">
                <div className="p-5 md:p-6 rounded-3xl bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-900 text-white border border-indigo-800/40 shadow-2xl space-y-6 relative overflow-hidden">
                  
                  {/* Encabezado del Ejercicio */}
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-white/10 pb-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-black uppercase tracking-wider text-indigo-300">
                          Respiración Diafragmática Bioacústica
                        </span>
                        {isVoiceGuideEnabled && (
                          <span className="text-[9px] font-black px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1">
                            <Volume2 size={10} /> Voz y Tonos Activos
                          </span>
                        )}
                      </div>
                      <h3 className="text-base md:text-lg font-black text-white">
                        Oxigenación &amp; Descompresión Vagal
                      </h3>
                    </div>

                    <div className="flex items-center gap-1.5 p-1 rounded-xl bg-black/40 border border-white/10">
                      <button
                        onClick={() => {
                          stopBreathing();
                          setBreathingPattern("4-2-6");
                        }}
                        className={`px-3 py-1 rounded-lg text-xs font-black transition-all ${
                          breathingPattern === "4-2-6"
                            ? "bg-indigo-600 text-white shadow-xs"
                            : "text-slate-400 hover:text-white"
                        }`}
                      >
                        4-2-6 (SOS Rápido)
                      </button>
                      <button
                        onClick={() => {
                          stopBreathing();
                          setBreathingPattern("4-4-8");
                        }}
                        className={`px-3 py-1 rounded-lg text-xs font-black transition-all ${
                          breathingPattern === "4-4-8"
                            ? "bg-indigo-600 text-white shadow-xs"
                            : "text-slate-400 hover:text-white"
                        }`}
                      >
                        4-4-8 (Para Dormir)
                      </button>
                    </div>
                  </div>

                  {/* =================================================================
                      CENTRAL: EL ORBE BIO-RESPIRATORIO DE ALTA GAMA (LIMPIO Y ELEGANTE)
                     ================================================================= */}
                  <div className="py-6 flex flex-col items-center justify-center space-y-6">
                    <div className="relative flex items-center justify-center w-64 h-64 sm:w-72 sm:h-72">
                      {/* 1. Anillo exterior pulsante con ondas */}
                      <motion.div
                        animate={{
                          scale:
                            breathingPhase === "inhala"
                              ? [1.0, 1.45]
                              : breathingPhase === "manten"
                              ? 1.45
                              : breathingPhase === "exhala"
                              ? [1.45, 1.0]
                              : 1.0,
                          opacity: breathingPhase === "inactivo" ? 0.15 : [0.3, 0.7, 0.4]
                        }}
                        transition={{
                          duration:
                            breathingPhase === "inhala"
                              ? 4
                              : breathingPhase === "exhala"
                              ? breathingPattern === "4-2-6"
                                ? 6
                                : 8
                              : 1,
                          ease: "easeInOut"
                        }}
                        className={`absolute inset-0 rounded-full blur-2xl transition-colors ${
                          breathingPhase === "inhala"
                            ? "bg-cyan-500/40"
                            : breathingPhase === "manten"
                            ? "bg-amber-400/40"
                            : breathingPhase === "exhala"
                            ? "bg-indigo-500/40"
                            : "bg-purple-600/20"
                        }`}
                      />

                      {/* 2. Anillo de volumen y sincronía */}
                      <motion.div
                        animate={{
                          scale:
                            breathingPhase === "inhala"
                              ? 1.35
                              : breathingPhase === "manten"
                              ? 1.35
                              : 1.0,
                          rotate: isBreathingActive ? 360 : 0
                        }}
                        transition={{
                          scale: {
                            duration:
                              breathingPhase === "inhala"
                                ? 4
                                : breathingPhase === "exhala"
                                ? breathingPattern === "4-2-6"
                                  ? 6
                                  : 8
                                : 0.5,
                            ease: "easeInOut"
                          },
                          rotate: {
                            repeat: Infinity,
                            duration: 20,
                            ease: "linear"
                          }
                        }}
                        className={`absolute w-48 h-48 sm:w-56 sm:h-56 rounded-full border-2 border-dashed ${
                          breathingPhase === "inhala"
                            ? "border-cyan-400/60"
                            : breathingPhase === "manten"
                            ? "border-amber-400/60"
                            : breathingPhase === "exhala"
                            ? "border-indigo-400/60"
                            : "border-white/20"
                        }`}
                      />

                      {/* 3. El Orbe Central que se expande durante la inhalación y se contrae al botar el aire */}
                      <motion.div
                        animate={{
                          scale:
                            breathingPhase === "inhala"
                              ? 1.25
                              : breathingPhase === "manten"
                              ? 1.25
                              : breathingPhase === "exhala"
                              ? 0.85
                              : 1.0,
                          boxShadow:
                            breathingPhase === "inhala"
                              ? "0 0 50px rgba(6, 182, 212, 0.6)"
                              : breathingPhase === "manten"
                              ? "0 0 50px rgba(251, 191, 36, 0.6)"
                              : breathingPhase === "exhala"
                              ? "0 0 30px rgba(99, 102, 241, 0.4)"
                              : "0 0 20px rgba(255, 255, 255, 0.1)"
                        }}
                        transition={{
                          duration:
                            breathingPhase === "inhala"
                              ? 4
                              : breathingPhase === "exhala"
                              ? breathingPattern === "4-2-6"
                                ? 6
                                : 8
                              : 0.5,
                          ease: "easeInOut"
                        }}
                        className={`relative z-10 w-40 h-40 sm:w-48 sm:h-48 rounded-full border-2 flex flex-col items-center justify-center p-4 text-center backdrop-blur-xl transition-colors duration-500 ${
                          breathingPhase === "inhala"
                            ? "bg-gradient-to-br from-cyan-900/90 to-slate-950 border-cyan-400 text-cyan-200"
                            : breathingPhase === "manten"
                            ? "bg-gradient-to-br from-amber-950/90 to-slate-950 border-amber-400 text-amber-200"
                            : breathingPhase === "exhala"
                            ? "bg-gradient-to-br from-indigo-950/90 to-slate-950 border-indigo-400 text-indigo-200"
                            : "bg-slate-900/80 border-white/20 text-slate-300"
                        }`}
                      >
                        <Wind
                          size={24}
                          className={`mb-1 transition-transform ${
                            breathingPhase === "inhala"
                              ? "text-cyan-300 scale-110"
                              : breathingPhase === "manten"
                              ? "text-amber-300 rotate-90"
                              : breathingPhase === "exhala"
                              ? "text-indigo-300 scale-90"
                              : "text-slate-400"
                          }`}
                        />

                        <span className="text-xs sm:text-sm font-black uppercase tracking-wider text-white">
                          {breathingPhase === "inactivo"
                            ? "Listo para Iniciar"
                            : breathingPhase === "inhala"
                            ? "Inhala (Nariz)"
                            : breathingPhase === "manten"
                            ? "Mantén el Aire"
                            : "Bota (Boca)"}
                        </span>

                        {isBreathingActive ? (
                          <div className="flex flex-col items-center mt-1">
                            <span className="text-3xl font-black font-mono tracking-tight text-white">
                              {breathingSecondsLeft}s
                            </span>
                            <span className="text-[10px] font-bold opacity-80 mt-0.5">
                              Ciclo #{breathingCycleCount + 1}
                            </span>
                          </div>
                        ) : (
                          <span className="text-[10px] text-slate-400 font-semibold mt-1">
                            Patrón {breathingPattern}
                          </span>
                        )}
                      </motion.div>
                    </div>

                    {/* Subtítulo dinámico con la instrucción para el paciente */}
                    <div className="min-h-[44px] flex items-center justify-center text-center px-4">
                      {isBreathingActive ? (
                        <motion.div
                          key={breathingPhase}
                          initial={{ opacity: 0, y: 6 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="px-4 py-2 rounded-2xl bg-white/10 border border-white/15 backdrop-blur-md text-xs sm:text-sm font-bold text-white max-w-lg shadow-sm"
                        >
                          {breathingPhase === "inhala" && "👃 Toma aire por la nariz inflando la guatita como un globo..."}
                          {breathingPhase === "manten" && "⏸️ Mantén el aire con calma, sin hacer fuerza..."}
                          {breathingPhase === "exhala" && "👄 Bota el aire suavemente por la boca, como apagando una vela..."}
                        </motion.div>
                      ) : (
                        <span className="text-xs text-slate-400 font-medium">
                          Presiona «Iniciar Respiración» para comenzar la guía auditiva y visual.
                        </span>
                      )}
                    </div>

                    {/* CONTROLES DE INICIO / DETENER */}
                    <div className="flex items-center gap-3">
                      {!isBreathingActive ? (
                        <button
                          onClick={startBreathing}
                          className="px-8 py-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-sm shadow-xl shadow-emerald-600/30 transition-all flex items-center gap-2.5 hover:scale-[1.02]"
                        >
                          <Play size={18} />
                          <span>Iniciar Respiración con Guía</span>
                        </button>
                      ) : (
                        <button
                          onClick={stopBreathing}
                          className="px-8 py-3.5 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white font-black text-sm shadow-xl shadow-rose-600/30 transition-all flex items-center gap-2.5"
                        >
                          <Pause size={18} />
                          <span>Detener Respiración</span>
                        </button>
                      )}
                    </div>
                  </div>

                  {/* 3 Pasos Clave en Píldoras Minimalistas */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-3 border-t border-white/10">
                    <div className="p-3 rounded-2xl bg-white/5 border border-white/10 space-y-1 text-center">
                      <span className="text-[10px] font-black uppercase text-cyan-300">1. Inhala (4 seg)</span>
                      <p className="text-xs text-slate-200 font-medium">Por la nariz inflando suavemente el abdomen.</p>
                    </div>

                    <div className="p-3 rounded-2xl bg-white/5 border border-white/10 space-y-1 text-center">
                      <span className="text-[10px] font-black uppercase text-amber-300">2. Mantén ({breathingPattern === "4-2-6" ? "2" : "4"} seg)</span>
                      <p className="text-xs text-slate-200 font-medium">Pausa serena sin apretar la garganta.</p>
                    </div>

                    <div className="p-3 rounded-2xl bg-white/5 border border-white/10 space-y-1 text-center">
                      <span className="text-[10px] font-black uppercase text-indigo-300">3. Bota ({breathingPattern === "4-2-6" ? "6" : "8"} seg)</span>
                      <p className="text-xs text-slate-200 font-medium">Por la boca despacito como soplando una vela.</p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ===================================================================
                TÉCNICA 2: SURFEO DE LA OLA DE CRAVING (15 MINUTOS) CON GUÍA AUDITIVA
               =================================================================== */}
            {activeAfrontamientoTab === "surfeo" && (
              <div className="space-y-4">
                <div className="p-5 md:p-6 rounded-3xl bg-slate-900 text-white border border-teal-800/40 shadow-xl space-y-5">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-white/10 pb-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-black uppercase tracking-wider text-teal-400">
                          Técnica del Surfeo de la Ola (Alan Marlatt)
                        </span>
                        <span className="text-[9px] font-black px-2 py-0.5 rounded-full bg-teal-500/20 text-teal-300 border border-teal-500/40">
                          15 Minutos de Victoria
                        </span>
                      </div>
                      <h3 className="text-base md:text-lg font-black text-white">
                        Aprende a Pasar las Ganas Sin Consumir
                      </h3>
                    </div>

                    {/* CRONÓMETRO GIGANTE */}
                    <div className="px-4 py-2 rounded-2xl bg-black/70 border border-white/15 flex items-center gap-2.5 shrink-0 shadow-inner">
                      <Timer size={22} className="text-teal-400" />
                      <span className="text-2xl md:text-3xl font-black font-mono text-white tracking-wider">
                        {formatTime(surfSecondsLeft)}
                      </span>
                    </div>
                  </div>

                  {/* ILUSTRACIÓN VISUAL DE LA OLA CON SURFEADOR */}
                  <div className="relative p-4 rounded-2xl bg-slate-950/80 border border-teal-900/50 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className={`text-xs font-black ${currentSurfPhase.color}`}>
                        {currentSurfPhase.title}
                      </span>
                      <button
                        onClick={playPhaseAudioAdvice}
                        className="px-3 py-1 rounded-xl bg-teal-500/20 hover:bg-teal-500/30 text-teal-300 border border-teal-500/40 text-[11px] font-bold flex items-center gap-1.5 transition-all"
                        title="Escuchar explicación hablada en voz alta"
                      >
                        <Volume2 size={13} />
                        <span>Escuchar Consejo</span>
                      </button>
                    </div>

                    {/* GRÁFICO DE LA OLA CON INDICADOR DE POSICIÓN */}
                    <div className="relative h-20 w-full overflow-hidden rounded-xl bg-slate-900 flex items-end">
                      <svg viewBox="0 0 500 80" className="w-full h-full" preserveAspectRatio="none">
                        <path
                          d="M 0 75 Q 120 70 200 15 Q 260 10 320 40 Q 420 75 500 75 L 500 80 L 0 80 Z"
                          fill="rgba(20, 184, 166, 0.25)"
                          stroke="#14b8a6"
                          strokeWidth="2"
                        />
                      </svg>

                      {/* Indicador que se mueve según el tiempo transcurrido */}
                      <motion.div
                        className="absolute bottom-2 -translate-x-1/2 flex flex-col items-center"
                        style={{
                          left: `${Math.min(95, Math.max(5, ((15 * 60 - surfSecondsLeft) / (15 * 60)) * 100))}%`
                        }}
                      >
                        <div className="p-1 rounded-full bg-teal-400 text-slate-950 shadow-lg text-xs font-black animate-bounce">
                          🏄
                        </div>
                        <span className="text-[9px] font-black text-teal-300 bg-black/80 px-1.5 py-0.2 rounded mt-0.5">
                          Tú estás aquí
                        </span>
                      </motion.div>
                    </div>

                    {/* BARRA DE PROGRESO */}
                    <div className="w-full h-3 rounded-full bg-slate-800 overflow-hidden">
                      <motion.div
                        className={`h-full ${currentSurfPhase.barColor} transition-all duration-500`}
                        style={{ width: `${((15 * 60 - surfSecondsLeft) / (15 * 60)) * 100}%` }}
                      />
                    </div>

                    {/* EXPLICACIÓN SENCILLA PARA EL PACIENTE */}
                    <div className="p-3 rounded-xl bg-white/5 border border-white/10 space-y-1">
                      <p className="text-xs font-medium text-slate-200 leading-relaxed">
                        {currentSurfPhase.simpleExplanation}
                      </p>
                      <p className="text-xs font-bold text-teal-300">
                        👉 <strong>Tu misión ahora:</strong> {currentSurfPhase.actionText}
                      </p>
                    </div>
                  </div>

                  {/* CONTROLES & MEDICIÓN EVA */}
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pt-1">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={toggleSurfTimer}
                        className={`px-5 py-2.5 rounded-2xl font-black text-xs transition-all flex items-center gap-2 shadow-lg ${
                          isSurfRunning
                            ? "bg-amber-600 hover:bg-amber-500 text-white"
                            : "bg-teal-600 hover:bg-teal-500 text-white"
                        }`}
                      >
                        {isSurfRunning ? <Pause size={15} /> : <Play size={15} />}
                        <span>{isSurfRunning ? "Pausar Ola" : "Iniciar los 15 Minutos"}</span>
                      </button>

                      <button
                        onClick={resetSurfTimer}
                        className="px-3.5 py-2.5 rounded-2xl bg-white/10 hover:bg-white/20 text-slate-300 font-bold text-xs transition-all flex items-center gap-1.5"
                      >
                        <RotateCcw size={13} />
                        <span>Reiniciar</span>
                      </button>
                    </div>

                    {/* SELECTORES DE EVALUACIÓN DE GANAS (EVA 1-10) */}
                    <div className="flex items-center gap-3 text-xs font-bold bg-black/40 p-2 rounded-2xl border border-white/10">
                      <div className="flex items-center gap-1.5">
                        <span className="text-slate-400 text-[11px]">Ganas al inicio:</span>
                        <select
                          value={surfInitialCraving}
                          onChange={(e) => setSurfInitialCraving(Number(e.target.value))}
                          className="px-2 py-1 rounded-lg bg-slate-800 border border-slate-700 text-white text-xs font-bold"
                        >
                          {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((n) => (
                            <option key={n} value={n}>
                              {n}/10
                            </option>
                          ))}
                        </select>
                      </div>

                      <div className="flex items-center gap-1.5">
                        <span className="text-slate-400 text-[11px]">Ganas al final:</span>
                        <select
                          value={surfFinalCraving}
                          onChange={(e) => setSurfFinalCraving(Number(e.target.value))}
                          className="px-2 py-1 rounded-lg bg-slate-800 border border-slate-700 text-white text-xs font-bold"
                        >
                          {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((n) => (
                            <option key={n} value={n}>
                              {n}/10
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>
                  </div>

                  {/* 4 REGLAS BÁSICAS */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2">
                    <div className="p-2.5 rounded-xl bg-teal-950/40 border border-teal-800/40 text-center space-y-1">
                      <span className="text-base">🪑</span>
                      <h5 className="text-[11px] font-black text-teal-300">1. Quédate Quieto</h5>
                      <p className="text-[10px] text-slate-300">No salgas corriendo ni vayas a comprar.</p>
                    </div>

                    <div className="p-2.5 rounded-xl bg-teal-950/40 border border-teal-800/40 text-center space-y-1">
                      <span className="text-base">🌊</span>
                      <h5 className="text-[11px] font-black text-teal-300">2. Es solo una Ola</h5>
                      <p className="text-[10px] text-slate-300">Las ganas suben rápido, pero caen solas.</p>
                    </div>

                    <div className="p-2.5 rounded-xl bg-teal-950/40 border border-teal-800/40 text-center space-y-1">
                      <span className="text-base">💧</span>
                      <h5 className="text-[11px] font-black text-teal-300">3. Bebe Agua Fría</h5>
                      <p className="text-[10px] text-slate-300">Ayuda al corazón a latir más despacio.</p>
                    </div>

                    <div className="p-2.5 rounded-xl bg-teal-950/40 border border-teal-800/40 text-center space-y-1">
                      <span className="text-base">⏳</span>
                      <h5 className="text-[11px] font-black text-teal-300">4. Espera 15 min</h5>
                      <p className="text-[10px] text-slate-300">El cerebro se calma y la crisis pasa.</p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ===================================================================
                TÉCNICA 3: PROTOCOLO SOS ESCALONADO (5 PASOS)
               =================================================================== */}
            {activeAfrontamientoTab === "protocolo" && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-black uppercase tracking-wider text-slate-700 dark:text-slate-300">
                    Protocolo de Emergencia SOS (5 Pasos en Crisis):
                  </h3>
                  <span className="text-[10px] font-bold text-rose-600 dark:text-rose-400">
                    Qué hacer paso a paso
                  </span>
                </div>

                <div className="space-y-2.5">
                  {[
                    {
                      num: "1",
                      title: "Agua Fría en la Cara o Vaso con Hielo",
                      badge: "Cuerpo",
                      desc: "Toma un vaso de agua con hielo o lávate la cara con agua bien fría. Esto hace que el corazón baje sus pulsaciones al instante.",
                      color: "border-blue-200 dark:border-blue-900/50 bg-blue-50/60 dark:bg-blue-950/20 text-blue-900 dark:text-blue-200"
                    },
                    {
                      num: "2",
                      title: "5 Respiraciones Lentas (4-2-6)",
                      badge: "Oxigenación",
                      desc: "Toma aire por la nariz en 4 segundos, guárdalo 2 segundos y bótalo por la boca en 6 segundos como apagando una vela.",
                      color: "border-purple-200 dark:border-purple-900/50 bg-purple-50/60 dark:bg-purple-950/20 text-purple-900 dark:text-purple-200"
                    },
                    {
                      num: "3",
                      title: "Mirar la «Película Completa»",
                      badge: "Mente",
                      desc: "No te quedes pensando en los primeros minutos. Piensa en el día siguiente: la resaca, el bajón, la plata gastada y la culpa.",
                      color: "border-amber-200 dark:border-amber-900/50 bg-amber-50/60 dark:bg-amber-950/20 text-amber-900 dark:text-amber-200"
                    },
                    {
                      num: "4",
                      title: "Cambiar de Lugar en Menos de 1 Minuto",
                      badge: "Movimiento",
                      desc: "Sal de la pieza o del lugar donde estás. Camina 10 minutos a paso firme, lávate los dientes o ponte a ordenar.",
                      color: "border-teal-200 dark:border-teal-900/50 bg-teal-50/60 dark:bg-teal-950/20 text-teal-900 dark:text-teal-200"
                    },
                    {
                      num: "5",
                      title: "Pedir Ayuda (Llamar a alguien de confianza)",
                      badge: "Red de Apoyo",
                      desc: "Llama a tu persona de confianza, manda un audio sincero o comunícate con el COSAM Rinconada / Fono Senda 1412.",
                      color: "border-emerald-200 dark:border-emerald-900/50 bg-emerald-50/60 dark:bg-emerald-950/20 text-emerald-900 dark:text-emerald-200"
                    }
                  ].map((step) => (
                    <div
                      key={step.num}
                      className={`p-3.5 rounded-2xl border ${step.color} flex items-start gap-3 transition-all`}
                    >
                      <div className="w-7 h-7 rounded-xl bg-white dark:bg-slate-900 shadow-xs border border-black/5 dark:border-white/10 flex items-center justify-center font-black text-xs shrink-0">
                        {step.num}
                      </div>
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-2">
                          <h4 className="text-xs font-black">{step.title}</h4>
                          <span className="text-[9px] font-black uppercase tracking-wider opacity-75 px-1.5 py-0.2 rounded bg-black/5 dark:bg-white/10">
                            {step.badge}
                          </span>
                        </div>
                        <p className="text-xs opacity-90 leading-relaxed font-medium">
                          {step.desc}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* =========================================================================
          SECCIÓN INFERIOR: AUTORREGISTRO CLÍNICO & EXPORTACIÓN FICHA RAYEN
         ========================================================================= */}
      <div
        className={`rounded-3xl p-6 md:p-7 backdrop-blur-xl bg-white/70 dark:bg-slate-900/80 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-6 ${
          viewMode === "registro" ? "ring-2 ring-purple-500/50" : ""
        }`}
      >
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-2xl bg-purple-100 dark:bg-purple-950/80 text-purple-700 dark:text-purple-300">
              <ClipboardList size={22} />
            </div>
            <div>
              <h3 className="text-base md:text-lg font-black text-slate-900 dark:text-white">
                {isStandalonePatientView
                  ? "Mi Diario Personal de Calma & Registro"
                  : "Autorregistro Diario & Ficha Rayen APS"}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                {isStandalonePatientView
                  ? "Registra cómo te sentiste hoy y cómo cambió tu nivel de ansiedad o deseo tras usar las técnicas."
                  : "Centro de Salud Mental Comunitario (COSAM Rinconada - APS) • Monitoreo de estado de ánimo y ganas de consumir."}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={copyRayenFormat}
              className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-black text-xs shadow-md transition-all flex items-center gap-1.5"
            >
              <Copy size={14} />
              <span>
                {isStandalonePatientView
                  ? "Copiar Resumen para Mi Médico"
                  : "Copiar para Ficha Rayen"}
              </span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* FORMULARIO DE INGRESO */}
          <div className="lg:col-span-6 space-y-4 p-5 rounded-2xl bg-slate-50/70 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800">
            <h4 className="text-xs font-black uppercase tracking-wider text-slate-700 dark:text-slate-300">
              Nuevo Registro en Box o Domicilio
            </h4>

            {/* ESTADO DE ÁNIMO */}
            <div className="space-y-1.5">
              <label className="text-xs font-black text-slate-700 dark:text-slate-300">
                ¿Cómo te sientes hoy? (Ánimo predominante):
              </label>
              <div className="grid grid-cols-3 sm:grid-cols-5 gap-1.5">
                {[
                  { id: "Tranquilo", label: "Tranquilo/a", icon: "😌" },
                  { id: "Motivado", label: "Con Fuerza", icon: "💪" },
                  { id: "Ansioso", label: "Ansioso/a", icon: "😟" },
                  { id: "Irritable", label: "Enojado/a", icon: "😠" },
                  { id: "Desanimado", label: "Triste", icon: "😔" }
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setAnimo(item.id)}
                    className={`py-2 px-1.5 rounded-xl text-xs font-bold border transition-all flex flex-col items-center gap-0.5 ${
                      animo === item.id
                        ? "bg-purple-600 text-white border-purple-700 shadow-xs"
                        : "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:border-purple-400"
                    }`}
                  >
                    <span>{item.icon}</span>
                    <span>{item.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* GATILLANTE PRINCIPAL */}
            <div className="space-y-1.5">
              <label className="text-xs font-black text-slate-700 dark:text-slate-300">
                ¿Qué disparó las ganas de consumir?:
              </label>
              <select
                value={gatillante}
                onChange={(e) => setGatillante(e.target.value)}
                className="w-full p-2.5 rounded-xl border bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-900 dark:text-white"
              >
                <option value="Ninguno">Ninguno (Día tranquilo y protegido)</option>
                <option value="Hambre / Falta de comida (H)">Hambre / Falta de comida (H)</option>
                <option value="Rabia / Pelea familiar (A)">Rabia / Pelea familiar (A)</option>
                <option value="Soledad / Aburrimiento (L)">Soledad / Aburrimiento (L)</option>
                <option value="Cansancio / Falta de sueño (T)">Cansancio / Falta de sueño (T)</option>
                <option value="Tener plata en efectivo">Tener dinero en efectivo en el bolsillo</option>
                <option value="Ver a amigos de consumo">Ver a conocidos con los que consumía</option>
                <option value="Viernes por la tarde">Fin de semana o noche de pago</option>
              </select>
            </div>

            {/* SLIDERS ANSIEDAD Y CRAVING */}
            <div className="grid grid-cols-2 gap-4 pt-1">
              <div className="space-y-1">
                <div className="flex justify-between text-xs font-bold">
                  <span>Nivel de Ansiedad:</span>
                  <span className="text-purple-600 dark:text-purple-400">{ansiedad}/10</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="10"
                  value={ansiedad}
                  onChange={(e) => setAnsiedad(Number(e.target.value))}
                  className="w-full accent-purple-600"
                />
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-xs font-bold">
                  <span>Ganas de Consumir:</span>
                  <span className="text-rose-600 dark:text-rose-400">{craving}/10</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="10"
                  value={craving}
                  onChange={(e) => setCraving(Number(e.target.value))}
                  className="w-full accent-rose-600"
                />
              </div>
            </div>

            <button
              onClick={handleSaveRegistro}
              className="w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-black text-xs shadow-md transition-all flex items-center justify-center gap-2"
            >
              <CheckCircle2 size={16} />
              <span>Guardar Registro en Historial</span>
            </button>
          </div>

          {/* HISTORIAL CLÍNICO */}
          <div className="lg:col-span-6 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-black uppercase tracking-wider text-slate-700 dark:text-slate-300">
                Historial Guardado ({history.length})
              </h4>
              <span className="text-[11px] font-medium opacity-60">Memoria Local del Box</span>
            </div>

            <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
              {history.length === 0 ? (
                <div className="text-center py-10 opacity-50 text-xs font-bold border rounded-2xl border-dashed border-slate-300 dark:border-slate-700">
                  No hay registros guardados aún en esta sesión.
                </div>
              ) : (
                history.map((item) => (
                  <div
                    key={item.id}
                    className="p-3 rounded-2xl border bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3 text-xs shadow-xs"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-black text-slate-900 dark:text-white">{item.animo}</span>
                        <span className="text-[10px] opacity-60">• {item.fecha}</span>
                      </div>
                      <div className="flex items-center gap-3 text-[11px] text-slate-600 dark:text-slate-300">
                        <span>Ansiedad: <strong>{item.ansiedad}/10</strong></span>
                        <span>Ganas: <strong>{item.craving}/10</strong></span>
                        <span>Gatillante: <strong className="text-purple-600 dark:text-purple-400">{item.gatillante}</strong></span>
                      </div>
                    </div>

                    <button
                      onClick={() => handleDeleteRegistro(item.id)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-all"
                      title="Eliminar registro"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                ))
              )}
            </div>

            {/* TELÉFONOS INSTITUCIONALES APS */}
            <div className="p-3 rounded-2xl bg-purple-50 dark:bg-purple-950/30 border border-purple-200 dark:border-purple-900/40 flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-300">
              <span className="flex items-center gap-1.5">
                <PhoneCall size={14} className="text-rose-500" />
                SAMU: 131 • Fono Drogas Senda: 1412
              </span>
              <span className="text-[10px] font-black uppercase text-purple-700 dark:text-purple-300">
                Centro de Salud Mental Comunitario
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* TOAST DE NOTIFICACIÓN FLOTANTE */}
      <AnimatePresence>
        {toastMsg && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="fixed bottom-6 right-6 z-50 p-4 rounded-2xl bg-slate-900 text-white border border-purple-500/50 shadow-2xl text-xs font-bold flex items-center gap-2.5 max-w-md backdrop-blur-xl"
          >
            <Sparkles size={16} className="text-purple-400 shrink-0" />
            <span>{toastMsg}</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
