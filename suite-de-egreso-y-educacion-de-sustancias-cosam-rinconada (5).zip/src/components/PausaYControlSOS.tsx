import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  PauseCircle,
  ShieldAlert,
  ClipboardList,
  Info,
  Target,
  Brain,
  HeartPulse,
  Pill,
  Ambulance,
  PhoneCall,
  MapPin,
  Music,
  PlayCircle,
  Radio,
  Apple,
  Droplets,
  Eye,
  Activity,
  Wind,
  Save,
  Trash2,
  Share2,
  MessageCircle,
  Mail,
  Copy,
  CheckCircle,
  Volume2,
  Square,
  Building,
  Map,
  Clock,
  CheckSquare,
  AlertTriangle,
  RefreshCw,
  ArrowLeft
} from "lucide-react";
import { RegistroDiarioItem } from "../types";

export default function PausaYControlSOS() {
  const [subView, setSubView] = useState<
    "inicio" | "sos" | "registro" | "adiccion" | "gatillantes" | "craving" | "autocuidado" | "medicamentos"
  >("inicio");

  // Respiración 4-4-8
  const [breathingPhase, setBreathingPhase] = useState<"inactivo" | "inhala" | "manten" | "exhala">("inactivo");
  const [breathingText, setBreathingText] = useState<string>("Listo");
  const breathingTimerRef = useRef<any>(null);

  const startBreathing = () => {
    stopBreathing();
    const cycle = () => {
      setBreathingPhase("inhala");
      setBreathingText("Inhala profundamente (4s)");

      breathingTimerRef.current = setTimeout(() => {
        setBreathingPhase("manten");
        setBreathingText("Mantén el aire (4s)");

        breathingTimerRef.current = setTimeout(() => {
          setBreathingPhase("exhala");
          setBreathingText("Exhala lentamente por la boca (8s)");

          breathingTimerRef.current = setTimeout(() => {
            cycle();
          }, 8000);
        }, 4000);
      }, 4000);
    };

    cycle();
  };

  const stopBreathing = () => {
    if (breathingTimerRef.current) {
      clearTimeout(breathingTimerRef.current);
    }
    setBreathingPhase("inactivo");
    setBreathingText("Listo");
  };

  useEffect(() => {
    return () => {
      stopBreathing();
    };
  }, []);

  // Text to Speech (TTS)
  const [speakingText, setSpeakingText] = useState<string | null>(null);

  const speakText = (text: string) => {
    if (!("speechSynthesis" in window)) {
      alert("Su navegador no soporta síntesis de voz.");
      return;
    }

    if (speakingText === text) {
      window.speechSynthesis.cancel();
      setSpeakingText(null);
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = "es-CL";
    utterance.rate = 0.95;

    utterance.onstart = () => setSpeakingText(text);
    utterance.onend = () => setSpeakingText(null);
    utterance.onerror = () => setSpeakingText(null);

    window.speechSynthesis.speak(utterance);
  };

  // Registro Diario State
  const STORAGE_KEY = "cosam_pausa_registro";
  const [history, setHistory] = useState<RegistroDiarioItem[]>([]);
  const [animo, setAnimo] = useState<string>("");
  const [gatillante, setGatillante] = useState<string>("Ninguno");
  const [ansiedad, setAnsiedad] = useState<number>(0);
  const [craving, setCraving] = useState<number>(0);
  const [selectedTratante, setSelectedTratante] = useState<string>("");
  const [alertaRiesgo, setAlertaRiesgo] = useState<boolean>(false);
  const [feedbackMsg, setFeedbackMsg] = useState<string | null>(null);

  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        setHistory(JSON.parse(saved));
      } catch (e) {
        console.error(e);
      }
    }
  }, []);

  const triggerToast = (msg: string) => {
    setFeedbackMsg(msg);
    setTimeout(() => setFeedbackMsg(null), 3000);
  };

  const handleSaveRegistro = () => {
    if (!animo) {
      triggerToast("Por favor selecciona tu estado de ánimo.");
      return;
    }

    if (gatillante !== "Ninguno") {
      setAlertaRiesgo(true);
      setTimeout(() => setAlertaRiesgo(false), 5000);
    }

    const newItem: RegistroDiarioItem = {
      id: Date.now(),
      fecha: new Date().toLocaleString("es-CL", { dateStyle: "medium", timeStyle: "short" }),
      animo,
      gatillante,
      ansiedad,
      craving
    };

    const updated = [newItem, ...history];
    setHistory(updated);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));

    triggerToast("¡Registro guardado con éxito!");
    // Reset form
    setAnimo("");
    setGatillante("Ninguno");
    setAnsiedad(0);
    setCraving(0);
  };

  const handleDeleteRegistro = (id: string | number) => {
    const updated = history.filter((h) => h.id !== id);
    setHistory(updated);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    triggerToast("Registro eliminado.");
  };

  const handleExport = (type: "whatsapp" | "correo" | "rayen") => {
    if (history.length === 0) {
      triggerToast("No hay registros en el historial para exportar.");
      return;
    }

    if (type === "rayen") {
      let rayenText = `FECHA: ${new Date().toLocaleDateString("es-CL")} | HORA: ${new Date().toLocaleTimeString("es-CL")}\nRESUMEN DE AUTORREGISTRO (Pausa y Control - COSAM Rinconada de San Ramón):\n`;
      history.slice(0, 5).forEach((r) => {
        rayenText += `- ${r.fecha} | Ánimo: ${r.animo} | Ansiedad: ${r.ansiedad}/10 | Craving: ${r.craving}/10 | Gatillante: ${r.gatillante}\n`;
      });
      navigator.clipboard.writeText(rayenText);
      triggerToast("¡Copiado formato para Ficha Rayen al portapapeles!");
      return;
    }

    let report = `🗓️ *Reporte Pausa y Control (COSAM Rinconada de San Ramón)*\n\n`;
    history.slice(0, 5).forEach((r) => {
      report += `• ${r.fecha}\n  Ánimo: ${r.animo}\n  Ansiedad: ${r.ansiedad}/10 | Craving: ${r.craving}/10\n  Gatillante: ${r.gatillante}\n\n`;
    });
    report += `Enviado desde la App Pausa y Control.`;

    if (type === "whatsapp") {
      window.open(`https://wa.me/?text=${encodeURIComponent(report)}`, "_blank");
    } else if (type === "correo") {
      if (!selectedTratante) {
        triggerToast("Selecciona primero a tu profesional tratante.");
        return;
      }
      window.location.href = `mailto:${selectedTratante}?subject=Reporte Clínico - Pausa y Control&body=${encodeURIComponent(report)}`;
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      {/* HEADER & NAV PÍLDORAS */}
      <div className="bg-white/90 backdrop-blur-md rounded-3xl p-5 md:p-6 shadow-sm border border-purple-100 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="bg-purple-100 text-purple-700 text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-lg">
              Módulo de Autogestión &amp; Paciente
            </span>
            <span className="text-slate-400 text-xs font-semibold">• COSAM Rinconada de San Ramón</span>
          </div>
          <h2 className="text-xl md:text-2xl font-black text-slate-800 tracking-tight flex items-center gap-2">
            <PauseCircle className="text-purple-600" size={24} />
            Pausa y Control: Mi Caja SOS, Registro Diario &amp; Urgencias
          </h2>
        </div>

        {/* NAVEGACIÓN RÁPIDA INTERNA */}
        <div className="flex flex-wrap gap-1.5 bg-slate-100 p-1.5 rounded-2xl border border-slate-200 shrink-0">
          <button
            onClick={() => setSubView("inicio")}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
              subView === "inicio" ? "bg-purple-600 text-white shadow-sm" : "text-slate-600 hover:text-slate-900"
            }`}
          >
            Inicio
          </button>
          <button
            onClick={() => setSubView("sos")}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 ${
              subView === "sos" ? "bg-rose-600 text-white shadow-sm" : "text-rose-600 hover:bg-rose-50"
            }`}
          >
            <ShieldAlert size={14} />
            <span>Caja SOS</span>
          </button>
          <button
            onClick={() => setSubView("registro")}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 ${
              subView === "registro" ? "bg-slate-900 text-white shadow-sm" : "text-slate-600 hover:text-slate-900"
            }`}
          >
            <ClipboardList size={14} />
            <span>Registro Diario</span>
          </button>
        </div>
      </div>

      {/* SUB-VISTA 1: INICIO DE PAUSA Y CONTROL */}
      {subView === "inicio" && (
        <div className="space-y-6">
          <div className="bg-gradient-to-br from-purple-700 via-purple-800 to-indigo-900 rounded-3xl p-8 text-white shadow-md relative overflow-hidden">
            <div className="relative z-10 max-w-2xl space-y-3">
              <span className="text-[10px] font-black uppercase tracking-widest bg-white/20 px-3 py-1 rounded-md">
                Programa de Tratamiento en Adicciones
              </span>
              <h3 className="text-2xl md:text-4xl font-black leading-tight">
                Pausa y Control: Tu espacio seguro contra el Craving
              </h3>
              <p className="text-purple-100 text-xs md:text-sm font-medium leading-relaxed">
                Herramienta clínica para la autorregulación emocional, respiración diafragmática guiada, prevención de recaídas y conexión inmediata con tu red de apoyo.
              </p>
            </div>
            <div className="absolute -right-10 -bottom-10 w-64 h-64 bg-white/10 rounded-full blur-3xl"></div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <button
              onClick={() => setSubView("sos")}
              className="bg-white p-6 rounded-3xl border border-rose-100 shadow-sm hover:shadow-md transition-all text-left flex items-center gap-5 group"
            >
              <div className="w-16 h-16 bg-rose-50 text-rose-500 rounded-2xl flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                <ShieldAlert size={32} />
              </div>
              <div>
                <span className="text-[10px] font-black text-rose-600 uppercase tracking-wider block">Acción Inmediata</span>
                <h4 className="text-lg font-black text-slate-900">Mi Caja SOS &amp; Urgencias</h4>
                <p className="text-xs text-slate-500 font-medium mt-0.5">Respiración 4-4-8, choque térmico y teléfonos 131 / 1412.</p>
              </div>
            </button>

            <button
              onClick={() => setSubView("registro")}
              className="bg-white p-6 rounded-3xl border border-purple-100 shadow-sm hover:shadow-md transition-all text-left flex items-center gap-5 group"
            >
              <div className="w-16 h-16 bg-purple-50 text-purple-600 rounded-2xl flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                <ClipboardList size={32} />
              </div>
              <div>
                <span className="text-[10px] font-black text-purple-600 uppercase tracking-wider block">Monitoreo Diario</span>
                <h4 className="text-lg font-black text-slate-900">Registro de Ánimo &amp; Craving</h4>
                <p className="text-xs text-slate-500 font-medium mt-0.5">Seguimiento de gatillantes y envío directo a tu terapeuta.</p>
              </div>
            </button>
          </div>

          <div className="space-y-3 pt-4 border-t border-purple-50">
            <h4 className="text-xs font-black uppercase tracking-wider text-slate-500">
              Módulos Educativos con Audio Guiado:
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
              {[
                { id: "adiccion", label: "La Adicción", icon: Info },
                { id: "gatillantes", label: "Mis Gatillantes", icon: Target },
                { id: "craving", label: "El Craving", icon: Brain },
                { id: "autocuidado", label: "Salud Integral", icon: HeartPulse },
                { id: "medicamentos", label: "Medicamentos (Regla 10d)", icon: Pill }
              ].map((mod) => {
                const Icon = mod.icon;
                return (
                  <button
                    key={mod.id}
                    onClick={() => setSubView(mod.id as any)}
                    className="p-4 bg-white rounded-2xl border border-slate-200/80 hover:border-purple-300 hover:shadow-sm transition-all flex flex-col items-center text-center gap-2 group"
                  >
                    <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center group-hover:bg-purple-600 group-hover:text-white transition-colors">
                      <Icon size={18} />
                    </div>
                    <span className="text-xs font-bold text-slate-700 leading-tight">{mod.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* SUB-VISTA 2: CAJA SOS & URGENCIAS */}
      {subView === "sos" && (
        <div className="space-y-6">
          <button
            onClick={() => setSubView("inicio")}
            className="flex items-center gap-2 text-slate-500 hover:text-purple-600 font-bold text-xs transition-colors"
          >
            <ArrowLeft size={16} /> Volver al Inicio
          </button>

          {/* CAJA SOS HERRAMIENTAS */}
          <div className="bg-white p-6 md:p-8 rounded-3xl shadow-sm border border-rose-100 space-y-6">
            <div>
              <span className="text-[10px] font-black uppercase tracking-widest text-rose-600 bg-rose-50 px-3 py-1 rounded-md">
                Protocolo Anti-Craving Inmediato
              </span>
              <h3 className="text-xl md:text-2xl font-black text-slate-900 mt-2">
                Mi Caja <span className="text-rose-600">SOS</span>: Romper el Ciclo de Angustia
              </h3>
              <p className="text-xs text-slate-500 font-medium">
                Técnicas basadas en neuromodulación parasimpática para reducir la activación de la amígdala en menos de 5 minutos.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              
              {/* Respiración 4-4-8 */}
              <div className="lg:col-span-6 bg-slate-50 p-6 rounded-3xl border border-slate-200 text-center flex flex-col items-center justify-between">
                <div>
                  <h4 className="text-base font-black text-slate-900">Respiración Diafragmática 4-4-8</h4>
                  <p className="text-xs text-slate-500 font-medium mt-1">
                    Estimula el nervio vago y desacelera el ritmo cardíaco de golpe.
                  </p>
                </div>

                <div className="my-6 relative flex items-center justify-center">
                  <div
                    className={`w-36 h-36 rounded-full flex items-center justify-center transition-all duration-700 ${
                      breathingPhase === "inhala"
                        ? "scale-125 bg-purple-500 text-white led-pulse-purple shadow-xl shadow-purple-200"
                        : breathingPhase === "manten"
                        ? "scale-125 bg-purple-700 text-white led-pulse-purple shadow-2xl shadow-purple-300 ring-4 ring-purple-300/60"
                        : breathingPhase === "exhala"
                        ? "scale-90 bg-purple-300 text-purple-950 led-pulse-soft"
                        : "scale-100 bg-slate-200 text-slate-600"
                    }`}
                  >
                    <span className="text-xs font-black text-center px-4 leading-tight">
                      {breathingText}
                    </span>
                  </div>
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={startBreathing}
                    className="px-6 py-2.5 bg-purple-600 text-white rounded-xl text-xs font-bold shadow-md hover:bg-purple-700 active:scale-95 transition-all"
                  >
                    Iniciar Ciclo
                  </button>
                  <button
                    onClick={stopBreathing}
                    className="px-5 py-2.5 bg-white text-slate-600 border border-slate-200 rounded-xl text-xs font-bold hover:bg-slate-50 active:scale-95 transition-all"
                  >
                    Detener
                  </button>
                </div>
              </div>

              {/* Técnicas Sensoriales y Musicales */}
              <div className="lg:col-span-6 space-y-3">
                {/* Música */}
                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200">
                  <h5 className="text-xs font-bold text-slate-800 mb-2 flex items-center gap-1.5">
                    <Music size={14} className="text-purple-600" /> Anclaje Musical Inmediato:
                  </h5>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <a
                      href="https://open.spotify.com"
                      target="_blank"
                      rel="noreferrer"
                      className="bg-[#1DB954] text-white p-2.5 rounded-xl font-bold flex items-center justify-center gap-1.5 shadow-sm hover:opacity-90"
                    >
                      <Music size={13} /> Spotify
                    </a>
                    <a
                      href="https://music.youtube.com"
                      target="_blank"
                      rel="noreferrer"
                      className="bg-[#FF0000] text-white p-2.5 rounded-xl font-bold flex items-center justify-center gap-1.5 shadow-sm hover:opacity-90"
                    >
                      <PlayCircle size={13} /> YT Music
                    </a>
                    <a
                      href="https://music.apple.com"
                      target="_blank"
                      rel="noreferrer"
                      className="bg-slate-900 text-white p-2.5 rounded-xl font-bold flex items-center justify-center gap-1.5 shadow-sm hover:opacity-90"
                    >
                      <Apple size={13} /> Apple Music
                    </a>
                    <a
                      href="https://deezer.com"
                      target="_blank"
                      rel="noreferrer"
                      className="bg-purple-600 text-white p-2.5 rounded-xl font-bold flex items-center justify-center gap-1.5 shadow-sm hover:opacity-90"
                    >
                      <Radio size={13} /> Deezer
                    </a>
                  </div>
                </div>

                {/* Choque Térmico */}
                <div className="bg-blue-50/70 p-3.5 rounded-2xl border border-blue-100 flex items-start gap-3 text-xs">
                  <div className="w-8 h-8 rounded-xl bg-blue-500 text-white flex items-center justify-center shrink-0 mt-0.5">
                    <Droplets size={16} />
                  </div>
                  <div>
                    <h5 className="font-bold text-blue-950">Choque Térmico (Reflejo de Inmersión)</h5>
                    <p className="text-blue-900 font-medium mt-0.5 leading-relaxed">
                      Lávate la cara con agua muy fría o sostén cubos de hielo en las manos por 30 segundos. Esto fuerza al sistema nervioso autónomo a resetear la alarma de pánico.
                    </p>
                  </div>
                </div>

                {/* Regla 5-4-3-2-1 */}
                <div className="bg-amber-50/70 p-3.5 rounded-2xl border border-amber-200 flex items-start gap-3 text-xs">
                  <div className="w-8 h-8 rounded-xl bg-amber-500 text-white flex items-center justify-center shrink-0 mt-0.5">
                    <Eye size={16} />
                  </div>
                  <div>
                    <h5 className="font-bold text-amber-950">Regla 5-4-3-2-1 de Conexión al Presente</h5>
                    <p className="text-amber-900 font-medium mt-0.5 leading-relaxed">
                      Nombra en voz alta: 5 cosas que veas, 4 que toques, 3 que escuches, 2 que huelas y 1 emoción que sientas. Rompe la fijación obsesiva.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* RED DE URGENCIAS */}
          <div className="bg-white p-6 md:p-8 rounded-3xl shadow-sm border-2 border-rose-200 space-y-6">
            <div className="flex items-center gap-3 border-b border-rose-100 pb-4">
              <div className="w-10 h-10 rounded-2xl bg-rose-600 text-white flex items-center justify-center shadow-md">
                <Ambulance size={20} />
              </div>
              <div>
                <h3 className="text-lg font-black text-slate-900">
                  Red de Urgencias Médicas Inmediatas
                </h3>
                <p className="text-xs text-slate-500 font-medium">
                  Si presentas dolor de pecho, ideas de autoagresión o pérdida de contacto con la realidad, pide ayuda de inmediato.
                </p>
              </div>
            </div>

            {/* Teléfonos Nacionales */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <a
                href="tel:131"
                className="bg-rose-600 hover:bg-rose-700 text-white p-4 rounded-2xl flex items-center justify-between shadow-md transition-all active:scale-95"
              >
                <div className="flex items-center gap-3">
                  <PhoneCall size={24} />
                  <div>
                    <h4 className="text-base font-black">SAMU Urgencia</h4>
                    <span className="text-[11px] text-rose-100 font-semibold">Atención de ambulancia</span>
                  </div>
                </div>
                <span className="text-xl font-black bg-white/20 px-3 py-1 rounded-xl">131</span>
              </a>

              <a
                href="tel:1412"
                className="bg-purple-600 hover:bg-purple-700 text-white p-4 rounded-2xl flex items-center justify-between shadow-md transition-all active:scale-95"
              >
                <div className="flex items-center gap-3">
                  <PhoneCall size={24} />
                  <div>
                    <h4 className="text-base font-black">Senda Responde</h4>
                    <span className="text-[11px] text-purple-100 font-semibold">Orientación gratuita en drogas 24/7</span>
                  </div>
                </div>
                <span className="text-xl font-black bg-white/20 px-3 py-1 rounded-xl">1412</span>
              </a>
            </div>

            {/* Centros de Atención Local (San Ramón) */}
            <div className="space-y-3 pt-2">
              <h4 className="text-xs font-black uppercase tracking-wider text-slate-600 flex items-center gap-1.5">
                <MapPin size={14} className="text-purple-600" /> Centros de Urgencia en Red:
              </h4>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex flex-col justify-between space-y-3">
                  <div>
                    <span className="text-[9px] font-black uppercase tracking-widest text-rose-600 block">Atención 24 Horas</span>
                    <h5 className="text-xs font-black text-slate-800 mt-0.5">SAR La Bandera</h5>
                    <p className="text-[11px] text-slate-500 font-medium">Almirante Latorre 9942, San Ramón.</p>
                  </div>
                  <div className="flex gap-2">
                    <a
                      href="https://maps.google.com/?q=SAR+La+Bandera+San+Ramon"
                      target="_blank"
                      rel="noreferrer"
                      className="flex-1 py-1.5 bg-white border border-slate-200 rounded-xl text-center text-xs font-bold text-slate-700 hover:bg-slate-100 flex items-center justify-center gap-1"
                    >
                      <Map size={12} /> Mapa
                    </a>
                    <a
                      href="tel:+56225774000"
                      className="flex-1 py-1.5 bg-purple-600 text-white rounded-xl text-center text-xs font-bold hover:bg-purple-700 flex items-center justify-center gap-1"
                    >
                      <PhoneCall size={12} /> Llamar
                    </a>
                  </div>
                </div>

                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex flex-col justify-between space-y-3">
                  <div>
                    <span className="text-[9px] font-black uppercase tracking-widest text-purple-600 block">SAPU Comunal</span>
                    <h5 className="text-xs font-black text-slate-800 mt-0.5">SAPU Gabriela Mistral</h5>
                    <p className="text-[11px] text-slate-500 font-medium">Pedro Aguirre Cerda 8171.</p>
                  </div>
                  <div className="flex gap-2">
                    <a
                      href="https://maps.google.com/?q=SAPU+Gabriela+Mistral+San+Ramon"
                      target="_blank"
                      rel="noreferrer"
                      className="flex-1 py-1.5 bg-white border border-slate-200 rounded-xl text-center text-xs font-bold text-slate-700 hover:bg-slate-100 flex items-center justify-center gap-1"
                    >
                      <Map size={12} /> Mapa
                    </a>
                    <a
                      href="tel:+56225774000"
                      className="flex-1 py-1.5 bg-purple-600 text-white rounded-xl text-center text-xs font-bold hover:bg-purple-700 flex items-center justify-center gap-1"
                    >
                      <PhoneCall size={12} /> Llamar
                    </a>
                  </div>
                </div>

                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex flex-col justify-between space-y-3">
                  <div>
                    <span className="text-[9px] font-black uppercase tracking-widest text-emerald-600 block">Atención Primaria</span>
                    <h5 className="text-xs font-black text-slate-800 mt-0.5">CESFAM Salvador Allende</h5>
                    <p className="text-[11px] text-slate-500 font-medium">Almirante Latorre 9942.</p>
                  </div>
                  <div className="flex gap-2">
                    <a
                      href="https://maps.google.com/?q=CESFAM+Salvador+Allende+San+Ramon"
                      target="_blank"
                      rel="noreferrer"
                      className="flex-1 py-1.5 bg-white border border-slate-200 rounded-xl text-center text-xs font-bold text-slate-700 hover:bg-slate-100 flex items-center justify-center gap-1"
                    >
                      <Map size={12} /> Mapa
                    </a>
                    <a
                      href="tel:+56225774000"
                      className="flex-1 py-1.5 bg-purple-600 text-white rounded-xl text-center text-xs font-bold hover:bg-purple-700 flex items-center justify-center gap-1"
                    >
                      <PhoneCall size={12} /> Llamar
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SUB-VISTA 3: REGISTRO DIARIO */}
      {subView === "registro" && (
        <div className="space-y-6">
          <button
            onClick={() => setSubView("inicio")}
            className="flex items-center gap-2 text-slate-500 hover:text-purple-600 font-bold text-xs transition-colors"
          >
            <ArrowLeft size={16} /> Volver al Inicio
          </button>

          {/* ALERTA DE RIESGO */}
          {alertaRiesgo && (
            <div className="bg-rose-50 border-l-4 border-rose-500 p-4 rounded-2xl shadow-sm text-xs text-rose-950 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <AlertTriangle size={18} className="text-rose-600 shrink-0" />
                <div>
                  <h5 className="font-black">Alerta de Exposición a Gatillante</h5>
                  <p className="text-[11px] text-rose-800 font-medium">
                    Has reportado un disparador de riesgo. Si sientes deseos intensos, utiliza tu <strong>Caja SOS</strong>.
                  </p>
                </div>
              </div>
              <button
                onClick={() => setSubView("sos")}
                className="px-3 py-1.5 bg-rose-600 text-white rounded-xl text-xs font-bold shrink-0 shadow-sm"
              >
                Abrir SOS
              </button>
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Formulario */}
            <div className="lg:col-span-6 bg-white p-6 md:p-8 rounded-3xl shadow-sm border border-purple-100 space-y-6">
              <div className="flex justify-between items-center border-b border-purple-50 pb-4">
                <h3 className="text-lg font-black text-slate-800">
                  Nuevo Registro de Estado &amp; Craving
                </h3>
                <button
                  onClick={() => {
                    setAnimo("");
                    setGatillante("Ninguno");
                    setAnsiedad(0);
                    setCraving(0);
                  }}
                  className="text-xs font-bold text-slate-400 hover:text-purple-600 flex items-center gap-1"
                >
                  <RefreshCw size={12} /> Limpiar
                </button>
              </div>

              {/* 1. Ánimo */}
              <div>
                <label className="text-xs font-black text-slate-700 uppercase tracking-wider block mb-2.5">
                  1. ¿Cómo te has sentido hoy?
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {[
                    { val: "Malo 😫", emoji: "😫", label: "Malo" },
                    { val: "Regular 😐", emoji: "😐", label: "Regular" },
                    { val: "Bien 🙂", emoji: "🙂", label: "Bien" },
                    { val: "Excelente 🤩", emoji: "🤩", label: "Excelente" }
                  ].map((item) => (
                    <button
                      key={item.val}
                      onClick={() => setAnimo(item.val)}
                      className={`p-3 rounded-2xl border text-center transition-all ${
                        animo === item.val
                          ? "bg-purple-100 border-purple-500 shadow-sm ring-2 ring-purple-200"
                          : "bg-slate-50 border-slate-200 hover:bg-white"
                      }`}
                    >
                      <span className="text-2xl block">{item.emoji}</span>
                      <span className="text-[10px] font-bold text-slate-600 block mt-1">{item.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* 2. Gatillantes */}
              <div>
                <label className="text-xs font-black text-slate-700 uppercase tracking-wider block mb-2">
                  2. ¿Estuviste expuesto a un gatillante?
                </label>
                <select
                  value={gatillante}
                  onChange={(e) => setGatillante(e.target.value)}
                  className="w-full p-3 rounded-xl border border-slate-200 bg-white font-medium text-xs text-slate-700 outline-none focus:ring-2 focus:ring-purple-500 shadow-sm"
                >
                  <option value="Ninguno">No, ninguno hoy.</option>
                  <option value="Lugares de riesgo (Barrio, botillería)">Sí, pasé por lugares de riesgo.</option>
                  <option value="Personas de riesgo (Amigos de consumo)">Sí, vi a personas de riesgo.</option>
                  <option value="Emocional (Estrés, rabia o pena intensa)">Sí, tuve estrés o pena intensa.</option>
                  <option value="Deseo espontáneo o ideas engañosas">Sí, sentí deseo espontáneo.</option>
                </select>
              </div>

              {/* 3. Sliders Ansiedad & Craving */}
              <div className="space-y-4 bg-slate-50 p-4 rounded-2xl border border-slate-200">
                <div>
                  <div className="flex justify-between text-xs font-bold text-slate-700 mb-1">
                    <span>Nivel de Ansiedad:</span>
                    <span className="text-purple-700 font-extrabold">{ansiedad} / 10</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="10"
                    value={ansiedad}
                    onChange={(e) => setAnsiedad(Number(e.target.value))}
                    className="w-full h-2 bg-purple-200 rounded-lg accent-purple-600"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs font-bold text-slate-700 mb-1">
                    <span>Nivel de Craving (Deseo de Consumo):</span>
                    <span className="text-purple-700 font-extrabold">{craving} / 10</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="10"
                    value={craving}
                    onChange={(e) => setCraving(Number(e.target.value))}
                    className="w-full h-2 bg-purple-200 rounded-lg accent-purple-600"
                  />
                </div>
              </div>

              <button
                onClick={handleSaveRegistro}
                className="w-full py-3.5 bg-purple-600 hover:bg-purple-700 text-white rounded-2xl text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 shadow-md shadow-purple-200 active:scale-95 transition-all"
              >
                <Save size={16} /> Guardar en Mi Historial
              </button>
            </div>

            {/* Historial & Exportación */}
            <div className="lg:col-span-6 space-y-4 flex flex-col justify-between">
              <div className="bg-white p-6 rounded-3xl shadow-sm border border-purple-100 space-y-3 flex-1 flex flex-col">
                <h4 className="text-xs font-black uppercase tracking-wider text-slate-600 flex items-center gap-1.5">
                  <Clock size={14} className="text-purple-600" /> Historial de Registros Guardados:
                </h4>

                <div className="space-y-2 overflow-y-auto max-h-[320px] pr-1 flex-1">
                  {history.length === 0 ? (
                    <div className="text-center py-12 text-slate-400 text-xs font-medium">
                      No hay registros guardados aún.
                    </div>
                  ) : (
                    history.map((reg) => (
                      <div
                        key={reg.id}
                        className="p-3 bg-slate-50 border border-slate-200/80 rounded-2xl flex items-center justify-between text-xs"
                      >
                        <div className="flex items-center gap-3">
                          <span className="text-2xl">{reg.animo.split(" ")[1] || "🙂"}</span>
                          <div>
                            <span className="font-bold text-slate-800 block">{reg.fecha}</span>
                            <span className="text-[11px] text-slate-500 line-clamp-1">
                              Gatillante: {reg.gatillante}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <span className="px-2 py-1 bg-rose-100 text-rose-800 rounded-lg text-[10px] font-black">
                            Ans: {reg.ansiedad}
                          </span>
                          <span className="px-2 py-1 bg-purple-100 text-purple-800 rounded-lg text-[10px] font-black">
                            Crav: {reg.craving}
                          </span>
                          <button
                            onClick={() => handleDeleteRegistro(reg.id)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 transition-colors"
                          >
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* Opciones de Compartir */}
              <div className="bg-purple-50/70 p-5 rounded-3xl border border-purple-100 space-y-3">
                <h4 className="text-xs font-black uppercase tracking-wider text-purple-900 flex items-center gap-1.5">
                  <Share2 size={14} className="text-purple-600" /> Compartir con Equipo Tratante COSAM:
                </h4>

                <select
                  value={selectedTratante}
                  onChange={(e) => setSelectedTratante(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-purple-200 text-xs bg-white font-medium text-slate-700 outline-none"
                >
                  <option value="">-- Seleccionar Tratante --</option>
                  <option value="fcarrera@cosam.cl">Fernando Carrera</option>
                  <option value="castudillo@cosam.cl">Katherine Astudillo Carrillo</option>
                  <option value="andresruizmiranda1988@gmail.com">Dr. Andrés Felipe Ruiz Miranda (Médico / Prog. Adicciones)</option>
                </select>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => handleExport("whatsapp")}
                    className="py-2.5 bg-[#25D366] hover:opacity-90 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm"
                  >
                    <MessageCircle size={14} /> WhatsApp
                  </button>
                  <button
                    onClick={() => handleExport("correo")}
                    className="py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm"
                  >
                    <Mail size={14} /> Correo
                  </button>
                </div>

                <button
                  onClick={() => handleExport("rayen")}
                  className="w-full py-2.5 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm transition-all"
                >
                  <Copy size={14} /> Copiar Formato Ficha Rayen (Clínico)
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SUB-VISTAS EDUCATIVAS CON TTS (ADICCIÓN, GATILLANTES, CRAVING, AUTOCUIDADO, MEDICAMENTOS) */}
      {["adiccion", "gatillantes", "craving", "autocuidado", "medicamentos"].includes(subView) && (
        <div className="space-y-6">
          <button
            onClick={() => setSubView("inicio")}
            className="flex items-center gap-2 text-slate-500 hover:text-purple-600 font-bold text-xs transition-colors"
          >
            <ArrowLeft size={16} /> Volver al Inicio
          </button>

          {/* 1. LA ADICCIÓN */}
          {subView === "adiccion" && (
            <div className="bg-white p-6 md:p-8 rounded-3xl shadow-sm border border-purple-100 space-y-6">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-purple-50 pb-5">
                <div>
                  <span className="text-[10px] font-black uppercase tracking-widest text-purple-700 bg-purple-100 px-3 py-1 rounded-md">
                    Psicoeducación
                  </span>
                  <h3 className="text-2xl font-black text-slate-800 mt-1">
                    La Adicción: Una Condición Médica Reversible
                  </h3>
                </div>

                <button
                  onClick={() =>
                    speakText(
                      "La adicción no es falta de voluntad. Es una enfermedad médica crónica que cambia el sistema de recompensa cerebral. Con abstinencia y tratamiento, el cerebro recupera su capacidad de sentir bienestar natural."
                    )
                  }
                  className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 border transition-all ${
                    speakingText
                      ? "bg-purple-600 text-white border-purple-600 animate-pulse"
                      : "bg-purple-50 text-purple-700 border-purple-200 hover:bg-purple-100"
                  }`}
                >
                  {speakingText ? <Square size={14} /> : <Volume2 size={14} />}
                  <span>{speakingText ? "Detener Audio" : "Escuchar Voz"}</span>
                </button>
              </div>

              <div className="bg-purple-50/70 p-6 rounded-3xl border border-purple-100 space-y-3">
                <h4 className="text-base font-black text-purple-950">Tu cerebro tiene la capacidad de sanar</h4>
                <p className="text-xs md:text-sm text-purple-900 font-medium leading-relaxed">
                  La adicción no es debilidad moral ni falta de amor propio. Es una alteración en los receptores de dopamina producida por un estímulo tóxico. Al mantener la abstinencia y apoyar con nutrición y psicoterapia, los circuitos del autocontrol se restablecen.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-5 bg-slate-50 rounded-2xl border border-slate-200">
                  <h5 className="font-black text-slate-900 text-sm mb-1">Enfermedad Crónica Manejable</h5>
                  <p className="text-xs text-slate-600 font-medium leading-relaxed">
                    Igual que la hipertensión o la diabetes, requiere acompañamiento multidisciplinario continuo y pautas de autocuidado a largo plazo.
                  </p>
                </div>
                <div className="p-5 bg-slate-50 rounded-2xl border border-slate-200">
                  <h5 className="font-black text-slate-900 text-sm mb-1">Tratamiento Integral COSAM</h5>
                  <p className="text-xs text-slate-600 font-medium leading-relaxed">
                    En COSAM Rinconada de San Ramón contamos con equipo médico, psicológico y social enfocado en tu recuperación integral y la de tu familia.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* 2. MIS GATILLANTES */}
          {subView === "gatillantes" && (
            <div className="bg-white p-6 md:p-8 rounded-3xl shadow-sm border border-purple-100 space-y-6">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-purple-50 pb-5">
                <div>
                  <span className="text-[10px] font-black uppercase tracking-widest text-purple-700 bg-purple-100 px-3 py-1 rounded-md">
                    Prevención de Recaídas
                  </span>
                  <h3 className="text-2xl font-black text-slate-800 mt-1">
                    Mis Gatillantes: Externos e Internos
                  </h3>
                </div>

                <button
                  onClick={() =>
                    speakText(
                      "Gatillantes externos: Lugares de riesgo, personas de consumo y fechas de pago. Gatillantes internos: Emociones intensas como estrés o pena, sensaciones físicas como hambre, o pensamientos engañosos."
                    )
                  }
                  className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 border transition-all ${
                    speakingText
                      ? "bg-purple-600 text-white border-purple-600 animate-pulse"
                      : "bg-purple-50 text-purple-700 border-purple-200 hover:bg-purple-100"
                  }`}
                >
                  {speakingText ? <Square size={14} /> : <Volume2 size={14} />}
                  <span>{speakingText ? "Detener Audio" : "Escuchar Voz"}</span>
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="p-6 bg-slate-50 rounded-3xl border border-slate-200 space-y-3">
                  <div className="w-10 h-10 rounded-2xl bg-purple-600 text-white flex items-center justify-center font-black">
                    <MapPin size={20} />
                  </div>
                  <h4 className="text-base font-black text-slate-900">Gatillantes Externos (Ambiente)</h4>
                  <ul className="space-y-2 text-xs text-slate-700 font-medium">
                    <li className="flex items-center gap-2">📍 Lugares de venta o consumo anterior.</li>
                    <li className="flex items-center gap-2">👥 Amigos o conocidos del circuito de consumo.</li>
                    <li className="flex items-center gap-2">💵 Disponibilidad de dinero en efectivo / Día de pago.</li>
                  </ul>
                </div>

                <div className="p-6 bg-slate-50 rounded-3xl border border-slate-200 space-y-3">
                  <div className="w-10 h-10 rounded-2xl bg-indigo-600 text-white flex items-center justify-center font-black">
                    <Brain size={20} />
                  </div>
                  <h4 className="text-base font-black text-slate-900">Gatillantes Internos (Mente &amp; Cuerpo)</h4>
                  <ul className="space-y-2 text-xs text-slate-700 font-medium">
                    <li className="flex items-center gap-2">❤️ Emociones intensas: rabia, pena, soledad o euforia.</li>
                    <li className="flex items-center gap-2">🔋 Hambre, falta de sueño y agotamiento físico.</li>
                    <li className="flex items-center gap-2">💭 Ideas trampa: &quot;solo una dosis&quot; o &quot;lo tengo controlado&quot;.</li>
                  </ul>
                </div>
              </div>
            </div>
          )}

          {/* 3. EL CRAVING */}
          {subView === "craving" && (
            <div className="bg-white p-6 md:p-8 rounded-3xl shadow-sm border border-purple-100 space-y-6">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-purple-50 pb-5">
                <div>
                  <span className="text-[10px] font-black uppercase tracking-widest text-purple-700 bg-purple-100 px-3 py-1 rounded-md">
                    Neurobiología Aplicada
                  </span>
                  <h3 className="text-2xl font-black text-slate-800 mt-1">
                    El Craving: La Ola que Sube y Siempre Baja
                  </h3>
                </div>

                <button
                  onClick={() =>
                    speakText(
                      "El craving es el deseo urgente e intenso de consumir. Actúa como una ola marina: sube muy rápido, llega a su cresta máxima a los 15 minutos, y si no cedes, siempre vuelve a bajar."
                    )
                  }
                  className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 border transition-all ${
                    speakingText
                      ? "bg-purple-600 text-white border-purple-600 animate-pulse"
                      : "bg-purple-50 text-purple-700 border-purple-200 hover:bg-purple-100"
                  }`}
                >
                  {speakingText ? <Square size={14} /> : <Volume2 size={14} />}
                  <span>{speakingText ? "Detener Audio" : "Escuchar Voz"}</span>
                </button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl">
                  <span className="font-extrabold text-purple-700 block mb-1">💪 Nivel Físico</span>
                  <p className="text-slate-600">Taquicardia, sudoración, tensión en cuello y mandíbula.</p>
                </div>
                <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl">
                  <span className="font-extrabold text-blue-700 block mb-1">🧠 Nivel Mental</span>
                  <p className="text-slate-600">Pensamiento obsesivo, dificultad para concentrarse.</p>
                </div>
                <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl">
                  <span className="font-extrabold text-rose-700 block mb-1">💔 Nivel Emocional</span>
                  <p className="text-slate-600">Irritabilidad brusca, angustia profunda o vacío.</p>
                </div>
                <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl">
                  <span className="font-extrabold text-amber-700 block mb-1">☕ Digestivo</span>
                  <p className="text-slate-600">Nudo en la boca del estómago o náuseas reflejas.</p>
                </div>
              </div>
            </div>
          )}

          {/* 4. AUTOCUIDADO */}
          {subView === "autocuidado" && (
            <div className="bg-white p-6 md:p-8 rounded-3xl shadow-sm border border-purple-100 space-y-6">
              <div className="border-b border-purple-50 pb-5">
                <span className="text-[10px] font-black uppercase tracking-widest text-emerald-700 bg-emerald-100 px-3 py-1 rounded-md">
                  Salud Integral
                </span>
                <h3 className="text-2xl font-black text-slate-800 mt-1">
                  Pilares de Autocuidado Diario
                </h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-indigo-50 p-6 rounded-3xl border border-indigo-100 space-y-2">
                  <h4 className="font-black text-indigo-950 text-sm">Higiene del Sueño</h4>
                  <p className="text-xs text-indigo-900 font-medium leading-relaxed">
                    El cerebro se repara y lava toxinas exclusivamente de noche. El insomnio crónico dispara el cortisol y actúa como gatillante directo.
                  </p>
                </div>

                <div className="bg-emerald-50 p-6 rounded-3xl border border-emerald-100 space-y-2">
                  <h4 className="font-black text-emerald-950 text-sm">Alimentación Regular</h4>
                  <p className="text-xs text-emerald-900 font-medium leading-relaxed">
                    Saltarse comidas genera hipoglicemia. La falta de glucosa cerebral engaña a la mente haciéndola sentir craving urgente.
                  </p>
                </div>

                <div className="bg-teal-50 p-6 rounded-3xl border border-teal-100 space-y-2">
                  <h4 className="font-black text-teal-950 text-sm">Controles CESFAM</h4>
                  <p className="text-xs text-teal-900 font-medium leading-relaxed">
                    El dolor crónico y los problemas de salud física no tratados sobrecargan tu cuerpo. Mantén tus controles crónicos al día.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* 5. MEDICAMENTOS & REGLA 10 DÍAS */}
          {subView === "medicamentos" && (
            <div className="bg-white p-6 md:p-8 rounded-3xl shadow-sm border border-purple-100 space-y-6">
              <div className="border-b border-purple-50 pb-5">
                <span className="text-[10px] font-black uppercase tracking-widest text-purple-700 bg-purple-100 px-3 py-1 rounded-md">
                  Adherencia Farmacológica
                </span>
                <h3 className="text-2xl font-black text-slate-800 mt-1">
                  Uso de Psicofármacos &amp; Regla de los 10 Días
                </h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-purple-700 text-white p-6 rounded-3xl space-y-3 relative overflow-hidden shadow-md">
                  <h4 className="text-base font-black flex items-center gap-2">
                    <Clock size={18} /> La Regla de Oro de los 10 Días
                  </h4>
                  <p className="text-xs text-purple-100 leading-relaxed font-medium">
                    Nunca te quedes sin medicamentos. Quedarse sin psicofármacos de golpe provoca síndrome de abstinencia severo y crisis de rebote.
                  </p>
                  <div className="p-3 bg-white/20 rounded-2xl text-xs font-bold">
                    Faltando 10 días para que se terminen tus pastillas, acércate o llama al SOME del COSAM Rinconada de San Ramón para inscribirte en renovación de receta médica.
                  </div>
                </div>

                <div className="p-6 bg-slate-50 rounded-3xl border border-slate-200 space-y-3">
                  <h4 className="text-sm font-black text-slate-900">Pautas de Seguridad</h4>
                  <ul className="space-y-2 text-xs text-slate-700 font-medium">
                    <li className="flex items-center gap-2">⏰ Programa alarmas en tu celular para no olvidar las tomas.</li>
                    <li className="flex items-center gap-2">🚫 Jamás ajustes o suspendas dosis sin consultar con tu psiquiatra.</li>
                    <li className="flex items-center gap-2">⚠️ Informa cualquier efecto adverso de inmediato en tu control.</li>
                  </ul>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TOAST FEEDBACK */}
      <AnimatePresence>
        {feedbackMsg && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="fixed bottom-6 right-6 bg-slate-900 text-white px-5 py-3 rounded-2xl text-xs font-bold shadow-2xl z-50 flex items-center gap-2 border border-slate-800"
          >
            <CheckCircle size={15} className="text-emerald-400" />
            <span>{feedbackMsg}</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
