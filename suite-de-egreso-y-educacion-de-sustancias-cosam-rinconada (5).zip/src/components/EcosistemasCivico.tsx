import { useState, useMemo, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  FileText,
  ClipboardList,
  HeartPulse,
  Users,
  Search,
  Cloud,
  FileCheck2,
  BookOpen,
  MessageSquare,
  Database,
  Compass,
  CheckCircle2,
  Stethoscope,
  HardDrive,
  Presentation,
  Mail,
  FilePlus2,
  Calendar,
  CheckSquare,
  X
} from "lucide-react";

import { GoogleDriveService } from "../services/googleDriveService";
import { SearchGroundingPanel } from "./clinical/SearchGroundingPanel";
import { DriveSyncSettingsBar } from "./clinical/DriveSyncSettingsBar";
import { EvolucionesSOAP } from "./clinical/EvolucionesSOAP";
import { IngresoPAI } from "./clinical/IngresoPAI";
import { LaboratorioIA } from "./clinical/LaboratorioIA";
import { VademecumClinico } from "./clinical/VademecumClinico";
import { DerivacionesAltas } from "./clinical/DerivacionesAltas";
import { EgresosAdministrativos } from "./clinical/EgresosAdministrativos";
import { ReunionesClinicas } from "./clinical/ReunionesClinicas";
import { PresentacionesSlides } from "./clinical/PresentacionesSlides";
import { DocumentosDocs } from "./clinical/DocumentosDocs";
import { CorreoGmailClinico } from "./clinical/CorreoGmailClinico";
import { AgendaCalendarClinico } from "./clinical/AgendaCalendarClinico";
import { TareasKeepClinico } from "./clinical/TareasKeepClinico";
import { ProtocolosIngreso } from "./clinical/ProtocolosIngreso";
import { TriajeSIC } from "./clinical/TriajeSIC";
import { GuiaClinicaModal } from "./clinical/GuiaClinicaModal";
import { LiveVoiceModal } from "./clinical/LiveVoiceModal";
import { DeploymentGuideModal } from "./clinical/DeploymentGuideModal";

export type ActiveModuleId =
  | "soap"
  | "pai"
  | "laboratorio"
  | "vademecum"
  | "triaje"
  | "derivacion"
  | "egresos"
  | "reuniones"
  | "slides"
  | "docs"
  | "gmail"
  | "calendar"
  | "tasks_keep"
  | "protocolos";

interface ModuleConfig {
  id: ActiveModuleId;
  title: string;
  shortTitle: string;
  desc: string;
  category: "atencion" | "gestion" | "protocolos";
  icon: any;
  badge?: string;
}

export default function EcosistemasCivico() {
  const [activeModule, setActiveModule] = useState<ActiveModuleId>("soap");
  const [selectedCategory, setSelectedCategory] = useState<"todos" | "atencion" | "gestion" | "protocolos">("todos");
  const [searchQuery, setSearchQuery] = useState("");
  const [isModuleChanging, setIsModuleChanging] = useState(false);

  // Modales
  const [showGuiaModal, setShowGuiaModal] = useState(false);
  const [showLiveVoice, setShowLiveVoice] = useState(false);
  const [showDeployment, setShowDeployment] = useState(false);
  const [showIntegrations, setShowIntegrations] = useState(false);
  const [showDriveModal, setShowDriveModal] = useState(false);
  const [isDriveConnected, setIsDriveConnected] = useState(() => GoogleDriveService.isConnected());

  useEffect(() => {
    setIsDriveConnected(GoogleDriveService.isConnected());
    const handleAuthChange = () => {
      setIsDriveConnected(GoogleDriveService.isConnected());
    };
    window.addEventListener("cosam:gdrive-auth-changed", handleAuthChange);
    return () => {
      window.removeEventListener("cosam:gdrive-auth-changed", handleAuthChange);
    };
  }, []);

  const triggerHapticFeedback = () => {
    if (typeof window !== "undefined" && window.navigator && typeof window.navigator.vibrate === "function") {
      window.navigator.vibrate(10);
    }
  };

  const handleModuleChange = (moduleId: ActiveModuleId) => {
    triggerHapticFeedback();
    if (moduleId === activeModule) return;
    setIsModuleChanging(true);
    setActiveModule(moduleId);
    setTimeout(() => {
      setIsModuleChanging(false);
    }, 200);
  };

  const modules: ModuleConfig[] = [
    {
      id: "soap",
      title: "Evoluciones SOAP",
      shortTitle: "SOAP",
      desc: "Gestión de evoluciones clínicas estructuradas (Subjetivo, Objetivo, Análisis y Plan).",
      category: "atencion",
      icon: FileText,
      badge: "Vigente",
    },
    {
      id: "pai",
      title: "Planes Individuales PAI",
      shortTitle: "PAI 5Ps",
      desc: "Planes de Tratamiento Integral basados en factores predisponentes, precipitantes y protectores.",
      category: "atencion",
      icon: ClipboardList,
      badge: "5Ps",
    },
    {
      id: "laboratorio",
      title: "Laboratorio IA",
      shortTitle: "Laboratorio IA",
      desc: "Interpretación clínica de metabolitos, litemias, hemogramas y paneles toxicológicos.",
      category: "atencion",
      icon: HeartPulse,
      badge: "IA",
    },
    {
      id: "vademecum",
      title: "Vademécum & Equivalencias",
      shortTitle: "Vademécum",
      desc: "Calculadora de equivalencias de psicofármacos y pauta de reemplazo a Diazepam.",
      category: "atencion",
      icon: Database,
      badge: "Equivalencias",
    },
    {
      id: "triaje",
      title: "Recepción Triaje SIC",
      shortTitle: "Triaje SIC",
      desc: "Recepción y priorización clínica de solicitudes de interconsulta.",
      category: "gestion",
      icon: ClipboardList,
      badge: "Prioridad",
    },
    {
      id: "derivacion",
      title: "Derivaciones & Altas",
      shortTitle: "Derivaciones",
      desc: "Gestión de contra-derivaciones hacia CESFAM y coordinación con la red de salud.",
      category: "gestion",
      icon: Compass,
    },
    {
      id: "egresos",
      title: "Egresos y Cierres",
      shortTitle: "Egresos",
      desc: "Documentación de egreso administrativo o alta terapéutica según metas PAI.",
      category: "gestion",
      icon: FileCheck2,
    },
    {
      id: "reuniones",
      title: "Reuniones Clínicas",
      shortTitle: "Comités",
      desc: "Acuerdos y seguimientos de casos en reuniones de equipo multiprofesional.",
      category: "gestion",
      icon: Users,
    },
    {
      id: "slides",
      title: "Presentaciones Slides",
      shortTitle: "Google Slides",
      desc: "Creación, edición y visualización de presentaciones clínicas en Google Slides.",
      category: "gestion",
      icon: Presentation,
      badge: "Slides",
    },
    {
      id: "docs",
      title: "Documentos Google Docs",
      shortTitle: "Google Docs",
      desc: "Redacción, lectura y actualización de informes clínicos, certificados y actas en Google Docs.",
      category: "gestion",
      icon: FilePlus2,
      badge: "Docs",
    },
    {
      id: "gmail",
      title: "Correo Clínico Gmail",
      shortTitle: "Gmail",
      desc: "Bandeja de entrada, búsqueda y envío de correos clínicos para coordinación de red y Farmacia.",
      category: "gestion",
      icon: Mail,
      badge: "Gmail",
    },
    {
      id: "calendar",
      title: "Agenda Google Calendar",
      shortTitle: "Calendar",
      desc: "Programación de controles psiquiátricos, ingresos PAI 5Ps, comités clínicos y disponibilidad en Google Calendar.",
      category: "gestion",
      icon: Calendar,
      badge: "Calendar",
    },
    {
      id: "tasks_keep",
      title: "Tareas & Notas (Tasks + Keep)",
      shortTitle: "Tasks & Keep",
      desc: "Seguimiento clínico en Google Tasks y notas rápidas de box con listas de chequeo en Google Keep.",
      category: "gestion",
      icon: CheckSquare,
      badge: "Tasks/Keep",
    },
    {
      id: "protocolos",
      title: "Protocolos de Box",
      shortTitle: "Protocolos",
      desc: "Guías técnicas, flujos de atención y normativas clínicas vigentes.",
      category: "protocolos",
      icon: BookOpen,
      badge: "COSAM",
    },
  ];

  const filteredModules = useMemo(() => {
    return modules.filter((m) => {
      const matchesCategory = selectedCategory === "todos" || m.category === selectedCategory;
      const matchesSearch =
        !searchQuery.trim() ||
        m.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        m.shortTitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
        m.desc.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    });
  }, [modules, selectedCategory, searchQuery]);

  const activeModuleData = modules.find((m) => m.id === activeModule) || modules[0];

  return (
    <div className="space-y-4 animate-fadeIn pb-10" id="ecosistemas-civico-workspace">
      
      {/* =========================================================================
          BARRA DE NAVEGACIÓN UNIFICADA DE MÓDULOS CON GLASSMORPHISM EN SCROLL
         ========================================================================= */}
      <section className="sticky top-[53px] z-20 clinical-glass-bar rounded-2xl p-3 sm:p-4 space-y-3 transition-all">
        {/* Fila Superior: Contexto Institucional + Acciones Rápidas Unificadas */}
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-3 pb-2.5 border-b border-slate-200/80 dark:border-slate-800/80">
          <div className="flex items-center gap-2.5">
            <span className="bg-sky-50 dark:bg-sky-950/60 text-[#075985] dark:text-sky-300 border border-sky-200/80 dark:border-sky-800/60 text-[10px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded-md">
              ESTACIÓN CLÍNICA COSAM
            </span>
            <h2 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white tracking-tight">
              {activeModuleData.title}
            </h2>
            <span className="hidden md:inline text-xs text-slate-400 dark:text-slate-500">
              — {activeModuleData.desc}
            </span>
          </div>

          {/* Acciones Rápidas con Paleta Clínica Armonizada (Sin Sobrecarga Cromática) */}
          <div className="flex items-center gap-1.5 flex-wrap self-stretch lg:self-auto justify-end">
            <button
              onClick={() => handleModuleChange("calendar")}
              className="px-2.5 py-1.5 bg-slate-50 hover:bg-slate-100 dark:bg-slate-800/80 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 rounded-lg text-[11px] font-medium transition-colors flex items-center gap-1.5 border border-slate-200/90 dark:border-slate-700 cursor-pointer"
              title="Agenda médica, controles y comités en Google Calendar"
            >
              <Calendar size={12} strokeWidth={1.75} className="text-[#075985] dark:text-sky-400" />
              <span>Calendar</span>
            </button>

            <button
              onClick={() => handleModuleChange("docs")}
              className="px-2.5 py-1.5 bg-slate-50 hover:bg-slate-100 dark:bg-slate-800/80 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 rounded-lg text-[11px] font-medium transition-colors flex items-center gap-1.5 border border-slate-200/90 dark:border-slate-700 cursor-pointer"
              title="Crear y gestionar documentos clínicos en Google Docs"
            >
              <FilePlus2 size={12} strokeWidth={1.75} className="text-[#075985] dark:text-sky-400" />
              <span>Docs</span>
            </button>

            <button
              onClick={() => handleModuleChange("gmail")}
              className="px-2.5 py-1.5 bg-slate-50 hover:bg-slate-100 dark:bg-slate-800/80 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 rounded-lg text-[11px] font-medium transition-colors flex items-center gap-1.5 border border-slate-200/90 dark:border-slate-700 cursor-pointer"
              title="Bandeja y envío de correo clínico en Gmail"
            >
              <Mail size={12} strokeWidth={1.75} className="text-[#075985] dark:text-sky-400" />
              <span>Gmail</span>
            </button>

            <button
              onClick={() => handleModuleChange("slides")}
              className="px-2.5 py-1.5 bg-slate-50 hover:bg-slate-100 dark:bg-slate-800/80 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 rounded-lg text-[11px] font-medium transition-colors flex items-center gap-1.5 border border-slate-200/90 dark:border-slate-700 cursor-pointer"
              title="Crear y gestionar presentaciones clínicas en Google Slides"
            >
              <Presentation size={12} strokeWidth={1.75} className="text-[#075985] dark:text-sky-400" />
              <span>Slides</span>
            </button>

            <button
              onClick={() => setShowDriveModal(true)}
              className="px-2.5 py-1.5 bg-slate-50 hover:bg-slate-100 dark:bg-slate-800/80 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 rounded-lg text-[11px] font-medium transition-colors flex items-center gap-1.5 border border-slate-200/90 dark:border-slate-700 cursor-pointer"
              title="Configuración de Respaldo y Sincronización con Google Drive"
            >
              <HardDrive size={12} strokeWidth={1.75} className="text-slate-500 dark:text-slate-400" />
              <span>Drive</span>
            </button>

            <button
              onClick={() => setShowIntegrations(true)}
              className="px-2.5 py-1.5 bg-slate-50 hover:bg-slate-100 dark:bg-slate-800/80 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 rounded-lg text-[11px] font-medium transition-colors flex items-center gap-1.5 border border-slate-200/90 dark:border-slate-700 cursor-pointer"
            >
              <Cloud size={12} strokeWidth={1.75} className="text-slate-500 dark:text-slate-400" />
              <span>Cloud &amp; IA</span>
            </button>

            <button
              onClick={() => setShowGuiaModal(true)}
              className="px-2.5 py-1.5 bg-slate-50 hover:bg-slate-100 dark:bg-slate-800/80 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 rounded-lg text-[11px] font-medium transition-colors flex items-center gap-1.5 border border-slate-200/90 dark:border-slate-700 cursor-pointer"
            >
              <BookOpen size={12} strokeWidth={1.75} className="text-slate-500 dark:text-slate-400" />
              <span>Guía</span>
            </button>

            <button
              onClick={() => setShowLiveVoice(true)}
              className="px-3 py-1.5 bg-[#075985] hover:bg-[#0c4a6e] text-white rounded-lg text-[11px] font-semibold transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
            >
              <MessageSquare size={12} strokeWidth={1.75} />
              <span>Voz Box</span>
            </button>
          </div>
        </div>
        
        {/* Filtros de Categoría y Buscador en una sola fila */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
          <div className="flex items-center gap-1 bg-slate-100/90 dark:bg-slate-800/80 p-0.5 rounded-lg border border-slate-200/80 dark:border-slate-700/60 overflow-x-auto">
            <button
              onClick={() => setSelectedCategory("todos")}
              className={`px-2.5 py-1 rounded-md text-xs font-semibold transition-colors whitespace-nowrap cursor-pointer ${
                selectedCategory === "todos"
                  ? "bg-white dark:bg-slate-900 text-[#075985] dark:text-sky-300 shadow-xs"
                  : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
              }`}
            >
              Todos ({modules.length})
            </button>
            <button
              onClick={() => setSelectedCategory("atencion")}
              className={`px-2.5 py-1 rounded-md text-xs font-semibold transition-colors whitespace-nowrap cursor-pointer ${
                selectedCategory === "atencion"
                  ? "bg-white dark:bg-slate-900 text-[#075985] dark:text-sky-300 shadow-xs"
                  : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
              }`}
            >
              Atención Médica
            </button>
            <button
              onClick={() => setSelectedCategory("gestion")}
              className={`px-2.5 py-1 rounded-md text-xs font-semibold transition-colors whitespace-nowrap cursor-pointer ${
                selectedCategory === "gestion"
                  ? "bg-white dark:bg-slate-900 text-[#075985] dark:text-sky-300 shadow-xs"
                  : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
              }`}
            >
              Gestión &amp; Red
            </button>
            <button
              onClick={() => setSelectedCategory("protocolos")}
              className={`px-2.5 py-1 rounded-md text-xs font-semibold transition-colors whitespace-nowrap cursor-pointer ${
                selectedCategory === "protocolos"
                  ? "bg-white dark:bg-slate-900 text-[#075985] dark:text-sky-300 shadow-xs"
                  : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
              }`}
            >
              Protocolos COSAM
            </button>
          </div>

          {/* Buscador de módulo compacto */}
          <div className="relative sm:w-64">
            <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Filtrar módulo clínico..."
              className="w-full pl-8 pr-7 py-1 rounded-lg bg-white/90 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-800 dark:text-slate-200 placeholder:text-slate-400 focus:outline-hidden focus:border-[#075985]"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery("")}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X size={12} />
              </button>
            )}
          </div>
        </div>

        {/* Tira de Módulos Seleccionables con Jerarquía Visual Unificada */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 pt-0.5 no-scrollbar">
          {filteredModules.map((m) => {
            const Icon = m.icon;
            const isActive = activeModule === m.id;
            return (
              <button
                key={m.id}
                onClick={() => handleModuleChange(m.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 whitespace-nowrap shrink-0 border cursor-pointer ${
                  isActive
                    ? "bg-[#075985] text-white border-[#075985] shadow-xs"
                    : "bg-white/80 dark:bg-slate-800/60 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200/90 dark:border-slate-700/80"
                }`}
              >
                <Icon size={13} strokeWidth={isActive ? 2 : 1.75} className={isActive ? "text-sky-200" : "text-slate-500 dark:text-slate-400"} />
                <span>{m.title}</span>
                {m.badge && (
                  <span
                    className={`text-[9px] px-1.5 py-0.2 rounded-md font-bold ${
                      isActive
                        ? "bg-white/20 text-white"
                        : "bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300"
                    }`}
                  >
                    {m.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </section>

      {/* =========================================================================
          CONTENIDO CLÍNICO ACTIVO A ANCHO COMPLETO (SIN CABECERA DUPLICADA)
         ========================================================================= */}
      <main className="w-full">

        {/* Renderizado directo del módulo clínico */}
        <div className="w-full">
          <AnimatePresence mode="wait">
            {isModuleChanging ? (
              <motion.div
                key="skeleton-loader"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.1 }}
                className="w-full p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3"
              >
                <div className="h-4 bg-slate-200 dark:bg-slate-800 rounded-md w-1/4 animate-pulse" />
                <div className="h-20 bg-slate-100 dark:bg-slate-800/60 rounded-xl animate-pulse" />
              </motion.div>
            ) : (
              <motion.div
                key={activeModule}
                initial={{ opacity: 0, y: 4 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -4 }}
                transition={{ duration: 0.14 }}
                className="w-full"
              >
                {activeModule === "soap" && (
                  <EvolucionesSOAP
                    isDriveConnected={isDriveConnected}
                    onOpenDriveModal={() => setShowDriveModal(true)}
                  />
                )}
                {activeModule === "pai" && (
                  <IngresoPAI
                    isDriveConnected={isDriveConnected}
                    onOpenDriveModal={() => setShowDriveModal(true)}
                  />
                )}
                {activeModule === "laboratorio" && <LaboratorioIA />}
                {activeModule === "vademecum" && <VademecumClinico />}
                {activeModule === "triaje" && <TriajeSIC />}
                {activeModule === "derivacion" && <DerivacionesAltas />}
                {activeModule === "egresos" && <EgresosAdministrativos />}
                {activeModule === "reuniones" && <ReunionesClinicas />}
                {activeModule === "slides" && <PresentacionesSlides />}
                {activeModule === "docs" && <DocumentosDocs />}
                {activeModule === "gmail" && <CorreoGmailClinico />}
                {activeModule === "calendar" && <AgendaCalendarClinico />}
                {activeModule === "tasks_keep" && <TareasKeepClinico />}
                {activeModule === "protocolos" && <ProtocolosIngreso />}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>

      {/* =========================================================================
          MODAL LIMPIO DE CLOUD & IA (NO EMPUJA EL CONTENIDO HACIA ABAJO)
         ========================================================================= */}
      <AnimatePresence>
        {showIntegrations && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.97 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.97 }}
              transition={{ duration: 0.15 }}
              className="w-full max-w-4xl max-h-[90vh] bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xl overflow-hidden flex flex-col"
            >
              {/* Header Modal */}
              <div className="px-5 py-3.5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Cloud size={16} strokeWidth={1.75} className="text-slate-600 dark:text-slate-300" />
                  <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                    Cloud &amp; Búsqueda Clínica Grounding
                  </h3>
                </div>
                <button
                  onClick={() => setShowIntegrations(false)}
                  className="p-1 rounded-md text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                >
                  <X size={16} />
                </button>
              </div>

              {/* Contenido Modal */}
              <div className="p-5 overflow-y-auto space-y-4">
                <DriveSyncSettingsBar />
                <SearchGroundingPanel />
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* =========================================================================
          MODAL DE GOOGLE DRIVE LIMPIO Y RÁPIDO
         ========================================================================= */}
      <AnimatePresence>
        {showDriveModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.97 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.97 }}
              transition={{ duration: 0.15 }}
              className="w-full max-w-2xl bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xl overflow-hidden flex flex-col"
            >
              <div className="px-5 py-3.5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <HardDrive size={16} strokeWidth={1.75} className="text-slate-700 dark:text-slate-300" />
                  <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                    Sincronización y Respaldo en Google Drive
                  </h3>
                </div>
                <button
                  onClick={() => setShowDriveModal(false)}
                  className="p-1 rounded-md text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  <X size={16} />
                </button>
              </div>

              <div className="p-5 space-y-4">
                <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                  Configuración centralizada de sincronización automática y carpetas destino para el guardado institucional de evoluciones SOAP y planes PAI.
                </p>
                <DriveSyncSettingsBar moduleKey="soap" moduleTitle="Evoluciones SOAP & Formulación PAI" />
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Modales de Asistencia y Voz */}
      {showGuiaModal && <GuiaClinicaModal onClose={() => setShowGuiaModal(false)} />}
      {showLiveVoice && <LiveVoiceModal onClose={() => setShowLiveVoice(false)} />}
      {showDeployment && <DeploymentGuideModal onClose={() => setShowDeployment(false)} />}
    </div>
  );
}
