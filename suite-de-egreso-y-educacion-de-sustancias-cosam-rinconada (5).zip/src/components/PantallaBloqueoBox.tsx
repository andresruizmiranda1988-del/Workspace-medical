import { useState, useEffect, useCallback, useMemo } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  ShieldCheck,
  SlidersHorizontal,
  Settings2,
  KeyRound,
  LockKeyhole,
  LockKeyholeOpen,
  X,
  Volume2,
  VolumeX,
  Timer,
  Clock3,
  Clock,
  Sparkles,
  Soup,
  Users,
  Moon,
  Leaf,
  GlassWater,
  Quote,
  RotateCcw,
  Delete,
  Check,
  Plus,
  Trash2,
  UtensilsCrossed,
  Footprints,
  Hourglass
} from "lucide-react";
import { playTherapeuticTone } from "../utils/audioGuide";

interface PantallaBloqueoBoxProps {
  isLocked: boolean;
  onUnlock: () => void;
  doctorName?: string;
}

export type LockPresetMode = "auto" | "almuerzo" | "reunion" | "fuera_horario" | "pausa";

export const SCHEDULE_LOCK_CONFIG = {
  almuerzo: {
    id: "almuerzo",
    badge: "HORA DE ALMUERZO • 13:30 A 14:30",
    badgeColor: "bg-amber-500/15 text-amber-300 border-amber-400/25",
    icon: UtensilsCrossed,
    title: "Almorzando donde la Carito o en el Casino 🍲",
    text: "Hola, salí a almorzar. Estoy donde la Carito o en el casino del COSAM. ¡Vuelvo a las 14:30 horas!"
  },
  reunion: {
    id: "reunion",
    badge: "REUNIÓN CLÍNICA DE EQUIPO",
    badgeColor: "bg-indigo-500/15 text-indigo-300 border-indigo-400/25",
    icon: Users,
    title: "Reunión clínica de equipo 👥",
    text: "Hola, en este momento estoy en reunión clínica de equipo en la sala común. Si es muy urgente, asómate a buscarme allá."
  },
  fuera_horario: {
    id: "fuera_horario",
    badge: "JORNADA TERMINADA",
    badgeColor: "bg-slate-500/15 text-slate-300 border-slate-400/25",
    icon: Moon,
    title: "Turno finalizado • Fuera de horario 🌙",
    text: "Hola, la jornada terminó. Estoy descansando con mi familia, en cualquier parte menos en el box. ¡Nos vemos mañana!"
  },
  pausa_activa: {
    id: "pausa_activa",
    badge: "PAUSA ACTIVA DEL BOX",
    badgeColor: "bg-emerald-500/15 text-emerald-300 border-emerald-400/25",
    icon: Leaf,
    title: "Ya vengo • Pausa breve de box 🌿",
    text: "Pausa breve de box, agüita fresca y respiración. Escríbeme al WhatsApp cualquier cosa."
  }
} as const;

export const HORARIOS_BLOQUEO_CONFIG = SCHEDULE_LOCK_CONFIG;

// Píldoras de humor y anécdotas iniciales de la APS chilena (sin café, con humor de recetas, SOME y farmacia)
const DEFAULT_HUMOR_QUOTES = [
  "Ruiz, ¡que no se te olvide el timbre y la firma en las recetas! 📝",
  "Ruiz, anota bien el RUT para que en farmacia no le rechacen la receta al paciente. 🩺",
  "Ruiz, revisa el WhatsApp del equipo de tratamiento y el WhatsApp de farmacia comunal. 📱",
  "Doctor que no revisa dos veces el RUT en la receta... ¡terminan buscando al doctor por todo el pasillo! 🏃‍♂️😅",
  "Paciencia, por favor... que en farmacia me entiendan la letra hoy. 🩺",
  "Paciencia, mucha paciencia con la legendaria impresora del SOME. 🖨️",
  "¿Dónde dejé el talonario de recetas cheque? Si alguien lo vio, favor no asustarme... 📑",
  "Por favor, hagan más grande el talonario de recetas retenidas. Se lo suplico. 📋🙏",
  "Por favor, que llegue rápido el WhatsApp del menú de la Carito el día de hoy. 🍲📱",
  "Es hora de un momento zen... sentado en el box para dormir. 😴💺",
  "Si el Rayen se queda pegado, tómalo como una señal del universo para estirar las piernas y respirar. 💻✨",
  "Inhala paciencia (4s), retén tranquilidad (7s) y no discutas con el tóner de la impresora. 🧘‍♂️",
  "Recuerda: Si la interconsulta no lleva epicrisis clara, los colegas de enlace te la van a rebotar con cariño. 📋",
  "Diagnóstico del box: Batería social al 60%, agüita fresca en la botella y vocación médica intacta al 100%. 💧",
  "Acuérdate de guardar los cambios en la ficha clínica antes de que el sistema decida cerrar sesión por inactividad. 💾",
  "En caso de duda clínica: respira profundo y recuerda que eres un tremendo profesional. Ánimo Dr. Andrés. 🛡️",
  "Modo Zen en el box: Cinco minutos de desconexión total antes de continuar con la siguiente atención. 🌿"
];

// Temas ambientales relajantes
type AmbientTheme = "sunset" | "cosmic" | "mint" | "lofi";

// Tipos de cuenta regresiva secundaria
type SecondaryCountdownType = "almuerzo" | "pausa_tarde" | "micro_pause";

// Pestañas de configuración protegida
type ConfigTab = "timers" | "quotes" | "theme";

interface GlowingLockIconProps {
  size?: number;
  strokeWidth?: number;
  className?: string;
  glowColor?: string;
  active?: boolean;
}

function GlowingLockIcon({
  size = 13,
  strokeWidth = 1.5,
  className = "text-amber-300",
  glowColor = "rgba(251, 191, 36, 0.45)",
  active = true
}: GlowingLockIconProps) {
  return (
    <span className="relative inline-flex items-center justify-center">
      {active && (
        <motion.span
          animate={{
            opacity: [0.25, 0.75, 0.25],
            scale: [0.9, 1.25, 0.9]
          }}
          transition={{
            duration: 2.6,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute -inset-1 rounded-full blur-[4px] pointer-events-none"
          style={{ backgroundColor: glowColor }}
        />
      )}
      <LockKeyhole
        size={size}
        strokeWidth={strokeWidth}
        className={`relative z-10 ${className}`}
        style={active ? { filter: `drop-shadow(0 0 5px ${glowColor})` } : undefined}
      />
    </span>
  );
}

function GlowingUnlockIcon({
  size = 14,
  strokeWidth = 1.5,
  className = "text-slate-950"
}: {
  size?: number;
  strokeWidth?: number;
  className?: string;
}) {
  return (
    <span className="relative inline-flex items-center justify-center">
      <motion.span
        animate={{
          opacity: [0.25, 0.7, 0.25],
          scale: [0.92, 1.25, 0.92]
        }}
        transition={{
          duration: 2.2,
          repeat: Infinity,
          ease: "easeInOut"
        }}
        className="absolute -inset-1 rounded-full bg-emerald-300/40 blur-[4px] pointer-events-none"
      />
      <LockKeyholeOpen
        size={size}
        strokeWidth={strokeWidth}
        className={`relative z-10 ${className}`}
      />
    </span>
  );
}

export default function PantallaBloqueoBox({
  isLocked,
  onUnlock,
  doctorName = "Dr. Andrés Felipe Ruiz Miranda"
}: PantallaBloqueoBoxProps) {
  const [pin, setPin] = useState<string>("");
  const [isError, setIsError] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string>("");
  const [currentTime, setCurrentTime] = useState<Date>(new Date());
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);

  // Tema ambiental
  const [ambientTheme, setAmbientTheme] = useState<AmbientTheme>(() => {
    try {
      return (localStorage.getItem("cosam_ambient_theme") as AmbientTheme) || "sunset";
    } catch {
      return "sunset";
    }
  });

  // Hora de fin de jornada (Cuenta regresiva 1)
  const [workdayEndTime, setWorkdayEndTime] = useState<string>(() => {
    try {
      return localStorage.getItem("cosam_workday_end") || "17:30";
    } catch {
      return "17:30";
    }
  });

  // Hora personalizada para almuerzo y pausa
  const [lunchTargetTime, setLunchTargetTime] = useState<string>(() => {
    try {
      return localStorage.getItem("cosam_lunch_time") || "13:30";
    } catch {
      return "13:30";
    }
  });

  const [afternoonBreakTime, setAfternoonBreakTime] = useState<string>(() => {
    try {
      return localStorage.getItem("cosam_break_time") || "16:00";
    } catch {
      return "16:00";
    }
  });

  // Tipo de cuenta regresiva secundaria
  const [secondaryType, setSecondaryType] = useState<SecondaryCountdownType>(() => {
    try {
      return (localStorage.getItem("cosam_secondary_timer_type") as SecondaryCountdownType) || "almuerzo";
    } catch {
      return "almuerzo";
    }
  });

  // Micro-Pausa
  const [microPauseSeconds, setMicroPauseSeconds] = useState<number>(300);
  const [isMicroPauseRunning, setIsMicroPauseRunning] = useState<boolean>(false);

  // Modo de bloqueo seleccionado
  const [lockMode, setLockMode] = useState<LockPresetMode>(() => {
    try {
      return (localStorage.getItem("cosam_lock_mode") as LockPresetMode) || "auto";
    } catch {
      return "auto";
    }
  });

  // Lista dinámica de frases de humor personalizables
  const [humorQuotes, setHumorQuotes] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem("cosam_custom_humor_quotes");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
      return DEFAULT_HUMOR_QUOTES;
    } catch {
      return DEFAULT_HUMOR_QUOTES;
    }
  });

  // Velocidad de rotación en segundos
  const [rotationSpeedSecs, setRotationSpeedSecs] = useState<number>(() => {
    try {
      return Number(localStorage.getItem("cosam_quote_interval_secs")) || 7;
    } catch {
      return 7;
    }
  });

  // Frase actual
  const [quoteIndex, setQuoteIndex] = useState<number>(0);
  const [newQuoteInput, setNewQuoteInput] = useState<string>("");

  // SEGURIDAD: Control de acceso a configuraciones con PIN
  const [isAuthPinModalOpen, setIsAuthPinModalOpen] = useState<boolean>(false);
  const [pendingTab, setPendingTab] = useState<ConfigTab>("timers");
  const [authPinInput, setAuthPinInput] = useState<string>("");
  const [authPinError, setAuthPinError] = useState<string>("");

  // Modal de configuración desbloqueado
  const [isConfigModalOpen, setIsConfigModalOpen] = useState<boolean>(false);
  const [activeConfigTab, setActiveConfigTab] = useState<ConfigTab>("timers");

  // PIN guardado
  const [savedPin, setSavedPin] = useState<string>(() => {
    try {
      return localStorage.getItem("cosam_box_pin") || "1234";
    } catch {
      return "1234";
    }
  });

  // Reloj digital en tiempo real cada 1 segundo
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Micro-Pausa timer countdown
  useEffect(() => {
    if (!isMicroPauseRunning || !isLocked) return;
    const interval = setInterval(() => {
      setMicroPauseSeconds((prev) => {
        if (prev <= 1) {
          setIsMicroPauseRunning(false);
          if (soundEnabled) playTherapeuticTone("bell");
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [isMicroPauseRunning, isLocked, soundEnabled]);

  // Rotación AUTOMÁTICA de frases según velocidad configurada
  useEffect(() => {
    if (!isLocked || rotationSpeedSecs <= 0 || humorQuotes.length === 0) return;

    const intervalMs = rotationSpeedSecs * 1000;
    const timer = setInterval(() => {
      setQuoteIndex((prev) => (prev + 1) % humorQuotes.length);
    }, intervalMs);

    return () => clearInterval(timer);
  }, [isLocked, rotationSpeedSecs, humorQuotes.length]);

  // Manejo de teclado físico global mientras esté bloqueado
  useEffect(() => {
    if (!isLocked) return;

    const handleGlobalKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA")) {
        return;
      }

      if (isConfigModalOpen || isAuthPinModalOpen) return;

      if (e.key >= "0" && e.key <= "9") {
        e.preventDefault();
        handleNumClick(e.key);
      } else if (e.key === "Backspace") {
        e.preventDefault();
        setPin((prev) => prev.slice(0, -1));
        if (soundEnabled) playTherapeuticTone("ding");
      } else if (e.key === "Escape" || e.key === "c" || e.key === "C") {
        setPin("");
      }
    };

    window.addEventListener("keydown", handleGlobalKeyDown);
    return () => window.removeEventListener("keydown", handleGlobalKeyDown);
  }, [isLocked, isConfigModalOpen, isAuthPinModalOpen, pin, savedPin, soundEnabled]);

  const handleNumClick = useCallback(
    (num: string) => {
      setPin((prev) => {
        if (prev.length >= 6) return prev;
        const nextPin = prev + num;
        if (soundEnabled) playTherapeuticTone("ding");

        if (nextPin === savedPin) {
          if (soundEnabled) playTherapeuticTone("success");
          setTimeout(() => {
            setPin("");
            setIsError(false);
            onUnlock();
          }, 150);
        } else if (nextPin.length >= savedPin.length) {
          setIsError(true);
          setErrorMessage("PIN incorrecto. Intente de nuevo.");
          if (soundEnabled) playTherapeuticTone("hold");
          setTimeout(() => {
            setPin("");
            setIsError(false);
          }, 700);
        }
        return nextPin;
      });
    },
    [savedPin, onUnlock, soundEnabled]
  );

  const handleNextQuoteManually = () => {
    if (humorQuotes.length === 0) return;
    setQuoteIndex((prev) => (prev + 1) % humorQuotes.length);
    if (soundEnabled) playTherapeuticTone("ding");
  };

  // Solicitar PIN para abrir configuración en pestaña específica
  const requestProtectedConfig = (tab: ConfigTab = "timers") => {
    setPendingTab(tab);
    setAuthPinInput("");
    setAuthPinError("");
    setIsAuthPinModalOpen(true);
  };

  const handleVerifyAuthPin = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (authPinInput === savedPin) {
      if (soundEnabled) playTherapeuticTone("success");
      setIsAuthPinModalOpen(false);
      setActiveConfigTab(pendingTab);
      setIsConfigModalOpen(true);
      setAuthPinInput("");
      setAuthPinError("");
    } else {
      setAuthPinError("PIN incorrecto. Modificación no autorizada.");
      if (soundEnabled) playTherapeuticTone("hold");
      setAuthPinInput("");
    }
  };

  // CÁLCULO 1: CUENTA REGRESIVA DE FIN DE JORNADA
  const workdayCountdown = useMemo(() => {
    const now = currentTime;
    const [targetHour, targetMin] = (workdayEndTime || "17:30").split(":").map(Number);
    const target = new Date(now);
    target.setHours(targetHour, targetMin, 0, 0);

    const diffMs = target.getTime() - now.getTime();
    if (diffMs <= 0) {
      return {
        isFinished: true,
        hours: 0,
        minutes: 0,
        seconds: 0,
        percentage: 100,
        label: "¡Jornada finalizada! Hora de desconectar y descansar 🎉"
      };
    }

    const totalSecs = Math.floor(diffMs / 1000);
    const h = Math.floor(totalSecs / 3600);
    const m = Math.floor((totalSecs % 3600) / 60);
    const s = totalSecs % 60;

    const startOfDay = new Date(now);
    startOfDay.setHours(8, 0, 0, 0);
    const totalWorkdayMs = target.getTime() - startOfDay.getTime();
    const elapsedMs = Math.max(0, now.getTime() - startOfDay.getTime());
    const pct = Math.min(100, Math.max(0, Math.round((elapsedMs / totalWorkdayMs) * 100)));

    let statusPhrase = "Paso a paso, un paciente a la vez.";
    if (h === 0 && m < 30) {
      statusPhrase = "¡Últimos minutos de turno! La meta está aquí 🚀";
    } else if (h === 0) {
      statusPhrase = "Menos de una hora para la salida. ¡Recta final! 🎯";
    } else if (h <= 2) {
      statusPhrase = "Avanzando con solidez la tarde médica. 🌿";
    } else {
      statusPhrase = "Jornada en curso con energía y vocación. 💧";
    }

    return {
      isFinished: false,
      hours: h,
      minutes: m,
      seconds: s,
      percentage: pct,
      label: statusPhrase
    };
  }, [currentTime, workdayEndTime]);

  // CÁLCULO 2: CUENTA REGRESIVA SECUNDARIA
  const secondaryCountdown = useMemo(() => {
    const now = currentTime;

    if (secondaryType === "micro_pause") {
      const m = Math.floor(microPauseSeconds / 60);
      const s = microPauseSeconds % 60;
      return {
        title: "Micro-Pausa Zen (5 min)",
        icon: Timer,
        isFinished: microPauseSeconds === 0,
        hours: 0,
        minutes: m,
        seconds: s,
        note: isMicroPauseRunning
          ? "Respirando con calma..."
          : microPauseSeconds === 0
          ? "¡Pausa completada!"
          : "Pausa en espera"
      };
    }

    const targetTimeStr = secondaryType === "almuerzo" ? lunchTargetTime : afternoonBreakTime;
    const [targetHour, targetMin] = (targetTimeStr || "13:30").split(":").map(Number);
    const target = new Date(now);
    target.setHours(targetHour, targetMin, 0, 0);

    const diffMs = target.getTime() - now.getTime();
    const isPast = diffMs <= 0;

    const totalSecs = Math.max(0, Math.floor(diffMs / 1000));
    const h = Math.floor(totalSecs / 3600);
    const m = Math.floor((totalSecs % 3600) / 60);
    const s = totalSecs % 60;

    if (secondaryType === "almuerzo") {
      return {
        title: `Próximo Almuerzo (${lunchTargetTime})`,
        icon: Soup,
        isFinished: isPast,
        hours: h,
        minutes: m,
        seconds: s,
        note: isPast
          ? "¡Hora de almorzar! La Carito o Casino te esperan 🍲"
          : "La cazuela y el descanso están en camino 🍲"
      };
    } else {
      return {
        title: `Pausa de la Tarde (${afternoonBreakTime})`,
        icon: GlassWater,
        isFinished: isPast,
        hours: h,
        minutes: m,
        seconds: s,
        note: isPast
          ? "¡Momento para estirar las piernas y tomar agüita! 💧"
          : "Pausa de hidratación y descanso mental 🌿"
      };
    }
  }, [currentTime, secondaryType, lunchTargetTime, afternoonBreakTime, microPauseSeconds, isMicroPauseRunning]);

  const getDisplayContent = () => {
    if (lockMode === "almuerzo") return SCHEDULE_LOCK_CONFIG.almuerzo;
    if (lockMode === "reunion") return SCHEDULE_LOCK_CONFIG.reunion;
    if (lockMode === "fuera_horario") return SCHEDULE_LOCK_CONFIG.fuera_horario;
    if (lockMode === "pausa") return SCHEDULE_LOCK_CONFIG.pausa_activa;

    const hours = currentTime.getHours();
    const minutes = currentTime.getMinutes();
    const totalMinutes = hours * 60 + minutes;
    const dayOfWeek = currentTime.getDay();

    if (dayOfWeek === 0 || dayOfWeek === 6) return SCHEDULE_LOCK_CONFIG.fuera_horario;
    if (totalMinutes >= 810 && totalMinutes < 870) return SCHEDULE_LOCK_CONFIG.almuerzo;
    if (totalMinutes >= 480 && totalMinutes < 525) return SCHEDULE_LOCK_CONFIG.reunion;
    if (dayOfWeek === 4 && totalMinutes >= 720 && totalMinutes < 780) return SCHEDULE_LOCK_CONFIG.reunion;
    if (totalMinutes >= 1050 || totalMinutes < 480) return SCHEDULE_LOCK_CONFIG.fuera_horario;
    return SCHEDULE_LOCK_CONFIG.pausa_activa;
  };

  const currentContent = getDisplayContent();
  const IconComponent = currentContent.icon;
  const SecondaryIcon = secondaryCountdown.icon;

  const themeGradients = {
    sunset: "from-slate-950 via-purple-950/70 to-amber-950/60",
    cosmic: "from-slate-950 via-indigo-950/85 to-blue-950/75",
    mint: "from-slate-950 via-teal-950/70 to-slate-900",
    lofi: "from-slate-950 via-fuchsia-950/60 to-slate-900"
  };

  // Funciones para gestión de frases personalizadas
  const handleAddCustomQuote = () => {
    const text = newQuoteInput.trim();
    if (!text) return;
    const updated = [text, ...humorQuotes];
    setHumorQuotes(updated);
    localStorage.setItem("cosam_custom_humor_quotes", JSON.stringify(updated));
    setNewQuoteInput("");
    setQuoteIndex(0);
    if (soundEnabled) playTherapeuticTone("ding");
  };

  const handleDeleteQuote = (idx: number) => {
    if (humorQuotes.length <= 1) return;
    const updated = humorQuotes.filter((_, i) => i !== idx);
    setHumorQuotes(updated);
    localStorage.setItem("cosam_custom_humor_quotes", JSON.stringify(updated));
    setQuoteIndex(0);
  };

  const handleResetQuotes = () => {
    setHumorQuotes(DEFAULT_HUMOR_QUOTES);
    localStorage.removeItem("cosam_custom_humor_quotes");
    setQuoteIndex(0);
  };

  if (!isLocked) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className={`fixed inset-0 z-50 bg-gradient-to-br ${themeGradients[ambientTheme]} text-white flex flex-col justify-between p-4 sm:p-6 select-none overflow-y-auto backdrop-blur-md font-sans`}
      >
        {/* CABECERA SUPERIOR MINIMALISTA & PREMIUM */}
        <header className="flex flex-col sm:flex-row items-center justify-between gap-3 border-b border-white/10 pb-3 max-w-6xl mx-auto w-full">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-white/10 border border-white/15 flex items-center justify-center text-amber-300/90 shadow-xs backdrop-blur-md relative group">
              <span className="absolute -inset-0.5 rounded-xl bg-amber-400/10 blur-[3px] pointer-events-none" />
              <ShieldCheck size={18} strokeWidth={1.5} className="relative z-10" />
            </div>
            <div>
              <span className="text-[11px] font-medium tracking-wide text-slate-300 block">
                COSAM Rinconada • San Ramón
              </span>
              <h2 className="text-sm sm:text-base font-semibold text-white tracking-tight leading-tight">
                {doctorName}
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {/* Alternar sonido con indicador minimalista */}
            <button
              onClick={() => setSoundEnabled(!soundEnabled)}
              className="p-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 hover:text-white transition-all cursor-pointer relative"
              title={soundEnabled ? "Silenciar tonos terapéuticos" : "Activar tonos terapéuticos"}
            >
              {soundEnabled ? (
                <span className="relative flex items-center justify-center">
                  <span className="absolute -top-1 -right-1 w-1.5 h-1.5 rounded-full bg-emerald-400 shadow-[0_0_6px_rgba(52,211,153,0.9)]" />
                  <Volume2 size={14} strokeWidth={1.5} className="text-emerald-300" />
                </span>
              ) : (
                <VolumeX size={14} strokeWidth={1.5} className="text-slate-400" />
              )}
            </button>

            {/* Opciones protegidas obligatoriamente con PIN con animación de brillo suave */}
            <button
              onClick={() => requestProtectedConfig("timers")}
              className="px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 border border-amber-400/25 hover:border-amber-400/45 text-xs font-medium text-slate-200 hover:text-white flex items-center gap-2 transition-all cursor-pointer shadow-xs group"
              title="Configuraciones protegidas por PIN"
            >
              <GlowingLockIcon size={13} strokeWidth={1.5} active={true} />
              <span className="tracking-wide font-medium">Opciones</span>
            </button>

            {/* Reloj Digital Minimalista */}
            <div className="px-3 py-1.5 rounded-xl bg-white/10 border border-white/15 text-right backdrop-blur-md shadow-xs flex items-center gap-2.5">
              <Clock3 size={15} strokeWidth={1.5} className="text-amber-300/85 hidden sm:block" />
              <div>
                <div className="text-[10px] font-medium text-slate-300 capitalize">
                  {currentTime.toLocaleDateString("es-CL", {
                    weekday: "short",
                    day: "numeric",
                    month: "short"
                  })}
                </div>
                <div className="text-base font-bold font-mono tracking-wider text-white leading-none">
                  {currentTime.toLocaleTimeString("es-CL", {
                    hour: "2-digit",
                    minute: "2-digit",
                    second: "2-digit"
                  })}
                </div>
              </div>
            </div>
          </div>
        </header>

        {/* CONTENIDO PRINCIPAL: 2 COLUMNAS */}
        <main className="my-auto py-3 grid grid-cols-1 lg:grid-cols-12 gap-5 items-center max-w-6xl mx-auto w-full">
          
          {/* PANEL IZQUIERDO:
              1° TARJETA DE ESTADO (MÁS GRANDE Y PROMINENTE ARRIBA)
              2° WIDGETS DE CONTEO REGRESIVO (EN MEDIO)
              3° TARJETA DE FRASES DIVERTIDAS (ABAJO, SIN TÍTULO NI BARRA)
          */}
          <div className="lg:col-span-7 space-y-3.5">
            
            {/* 1° TARJETA DE ESTADO ACTUAL DEL BOX - PRIMERA Y MÁS GRANDE */}
            <section className="p-5 sm:p-6 rounded-3xl bg-white/10 border border-white/15 backdrop-blur-xl shadow-xl space-y-4">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <span className={`text-[11px] font-semibold uppercase px-3 py-0.5 rounded-full border ${currentContent.badgeColor} flex items-center gap-1.5 tracking-wide`}>
                  <IconComponent size={13} strokeWidth={1.5} />
                  <span>{currentContent.badge}</span>
                </span>

                {/* Accesos rápidos de cambio de estado con iconos minimalistas consistentes */}
                <div className="flex items-center gap-1 bg-black/25 p-1 rounded-xl border border-white/10">
                  <button
                    onClick={() => {
                      setLockMode("almuerzo");
                      if (soundEnabled) playTherapeuticTone("ding");
                    }}
                    className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors cursor-pointer flex items-center gap-1.5 ${
                      lockMode === "almuerzo" ? "bg-amber-500 text-slate-950 font-bold shadow-xs" : "text-slate-300 hover:text-white hover:bg-white/10"
                    }`}
                  >
                    <UtensilsCrossed size={11} strokeWidth={1.5} />
                    <span>Almuerzo</span>
                  </button>
                  <button
                    onClick={() => {
                      setLockMode("reunion");
                      if (soundEnabled) playTherapeuticTone("ding");
                    }}
                    className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors cursor-pointer flex items-center gap-1.5 ${
                      lockMode === "reunion" ? "bg-indigo-500 text-white font-bold shadow-xs" : "text-slate-300 hover:text-white hover:bg-white/10"
                    }`}
                  >
                    <Users size={11} strokeWidth={1.5} />
                    <span>Reunión</span>
                  </button>
                  <button
                    onClick={() => {
                      setLockMode("pausa");
                      if (soundEnabled) playTherapeuticTone("ding");
                    }}
                    className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors cursor-pointer flex items-center gap-1.5 ${
                      lockMode === "pausa" ? "bg-emerald-500 text-slate-950 font-bold shadow-xs" : "text-slate-300 hover:text-white hover:bg-white/10"
                    }`}
                  >
                    <Footprints size={11} strokeWidth={1.5} />
                    <span>Ya vengo</span>
                  </button>
                  <button
                    onClick={() => {
                      setLockMode("auto");
                      if (soundEnabled) playTherapeuticTone("ding");
                    }}
                    className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors cursor-pointer flex items-center gap-1.5 ${
                      lockMode === "auto" ? "bg-white text-slate-950 font-bold shadow-xs" : "text-slate-300 hover:text-white hover:bg-white/10"
                    }`}
                    title="Automático según la hora y día"
                  >
                    <Sparkles size={11} strokeWidth={1.5} />
                    <span>Auto</span>
                  </button>
                </div>
              </div>

              <div className="flex items-start gap-4 pt-1">
                <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-white/10 border border-white/20 text-amber-300 flex items-center justify-center shrink-0 shadow-md relative overflow-hidden">
                  <span className="absolute -inset-1 rounded-2xl bg-amber-400/10 blur-[6px] pointer-events-none" />
                  <IconComponent size={24} strokeWidth={1.5} className="relative z-10" />
                </div>
                <div className="space-y-1.5 flex-1">
                  <h3 className="text-base sm:text-xl font-bold text-white leading-snug">
                    {currentContent.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-200 leading-relaxed font-normal">
                    {currentContent.text}
                  </p>
                </div>
              </div>
            </section>

            {/* 2° WIDGETS DE CONTEO REGRESIVO (EN MEDIO) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              
              {/* CUENTA REGRESIVA 1: FIN DE JORNADA */}
              <section className="p-4 rounded-2xl bg-white/10 border border-white/15 backdrop-blur-xl shadow-lg space-y-2.5 flex flex-col justify-between relative group">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-amber-500/15 text-amber-300 border border-amber-400/25 flex items-center justify-center relative">
                      <span className="absolute -inset-0.5 rounded-lg bg-amber-400/10 blur-[2px] pointer-events-none" />
                      <Timer size={15} strokeWidth={1.5} className="relative z-10" />
                    </div>
                    <div>
                      <h4 className="text-[11px] font-bold uppercase tracking-wider text-amber-200">
                        Fin de Jornada
                      </h4>
                      <p className="text-[10px] text-slate-300">
                        Meta: <strong>{workdayEndTime} hrs</strong>
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded-md bg-white/10 text-slate-200">
                      {workdayCountdown.percentage}%
                    </span>
                    {/* Botón de configuración con PIN obligatorio y brillo suave */}
                    <button
                      onClick={() => requestProtectedConfig("timers")}
                      className="p-1.5 rounded-md bg-white/5 hover:bg-white/15 text-slate-300 hover:text-amber-300 transition-colors cursor-pointer flex items-center justify-center group"
                      title="Configurar hora de fin de jornada (Requiere PIN)"
                    >
                      <GlowingLockIcon size={12} strokeWidth={1.5} className="text-amber-300" />
                    </button>
                  </div>
                </div>

                {/* Display numérico */}
                <div className="flex items-center justify-center gap-1.5 py-1">
                  <div className="bg-black/35 border border-white/10 rounded-lg px-2.5 py-1 text-center min-w-[48px]">
                    <span className="text-xl font-bold font-mono text-white">
                      {String(workdayCountdown.hours).padStart(2, "0")}
                    </span>
                    <span className="block text-[8px] font-semibold text-slate-400 uppercase">Hrs</span>
                  </div>
                  <span className="text-sm font-bold text-amber-300/70">:</span>
                  <div className="bg-black/35 border border-white/10 rounded-lg px-2.5 py-1 text-center min-w-[48px]">
                    <span className="text-xl font-bold font-mono text-white">
                      {String(workdayCountdown.minutes).padStart(2, "0")}
                    </span>
                    <span className="block text-[8px] font-semibold text-slate-400 uppercase">Min</span>
                  </div>
                  <span className="text-sm font-bold text-amber-300/70">:</span>
                  <div className="bg-black/35 border border-white/10 rounded-lg px-2.5 py-1 text-center min-w-[48px]">
                    <span className="text-xl font-bold font-mono text-amber-300">
                      {String(workdayCountdown.seconds).padStart(2, "0")}
                    </span>
                    <span className="block text-[8px] font-semibold text-slate-400 uppercase">Seg</span>
                  </div>
                </div>

                {/* Barra de progreso de la jornada */}
                <div className="space-y-1">
                  <div className="w-full h-1.5 bg-black/40 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-amber-400 to-emerald-400 rounded-full transition-all duration-1000"
                      style={{ width: `${workdayCountdown.percentage}%` }}
                    />
                  </div>
                  <p className="text-[10px] text-slate-300 truncate text-center">
                    {workdayCountdown.label}
                  </p>
                </div>
              </section>

              {/* CUENTA REGRESIVA 2: ALMUERZO / PAUSA DE LA TARDE / MICRO-PAUSA */}
              <section className="p-4 rounded-2xl bg-white/10 border border-white/15 backdrop-blur-xl shadow-lg space-y-2.5 flex flex-col justify-between">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-emerald-500/15 text-emerald-300 border border-emerald-400/25 flex items-center justify-center relative">
                      <span className="absolute -inset-0.5 rounded-lg bg-emerald-400/10 blur-[2px] pointer-events-none" />
                      <SecondaryIcon size={15} strokeWidth={1.5} className="relative z-10" />
                    </div>
                    <div>
                      <h4 className="text-[11px] font-bold uppercase tracking-wider text-emerald-200">
                        {secondaryCountdown.title}
                      </h4>
                      <p className="text-[10px] text-slate-300">
                        Pausa activa del box
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1">
                    {/* Selector rápido con micro-iconos consistentes */}
                    <div className="flex items-center gap-0.5 bg-black/30 p-0.5 rounded-lg border border-white/10">
                      <button
                        onClick={() => {
                          setSecondaryType("almuerzo");
                          localStorage.setItem("cosam_secondary_timer_type", "almuerzo");
                        }}
                        className={`px-1.5 py-0.5 rounded text-[9px] font-medium transition-colors cursor-pointer flex items-center gap-1 ${
                          secondaryType === "almuerzo" ? "bg-amber-500 text-slate-950 font-bold" : "text-slate-300 hover:text-white"
                        }`}
                        title="Cuenta regresiva al almuerzo"
                      >
                        <UtensilsCrossed size={9} strokeWidth={1.5} />
                        <span>Alm</span>
                      </button>
                      <button
                        onClick={() => {
                          setSecondaryType("pausa_tarde");
                          localStorage.setItem("cosam_secondary_timer_type", "pausa_tarde");
                        }}
                        className={`px-1.5 py-0.5 rounded text-[9px] font-medium transition-colors cursor-pointer flex items-center gap-1 ${
                          secondaryType === "pausa_tarde" ? "bg-amber-500 text-slate-950 font-bold" : "text-slate-300 hover:text-white"
                        }`}
                        title="Cuenta regresiva a la pausa de la tarde"
                      >
                        <GlassWater size={9} strokeWidth={1.5} />
                        <span>Pausa</span>
                      </button>
                      <button
                        onClick={() => {
                          setSecondaryType("micro_pause");
                          localStorage.setItem("cosam_secondary_timer_type", "micro_pause");
                        }}
                        className={`px-1.5 py-0.5 rounded text-[9px] font-medium transition-colors cursor-pointer flex items-center gap-1 ${
                          secondaryType === "micro_pause" ? "bg-emerald-500 text-slate-950 font-bold" : "text-slate-300 hover:text-white"
                        }`}
                        title="Micro-Pausa activa de 5 minutos"
                      >
                        <Hourglass size={9} strokeWidth={1.5} />
                        <span>5m</span>
                      </button>
                    </div>

                    {/* Botón de configuración con PIN obligatorio y brillo suave */}
                    <button
                      onClick={() => requestProtectedConfig("timers")}
                      className="p-1.5 rounded-md bg-white/5 hover:bg-white/15 text-slate-300 hover:text-emerald-300 transition-colors cursor-pointer flex items-center justify-center group"
                      title="Configurar horarios de pausas (Requiere PIN)"
                    >
                      <GlowingLockIcon size={12} strokeWidth={1.5} className="text-emerald-300" glowColor="rgba(52, 211, 153, 0.4)" />
                    </button>
                  </div>
                </div>

                {/* Display numérico secundario */}
                <div className="flex items-center justify-center gap-1.5 py-1">
                  {secondaryType !== "micro_pause" && (
                    <>
                      <div className="bg-black/35 border border-white/10 rounded-lg px-2.5 py-1 text-center min-w-[48px]">
                        <span className="text-xl font-bold font-mono text-white">
                          {String(secondaryCountdown.hours).padStart(2, "0")}
                        </span>
                        <span className="block text-[8px] font-semibold text-slate-400 uppercase">Hrs</span>
                      </div>
                      <span className="text-sm font-bold text-emerald-300/70">:</span>
                    </>
                  )}
                  <div className="bg-black/35 border border-white/10 rounded-lg px-2.5 py-1 text-center min-w-[48px]">
                    <span className="text-xl font-bold font-mono text-white">
                      {String(secondaryCountdown.minutes).padStart(2, "0")}
                    </span>
                    <span className="block text-[8px] font-semibold text-slate-400 uppercase">Min</span>
                  </div>
                  <span className="text-sm font-bold text-emerald-300/70">:</span>
                  <div className="bg-black/35 border border-white/10 rounded-lg px-2.5 py-1 text-center min-w-[48px]">
                    <span className="text-xl font-bold font-mono text-emerald-300">
                      {String(secondaryCountdown.seconds).padStart(2, "0")}
                    </span>
                    <span className="block text-[8px] font-semibold text-slate-400 uppercase">Seg</span>
                  </div>

                  {secondaryType === "micro_pause" && (
                    <button
                      onClick={() => setIsMicroPauseRunning(!isMicroPauseRunning)}
                      className="ml-2 px-2.5 py-1 rounded-lg bg-emerald-500/30 hover:bg-emerald-500/50 border border-emerald-400/40 text-emerald-200 text-xs font-bold transition-all flex items-center gap-1 cursor-pointer"
                    >
                      {isMicroPauseRunning ? "Pausar" : "Iniciar"}
                    </button>
                  )}
                </div>

                <p className="text-[10px] text-slate-300 truncate text-center">
                  {secondaryCountdown.note}
                </p>
              </section>
            </div>

            {/* 3° TARJETA DE FRASES DIVERTIDAS (ABAJO, SIN TÍTULO NI BARRA) */}
            <section
              className="p-3.5 sm:p-4 rounded-2xl bg-black/30 hover:bg-black/40 border border-white/10 backdrop-blur-md transition-all flex items-center justify-between gap-3 shadow-md group"
            >
              <div
                onClick={handleNextQuoteManually}
                className="flex items-center gap-3 flex-1 cursor-pointer"
                title="Haz clic para avanzar a la siguiente frase"
              >
                <div className="w-8 h-8 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center shrink-0 text-amber-300 relative">
                  <span className="absolute -inset-0.5 rounded-lg bg-amber-400/10 blur-[2px] pointer-events-none" />
                  <Quote size={15} strokeWidth={1.5} className="relative z-10 opacity-90" />
                </div>
                <AnimatePresence mode="wait">
                  <motion.div
                    key={quoteIndex}
                    initial={{ opacity: 0, y: 3 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -3 }}
                    transition={{ duration: 0.2 }}
                    className="text-xs sm:text-sm text-slate-100 italic leading-relaxed font-normal"
                  >
                    "{humorQuotes[quoteIndex] || DEFAULT_HUMOR_QUOTES[0]}"
                  </motion.div>
                </AnimatePresence>
              </div>

              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  onClick={handleNextQuoteManually}
                  className="p-1.5 rounded-lg bg-white/5 hover:bg-white/15 text-slate-300 hover:text-amber-300 transition-colors cursor-pointer"
                  title="Siguiente frase"
                >
                  <RotateCcw size={13} strokeWidth={1.5} />
                </button>
                {/* Botón para configurar frases (Protegido por PIN con brillo suave) */}
                <button
                  onClick={() => requestProtectedConfig("quotes")}
                  className="p-1.5 rounded-lg bg-white/5 hover:bg-white/15 text-slate-300 hover:text-amber-300 transition-colors cursor-pointer flex items-center justify-center group"
                  title="Personalizar frases y velocidad (Requiere PIN)"
                >
                  <GlowingLockIcon size={12} strokeWidth={1.5} className="text-amber-300" />
                </button>
              </div>
            </section>
          </div>

          {/* PANEL DERECHO: DESBLOQUEO RÁPIDO & TECLADO PIN */}
          <div className="lg:col-span-5 flex flex-col items-center justify-center">
            <div className="w-full max-w-xs p-5 sm:p-6 rounded-3xl bg-white/10 border border-white/15 backdrop-blur-xl shadow-2xl space-y-4 flex flex-col items-center">
              
              {/* BOTÓN DE DESBLOQUEO RÁPIDO (1-CLIC) */}
              <button
                onClick={() => {
                  if (soundEnabled) playTherapeuticTone("success");
                  onUnlock();
                }}
                className="w-full py-2.5 px-4 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold rounded-2xl shadow-lg hover:shadow-emerald-500/20 active:scale-98 transition-all flex items-center justify-center gap-2 text-xs uppercase tracking-wider cursor-pointer"
              >
                <GlowingUnlockIcon size={14} strokeWidth={1.5} />
                <span>Desbloqueo Rápido</span>
              </button>

              <div className="flex items-center gap-2 w-full">
                <div className="flex-1 h-px bg-white/15" />
                <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">o ingresa PIN</span>
                <div className="flex-1 h-px bg-white/15" />
              </div>

              {/* Indicadores de Dígitos PIN */}
              <motion.div
                animate={isError ? { x: [-10, 10, -8, 8, -4, 4, 0] } : {}}
                transition={{ duration: 0.35 }}
                className="flex items-center justify-center gap-2.5 py-0.5"
              >
                {Array.from({ length: savedPin.length }).map((_, idx) => {
                  const isFilled = pin.length > idx;
                  return (
                    <div
                      key={idx}
                      className={`w-3.5 h-3.5 rounded-full border transition-all duration-150 ${
                        isFilled
                          ? "bg-amber-300 border-amber-200 scale-110 shadow-sm shadow-amber-400/50"
                          : "border-slate-500 bg-black/30"
                      }`}
                    />
                  );
                })}
              </motion.div>

              {isError && (
                <span className="text-[11px] font-medium text-rose-400 text-center">
                  {errorMessage}
                </span>
              )}

              {/* Teclado Numérico con Iconografía Refinada */}
              <div className="grid grid-cols-3 gap-2 w-full">
                {["1", "2", "3", "4", "5", "6", "7", "8", "9"].map((num) => (
                  <button
                    key={num}
                    onClick={() => handleNumClick(num)}
                    className="h-11 rounded-xl bg-white/10 hover:bg-white/20 active:bg-amber-400 active:text-slate-950 active:scale-95 border border-white/10 text-base font-semibold text-white flex items-center justify-center transition-all cursor-pointer shadow-xs"
                  >
                    {num}
                  </button>
                ))}
                <button
                  onClick={() => setPin("")}
                  className="h-11 rounded-xl bg-white/5 hover:bg-white/10 active:scale-95 border border-white/5 text-[11px] font-medium text-slate-300 hover:text-white flex items-center justify-center transition-all cursor-pointer"
                >
                  Borrar
                </button>
                <button
                  onClick={() => handleNumClick("0")}
                  className="h-11 rounded-xl bg-white/10 hover:bg-white/20 active:bg-amber-400 active:text-slate-950 active:scale-95 border border-white/10 text-base font-semibold text-white flex items-center justify-center transition-all cursor-pointer shadow-xs"
                >
                  0
                </button>
                <button
                  onClick={() => {
                    setPin((prev) => prev.slice(0, -1));
                    if (soundEnabled) playTherapeuticTone("ding");
                  }}
                  className="h-11 rounded-xl bg-white/5 hover:bg-white/10 active:scale-95 border border-white/5 text-slate-300 hover:text-white flex items-center justify-center transition-all cursor-pointer text-xs"
                  title="Borrar último dígito"
                >
                  <Delete size={16} strokeWidth={1.5} />
                </button>
              </div>

              <div className="w-full pt-1.5 border-t border-white/10 flex items-center justify-between text-[10px] text-slate-400">
                <span>Atajo: <strong>Ctrl + L</strong></span>
                <span className="text-amber-300/90 font-medium">PIN por defecto: 1234</span>
              </div>
            </div>
          </div>
        </main>

        {/* PIE DE PÁGINA */}
        <footer className="text-center text-[11px] text-slate-400 flex flex-col sm:flex-row items-center justify-between gap-2 border-t border-white/10 pt-2.5 max-w-6xl mx-auto w-full">
          <span>COSAM Rinconada • San Ramón • Box Médico</span>
          <span className="text-[10px] text-slate-400 flex items-center gap-1.5">
            <GlowingLockIcon size={11} strokeWidth={1.5} className="text-amber-300/80" glowColor="rgba(251, 191, 36, 0.3)" />
            <span>Configuraciones protegidas por PIN</span>
          </span>
        </footer>

        {/* 1. MODAL DE AUTENTICACIÓN PREVIA OBLIGATORIA CON PIN */}
        <AnimatePresence>
          {isAuthPinModalOpen && (
            <div className="fixed inset-0 z-60 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="bg-slate-900 border border-white/20 rounded-3xl p-6 max-w-sm w-full space-y-4 shadow-2xl text-white"
              >
                <div className="flex items-center justify-between border-b border-white/10 pb-3">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-amber-400/20 text-amber-300 border border-amber-400/30 flex items-center justify-center">
                      <KeyRound size={15} strokeWidth={1.5} />
                    </div>
                    <h3 className="text-sm font-bold text-white">Verificación de Seguridad</h3>
                  </div>
                  <button
                    onClick={() => setIsAuthPinModalOpen(false)}
                    className="p-1 rounded-lg bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white cursor-pointer"
                  >
                    <X size={15} strokeWidth={1.5} />
                  </button>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed">
                  Para proteger tus ajustes de horarios, frases y temas, ingresa el código PIN del box:
                </p>

                <form onSubmit={handleVerifyAuthPin} className="space-y-3">
                  <input
                    type="password"
                    maxLength={6}
                    autoFocus
                    value={authPinInput}
                    onChange={(e) => {
                      setAuthPinInput(e.target.value);
                      setAuthPinError("");
                    }}
                    placeholder="PIN (4 a 6 dígitos)"
                    className="w-full px-4 py-2.5 rounded-xl bg-black/50 border border-white/20 text-white text-center text-lg tracking-widest font-mono focus:border-amber-400 focus:outline-hidden"
                  />

                  {authPinError && (
                    <div className="text-xs font-medium text-rose-400 text-center">
                      {authPinError}
                    </div>
                  )}

                  <div className="flex items-center justify-end gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => setIsAuthPinModalOpen(false)}
                      className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-slate-300 text-xs font-semibold cursor-pointer"
                    >
                      Cancelar
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5"
                    >
                      <Check size={13} strokeWidth={2} />
                      <span>Acceder</span>
                    </button>
                  </div>
                </form>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* 2. MODAL DE OPCIONES Y TEMAS (SOLO TRAS AUTENTICACIÓN CON PIN) */}
        <AnimatePresence>
          {isConfigModalOpen && (
            <div className="fixed inset-0 z-60 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="bg-slate-900 border border-white/20 rounded-3xl p-5 sm:p-6 max-w-lg w-full space-y-4 shadow-2xl text-white max-h-[90vh] overflow-y-auto"
              >
                <div className="flex items-center justify-between border-b border-white/10 pb-3">
                  <div className="flex items-center gap-2">
                    <SlidersHorizontal size={16} strokeWidth={1.5} className="text-amber-300" />
                    <h3 className="text-sm font-bold text-white">Configuración del Box</h3>
                  </div>
                  <button
                    onClick={() => setIsConfigModalOpen(false)}
                    className="p-1 rounded-lg bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white cursor-pointer"
                  >
                    <X size={15} strokeWidth={1.5} />
                  </button>
                </div>

                {/* PESTAÑAS DE CONFIGURACIÓN */}
                <div className="flex items-center gap-1.5 border-b border-white/10 pb-2">
                  <button
                    onClick={() => setActiveConfigTab("timers")}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer flex items-center gap-1.5 ${
                      activeConfigTab === "timers"
                        ? "bg-amber-400 text-slate-950 shadow-xs"
                        : "bg-white/5 text-slate-300 hover:bg-white/10"
                    }`}
                  >
                    <Clock3 size={13} strokeWidth={1.5} />
                    <span>Cuentas Regresivas</span>
                  </button>
                  <button
                    onClick={() => setActiveConfigTab("quotes")}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer flex items-center gap-1.5 ${
                      activeConfigTab === "quotes"
                        ? "bg-amber-400 text-slate-950 shadow-xs"
                        : "bg-white/5 text-slate-300 hover:bg-white/10"
                    }`}
                  >
                    <Quote size={13} strokeWidth={1.5} />
                    <span>Frases & Humor</span>
                  </button>
                  <button
                    onClick={() => setActiveConfigTab("theme")}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer flex items-center gap-1.5 ${
                      activeConfigTab === "theme"
                        ? "bg-amber-400 text-slate-950 shadow-xs"
                        : "bg-white/5 text-slate-300 hover:bg-white/10"
                    }`}
                  >
                    <Sparkles size={13} strokeWidth={1.5} />
                    <span>Ambiente & PIN</span>
                  </button>
                </div>

                {/* CONTENIDO TAB 1: CUENTAS REGRESIVAS */}
                {activeConfigTab === "timers" && (
                  <div className="space-y-3.5 py-1">
                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
                        <span>Fin de Turno (Cuenta Regresiva 1):</span>
                        <span className="text-amber-300 font-mono text-[11px]">{workdayEndTime} hrs</span>
                      </label>
                      <input
                        type="time"
                        value={workdayEndTime}
                        onChange={(e) => {
                          setWorkdayEndTime(e.target.value);
                          localStorage.setItem("cosam_workday_end", e.target.value);
                        }}
                        className="w-full px-3 py-2 rounded-xl bg-black/50 border border-white/20 text-white text-xs font-mono"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
                        <span>Horario de Almuerzo (Cuenta Regresiva 2):</span>
                        <span className="text-amber-300 font-mono text-[11px]">{lunchTargetTime} hrs</span>
                      </label>
                      <input
                        type="time"
                        value={lunchTargetTime}
                        onChange={(e) => {
                          setLunchTargetTime(e.target.value);
                          localStorage.setItem("cosam_lunch_time", e.target.value);
                        }}
                        className="w-full px-3 py-2 rounded-xl bg-black/50 border border-white/20 text-white text-xs font-mono"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
                        <span>Horario de Pausa de la Tarde:</span>
                        <span className="text-amber-300 font-mono text-[11px]">{afternoonBreakTime} hrs</span>
                      </label>
                      <input
                        type="time"
                        value={afternoonBreakTime}
                        onChange={(e) => {
                          setAfternoonBreakTime(e.target.value);
                          localStorage.setItem("cosam_break_time", e.target.value);
                        }}
                        className="w-full px-3 py-2 rounded-xl bg-black/50 border border-white/20 text-white text-xs font-mono"
                      />
                    </div>
                  </div>
                )}

                {/* CONTENIDO TAB 2: FRASES Y PÍLDORAS DE HUMOR */}
                {activeConfigTab === "quotes" && (
                  <div className="space-y-3.5 py-1">
                    {/* Velocidad de rotación */}
                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-slate-300">
                        Velocidad de rotación automática:
                      </label>
                      <div className="grid grid-cols-4 gap-1.5">
                        {[
                          { secs: 5, label: "5 seg" },
                          { secs: 7, label: "7 seg (recomendado)" },
                          { secs: 10, label: "10 seg" },
                          { secs: 0, label: "Pausar" }
                        ].map((spd) => (
                          <button
                            key={spd.secs}
                            onClick={() => {
                              setRotationSpeedSecs(spd.secs);
                              localStorage.setItem("cosam_quote_interval_secs", String(spd.secs));
                            }}
                            className={`p-1.5 rounded-lg border text-xs font-medium transition-all cursor-pointer text-center ${
                              rotationSpeedSecs === spd.secs
                                ? "bg-amber-400 text-slate-950 font-bold border-amber-300"
                                : "bg-white/5 border-white/10 text-slate-300 hover:bg-white/10"
                            }`}
                          >
                            {spd.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Agregar nueva frase personalizada */}
                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-slate-300">
                        Agregar nueva frase o cápsula al repertorio:
                      </label>
                      <div className="flex items-center gap-1.5">
                        <input
                          type="text"
                          value={newQuoteInput}
                          onChange={(e) => setNewQuoteInput(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === "Enter") {
                              e.preventDefault();
                              handleAddCustomQuote();
                            }
                          }}
                          placeholder="Escribe aquí tu propia anécdota o frase..."
                          className="flex-1 px-3 py-2 rounded-xl bg-black/50 border border-white/20 text-white text-xs focus:border-amber-400 focus:outline-hidden"
                        />
                        <button
                          onClick={handleAddCustomQuote}
                          className="px-3 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold transition-all cursor-pointer flex items-center gap-1 shrink-0"
                        >
                          <Plus size={14} strokeWidth={2} />
                          <span>Agregar</span>
                        </button>
                      </div>
                    </div>

                    {/* Lista con scroll de frases actuales */}
                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-[11px] text-slate-400">
                        <span>Frases activas ({humorQuotes.length}):</span>
                        <button
                          onClick={handleResetQuotes}
                          className="text-amber-300 hover:underline cursor-pointer"
                        >
                          Restaurar iniciales
                        </button>
                      </div>
                      <div className="max-h-36 overflow-y-auto space-y-1 pr-1">
                        {humorQuotes.map((q, idx) => (
                          <div
                            key={idx}
                            className="p-2 rounded-lg bg-black/30 border border-white/10 text-[11px] text-slate-200 flex items-center justify-between gap-2"
                          >
                            <span className="truncate">{q}</span>
                            {humorQuotes.length > 1 && (
                              <button
                                onClick={() => handleDeleteQuote(idx)}
                                className="p-1 rounded text-slate-400 hover:text-rose-400 hover:bg-white/10 shrink-0 cursor-pointer"
                                title="Eliminar frase"
                              >
                                <Trash2 size={12} strokeWidth={1.5} />
                              </button>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {/* CONTENIDO TAB 3: AMBIENTE & PIN */}
                {activeConfigTab === "theme" && (
                  <div className="space-y-3.5 py-1">
                    {/* Selección de tema ambiental */}
                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-slate-300">Ambiente Visual Relajante:</label>
                      <div className="grid grid-cols-2 gap-2">
                        {[
                          { id: "sunset", label: "Atardecer Cálido", icon: Sparkles, iconColor: "text-amber-400" },
                          { id: "cosmic", label: "Noche Cósmica", icon: Moon, iconColor: "text-indigo-400" },
                          { id: "mint", label: "Jardín Zen", icon: Leaf, iconColor: "text-emerald-400" },
                          { id: "lofi", label: "Chill Suave", icon: Volume2, iconColor: "text-rose-400" }
                        ].map((theme) => {
                          const ThemeIcon = theme.icon;
                          const isSelected = ambientTheme === theme.id;
                          return (
                            <button
                              key={theme.id}
                              onClick={() => {
                                setAmbientTheme(theme.id as AmbientTheme);
                                localStorage.setItem("cosam_ambient_theme", theme.id);
                              }}
                              className={`p-2.5 rounded-xl border text-xs font-medium text-left transition-all cursor-pointer flex items-center gap-2 ${
                                isSelected
                                  ? "bg-white/20 border-white text-white shadow-xs"
                                  : "bg-white/5 border-white/10 text-slate-300 hover:bg-white/10"
                              }`}
                            >
                              <div className={`w-6 h-6 rounded-lg flex items-center justify-center ${isSelected ? "bg-white/20" : "bg-white/5"}`}>
                                <ThemeIcon size={14} strokeWidth={1.5} className={theme.iconColor} />
                              </div>
                              <span>{theme.label}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* Cambiar PIN */}
                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-slate-300">
                        Cambiar Código PIN del Box (4 a 6 dígitos):
                      </label>
                      <input
                        type="password"
                        maxLength={6}
                        defaultValue={savedPin}
                        onBlur={(e) => {
                          const val = e.target.value.trim();
                          if (val.length >= 4) {
                            setSavedPin(val);
                            localStorage.setItem("cosam_box_pin", val);
                          }
                        }}
                        placeholder="PIN numérico (4 a 6 dígitos)"
                        className="w-full px-3 py-2 rounded-xl bg-black/50 border border-white/20 text-white text-xs font-mono focus:border-amber-400 focus:outline-hidden"
                      />
                      <p className="text-[10px] text-slate-400">
                        Este código será necesario para ingresar a estas configuraciones y desbloquear el box.
                      </p>
                    </div>
                  </div>
                )}

                <div className="pt-2 border-t border-white/10 flex justify-end">
                  <button
                    onClick={() => setIsConfigModalOpen(false)}
                    className="px-4 py-2 rounded-xl bg-white text-slate-950 font-bold text-xs hover:bg-slate-100 transition-colors cursor-pointer"
                  >
                    Guardar y Cerrar
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </motion.div>
    </AnimatePresence>
  );
}
