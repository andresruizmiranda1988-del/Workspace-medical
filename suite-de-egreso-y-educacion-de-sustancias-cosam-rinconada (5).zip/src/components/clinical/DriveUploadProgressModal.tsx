import React from "react";
import { DriveUploadProgress } from "../../types";
import {
  HardDrive,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Folder,
  ExternalLink,
  X,
  FileText,
  ShieldCheck,
  RefreshCw,
} from "lucide-react";

interface DriveUploadProgressModalProps {
  isOpen: boolean;
  progress: DriveUploadProgress | null;
  onClose: () => void;
  onRetry?: () => void;
}

export function DriveUploadProgressModal({
  isOpen,
  progress,
  onClose,
  onRetry,
}: DriveUploadProgressModalProps) {
  if (!isOpen || !progress) return null;

  const isCompleted = progress.stage === "completed";
  const isError = progress.stage === "error";
  const isLoading = !isCompleted && !isError;

  return (
    <div
      id="drive-upload-progress-modal"
      className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-in fade-in duration-200"
    >
      <div className="bg-slate-900 border border-slate-700/80 rounded-3xl w-full max-w-md shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 px-5 border-b border-slate-800 bg-slate-950/80">
          <div className="flex items-center gap-2.5">
            <div
              className={`w-8 h-8 rounded-xl flex items-center justify-center ${
                isCompleted
                  ? "bg-emerald-500/20 text-emerald-400"
                  : isError
                  ? "bg-rose-500/20 text-rose-400"
                  : "bg-purple-500/20 text-purple-400 animate-pulse"
              }`}
            >
              {isCompleted ? (
                <CheckCircle2 className="w-4 h-4" />
              ) : isError ? (
                <AlertCircle className="w-4 h-4" />
              ) : (
                <HardDrive className="w-4 h-4" />
              )}
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">
                {isCompleted
                  ? "Documento Guardado en Drive"
                  : isError
                  ? "Error en la Carga a Drive"
                  : "Enviando a Google Drive..."}
              </h3>
              <p className="text-[10px] text-slate-400">
                Almacenamiento Clínico COSAM Rinconada
              </p>
            </div>
          </div>
          {(isCompleted || isError) && (
            <button
              id="btn-close-drive-progress-modal"
              onClick={onClose}
              className="text-slate-400 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Body Content */}
        <div className="p-6 space-y-5">
          {/* File and Target Folder details */}
          <div className="bg-slate-950/80 border border-slate-800/80 rounded-2xl p-3.5 space-y-2.5 text-xs">
            {progress.fileName && (
              <div className="flex items-center gap-2 text-slate-300">
                <FileText className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                <span className="font-mono text-[11px] truncate font-medium text-purple-200">
                  {progress.fileName}
                </span>
              </div>
            )}
            <div className="flex items-center gap-2 text-slate-400">
              <Folder className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span className="truncate text-[11px]">
                Carpeta:{" "}
                <strong className="text-slate-200 font-semibold">
                  {progress.folderName || "COSAM Rinconada"}
                </strong>
              </span>
            </div>
          </div>

          {/* Progress Bar & Status */}
          <div className="space-y-2.5">
            <div className="flex items-center justify-between text-xs">
              <span
                className={`font-semibold flex items-center gap-1.5 ${
                  isCompleted
                    ? "text-emerald-400"
                    : isError
                    ? "text-rose-400"
                    : "text-purple-300"
                }`}
              >
                {isLoading && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                {progress.message}
              </span>
              <span className="font-mono font-bold text-slate-300 text-xs">
                {progress.percent}%
              </span>
            </div>
            {/* Visual Bar */}
            <div className="w-full h-3 bg-slate-800 rounded-full overflow-hidden p-0.5 border border-slate-700/60 shadow-inner">
              <div
                className={`h-full rounded-full transition-all duration-300 ${
                  isCompleted
                    ? "bg-gradient-to-r from-emerald-500 to-teal-400 shadow-sm shadow-emerald-500/50"
                    : isError
                    ? "bg-gradient-to-r from-rose-600 to-rose-400"
                    : "bg-gradient-to-r from-purple-600 via-indigo-500 to-purple-400 animate-pulse"
                }`}
                style={{ width: `${Math.max(5, Math.min(100, progress.percent))}%` }}
              />
            </div>
            {/* Stages Step Indicator */}
            <div className="grid grid-cols-4 gap-1.5 pt-1 text-[10px] text-center font-medium">
              <div
                className={`py-1 rounded-md transition-colors ${
                  progress.percent >= 15
                    ? "bg-purple-950/60 text-purple-300 border border-purple-800/40"
                    : "bg-slate-900 text-slate-600"
                }`}
              >
                1. Conexión
              </div>
              <div
                className={`py-1 rounded-md transition-colors ${
                  progress.percent >= 35
                    ? "bg-purple-950/60 text-purple-300 border border-purple-800/40"
                    : "bg-slate-900 text-slate-600"
                }`}
              >
                2. Carpeta
              </div>
              <div
                className={`py-1 rounded-md transition-colors ${
                  progress.percent >= 75
                    ? "bg-purple-950/60 text-purple-300 border border-purple-800/40"
                    : "bg-slate-900 text-slate-600"
                }`}
              >
                3. Carga
              </div>
              <div
                className={`py-1 rounded-md transition-colors ${
                  progress.percent === 100
                    ? "bg-emerald-950/80 text-emerald-300 border border-emerald-700/50 font-bold"
                    : "bg-slate-900 text-slate-600"
                }`}
              >
                4. Listo
              </div>
            </div>
          </div>

          {/* Error Message Details */}
          {isError && progress.error && (
            <div className="p-3 bg-rose-950/50 border border-rose-800/60 rounded-xl text-rose-300 text-xs">
              <p className="font-semibold text-[11px] mb-1">Detalle del error:</p>
              <p className="text-[11px] leading-relaxed opacity-90">{progress.error}</p>
            </div>
          )}

          {/* Privacy and Security Badge */}
          <div className="flex items-center gap-2 text-[10px] text-slate-400 bg-slate-950/50 p-2.5 rounded-xl border border-slate-800/60">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span>Transmisión segura cifrada TLS 1.3 con control de acceso por usuario Google.</span>
          </div>
        </div>

        {/* Footer actions */}
        <div className="p-4 px-5 border-t border-slate-800 bg-slate-950/80 flex items-center justify-between gap-3">
          {isCompleted ? (
            <>
              {progress.fileUrl ? (
                <a
                  id="link-open-gdrive-doc"
                  href={progress.fileUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 py-2.5 px-4 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/50 transition-all cursor-pointer"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Abrir Documento en Google Drive</span>
                </a>
              ) : (
                <div className="text-xs text-emerald-400 font-semibold">
                  ✓ Guardado exitoso
                </div>
              )}
              <button
                id="btn-confirm-close-progress"
                onClick={onClose}
                className="py-2.5 px-4 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold transition-colors cursor-pointer"
              >
                Cerrar
              </button>
            </>
          ) : isError ? (
            <>
              {onRetry && (
                <button
                  id="btn-retry-drive-upload"
                  onClick={onRetry}
                  className="flex-1 py-2.5 px-4 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Reintentar Envío</span>
                </button>
              )}
              <button
                onClick={onClose}
                className="py-2.5 px-4 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold transition-colors cursor-pointer"
              >
                Cerrar
              </button>
            </>
          ) : (
            <div className="w-full text-center text-[11px] text-slate-400 flex items-center justify-center gap-2">
              <Loader2 className="w-3.5 h-3.5 animate-spin text-purple-400" />
              <span>Por favor no cierre esta ventana mientras finaliza la carga...</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default DriveUploadProgressModal;
