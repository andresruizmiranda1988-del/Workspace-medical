import { useState, useEffect } from "react";
import { Plus, Trash2, Printer, Sparkles, RefreshCw, CheckCircle, FileText, BookOpen, AlertCircle, Presentation, ExternalLink, Calendar } from "lucide-react";
import { ReuniónClinicaRecord } from "../../types";
import { generateClinicalAI } from "../../services/geminiService";
import { GoogleSlidesService } from "../../services/googleSlidesService";
import { GoogleCalendarService } from "../../services/googleCalendarService";
import { exportElementToPdf } from "../../utils/pdfExport";

export function ReunionesClinicas() {
  const [records, setRecords] = useState<ReuniónClinicaRecord[]>([]);
  const [activeRecord, setActiveRecord] = useState<ReuniónClinicaRecord | null>(null);

  // Form Fields
  const [fecha, setFecha] = useState("");
  const [paciente, setPaciente] = useState("");
  const [diagnostico, setDiagnostico] = useState("");
  const [profesionalPresenta, setProfesionalPresenta] = useState("");
  const [integrantesEquipo, setIntegrantesEquipo] = useState("");
  const [resumenCaso, setResumenCaso] = useState("");
  const [nudosCriticos, setNudosCriticos] = useState("");
  const [acuerdosCompromisos, setAcuerdosCompromisos] = useState("");
  const [actaGenerada, setActaGenerada] = useState("");

  // UI States
  const [loadingAI, setLoadingAI] = useState(false);
  const [errorAI, setErrorAI] = useState<string | null>(null);
  const [creatingSlides, setCreatingSlides] = useState(false);
  const [slidesUrl, setSlidesUrl] = useState<string | null>(null);
  const [schedulingCalendar, setSchedulingCalendar] = useState(false);
  const [calendarEventUrl, setCalendarEventUrl] = useState<string | null>(null);
  const [showCalendarConfirm, setShowCalendarConfirm] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem("cosam_reuniones");
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        setRecords(parsed);
        if (parsed.length > 0) {
          loadRecord(parsed[0]);
        }
      } catch (e) {
        console.error("Failed to load meetings:", e);
      }
    }
  }, []);

  const saveToLocal = (updatedList: ReuniónClinicaRecord[]) => {
    setRecords(updatedList);
    localStorage.setItem("cosam_reuniones", JSON.stringify(updatedList));
  };

  const loadRecord = (rec: ReuniónClinicaRecord) => {
    setActiveRecord(rec);
    setFecha(rec.fecha);
    setPaciente(rec.paciente);
    setDiagnostico(rec.diagnostico);
    setProfesionalPresenta(rec.profesionalPresenta);
    setIntegrantesEquipo(rec.integrantesEquipo);
    setResumenCaso(rec.resumenCaso);
    setNudosCriticos(rec.nudosCriticos);
    setAcuerdosCompromisos(rec.acuerdosCompromisos);
    setActaGenerada(rec.actaGenerada || "");
  };

  const handleNewRecord = () => {
    setActiveRecord(null);
    setFecha(new Date().toISOString().split("T")[0]);
    setPaciente("");
    setDiagnostico("");
    setProfesionalPresenta("");
    setIntegrantesEquipo("");
    setResumenCaso("");
    setNudosCriticos("");
    setAcuerdosCompromisos("");
    setActaGenerada("");
  };

  const handleDeleteRecord = (id: string) => {
    const updated = records.filter((r) => r.id !== id);
    saveToLocal(updated);
    if (activeRecord?.id === id) {
      if (updated.length > 0) {
        loadRecord(updated[0]);
      } else {
        handleNewRecord();
      }
    }
  };

  const handleSaveRecord = () => {
    if (!paciente.trim()) return;

    const id = activeRecord?.id || `meet_${Date.now()}`;
    const newRecord: ReuniónClinicaRecord = {
      id,
      fecha,
      paciente,
      diagnostico,
      profesionalPresenta,
      integrantesEquipo,
      resumenCaso,
      nudosCriticos,
      acuerdosCompromisos,
      actaGenerada: actaGenerada || generatePlainTextSummary(),
    };

    let updatedList;
    if (activeRecord) {
      updatedList = records.map((r) => (r.id === id ? newRecord : r));
    } else {
      updatedList = [newRecord, ...records];
    }

    saveToLocal(updatedList);
    setActiveRecord(newRecord);
  };

  const generatePlainTextSummary = (): string => {
    return `FOLIO: COSAM-ACTA-${Date.now()}\nACTA DE REUNIÓN CLÍNICA\nPACIENTE: ${paciente}\nFECHA: ${fecha}\nPRESENTA: ${profesionalPresenta}\n\n=========================================\nSÍNTESIS DEL CASO:\n${resumenCaso}\n\nACUERDOS Y COMPROMISOS:\n${acuerdosCompromisos}\n=========================================\n`;
  };

  const handleAIStructure = async () => {
    setLoadingAI(true);
    setErrorAI(null);
    try {
      const prompt = `Por favor redacta y estructura un acta oficial de reunión clínica multidisciplinaria (Consultoría de Casos Complejos) para el COSAM Rinconada.
DATOS DE LA SESIÓN:
Fecha: ${fecha}
Paciente Analizado: ${paciente}
Diagnósticos CIE-10: ${diagnostico}
Profesional Expositor: ${profesionalPresenta}
Equipo Participante (Psiquiatras, Psicólogos, T. Ocupacionales, T. Sociales): ${integrantesEquipo}

SÍNTESIS DE LA PRESENTACIÓN DEL CASO:
${resumenCaso || "No especificado"}

NUDOS CRÍTICOS / DILEMAS CLÍNICOS DISCUTIDOS:
${nudosCriticos || "No especificado"}

ACUERDOS CLÍNICOS Y COMPROMISOS DE SEGUIMIENTO:
${acuerdosCompromisos || "No especificado"}

Por favor formatea todo en un acta clínica técnica rigurosa. Estructura el documento con secciones formales para el expediente, definiendo responsables, plazos, sugerencias de fármacos o interconsultas, y pauta psicoterapéutica recomendada por el equipo interdisciplinario.`;

      const result = await generateClinicalAI({
        prompt,
        systemInstruction: "Eres un redactor médico de actas clínicas de comités de ética, consultoría psiquiátrica y comisiones médicas de especialidad. Tu tarea es pulir actas de reuniones clínicas con el máximo nivel técnico y formal.",
      });

      setActaGenerada(result);
    } catch (err: any) {
      setErrorAI(err.message || "Error al estructurar acta de reunión por IA.");
    } finally {
      setLoadingAI(false);
    }
  };

  const handleExportPDF = async () => {
    handleSaveRecord();
    try {
      await exportElementToPdf("printable-reunion-area", {
        filename: `Acta_Reunion_Clinica_${paciente.replace(/\s+/g, "_")}.pdf`,
      });
    } catch (err) {
      console.error("Failed to generate PDF:", err);
    }
  };

  const handleExportSlides = async () => {
    if (!paciente.trim()) return;
    handleSaveRecord();
    setCreatingSlides(true);
    setErrorAI(null);
    setSlidesUrl(null);
    try {
      const slidesPayload = [
        {
          badge: "Antecedentes",
          title: "1. Presentación del Caso y Equipo Tratante",
          body: `Paciente: ${paciente}\nDiagnóstico CIE-10: ${diagnostico || "En evaluación"}\nProfesional Expositor: ${profesionalPresenta || "No especificado"}\nEquipo Participante: ${integrantesEquipo || "Equipo Multiprofesional COSAM"}\n\nSíntesis Clínica:\n${resumenCaso || "Sin resumen registrado."}`,
        },
        {
          badge: "Dilemas Clínicos",
          title: "2. Nudos Críticos y Discusión de Equipo",
          body: nudosCriticos || "Sin nudos críticos especificados.",
        },
        {
          badge: "Acuerdos",
          title: "3. Acuerdos Clínicos e Intervenciones Pactadas",
          body: acuerdosCompromisos || "Sin acuerdos especificados.",
        },
      ];
      if (actaGenerada) {
        slidesPayload.push({
          badge: "Acta Oficial",
          title: "4. Síntesis Técnica del Comité Clínico",
          body: actaGenerada.slice(0, 1800),
        });
      }
      const created = await GoogleSlidesService.createClinicalPresentation({
        title: `Caso Clínico: ${paciente} — Comité COSAM`,
        subtitle: `Diagnóstico: ${diagnostico || "Evaluación Integral"} · Expositor: ${profesionalPresenta || "Equipo COSAM"} · Fecha: ${fecha}`,
        slides: slidesPayload,
        organizeInCosamFolder: true,
      });
      setSlidesUrl(created.webViewLink);
    } catch (err: any) {
      setErrorAI(err.message || "Error al exportar presentación a Google Slides.");
    } finally {
      setCreatingSlides(false);
    }
  };

  const handleConfirmScheduleCalendar = async () => {
    if (!paciente.trim()) return;
    setShowCalendarConfirm(false);
    handleSaveRecord();
    setSchedulingCalendar(true);
    setErrorAI(null);
    setCalendarEventUrl(null);
    try {
      const targetDate = fecha || new Date().toISOString().split("T")[0];
      const startIso = new Date(`${targetDate}T11:00:00`).toISOString();
      const endIso = new Date(`${targetDate}T11:45:00`).toISOString();

      const created = await GoogleCalendarService.createEvent({
        summary: `Reunión Clínica COSAM: Caso ${paciente}`,
        location: "COSAM Rinconada — Sala de Reuniones Multiprofesional",
        description: `COMITÉ CLÍNICO MULTIDISCIPLINARIO — COSAM RINCONADA\nPaciente: ${paciente}\nDiagnóstico CIE-10: ${diagnostico || "En evaluación"}\nProfesional Expositor: ${profesionalPresenta || "No especificado"}\nEquipo Participante: ${integrantesEquipo || "Equipo COSAM"}\n\nResumen del Caso:\n${resumenCaso || "Sin resumen"}\n\nNudos Críticos:\n${nudosCriticos || "Sin nudos críticos"}\n\nAcuerdos Clínicos:\n${acuerdosCompromisos || "Por definir"}`,
        startDateTime: startIso,
        endDateTime: endIso,
      });
      setCalendarEventUrl(created.htmlLink || "https://calendar.google.com");
    } catch (err: any) {
      setErrorAI(err.message || "Error al agendar comité clínico en Google Calendar.");
    } finally {
      setSchedulingCalendar(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="reuniones-clinicas-module">
      {/* Sidebar list panel */}
      <div className="lg:col-span-4 bg-white rounded-xl border border-slate-200 shadow-sm flex flex-col h-[700px] overflow-hidden">
        <div className="p-4 border-b border-slate-100 bg-slate-50/70 flex items-center justify-between">
          <h3 className="font-bold text-slate-800 text-xs md:text-sm">Actas de Reuniones ({records.length})</h3>
          <button
            onClick={handleNewRecord}
            className="p-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold transition-colors flex items-center gap-1 shadow-sm"
          >
            <Plus className="w-3.5 h-3.5" /> Nueva Acta
          </button>
        </div>
        <div className="flex-1 overflow-y-auto divide-y divide-slate-100 text-xs">
          {records.length > 0 ? (
            records.map((rec) => (
              <div
                key={rec.id}
                className={`p-4 hover:bg-slate-50 transition-colors flex justify-between items-start group ${
                  activeRecord?.id === rec.id ? "bg-indigo-50/40 border-l-4 border-indigo-600" : ""
                }`}
              >
                <button onClick={() => loadRecord(rec)} className="flex-1 text-left min-w-0 pr-2">
                  <p className="font-bold text-slate-800 truncate">Caso: {rec.paciente}</p>
                  <p className="text-[10px] text-slate-500 mt-1 truncate">Presenta: {rec.profesionalPresenta || "No especificado"}</p>
                  <p className="text-[10px] text-slate-400 mt-0.5">{rec.fecha}</p>
                </button>
                <button
                  onClick={() => handleDeleteRecord(rec.id)}
                  className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded opacity-0 group-hover:opacity-100 transition-all shrink-0"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))
          ) : (
            <div className="p-8 text-center text-slate-400">No hay actas registradas.</div>
          )}
        </div>
      </div>

      {/* Main Workspace form panel */}
      <div className="lg:col-span-8 space-y-6">
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 space-y-5">
          <div className="flex flex-wrap justify-between items-center gap-2 border-b border-slate-100 pb-4">
            <h2 className="text-base font-bold text-slate-800">
              {activeRecord ? "Editar Acta de Reunión" : "Registrar Acta de Reunión Clínica / Interconsulta de Caso"}
            </h2>
            <div className="flex items-center gap-2 flex-wrap">
              <button
                onClick={() => setShowCalendarConfirm(true)}
                disabled={schedulingCalendar || !paciente.trim()}
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 disabled:bg-emerald-300 text-white rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
                title="Agendar esta reunión clínica en Google Calendar"
              >
                {schedulingCalendar ? (
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Calendar className="w-3.5 h-3.5" />
                )}
                <span>{schedulingCalendar ? "Agendando..." : "Agendar en Calendar"}</span>
              </button>
              <button
                onClick={handleExportSlides}
                disabled={creatingSlides || !paciente.trim()}
                className="px-3 py-1.5 bg-amber-500 hover:bg-amber-600 disabled:bg-amber-300 text-slate-950 rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
                title="Generar presentación de este caso en Google Slides"
              >
                {creatingSlides ? (
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Presentation className="w-3.5 h-3.5" />
                )}
                <span>{creatingSlides ? "Creando Slides..." : "Google Slides"}</span>
              </button>
              <button
                onClick={handleExportPDF}
                className="px-3 py-1.5 border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1"
              >
                <Printer className="w-3.5 h-3.5" /> PDF
              </button>
              <button
                onClick={handleSaveRecord}
                className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold transition-colors"
              >
                Guardar Local
              </button>
            </div>
          </div>

          {calendarEventUrl && (
            <div className="p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Reunión clínica agendada en Google Calendar para el caso <strong>{paciente}</strong>.</span>
              </div>
              <a
                href={calendarEventUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="px-2.5 py-1 rounded bg-emerald-600 hover:bg-emerald-700 text-white font-bold flex items-center gap-1 shrink-0"
              >
                <span>Ver en Google Calendar</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          )}

          {showCalendarConfirm && (
            <div className="p-4 rounded-xl bg-emerald-50/90 border border-emerald-300 text-emerald-950 text-xs space-y-2.5">
              <div className="font-bold flex items-center gap-1.5">
                <Calendar className="w-4 h-4 text-emerald-700" />
                <span>Confirmar agendamiento de Reunión Clínica en Google Calendar</span>
              </div>
              <p className="text-emerald-800">
                Se creará el evento <strong>"Reunión Clínica COSAM: Caso {paciente}"</strong> para la fecha{" "}
                <strong>{fecha || new Date().toISOString().split("T")[0]} (11:00 – 11:45 hrs)</strong> en su Google Calendar principal.
              </p>
              <div className="flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowCalendarConfirm(false)}
                  className="px-3 py-1 rounded-lg bg-white border border-slate-200 text-slate-700 font-medium cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={handleConfirmScheduleCalendar}
                  className="px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-semibold cursor-pointer"
                >
                  Confirmar y Agendar
                </button>
              </div>
            </div>
          )}

          {slidesUrl && (
            <div className="p-3 rounded-lg bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-amber-600 shrink-0" />
                <span>Presentación creada en Google Slides para el caso <strong>{paciente}</strong>.</span>
              </div>
              <a
                href={slidesUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="px-2.5 py-1 rounded bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold flex items-center gap-1 shrink-0"
              >
                <span>Abrir en Google Slides</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          )}

          {/* Form fields */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs">
            <div className="space-y-1">
              <span className="text-[10px] text-slate-400 font-bold uppercase">Paciente del Caso:</span>
              <input
                type="text"
                placeholder="Ej: Claudio Toledo Jara"
                value={paciente}
                onChange={(e) => setPaciente(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none"
              />
            </div>
            <div className="space-y-1">
              <span className="text-[10px] text-slate-400 font-bold uppercase">Diagnóstico CIE-10:</span>
              <input
                type="text"
                placeholder="Ej: F19.2 Policonsumo"
                value={diagnostico}
                onChange={(e) => setDiagnostico(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none"
              />
            </div>
            <div className="space-y-1">
              <span className="text-[10px] text-slate-400 font-bold uppercase">Profesional Expositor:</span>
              <input
                type="text"
                placeholder="Ej: Dra. Alicia Soto"
                value={profesionalPresenta}
                onChange={(e) => setProfesionalPresenta(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none"
              />
            </div>
            <div className="space-y-1">
              <span className="text-[10px] text-slate-400 font-bold uppercase">Fecha de Reunión:</span>
              <input
                type="date"
                value={fecha}
                onChange={(e) => setFecha(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg bg-white focus:outline-none"
              />
            </div>
          </div>

          <div className="space-y-1 text-xs">
            <span className="text-[10px] text-slate-400 font-bold uppercase">Integrantes del Equipo Multidisciplinario Asistentes:</span>
            <input
              type="text"
              placeholder="Ej: Dr. Ruiz (Psiquiatra), Lic. Lagos (Psicóloga), T.O. Carrasco..."
              value={integrantesEquipo}
              onChange={(e) => setIntegrantesEquipo(e.target.value)}
              className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none"
            />
          </div>

          {/* Textareas */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div className="space-y-1">
              <span className="font-bold text-slate-700">Resumen del Caso / Antecedentes:</span>
              <textarea
                placeholder="Historia clínica abreviada expuesta ante el equipo..."
                value={resumenCaso}
                onChange={(e) => setResumenCaso(e.target.value)}
                rows={4}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none text-slate-800"
              />
            </div>
            <div className="space-y-1">
              <span className="font-bold text-slate-700">Nudos Críticos (Dilemas / Dificultades):</span>
              <textarea
                placeholder="Baja adherencia, riesgo suicida fluctuante, resistencia a desintoxicación..."
                value={nudosCriticos}
                onChange={(e) => setNudosCriticos(e.target.value)}
                rows={4}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none text-slate-800"
              />
            </div>
            <div className="space-y-1">
              <span className="font-bold text-slate-700">Acuerdos Clínicos e Intervenciones Pactadas:</span>
              <textarea
                placeholder="Aumento de visitas de T.O., cambio en esquema psicofarmacológico, citación a familiar..."
                value={acuerdosCompromisos}
                onChange={(e) => setAcuerdosCompromisos(e.target.value)}
                rows={4}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none text-slate-800"
              />
            </div>
          </div>

          <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
            <div className="flex items-center gap-1 text-[11px] text-slate-400 italic">
              <BookOpen className="w-4.5 h-4.5 text-indigo-500" />
              Sincroniza y presiona "Sintetizar Acta por IA" para formalizar los acuerdos clínicos
            </div>
            <button
              onClick={handleAIStructure}
              disabled={loadingAI || (!resumenCaso && !acuerdosCompromisos)}
              className="px-4.5 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-400 text-white rounded-lg font-semibold flex items-center gap-1.5 shadow-sm"
            >
              {loadingAI ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
              Sintetizar Acta por IA
            </button>
          </div>
        </div>

        {/* Preview block */}
        {(actaGenerada || loadingAI || errorAI) && (
          <div className="bg-slate-50 rounded-xl border border-slate-200 p-6 space-y-4 shadow-sm" id="printable-reunion-area">
            <div className="flex justify-between items-center pb-3 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-indigo-600" />
                <h3 className="font-bold text-slate-800 text-xs md:text-sm">Acta Oficial de Reunión de Caso (Consultoría Técnica)</h3>
              </div>
              <span className="text-[9px] bg-indigo-100 text-indigo-700 font-extrabold px-2.5 py-0.5 rounded-full uppercase">
                COSAM Rinconada
              </span>
            </div>

            {loadingAI && (
              <div className="py-8 flex flex-col items-center gap-2">
                <RefreshCw className="w-8 h-8 text-indigo-600 animate-spin" />
                <p className="text-xs text-slate-500 font-medium animate-pulse">Sintetizando aportes multidisciplinarios y actas oficiales...</p>
              </div>
            )}

            {errorAI && (
              <div className="p-4 bg-rose-50 border border-rose-100 text-rose-700 text-xs rounded-lg">
                {errorAI}
              </div>
            )}

            {actaGenerada && !loadingAI && (
              <div className="text-slate-800 text-xs leading-relaxed space-y-4 font-mono select-all whitespace-pre-wrap bg-white p-5 rounded-lg border border-slate-200">
                {actaGenerada}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
