import { useState, useEffect } from "react";
import {
  Presentation,
  Plus,
  Trash2,
  Sparkles,
  RefreshCw,
  ExternalLink,
  CheckCircle2,
  AlertCircle,
  Layers,
  FileText,
  ClipboardList,
  Users,
  Eye,
  FolderOpen,
  Send,
} from "lucide-react";
import { GoogleDriveService } from "../../services/googleDriveService";
import {
  GoogleSlidesService,
  SlideSectionInput,
  SlidesPresentationSummary,
  SlidesPresentationDetail,
} from "../../services/googleSlidesService";
import { generateClinicalAI } from "../../services/geminiService";
import { ReunionClinicaRecord, PaiRecord, SoapRecord } from "../../types";

export function PresentacionesSlides() {
  const [isConnected, setIsConnected] = useState(() => GoogleDriveService.isConnected());
  const [isConnecting, setIsConnecting] = useState(false);

  // Presentations list & active detail
  const [presentations, setPresentations] = useState<SlidesPresentationSummary[]>([]);
  const [loadingList, setLoadingList] = useState(false);
  const [selectedDetail, setSelectedDetail] = useState<SlidesPresentationDetail | null>(null);
  const [loadingDetail, setLoadingDetail] = useState(false);
  const [showEmbedPreview, setShowEmbedPreview] = useState(false);

  // Builder state
  const [deckTitle, setDeckTitle] = useState("Presentación de Caso Clínico — COSAM Rinconada");
  const [deckSubtitle, setDeckSubtitle] = useState(
    `Consultoría Clínica Multidisciplinaria · ${new Date().toLocaleDateString("es-CL")}`
  );
  const [slides, setSlides] = useState<SlideSectionInput[]>([
    {
      badge: "Identificación",
      title: "1. Antecedentes y Contexto Clínico",
      body: "Motivo de consulta, historia longitudinal del cuadro y red de apoyo sociofamiliar actual.",
    },
    {
      badge: "Formulación",
      title: "2. Diagnóstico Multiaxial y Nudos Críticos",
      body: "Hipótesis diagnóstica CIE-10, factores predisponentes, precipitantes y dilemas terapéuticos.",
    },
    {
      badge: "Intervención",
      title: "3. Plan de Tratamiento y Acuerdos de Equipo",
      body: "Ajustes psicofarmacológicos, objetivos psicoterapéuticos, seguimiento por T.O. / T.S. y plazos.",
    },
  ]);

  // AI Topic Prompt
  const [aiTopicPrompt, setAiTopicPrompt] = useState("");
  const [loadingAI, setLoadingAI] = useState(false);

  // Creating / Appending state
  const [creatingDeck, setCreatingDeck] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Append slide to existing presentation
  const [appendTitle, setAppendTitle] = useState("");
  const [appendBadge, setAppendBadge] = useState("Seguimiento");
  const [appendBody, setAppendBody] = useState("");
  const [appendingSlide, setAppendingSlide] = useState(false);

  // Local records for quick import
  const [localMeetings, setLocalMeetings] = useState<ReunionClinicaRecord[]>([]);
  const [localPai, setLocalPai] = useState<PaiRecord[]>([]);
  const [localSoap, setLocalSoap] = useState<SoapRecord[]>([]);

  useEffect(() => {
    // Load local clinical records for 1-click import into Slide Builder
    try {
      const m = localStorage.getItem("cosam_reuniones");
      if (m) setLocalMeetings(JSON.parse(m));
      const p = localStorage.getItem("cosam_pai_records");
      if (p) setLocalPai(JSON.parse(p));
      const s = localStorage.getItem("cosam_soap_records");
      if (s) setLocalSoap(JSON.parse(s));
    } catch (e) {
      console.warn("Could not read local records:", e);
    }

    const handleAuthChange = () => {
      const connected = GoogleDriveService.isConnected();
      setIsConnected(connected);
      if (connected) {
        fetchPresentations();
      }
    };
    window.addEventListener("cosam:gdrive-auth-changed", handleAuthChange);
    if (GoogleDriveService.isConnected()) {
      fetchPresentations();
    }
    return () => {
      window.removeEventListener("cosam:gdrive-auth-changed", handleAuthChange);
    };
  }, []);

  const fetchPresentations = async () => {
    if (!GoogleDriveService.isConnected()) return;
    setLoadingList(true);
    setErrorMessage(null);
    try {
      const list = await GoogleSlidesService.listPresentations();
      setPresentations(list);
    } catch (err: any) {
      setErrorMessage(err.message || "Error al cargar presentaciones de Google Slides.");
    } finally {
      setLoadingList(false);
    }
  };

  const handleConnectGoogle = async () => {
    setIsConnecting(true);
    setErrorMessage(null);
    try {
      await GoogleDriveService.requestAuth();
      setIsConnected(true);
      await fetchPresentations();
    } catch (err: any) {
      setErrorMessage(err.message || "No se pudo conectar con Google Slides.");
    } finally {
      setIsConnecting(false);
    }
  };

  const handleInspectPresentation = async (id: string) => {
    setLoadingDetail(true);
    setErrorMessage(null);
    try {
      const detail = await GoogleSlidesService.getPresentation(id);
      setSelectedDetail(detail);
    } catch (err: any) {
      setErrorMessage(err.message || "Error al abrir los detalles de la presentación.");
    } finally {
      setLoadingDetail(false);
    }
  };

  const handleAddSlideDraft = () => {
    setSlides((prev) => [
      ...prev,
      {
        badge: `Sección ${prev.length + 1}`,
        title: `${prev.length + 1}. Nueva Diapositiva Clínica`,
        body: "Escriba los puntos clave, hallazgos o acuerdos clínicos...",
      },
    ]);
  };

  const handleRemoveSlideDraft = (idx: number) => {
    if (slides.length <= 1) return;
    setSlides((prev) => prev.filter((_, i) => i !== idx));
  };

  const handleUpdateSlideDraft = (
    idx: number,
    field: keyof SlideSectionInput,
    value: string
  ) => {
    setSlides((prev) =>
      prev.map((item, i) => (i === idx ? { ...item, [field]: value } : item))
    );
  };

  const importFromMeeting = (rec: ReunionClinicaRecord) => {
    setDeckTitle(`Caso Clínico: ${rec.paciente} — Comité COSAM`);
    setDeckSubtitle(
      `CIE-10: ${rec.diagnostico || "En evaluación"} · Expone: ${
        rec.profesionalPresenta || "Equipo"
      } · Fecha: ${rec.fecha}`
    );
    const nextSlides: SlideSectionInput[] = [
      {
        badge: "Antecedentes",
        title: "1. Síntesis del Caso y Equipo Tratante",
        body: `Paciente: ${rec.paciente}\nDiagnóstico CIE-10: ${
          rec.diagnostico || "No especificado"
        }\nExpositor: ${rec.profesionalPresenta || "No especificado"}\nEquipo Asistente: ${
          rec.integrantesEquipo || "Equipo Multiprofesional COSAM"
        }\n\nResumen del Caso:\n${rec.resumenCaso || "Sin resumen registrado."}`,
      },
      {
        badge: "Dilemas Clínicos",
        title: "2. Nudos Críticos y Complejidad Biopsicosocial",
        body: rec.nudosCriticos || "Sin nudos críticos registrados.",
      },
      {
        badge: "Plan y Acuerdos",
        title: "3. Acuerdos Clínicos e Intervenciones Pactadas",
        body: rec.acuerdosCompromisos || "Sin acuerdos registrados.",
      },
    ];
    if (rec.actaGenerada) {
      nextSlides.push({
        badge: "Acta Oficial",
        title: "4. Síntesis Técnica del Comité Clínico",
        body: rec.actaGenerada.slice(0, 1800),
      });
    }
    setSlides(nextSlides);
    setStatusMessage(`Datos cargados desde Reunión Clínica de ${rec.paciente}.`);
  };

  const importFromPai = (rec: PaiRecord) => {
    setDeckTitle(`Plan PAI (5Ps): ${rec.patientName}`);
    setDeckSubtitle(
      `Diagnóstico: ${rec.diagnosis || "Integral"} · Fecha: ${rec.date}`
    );
    const nextSlides: SlideSectionInput[] = [
      {
        badge: "Problema Actual",
        title: "1. Motivo de Ingreso y Diagnóstico",
        body: `Paciente: ${rec.patientName}\nDiagnóstico: ${rec.diagnosis}\n\nMotivo de Consulta / Presentación:\n${rec.motive}`,
      },
      {
        badge: "Vulnerabilidad y Gatillantes",
        title: "2. Factores Predisponentes y Precipitantes",
        body: `FACTORES PREDISPONENTES:\n${
          rec.predisposing || "No especificado"
        }\n\nFACTORES PRECIPITANTES:\n${rec.precipitating || "No especificado"}`,
      },
      {
        badge: "Mantención y Recursos",
        title: "3. Factores Perpetuantes y Protectores",
        body: `FACTORES PERPETUANTES:\n${
          rec.perpetuating || "No especificado"
        }\n\nFACTORES PROTECTORES:\n${rec.protective || "No especificado"}`,
      },
    ];
    if (rec.structuredResult) {
      nextSlides.push({
        badge: "Síntesis PAI",
        title: "4. Plan de Tratamiento Individual Estructurado",
        body: rec.structuredResult.slice(0, 1800),
      });
    }
    setSlides(nextSlides);
    setStatusMessage(`Datos cargados desde Plan PAI de ${rec.patientName}.`);
  };

  const importFromSoap = (rec: SoapRecord) => {
    setDeckTitle(`Evolución Clínica SOAP: ${rec.patientName}`);
    setDeckSubtitle(`RUT: ${rec.rut || "S/R"} · Fecha de Atención: ${rec.date}`);
    setSlides([
      {
        badge: "Subjetivo y Objetivo",
        title: "1. Relato Clínico (S) y Examen Mental (O)",
        body: `SUBJETIVO:\n${rec.s || "Sin registro"}\n\nOBJETIVO / EXAMEN MENTAL:\n${
          rec.o || "Sin registro"
        }`,
      },
      {
        badge: "Análisis y Plan",
        title: "2. Integración Diagnóstica (A) e Indicaciones (P)",
        body: `ANÁLISIS CLÍNICO:\n${rec.a || "Sin registro"}\n\nPLAN TERAPÉUTICO:\n${
          rec.p || "Sin registro"
        }`,
      },
    ]);
    setStatusMessage(`Datos cargados desde Evolución SOAP de ${rec.patientName}.`);
  };

  const handleGenerateSlidesWithAI = async () => {
    if (!aiTopicPrompt.trim()) return;
    setLoadingAI(true);
    setErrorMessage(null);
    setStatusMessage(null);
    try {
      const prompt = `Genera una estructura de presentación clínica de 4 diapositivas para Google Slides basada en el siguiente caso o tema clínico del COSAM Rinconada:
"${aiTopicPrompt}"

Responde EXCLUSIVAMENTE con un objeto JSON válido (sin bloques markdown \`\`\`json) con el siguiente formato exacto:
{
  "title": "Título formal de la presentación",
  "subtitle": "Subtítulo técnico o contexto del comité",
  "slides": [
    {
      "badge": "Etiqueta corta",
      "title": "1. Título de la diapositiva",
      "body": "Contenido clínico estructurado con viñetas claras (•) y datos técnicos precisos."
    }
  ]
}`;

      const raw = await generateClinicalAI({
        prompt,
        systemInstruction:
          "Eres un psiquiatra jefe y docente clínico del COSAM Rinconada. Diseñas presentaciones clínicas claras, concisas y rigurosas para reuniones de equipo y sesiones clínicas. Devuelve únicamente JSON válido.",
      });

      const cleaned = raw.replace(/```json/gi, "").replace(/```/g, "").trim();
      const parsed = JSON.parse(cleaned);
      if (parsed.title) setDeckTitle(parsed.title);
      if (parsed.subtitle) setDeckSubtitle(parsed.subtitle);
      if (Array.isArray(parsed.slides) && parsed.slides.length > 0) {
        setSlides(parsed.slides);
      }
      setStatusMessage("Estructura de diapositivas generada por IA lista para exportar a Google Slides.");
    } catch (err: any) {
      setErrorMessage(
        err.message || "No se pudo estructurar la presentación con IA. Intente de nuevo."
      );
    } finally {
      setLoadingAI(false);
    }
  };

  const handleCreateInGoogleSlides = async () => {
    if (!deckTitle.trim() || slides.length === 0) return;
    setCreatingDeck(true);
    setErrorMessage(null);
    setStatusMessage(null);
    try {
      const detail = await GoogleSlidesService.createClinicalPresentation({
        title: deckTitle,
        subtitle: deckSubtitle,
        slides,
        organizeInCosamFolder: true,
      });
      setIsConnected(true);
      setSelectedDetail(detail);
      setStatusMessage(`¡Presentación "${detail.title}" creada exitosamente en Google Slides!`);
      await fetchPresentations();
    } catch (err: any) {
      setErrorMessage(err.message || "Error al crear la presentación en Google Slides.");
    } finally {
      setCreatingDeck(false);
    }
  };

  const handleAppendSlide = async () => {
    if (!selectedDetail || !appendTitle.trim() || !appendBody.trim()) return;
    setAppendingSlide(true);
    setErrorMessage(null);
    try {
      const updated = await GoogleSlidesService.appendSlideToPresentation(
        selectedDetail.presentationId,
        {
          badge: appendBadge,
          title: appendTitle,
          body: appendBody,
        }
      );
      setSelectedDetail(updated);
      setAppendTitle("");
      setAppendBody("");
      setStatusMessage("Nueva diapositiva añadida exitosamente a la presentación en Google Slides.");
    } catch (err: any) {
      setErrorMessage(err.message || "No se pudo agregar la diapositiva.");
    } finally {
      setAppendingSlide(false);
    }
  };

  return (
    <div className="space-y-5" id="presentaciones-slides-module">
      {/* Top Status & Connection Banner */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-amber-50 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-800/60 flex items-center justify-center text-amber-600 dark:text-amber-400 shrink-0">
            <Presentation className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Google Slides Clínico · Presentaciones y Casos de Comité
              </h3>
              <span
                className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                  isConnected
                    ? "bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800"
                    : "bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400"
                }`}
              >
                {isConnected ? "Google Workspace Conectado" : "Sin conexión activa"}
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Crea presentaciones clínicas directamente en tu cuenta de Google Slides desde reuniones de equipo, planes PAI o evoluciones SOAP.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-stretch sm:self-auto justify-end">
          {isConnected && (
            <button
              onClick={fetchPresentations}
              disabled={loadingList}
              className="px-3 py-1.5 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loadingList ? "animate-spin" : ""}`} />
              <span>Actualizar Lista</span>
            </button>
          )}
          <button
            onClick={handleConnectGoogle}
            disabled={isConnecting}
            className="px-3.5 py-1.5 bg-slate-900 hover:bg-slate-800 dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-900 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
          >
            {isConnecting ? (
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Presentation className="w-3.5 h-3.5" />
            )}
            <span>{isConnected ? "Reconectar Cuenta Google" : "Conectar Google Slides"}</span>
          </button>
        </div>
      </div>

      {/* Status & Error Alerts */}
      {errorMessage && (
        <div className="p-3.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/60 text-rose-700 dark:text-rose-300 text-xs flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
          <button
            onClick={() => setErrorMessage(null)}
            className="text-[11px] underline font-medium"
          >
            Cerrar
          </button>
        </div>
      )}

      {statusMessage && (
        <div className="p-3.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/60 text-emerald-800 dark:text-emerald-200 text-xs flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
            <span>{statusMessage}</span>
          </div>
          {selectedDetail && (
            <a
              href={selectedDetail.webViewLink}
              target="_blank"
              rel="noopener noreferrer"
              className="px-2.5 py-1 rounded-md bg-emerald-600 hover:bg-emerald-700 text-white font-semibold flex items-center gap-1 shrink-0"
            >
              <span>Abrir en Google Slides</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          )}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* LEFT COLUMN: Presentation Builder & Clinical Record Importer */}
        <div className="lg:col-span-7 space-y-5">
          {/* Quick Import Bar from Clinical Modules */}
          <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4 space-y-3 shadow-xs">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                <FolderOpen className="w-3.5 h-3.5 text-indigo-600" />
                Importar Caso Clínico Local hacia Diapositivas
              </span>
              <span className="text-[10px] text-slate-400">1 clic para autocompletar</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
              {/* Meetings selector */}
              <div className="space-y-1">
                <label className="text-[10px] font-semibold text-slate-500 uppercase flex items-center gap-1">
                  <Users className="w-3 h-3" /> Reuniones ({localMeetings.length})
                </label>
                <select
                  onChange={(e) => {
                    const found = localMeetings.find((r) => r.id === e.target.value);
                    if (found) importFromMeeting(found);
                  }}
                  defaultValue=""
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs"
                >
                  <option value="" disabled>
                    Seleccionar acta...
                  </option>
                  {localMeetings.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.paciente} ({m.fecha})
                    </option>
                  ))}
                </select>
              </div>

              {/* PAI selector */}
              <div className="space-y-1">
                <label className="text-[10px] font-semibold text-slate-500 uppercase flex items-center gap-1">
                  <ClipboardList className="w-3 h-3" /> Planes PAI ({localPai.length})
                </label>
                <select
                  onChange={(e) => {
                    const found = localPai.find((r) => r.id === e.target.value);
                    if (found) importFromPai(found);
                  }}
                  defaultValue=""
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs"
                >
                  <option value="" disabled>
                    Seleccionar PAI 5Ps...
                  </option>
                  {localPai.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.patientName} ({p.date})
                    </option>
                  ))}
                </select>
              </div>

              {/* SOAP selector */}
              <div className="space-y-1">
                <label className="text-[10px] font-semibold text-slate-500 uppercase flex items-center gap-1">
                  <FileText className="w-3 h-3" /> Evoluciones SOAP ({localSoap.length})
                </label>
                <select
                  onChange={(e) => {
                    const found = localSoap.find((r) => r.id === e.target.value);
                    if (found) importFromSoap(found);
                  }}
                  defaultValue=""
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs"
                >
                  <option value="" disabled>
                    Seleccionar evolución...
                  </option>
                  {localSoap.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.patientName} ({s.date})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* AI Generator Bar */}
            <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row gap-2">
              <input
                type="text"
                value={aiTopicPrompt}
                onChange={(e) => setAiTopicPrompt(e.target.value)}
                placeholder="O escribe un caso/tema clínico para estructurar diapositivas con IA (ej: Manejo de patología dual F19.2 + F32.2)..."
                className="flex-1 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-800 dark:text-slate-200 focus:outline-none"
              />
              <button
                onClick={handleGenerateSlidesWithAI}
                disabled={loadingAI || !aiTopicPrompt.trim()}
                className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-400 text-white rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 shrink-0 transition-colors cursor-pointer"
              >
                {loadingAI ? (
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Sparkles className="w-3.5 h-3.5" />
                )}
                <span>Estructurar con IA</span>
              </button>
            </div>
          </div>

          {/* Slide Deck Editor Card */}
          <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-5 space-y-4 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
              <div>
                <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                  Constructor de Presentación para Google Slides
                </h4>
                <p className="text-[11px] text-slate-500">
                  Incluye portada institucional COSAM + {slides.length} diapositivas de contenido.
                </p>
              </div>
              <button
                onClick={handleCreateInGoogleSlides}
                disabled={creatingDeck || !deckTitle.trim()}
                className="px-4 py-2 bg-amber-500 hover:bg-amber-600 disabled:bg-amber-300 text-slate-950 rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
              >
                {creatingDeck ? (
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Presentation className="w-3.5 h-3.5" />
                )}
                <span>
                  {creatingDeck ? "Creando en Google Slides..." : "Exportar a Google Slides"}
                </span>
              </button>
            </div>

            {/* Cover Metadata */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-500 uppercase">
                  Título Principal (Portada):
                </label>
                <input
                  type="text"
                  value={deckTitle}
                  onChange={(e) => setDeckTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-semibold"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-500 uppercase">
                  Subtítulo / Metadatos de Portada:
                </label>
                <input
                  type="text"
                  value={deckSubtitle}
                  onChange={(e) => setDeckSubtitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300"
                />
              </div>
            </div>

            {/* Slides List */}
            <div className="space-y-3">
              {slides.map((slide, idx) => (
                <div
                  key={idx}
                  className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-700/80 bg-slate-50/70 dark:bg-slate-800/40 space-y-2.5"
                >
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 flex-1">
                      <span className="px-2 py-0.5 rounded-md bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 text-[10px] font-bold">
                        Slide {idx + 2}
                      </span>
                      <input
                        type="text"
                        value={slide.badge || ""}
                        onChange={(e) => handleUpdateSlideDraft(idx, "badge", e.target.value)}
                        placeholder="Etiqueta (ej: Diagnóstico)"
                        className="w-32 px-2 py-1 rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-[11px] font-semibold text-indigo-600 dark:text-indigo-400"
                      />
                      <input
                        type="text"
                        value={slide.title}
                        onChange={(e) => handleUpdateSlideDraft(idx, "title", e.target.value)}
                        placeholder="Título de la diapositiva"
                        className="flex-1 px-2.5 py-1 rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-bold text-slate-800 dark:text-white"
                      />
                    </div>
                    {slides.length > 1 && (
                      <button
                        onClick={() => handleRemoveSlideDraft(idx)}
                        className="p-1 text-slate-400 hover:text-rose-600 rounded transition-colors"
                        title="Eliminar diapositiva"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                  <textarea
                    rows={3}
                    value={slide.body}
                    onChange={(e) => handleUpdateSlideDraft(idx, "body", e.target.value)}
                    placeholder="Contenido de la diapositiva..."
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-700 dark:text-slate-200 leading-relaxed focus:outline-none"
                  />
                </div>
              ))}
            </div>

            <button
              onClick={handleAddSlideDraft}
              className="w-full py-2 border border-dashed border-slate-300 dark:border-slate-700 hover:border-slate-400 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Añadir Otra Diapositiva al Borrador</span>
            </button>
          </div>
        </div>

        {/* RIGHT COLUMN: Existing Google Slides Browser & Inspector */}
        <div className="lg:col-span-5 space-y-5">
          {/* Presentations List in Drive */}
          <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4 space-y-3 shadow-xs">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2.5">
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-amber-500" />
                <h4 className="text-xs font-bold text-slate-900 dark:text-white">
                  Tus Presentaciones en Google Slides ({presentations.length})
                </h4>
              </div>
            </div>

            {!isConnected ? (
              <div className="py-8 text-center space-y-2">
                <p className="text-xs text-slate-500">
                  Conecta tu cuenta de Google para listar y editar tus presentaciones de Google Slides.
                </p>
                <button
                  onClick={handleConnectGoogle}
                  className="px-3.5 py-1.5 bg-amber-500 hover:bg-amber-600 text-slate-950 rounded-lg text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer"
                >
                  <Presentation className="w-3.5 h-3.5" />
                  <span>Autorizar Google Slides</span>
                </button>
              </div>
            ) : loadingList ? (
              <div className="py-8 flex flex-col items-center gap-2 text-slate-400">
                <RefreshCw className="w-5 h-5 animate-spin text-amber-500" />
                <span className="text-xs">Consultando presentaciones en Google Drive...</span>
              </div>
            ) : presentations.length === 0 ? (
              <div className="py-6 text-center text-xs text-slate-400">
                No se encontraron presentaciones recientes. ¡Crea la primera con el botón "Exportar a Google Slides"!
              </div>
            ) : (
              <div className="max-h-64 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800 pr-1">
                {presentations.map((pres) => {
                  const isSelected = selectedDetail?.presentationId === pres.id;
                  return (
                    <div
                      key={pres.id}
                      className={`py-2.5 px-2.5 rounded-lg flex items-center justify-between gap-2 transition-colors ${
                        isSelected
                          ? "bg-amber-50/80 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/60"
                          : "hover:bg-slate-50 dark:hover:bg-slate-800/50"
                      }`}
                    >
                      <button
                        onClick={() => handleInspectPresentation(pres.id)}
                        className="flex-1 text-left min-w-0 cursor-pointer"
                      >
                        <p className="text-xs font-semibold text-slate-800 dark:text-slate-200 truncate">
                          {pres.name}
                        </p>
                        {pres.modifiedTime && (
                          <p className="text-[10px] text-slate-400">
                            Modificado: {new Date(pres.modifiedTime).toLocaleDateString("es-CL")}
                          </p>
                        )}
                      </button>
                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          onClick={() => handleInspectPresentation(pres.id)}
                          className="px-2 py-1 rounded bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-[10px] font-semibold text-slate-700 dark:text-slate-300 cursor-pointer"
                          title="Inspeccionar diapositivas"
                        >
                          Ver Slides
                        </button>
                        <a
                          href={pres.webViewLink}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="p-1.5 rounded bg-amber-500/10 hover:bg-amber-500/20 text-amber-700 dark:text-amber-300"
                          title="Abrir en Google Slides"
                        >
                          <ExternalLink className="w-3.5 h-3.5" />
                        </a>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Active Presentation Inspector & Slide Appender */}
          {loadingDetail && (
            <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-6 flex flex-col items-center gap-2">
              <RefreshCw className="w-5 h-5 animate-spin text-amber-500" />
              <span className="text-xs text-slate-500">
                Leyendo estructura de diapositivas desde Google Slides API...
              </span>
            </div>
          )}

          {selectedDetail && !loadingDetail && (
            <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4 space-y-4 shadow-xs">
              <div className="flex items-start justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
                <div className="min-w-0">
                  <span className="text-[10px] font-bold uppercase text-amber-600 dark:text-amber-400">
                    Presentación Activa ({selectedDetail.slides.length} diapositivas)
                  </span>
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white truncate">
                    {selectedDetail.title}
                  </h4>
                </div>
                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    onClick={() => setShowEmbedPreview((v) => !v)}
                    className="px-2.5 py-1 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-300 flex items-center gap-1 cursor-pointer"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>{showEmbedPreview ? "Ver Texto" : "Vista Previa"}</span>
                  </button>
                  <a
                    href={selectedDetail.webViewLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-2.5 py-1 rounded-lg bg-amber-500 hover:bg-amber-600 text-slate-950 text-xs font-bold flex items-center gap-1"
                  >
                    <span>Editar en Slides</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>

              {showEmbedPreview ? (
                <div className="aspect-video w-full rounded-lg overflow-hidden border border-slate-200 dark:border-slate-700 bg-slate-950">
                  <iframe
                    src={selectedDetail.embedLink}
                    title={selectedDetail.title}
                    className="w-full h-full border-0"
                    allowFullScreen
                  />
                </div>
              ) : (
                <div className="max-h-60 overflow-y-auto space-y-2 pr-1">
                  {selectedDetail.slides.map((s) => (
                    <div
                      key={s.objectId}
                      className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60 text-xs space-y-1"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-800 dark:text-slate-200">
                          Slide {s.index}: {s.title}
                        </span>
                      </div>
                      {s.bodyText && (
                        <p className="text-[11px] text-slate-600 dark:text-slate-400 whitespace-pre-wrap line-clamp-3">
                          {s.bodyText}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              )}

              {/* Append a new slide directly via batchUpdate */}
              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 space-y-2.5">
                <span className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block">
                  Añadir Diapositiva en Vivo a "{selectedDetail.title}"
                </span>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={appendBadge}
                    onChange={(e) => setAppendBadge(e.target.value)}
                    placeholder="Etiqueta"
                    className="w-28 px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs"
                  />
                  <input
                    type="text"
                    value={appendTitle}
                    onChange={(e) => setAppendTitle(e.target.value)}
                    placeholder="Título de la nueva diapositiva..."
                    className="flex-1 px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs"
                  />
                </div>
                <textarea
                  rows={2}
                  value={appendBody}
                  onChange={(e) => setAppendBody(e.target.value)}
                  placeholder="Notas clínicas, acuerdos o conclusiones para anexar a la presentación..."
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs"
                />
                <button
                  onClick={handleAppendSlide}
                  disabled={appendingSlide || !appendTitle.trim() || !appendBody.trim()}
                  className="w-full py-1.5 bg-slate-900 hover:bg-slate-800 dark:bg-white dark:hover:bg-slate-200 disabled:opacity-50 text-white dark:text-slate-900 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  {appendingSlide ? (
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Send className="w-3.5 h-3.5" />
                  )}
                  <span>Insertar Diapositiva en Google Slides</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
