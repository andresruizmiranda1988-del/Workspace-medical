import React, { useState, useEffect, useMemo } from "react";
import {
  CheckSquare,
  StickyNote,
  Plus,
  Trash2,
  RefreshCw,
  Loader2,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  Calendar,
  ListTodo,
  Pin,
  ArrowUpRight,
  Search,
  Edit3,
  X,
  FolderPlus,
  ShieldCheck,
} from "lucide-react";
import {
  GoogleTasksKeepService,
  GoogleTaskList,
  GoogleTaskItem,
  ClinicalKeepNote,
  KeepChecklistItem,
} from "../../services/googleTasksKeepService";
import { GoogleDriveService } from "../../services/googleDriveService";
import { getCurrentAuthUser, initAuth } from "../../services/firebaseAuthService";
import { GoogleSignInButton } from "./GoogleSignInButton";
import { PatientSelectorBar, PatientProfile, PRESET_PATIENTS } from "./PatientSelectorBar";
import { generateClinicalAI } from "../../services/geminiService";

interface ConfirmModalState {
  title: string;
  description: string;
  details: string[];
  confirmLabel: string;
  variant: "primary" | "danger";
  onConfirm: () => Promise<void>;
}

const CLINICAL_TASK_TEMPLATES = [
  {
    id: "litemia",
    label: "Control Litemia / Valproico",
    title: "Revisar Litemia 12h + Creatinina + TSH — ",
    notes:
      "Protocolo COSAM Rinconada:\n- Verificar toma de muestra a las 12h exactas post-dosis nocturna.\n- Rango terapéutico esperado: 0.6 - 0.8 mEq/L (mantenimiento).\n- Evaluar temblor fino, poliuria/polidipsia y función renal.",
    category: "Farmacovigilancia" as const,
  },
  {
    id: "ashton",
    label: "Seguimiento Pauta Ashton",
    title: "Control decalaje Benzodiacepinas (Pauta Ashton) — ",
    notes:
      "Protocolo de Deshabituación BZD:\n- Evaluar tolerancia a reducción del 10-25% de dosis equivalente de Diazepam.\n- Pesquisar insomnio de rebote, ansiedad inter-dosis o parestesias.\n- Reforzar higiene del sueño.",
    category: "Farmacovigilancia" as const,
  },
  {
    id: "examenes_aps",
    label: "Exámenes Basales APS",
    title: "Solicitar / rescatar exámenes basales COSAM (<3 meses) — ",
    notes:
      "Exámenes obligatorios según Protocolo COSAM Rinconada (San Ramón):\n1. Hemograma y VHS\n2. Perfil Bioquímico, Hepático y Lipídico\n3. TSH y T4 Libre\n4. Creatinina / VFG y Electrolitos\n5. ECG basal (>45 años o uso de psicofármacos con riesgo QTc)",
    category: "Protocolo COSAM" as const,
  },
  {
    id: "comite",
    label: "Presentación Reunión Clínica",
    title: "Presentar caso en Reunión Clínica Multiprofesional — ",
    notes:
      "Preparar formulación 5Ps, ajuste psicofarmacológico, adherencia terapéutica y coordinación con dupla psicosocial / CESFAM de origen.",
    category: "Interconsulta APS" as const,
  },
];

export const TareasKeepClinico: React.FC = () => {
  const [activeWorkspaceTab, setActiveWorkspaceTab] = useState<"tasks" | "keep" | "split">("split");
  const [isConnected, setIsConnected] = useState<boolean>(() => GoogleDriveService.isConnected());
  const [authUser, setAuthUser] = useState(() => getCurrentAuthUser());
  const [isConnecting, setIsConnecting] = useState(false);

  // Patient context
  const [selectedPatient, setSelectedPatient] = useState<PatientProfile | null>(PRESET_PATIENTS[0]);
  const [patientLabel, setPatientLabel] = useState(`${PRESET_PATIENTS[0].name} (${PRESET_PATIENTS[0].rut})`);

  // Google Tasks state
  const [taskLists, setTaskLists] = useState<GoogleTaskList[]>([]);
  const [selectedListId, setSelectedListId] = useState<string>("@default");
  const [tasks, setTasks] = useState<GoogleTaskItem[]>([]);
  const [isLoadingTasks, setIsLoadingTasks] = useState(false);
  const [taskFilter, setTaskFilter] = useState<"all" | "needsAction" | "completed">("all");
  const [taskSearch, setTaskSearch] = useState("");

  // Task form state
  const [taskFormMode, setTaskFormMode] = useState<"create" | "edit">("create");
  const [editingTaskId, setEditingTaskId] = useState<string | null>(null);
  const [taskTitle, setTaskTitle] = useState("");
  const [taskNotes, setTaskNotes] = useState("");
  const [taskDueDate, setTaskDueDate] = useState(() => {
    const tomorrow = new Date(Date.now() + 86400000);
    return tomorrow.toISOString().split("T")[0];
  });
  const [newListTitle, setNewListTitle] = useState("");
  const [showNewListInput, setShowNewListInput] = useState(false);

  // Google Keep state
  const [keepNotes, setKeepNotes] = useState<ClinicalKeepNote[]>([]);
  const [isLoadingKeep, setIsLoadingKeep] = useState(false);
  const [keepSearch, setKeepSearch] = useState("");
  const [keepCategoryFilter, setKeepCategoryFilter] = useState<string>("Todas");

  // Keep form state
  const [noteTitle, setNoteTitle] = useState("");
  const [noteBody, setNoteBody] = useState("");
  const [noteCategory, setNoteCategory] = useState<ClinicalKeepNote["category"]>("Protocolo COSAM");
  const [notePinned, setNotePinned] = useState(true);
  const [noteSyncToTasks, setNoteSyncToTasks] = useState(true);
  const [checklistInput, setChecklistInput] = useState("");
  const [noteChecklist, setNoteChecklist] = useState<KeepChecklistItem[]>([]);

  // AI & Confirmation Modal
  const [isGeneratingAI, setIsGeneratingAI] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [confirmModal, setConfirmModal] = useState<ConfirmModalState | null>(null);
  const [statusBanner, setStatusBanner] = useState<{
    type: "success" | "error" | "info";
    message: string;
  } | null>(null);

  useEffect(() => {
    const unsubscribe = initAuth(
      (user) => {
        setIsConnected(true);
        setAuthUser(user);
      },
      () => {
        setIsConnected(GoogleDriveService.isConnected());
        setAuthUser(getCurrentAuthUser());
      }
    );

    const handleAuthChanged = () => {
      const connected = GoogleDriveService.isConnected();
      setIsConnected(connected);
      setAuthUser(getCurrentAuthUser());
      if (connected) {
        loadTasksWorkspace(selectedListId);
      }
    };

    window.addEventListener("cosam:gdrive-auth-changed", handleAuthChanged);
    loadKeepWorkspace();
    if (GoogleDriveService.isConnected()) {
      loadTasksWorkspace("@default");
    }

    return () => {
      unsubscribe();
      window.removeEventListener("cosam:gdrive-auth-changed", handleAuthChanged);
    };
  }, []);

  const loadTasksWorkspace = async (listId = selectedListId) => {
    if (!GoogleDriveService.isConnected()) return;
    setIsLoadingTasks(true);
    try {
      const [lists, items] = await Promise.all([
        GoogleTasksKeepService.listTaskLists(),
        GoogleTasksKeepService.listTasks(listId, true),
      ]);
      setTaskLists(lists);
      setTasks(items);
      if (listId === "@default" && lists.length > 0) {
        setSelectedListId(lists[0].id);
      }
    } catch (err: any) {
      setStatusBanner({
        type: "error",
        message: err.message || "Error al sincronizar con Google Tasks API.",
      });
    } finally {
      setIsLoadingTasks(false);
    }
  };

  const loadKeepWorkspace = async () => {
    setIsLoadingKeep(true);
    try {
      const res = await GoogleTasksKeepService.listKeepNotes();
      setKeepNotes(res.notes);
    } catch (err: any) {
      setStatusBanner({
        type: "error",
        message: err.message || "Error al cargar notas clínicas de Google Keep.",
      });
    } finally {
      setIsLoadingKeep(false);
    }
  };

  const handleConnectGoogle = async () => {
    setIsConnecting(true);
    setStatusBanner(null);
    try {
      await GoogleDriveService.requestAuth();
      setIsConnected(true);
      setAuthUser(getCurrentAuthUser());
      setStatusBanner({
        type: "success",
        message: "Google Tasks y Google Keep conectados mediante Firebase Auth.",
      });
      await Promise.all([loadTasksWorkspace("@default"), loadKeepWorkspace()]);
    } catch (err: any) {
      setStatusBanner({
        type: "error",
        message: err.message || "No se pudo autenticar con Google Workspace.",
      });
    } finally {
      setIsConnecting(false);
    }
  };

  const handlePatientSelect = (patient: PatientProfile | null) => {
    setSelectedPatient(patient);
    if (patient) {
      setPatientLabel(`${patient.name} (${patient.rut})`);
    } else {
      setPatientLabel("");
    }
  };

  const handleApplyTemplate = (tpl: (typeof CLINICAL_TASK_TEMPLATES)[number]) => {
    const suffix = patientLabel ? patientLabel : "Paciente COSAM";
    setTaskFormMode("create");
    setEditingTaskId(null);
    setTaskTitle(`${tpl.title}${suffix}`);
    setTaskNotes(tpl.notes);

    setNoteTitle(`${tpl.title}${suffix}`);
    setNoteBody(tpl.notes);
    setNoteCategory(tpl.category);
  };

  const handleGenerateAIChecklist = async () => {
    setIsGeneratingAI(true);
    setStatusBanner(null);
    try {
      const contextTitle = taskTitle || noteTitle || "Seguimiento psiquiátrico COSAM Rinconada";
      const contextNotes = taskNotes || noteBody || "Control farmacológico y coordinación APS";
      const prompt = `Genera un plan breve de seguimiento clínico para Google Tasks y una lista de chequeo (checklist de 4 puntos) para Google Keep en el COSAM Rinconada (San Ramón).
Caso / Paciente: ${patientLabel || "Paciente en seguimiento ambulatorio"}
Motivo / Tarea: ${contextTitle}
Contexto actual: ${contextNotes}

Responde en texto estructurado claro, separando primero la nota clínica breve y luego 4 ítems accionables con guiones (-).`;

      const aiResponse = await generateClinicalAI({
        prompt,
        systemInstruction:
          "Eres médico psiquiatra de COSAM Rinconada. Estructuras tareas de seguimiento farmacológico y listas de chequeo clínicas concisas, rigurosas y sin distracciones.",
      });

      const lines = aiResponse
        .split("\n")
        .map((l) => l.trim())
        .filter(Boolean);
      const bulletLines = lines.filter((l) => l.startsWith("-") || l.startsWith("•") || /^\d+\./.test(l));
      const newCheckItems: KeepChecklistItem[] = (bulletLines.length > 0 ? bulletLines : lines.slice(0, 4)).map(
        (line, i) => ({
          id: `ai-chk-${Date.now()}-${i}`,
          text: line.replace(/^[-•\d.)\s]+/, "").trim(),
          checked: false,
        })
      );

      if (!taskTitle.trim()) {
        setTaskTitle(`Seguimiento Clínico COSAM — ${patientLabel || "Control Box"}`);
      }
      setTaskNotes(aiResponse.trim());

      if (!noteTitle.trim()) {
        setNoteTitle(`Checklist Clínico — ${patientLabel || "Control Box"}`);
      }
      setNoteBody(lines.slice(0, 2).join(" "));
      setNoteChecklist(newCheckItems);

      setStatusBanner({
        type: "info",
        message: "Pauta y checklist clínico estructurados con IA listos para guardar.",
      });
    } catch (err: any) {
      setStatusBanner({
        type: "error",
        message: err.message || "Error al estructurar tarea clínica con IA.",
      });
    } finally {
      setIsGeneratingAI(false);
    }
  };

  // ===========================================================================
  // GOOGLE TASKS MUTATIONS WITH MANDATORY USER CONFIRMATION
  // ===========================================================================

  const handleRequestCreateTaskList = () => {
    if (!newListTitle.trim()) return;
    const titleToCreate = newListTitle.trim();
    setConfirmModal({
      title: "Confirmar creación de lista en Google Tasks",
      description:
        "Se creará una nueva lista de tareas en su cuenta de Google Tasks para organizar el seguimiento clínico.",
      details: [`Nombre de la lista: ${titleToCreate}`],
      confirmLabel: "Crear Lista en Google Tasks",
      variant: "primary",
      onConfirm: async () => {
        setIsSubmitting(true);
        try {
          const created = await GoogleTasksKeepService.createTaskList(titleToCreate);
          setNewListTitle("");
          setShowNewListInput(false);
          setSelectedListId(created.id);
          await loadTasksWorkspace(created.id);
          setStatusBanner({
            type: "success",
            message: `Lista "${created.title}" creada en Google Tasks.`,
          });
        } catch (err: any) {
          setStatusBanner({
            type: "error",
            message: err.message || "Error al crear lista en Google Tasks.",
          });
        } finally {
          setIsSubmitting(false);
        }
      },
    });
  };

  const handleRequestSaveTask = () => {
    if (!taskTitle.trim()) {
      setStatusBanner({
        type: "error",
        message: "Ingrese un título para la tarea clínica antes de guardar.",
      });
      return;
    }

    const currentListName =
      taskLists.find((l) => l.id === selectedListId)?.title || "Lista Principal";

    if (taskFormMode === "edit" && editingTaskId) {
      setConfirmModal({
        title: "Confirmar actualización de tarea en Google Tasks",
        description:
          "Esta acción actualizará la tarea seleccionada en su cuenta de Google Tasks.",
        details: [
          `Lista: ${currentListName}`,
          `Tarea: ${taskTitle.trim()}`,
          `Vencimiento: ${taskDueDate || "Sin fecha"}`,
        ],
        confirmLabel: "Confirmar y Actualizar Tarea",
        variant: "primary",
        onConfirm: async () => {
          setIsSubmitting(true);
          try {
            await GoogleTasksKeepService.updateTask(selectedListId, editingTaskId, {
              title: taskTitle.trim(),
              notes: taskNotes.trim(),
              dueDate: taskDueDate || null,
            });
            setTaskFormMode("create");
            setEditingTaskId(null);
            setTaskTitle("");
            setTaskNotes("");
            await loadTasksWorkspace(selectedListId);
            setStatusBanner({
              type: "success",
              message: "Tarea actualizada correctamente en Google Tasks.",
            });
          } catch (err: any) {
            setStatusBanner({
              type: "error",
              message: err.message || "Error al actualizar tarea.",
            });
          } finally {
            setIsSubmitting(false);
          }
        },
      });
    } else {
      setConfirmModal({
        title: "Confirmar creación de tarea en Google Tasks",
        description:
          "Se registrará una nueva tarea de seguimiento clínico en su cuenta de Google Tasks.",
        details: [
          `Lista destino: ${currentListName}`,
          `Título: ${taskTitle.trim()}`,
          `Fecha límite: ${taskDueDate || "Sin fecha"}`,
          ...(taskNotes.trim() ? [`Notas: ${taskNotes.trim().slice(0, 90)}...`] : []),
        ],
        confirmLabel: "Confirmar y Crear Tarea",
        variant: "primary",
        onConfirm: async () => {
          setIsSubmitting(true);
          try {
            await GoogleTasksKeepService.createTask(selectedListId, {
              title: taskTitle.trim(),
              notes: taskNotes.trim(),
              dueDate: taskDueDate || undefined,
            });
            setTaskTitle("");
            setTaskNotes("");
            await loadTasksWorkspace(selectedListId);
            setStatusBanner({
              type: "success",
              message: "Tarea clínica creada exitosamente en Google Tasks.",
            });
          } catch (err: any) {
            setStatusBanner({
              type: "error",
              message: err.message || "Error al crear tarea en Google Tasks.",
            });
          } finally {
            setIsSubmitting(false);
          }
        },
      });
    }
  };

  const handleRequestToggleTask = (task: GoogleTaskItem) => {
    const nextStatus = task.status === "completed" ? "needsAction" : "completed";
    setConfirmModal({
      title:
        nextStatus === "completed"
          ? "Confirmar cierre de tarea en Google Tasks"
          : "Confirmar reapertura de tarea en Google Tasks",
      description: `¿Desea marcar la tarea "${task.title}" como ${
        nextStatus === "completed" ? "Completada" : "Pendiente"
      } en Google Tasks?`,
      details: [
        `Tarea: ${task.title}`,
        `Nuevo estado: ${nextStatus === "completed" ? "Completada" : "Pendiente de acción"}`,
      ],
      confirmLabel: nextStatus === "completed" ? "Marcar Completada" : "Marcar Pendiente",
      variant: "primary",
      onConfirm: async () => {
        setIsSubmitting(true);
        try {
          await GoogleTasksKeepService.updateTask(selectedListId, task.id, {
            status: nextStatus,
          });
          await loadTasksWorkspace(selectedListId);
          setStatusBanner({
            type: "success",
            message: `Estado de "${task.title}" actualizado en Google Tasks.`,
          });
        } catch (err: any) {
          setStatusBanner({
            type: "error",
            message: err.message || "No se pudo cambiar el estado de la tarea.",
          });
        } finally {
          setIsSubmitting(false);
        }
      },
    });
  };

  const handleRequestDeleteTask = (task: GoogleTaskItem) => {
    setConfirmModal({
      title: "Confirmar eliminación de tarea en Google Tasks",
      description:
        "Esta acción eliminará permanentemente la tarea seleccionada de su lista en Google Tasks.",
      details: [`Tarea a eliminar: ${task.title}`],
      confirmLabel: "Eliminar Tarea",
      variant: "danger",
      onConfirm: async () => {
        setIsSubmitting(true);
        try {
          await GoogleTasksKeepService.deleteTask(selectedListId, task.id);
          await loadTasksWorkspace(selectedListId);
          setStatusBanner({
            type: "info",
            message: `Tarea "${task.title}" eliminada de Google Tasks.`,
          });
        } catch (err: any) {
          setStatusBanner({
            type: "error",
            message: err.message || "No se pudo eliminar la tarea.",
          });
        } finally {
          setIsSubmitting(false);
        }
      },
    });
  };

  // ===========================================================================
  // GOOGLE KEEP NOTES MUTATIONS WITH MANDATORY USER CONFIRMATION
  // ===========================================================================

  const handleAddChecklistItem = () => {
    if (!checklistInput.trim()) return;
    setNoteChecklist((prev) => [
      ...prev,
      {
        id: `chk-${Date.now()}`,
        text: checklistInput.trim(),
        checked: false,
      },
    ]);
    setChecklistInput("");
  };

  const handleRequestCreateKeepNote = () => {
    if (!noteTitle.trim()) {
      setStatusBanner({
        type: "error",
        message: "Ingrese un título para la nota clínica de Keep.",
      });
      return;
    }

    setConfirmModal({
      title: "Confirmar creación de nota clínica en Google Keep",
      description:
        noteSyncToTasks && isConnected
          ? "Se guardará la nota clínica en Google Keep y se creará simultáneamente un recordatorio vinculado en Google Tasks."
          : "Se guardará la nota clínica estructurada en su panel de Google Keep.",
      details: [
        `Título: ${noteTitle.trim()}`,
        `Categoría: ${noteCategory}`,
        `Ítems de checklist: ${noteChecklist.length}`,
        `Vincular a Google Tasks: ${noteSyncToTasks && isConnected ? "Sí" : "No"}`,
      ],
      confirmLabel: "Confirmar y Guardar Nota Keep",
      variant: "primary",
      onConfirm: async () => {
        setIsSubmitting(true);
        try {
          await GoogleTasksKeepService.createKeepNote({
            title: noteTitle.trim(),
            bodyText: noteBody.trim(),
            checklist: noteChecklist,
            category: noteCategory,
            pinned: notePinned,
            syncToGoogleTasks: noteSyncToTasks && isConnected,
            taskListId: selectedListId,
          });
          setNoteTitle("");
          setNoteBody("");
          setNoteChecklist([]);
          await loadKeepWorkspace();
          if (noteSyncToTasks && isConnected) {
            await loadTasksWorkspace(selectedListId);
          }
          setStatusBanner({
            type: "success",
            message: "Nota clínica guardada en Google Keep correctamente.",
          });
        } catch (err: any) {
          setStatusBanner({
            type: "error",
            message: err.message || "No se pudo guardar la nota de Keep.",
          });
        } finally {
          setIsSubmitting(false);
        }
      },
    });
  };

  const handleToggleKeepChecklistItem = async (note: ClinicalKeepNote, itemId: string) => {
    const updatedChecklist = note.checklist.map((item) =>
      item.id === itemId ? { ...item, checked: !item.checked } : item
    );
    const updatedNotes = await GoogleTasksKeepService.updateKeepNote(note.name, {
      checklist: updatedChecklist,
    });
    setKeepNotes(updatedNotes);
  };

  const handleTogglePinKeepNote = async (note: ClinicalKeepNote) => {
    const updatedNotes = await GoogleTasksKeepService.updateKeepNote(note.name, {
      pinned: !note.pinned,
    });
    setKeepNotes(updatedNotes);
  };

  const handleRequestConvertKeepToTask = (note: ClinicalKeepNote) => {
    if (!isConnected) {
      setStatusBanner({
        type: "error",
        message: "Inicie sesión con Google para enviar notas de Keep hacia Google Tasks.",
      });
      return;
    }

    const checklistSummary =
      note.checklist.length > 0
        ? "\n" + note.checklist.map((c) => `${c.checked ? "[x]" : "[ ]"} ${c.text}`).join("\n")
        : "";

    setConfirmModal({
      title: "Confirmar envío de Nota Keep a Google Tasks",
      description:
        "Se creará una tarea accionable en su lista activa de Google Tasks con el contenido y checklist de esta nota de Keep.",
      details: [
        `Nota origen: ${note.title}`,
        `Categoría: ${note.category}`,
        `Lista destino: ${
          taskLists.find((l) => l.id === selectedListId)?.title || "Lista Principal"
        }`,
      ],
      confirmLabel: "Enviar a Google Tasks",
      variant: "primary",
      onConfirm: async () => {
        setIsSubmitting(true);
        try {
          await GoogleTasksKeepService.createTask(selectedListId, {
            title: `[Keep · ${note.category}] ${note.title}`,
            notes: `${note.bodyText}${checklistSummary}`.trim(),
          });
          await loadTasksWorkspace(selectedListId);
          setStatusBanner({
            type: "success",
            message: `Nota "${note.title}" convertida en tarea de Google Tasks.`,
          });
        } catch (err: any) {
          setStatusBanner({
            type: "error",
            message: err.message || "Error al convertir nota en tarea.",
          });
        } finally {
          setIsSubmitting(false);
        }
      },
    });
  };

  const handleRequestDeleteKeepNote = (note: ClinicalKeepNote) => {
    setConfirmModal({
      title: "Confirmar eliminación de nota en Google Keep",
      description:
        "Esta acción eliminará la nota clínica y su lista de chequeo asociada.",
      details: [`Nota: ${note.title}`, `Categoría: ${note.category}`],
      confirmLabel: "Eliminar Nota Keep",
      variant: "danger",
      onConfirm: async () => {
        setIsSubmitting(true);
        try {
          const remaining = await GoogleTasksKeepService.deleteKeepNote(note.name);
          setKeepNotes(remaining);
          setStatusBanner({
            type: "info",
            message: `Nota "${note.title}" eliminada.`,
          });
        } catch (err: any) {
          setStatusBanner({
            type: "error",
            message: err.message || "No se pudo eliminar la nota.",
          });
        } finally {
          setIsSubmitting(false);
        }
      },
    });
  };

  // Filtered lists
  const filteredTasks = useMemo(() => {
    return tasks.filter((t) => {
      const matchesStatus = taskFilter === "all" || t.status === taskFilter;
      const matchesSearch =
        !taskSearch.trim() ||
        t.title.toLowerCase().includes(taskSearch.toLowerCase()) ||
        (t.notes || "").toLowerCase().includes(taskSearch.toLowerCase());
      return matchesStatus && matchesSearch;
    });
  }, [tasks, taskFilter, taskSearch]);

  const filteredKeepNotes = useMemo(() => {
    return [...keepNotes]
      .sort((a, b) => Number(b.pinned) - Number(a.pinned))
      .filter((n) => {
        const matchesCat = keepCategoryFilter === "Todas" || n.category === keepCategoryFilter;
        const matchesSearch =
          !keepSearch.trim() ||
          n.title.toLowerCase().includes(keepSearch.toLowerCase()) ||
          n.bodyText.toLowerCase().includes(keepSearch.toLowerCase()) ||
          n.checklist.some((c) => c.text.toLowerCase().includes(keepSearch.toLowerCase()));
        return matchesCat && matchesSearch;
      });
  }, [keepNotes, keepCategoryFilter, keepSearch]);

  const pendingTasksCount = tasks.filter((t) => t.status === "needsAction").length;
  const completedTasksCount = tasks.filter((t) => t.status === "completed").length;

  return (
    <div className="space-y-5 animate-in fade-in duration-300">
      {/* Selector de Paciente Unificado */}
      <PatientSelectorBar
        selectedPatient={selectedPatient}
        onSelectPatient={handlePatientSelect}
      />

      {/* Encabezado Principal del Módulo con Glassmorphism */}
      <div className="clinical-card overflow-hidden">
        <div className="clinical-glass-header px-5 py-3.5 flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-sky-500/10 border border-sky-500/20 flex items-center justify-center text-[#075985] dark:text-sky-400 shrink-0">
              <CheckSquare className="w-4 h-4" strokeWidth={1.75} />
            </div>
            <div>
              <div className="flex items-center gap-2 text-[11px] font-medium text-slate-500 dark:text-slate-400">
                <span>Google Workspace Clínico</span>
                <span aria-hidden="true">·</span>
                <span>Tasks API & Keep</span>
                <span aria-hidden="true">·</span>
                <span className="font-mono tabular-nums">
                  {pendingTasksCount} pendientes / {keepNotes.length} notas Keep
                </span>
              </div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white tracking-tight">
                Tareas Clínicas (Google Tasks) & Notas de Box (Google Keep)
              </h2>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Selector de Vista */}
            <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl border border-slate-200/80 dark:border-slate-700">
              <button
                type="button"
                onClick={() => setActiveWorkspaceTab("split")}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all whitespace-nowrap cursor-pointer ${
                  activeWorkspaceTab === "split"
                    ? "bg-white dark:bg-slate-900 text-[#075985] dark:text-sky-400 shadow-2xs"
                    : "text-slate-600 dark:text-slate-400 hover:text-slate-900"
                }`}
              >
                Vista Integrada
              </button>
              <button
                type="button"
                onClick={() => setActiveWorkspaceTab("tasks")}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all whitespace-nowrap cursor-pointer ${
                  activeWorkspaceTab === "tasks"
                    ? "bg-white dark:bg-slate-900 text-[#075985] dark:text-sky-400 shadow-2xs"
                    : "text-slate-600 dark:text-slate-400 hover:text-slate-900"
                }`}
              >
                Google Tasks ({tasks.length})
              </button>
              <button
                type="button"
                onClick={() => setActiveWorkspaceTab("keep")}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all whitespace-nowrap cursor-pointer ${
                  activeWorkspaceTab === "keep"
                    ? "bg-white dark:bg-slate-900 text-[#075985] dark:text-sky-400 shadow-2xs"
                    : "text-slate-600 dark:text-slate-400 hover:text-slate-900"
                }`}
              >
                Google Keep ({keepNotes.length})
              </button>
            </div>

            {isConnected ? (
              <button
                type="button"
                onClick={() => {
                  loadTasksWorkspace(selectedListId);
                  loadKeepWorkspace();
                }}
                disabled={isLoadingTasks || isLoadingKeep}
                className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap"
              >
                <RefreshCw
                  className={`w-3.5 h-3.5 ${isLoadingTasks || isLoadingKeep ? "animate-spin" : ""}`}
                />
                <span>Sincronizar</span>
              </button>
            ) : (
              <GoogleSignInButton
                onClick={handleConnectGoogle}
                loading={isConnecting}
                text="Sign in with Google"
              />
            )}
          </div>
        </div>

        {/* Tira de Plantillas Rápidas según Protocolo COSAM Rinconada */}
        <div className="px-5 py-3 bg-slate-50/70 dark:bg-slate-900/50 border-t border-slate-200/70 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
              Plantillas Clínicas COSAM:
            </span>
            {CLINICAL_TASK_TEMPLATES.map((tpl) => (
              <button
                key={tpl.id}
                type="button"
                onClick={() => handleApplyTemplate(tpl)}
                className="px-2.5 py-1 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-[#075985] text-xs font-medium text-slate-700 dark:text-slate-200 transition-colors cursor-pointer whitespace-nowrap"
              >
                + {tpl.label}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={handleGenerateAIChecklist}
            disabled={isGeneratingAI}
            className="px-3 py-1.5 rounded-lg bg-[#075985] hover:bg-[#0c4a6e] text-white text-xs font-semibold flex items-center gap-1.5 transition-colors disabled:opacity-50 cursor-pointer whitespace-nowrap"
          >
            {isGeneratingAI ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Sparkles className="w-3.5 h-3.5" />
            )}
            <span>Estructurar Seguimiento con IA</span>
          </button>
        </div>
      </div>

      {/* Banner de Estado */}
      {statusBanner && (
        <div
          className={`px-4 py-3 rounded-xl border flex items-center justify-between gap-3 text-xs font-medium ${
            statusBanner.type === "success"
              ? "bg-emerald-50/90 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-800/60 text-emerald-800 dark:text-emerald-200"
              : statusBanner.type === "error"
              ? "bg-rose-50/90 dark:bg-rose-950/30 border-rose-200 dark:border-rose-800/60 text-rose-800 dark:text-rose-200"
              : "bg-sky-50/90 dark:bg-sky-950/30 border-sky-200 dark:border-sky-800/60 text-sky-900 dark:text-sky-200"
          }`}
        >
          <div className="flex items-center gap-2">
            {statusBanner.type === "success" ? (
              <CheckCircle2 className="w-4 h-4 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 shrink-0" />
            )}
            <span>{statusBanner.message}</span>
          </div>
          <button
            type="button"
            onClick={() => setStatusBanner(null)}
            className="text-slate-400 hover:text-slate-600 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Grilla Principal con Headers Glassmorphism Sticky en Scroll */}
      <div
        className={`grid grid-cols-1 ${
          activeWorkspaceTab === "split" ? "xl:grid-cols-2" : "xl:grid-cols-1"
        } gap-5 items-stretch`}
      >
        {/* =====================================================================
            COLUMNA 1: GOOGLE TASKS (SEGUIMIENTO CLÍNICO Y PENDIENTES DE BOX)
           ===================================================================== */}
        {(activeWorkspaceTab === "split" || activeWorkspaceTab === "tasks") && (
          <div className="clinical-card flex flex-col max-h-[780px] overflow-hidden">
            {/* Header Sticky Glassmorphism */}
            <div className="clinical-glass-header px-5 py-3.5 flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2.5">
                <ListTodo className="w-4 h-4 text-[#075985] dark:text-sky-400" strokeWidth={1.85} />
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white leading-tight">
                    Google Tasks — Pendientes y Seguimiento de Casos
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 font-mono tabular-nums">
                    {pendingTasksCount} activas · {completedTasksCount} completadas
                  </p>
                </div>
              </div>

              {isConnected && (
                <div className="flex items-center gap-2">
                  <select
                    value={selectedListId}
                    onChange={(e) => {
                      setSelectedListId(e.target.value);
                      loadTasksWorkspace(e.target.value);
                    }}
                    className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-2.5 py-1 text-xs font-medium text-slate-700 dark:text-slate-200 outline-none"
                  >
                    {taskLists.length === 0 && <option value="@default">Mis Tareas</option>}
                    {taskLists.map((list) => (
                      <option key={list.id} value={list.id}>
                        {list.title}
                      </option>
                    ))}
                  </select>
                  <button
                    type="button"
                    onClick={() => setShowNewListInput((prev) => !prev)}
                    title="Crear nueva lista en Google Tasks"
                    className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 cursor-pointer"
                  >
                    <FolderPlus className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </div>

            {/* Cuerpo Scrolleable de Google Tasks */}
            <div className="flex-1 overflow-y-auto p-5 space-y-4">
              {!isConnected ? (
                <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/50 p-6 text-center space-y-3">
                  <ListTodo className="w-8 h-8 text-[#075985] dark:text-sky-400 mx-auto" />
                  <div className="space-y-1 max-w-md mx-auto">
                    <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                      Conecte su cuenta de Google Tasks
                    </h4>
                    <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                      Autentique con Google para ver, crear, completar y organizar sus listas de seguimiento clínico y controles de farmacovigilancia directamente en Google Tasks.
                    </p>
                  </div>
                  <div className="flex justify-center pt-1">
                    <GoogleSignInButton
                      onClick={handleConnectGoogle}
                      loading={isConnecting}
                      text="Sign in with Google"
                    />
                  </div>
                </div>
              ) : (
                <>
                  {/* Crear Nueva Lista de Tareas */}
                  {showNewListInput && (
                    <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 flex items-center gap-2">
                      <input
                        type="text"
                        value={newListTitle}
                        onChange={(e) => setNewListTitle(e.target.value)}
                        placeholder="Ej: COSAM Rinconada - Controles Litemia"
                        className="flex-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-800 dark:text-slate-100 outline-none"
                      />
                      <button
                        type="button"
                        onClick={handleRequestCreateTaskList}
                        className="px-3 py-1.5 rounded-lg bg-[#075985] text-white text-xs font-semibold cursor-pointer whitespace-nowrap"
                      >
                        Crear Lista
                      </button>
                    </div>
                  )}

                  {/* Formulario de Nueva / Edición de Tarea */}
                  <div className="p-4 rounded-xl bg-slate-50/80 dark:bg-slate-800/40 border border-slate-200/90 dark:border-slate-800 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                        {taskFormMode === "edit"
                          ? "Editando Tarea de Google Tasks"
                          : "Nueva Tarea Clínica en Google Tasks"}
                      </span>
                      {taskFormMode === "edit" && (
                        <button
                          type="button"
                          onClick={() => {
                            setTaskFormMode("create");
                            setEditingTaskId(null);
                            setTaskTitle("");
                            setTaskNotes("");
                          }}
                          className="text-[11px] text-slate-500 hover:text-slate-800 cursor-pointer"
                        >
                          Cancelar edición
                        </button>
                      )}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                      <div className="sm:col-span-2">
                        <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                          Título de la Tarea Accionable
                        </label>
                        <input
                          type="text"
                          value={taskTitle}
                          onChange={(e) => setTaskTitle(e.target.value)}
                          placeholder="Ej: Revisar Litemia y ECG basal — Paciente..."
                          className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-900 dark:text-slate-100 focus:border-[#075985] outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                          Fecha Límite
                        </label>
                        <input
                          type="date"
                          value={taskDueDate}
                          onChange={(e) => setTaskDueDate(e.target.value)}
                          className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg px-2.5 py-2 text-xs font-mono text-slate-900 dark:text-slate-100 focus:border-[#075985] outline-none"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                        Notas Clínicas / Indicaciones de Seguimiento
                      </label>
                      <textarea
                        rows={2}
                        value={taskNotes}
                        onChange={(e) => setTaskNotes(e.target.value)}
                        placeholder="Detalles de farmacovigilancia, exámenes pendientes o coordinación con CESFAM..."
                        className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg p-2.5 text-xs text-slate-800 dark:text-slate-200 focus:border-[#075985] outline-none resize-none"
                      />
                    </div>

                    <div className="flex justify-end">
                      <button
                        type="button"
                        onClick={handleRequestSaveTask}
                        disabled={isSubmitting}
                        className="px-4 py-2 rounded-lg bg-[#075985] hover:bg-[#0c4a6e] text-white text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>
                          {taskFormMode === "edit"
                            ? "Actualizar en Google Tasks"
                            : "Guardar en Google Tasks"}
                        </span>
                      </button>
                    </div>
                  </div>

                  {/* Barra de Filtro y Búsqueda de Tareas */}
                  <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2">
                    <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg">
                      <button
                        type="button"
                        onClick={() => setTaskFilter("all")}
                        className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-colors cursor-pointer ${
                          taskFilter === "all"
                            ? "bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-2xs"
                            : "text-slate-600 dark:text-slate-400"
                        }`}
                      >
                        Todas ({tasks.length})
                      </button>
                      <button
                        type="button"
                        onClick={() => setTaskFilter("needsAction")}
                        className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-colors cursor-pointer ${
                          taskFilter === "needsAction"
                            ? "bg-white dark:bg-slate-900 text-[#075985] dark:text-sky-400 shadow-2xs"
                            : "text-slate-600 dark:text-slate-400"
                        }`}
                      >
                        Pendientes ({pendingTasksCount})
                      </button>
                      <button
                        type="button"
                        onClick={() => setTaskFilter("completed")}
                        className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-colors cursor-pointer ${
                          taskFilter === "completed"
                            ? "bg-white dark:bg-slate-900 text-emerald-700 dark:text-emerald-400 shadow-2xs"
                            : "text-slate-600 dark:text-slate-400"
                        }`}
                      >
                        Completadas ({completedTasksCount})
                      </button>
                    </div>

                    <div className="relative flex-1 max-w-xs">
                      <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        value={taskSearch}
                        onChange={(e) => setTaskSearch(e.target.value)}
                        placeholder="Filtrar tareas..."
                        className="w-full pl-8 pr-3 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-800 dark:text-slate-200 outline-none"
                      />
                    </div>
                  </div>

                  {/* Lista de Tareas */}
                  {isLoadingTasks ? (
                    <div className="py-10 text-center space-y-2">
                      <Loader2 className="w-6 h-6 animate-spin text-[#075985] mx-auto" />
                      <p className="text-xs text-slate-500">Cargando tareas desde Google Tasks...</p>
                    </div>
                  ) : filteredTasks.length === 0 ? (
                    <div className="py-8 text-center rounded-xl border border-dashed border-slate-200 dark:border-slate-800">
                      <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
                        No hay tareas registradas en esta vista. Utilice el formulario superior o una plantilla COSAM para crear la primera tarea.
                      </p>
                    </div>
                  ) : (
                    <div className="divide-y divide-slate-200/70 dark:divide-slate-800 border border-slate-200/80 dark:border-slate-800 rounded-xl overflow-hidden bg-white dark:bg-slate-900">
                      {filteredTasks.map((task) => {
                        const isDone = task.status === "completed";
                        return (
                          <div
                            key={task.id}
                            className="p-3.5 hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors flex items-start justify-between gap-3"
                          >
                            <div className="flex items-start gap-3 min-w-0">
                              <button
                                type="button"
                                onClick={() => handleRequestToggleTask(task)}
                                className={`mt-0.5 w-4 h-4 rounded border flex items-center justify-center shrink-0 transition-colors cursor-pointer ${
                                  isDone
                                    ? "bg-emerald-600 border-emerald-600 text-white"
                                    : "border-slate-300 dark:border-slate-600 hover:border-[#075985]"
                                }`}
                                title={isDone ? "Marcar como pendiente" : "Marcar como completada"}
                              >
                                {isDone && <CheckCircle2 className="w-3 h-3" />}
                              </button>
                              <div className="min-w-0 space-y-1">
                                <p
                                  className={`text-xs font-semibold leading-snug ${
                                    isDone
                                      ? "line-through text-slate-400 dark:text-slate-500"
                                      : "text-slate-900 dark:text-slate-100"
                                  }`}
                                >
                                  {task.title}
                                </p>
                                {task.notes && (
                                  <p className="text-[11px] text-slate-600 dark:text-slate-400 whitespace-pre-line line-clamp-3">
                                    {task.notes}
                                  </p>
                                )}
                                {task.due && (
                                  <div className="flex items-center gap-1.5 text-[10px] font-mono text-slate-500 dark:text-slate-400">
                                    <Calendar className="w-3 h-3" />
                                    <span>Vence: {task.due.split("T")[0]}</span>
                                  </div>
                                )}
                              </div>
                            </div>

                            <div className="flex items-center gap-1 shrink-0">
                              <button
                                type="button"
                                onClick={() => {
                                  setTaskFormMode("edit");
                                  setEditingTaskId(task.id);
                                  setTaskTitle(task.title);
                                  setTaskNotes(task.notes || "");
                                  if (task.due) {
                                    setTaskDueDate(task.due.split("T")[0]);
                                  }
                                }}
                                className="p-1.5 rounded-lg text-slate-400 hover:text-[#075985] hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                                title="Editar tarea"
                              >
                                <Edit3 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => handleRequestDeleteTask(task)}
                                className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 cursor-pointer"
                                title="Eliminar tarea"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </>
              )}
            </div>
          </div>
        )}

        {/* =====================================================================
            COLUMNA 2: GOOGLE KEEP (NOTAS RÁPIDAS DE BOX Y CHECKLISTS CLÍNICOS)
           ===================================================================== */}
        {(activeWorkspaceTab === "split" || activeWorkspaceTab === "keep") && (
          <div className="clinical-card flex flex-col max-h-[780px] overflow-hidden">
            {/* Header Sticky Glassmorphism */}
            <div className="clinical-glass-header px-5 py-3.5 flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2.5">
                <StickyNote className="w-4 h-4 text-[#075985] dark:text-sky-400" strokeWidth={1.85} />
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white leading-tight">
                    Google Keep — Notas Clínicas de Box & Listas de Chequeo
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    Recordatorios farmacológicos, criterios de derivación y checklists operativos
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-1.5 text-[11px] font-medium text-slate-500 dark:text-slate-400">
                <ShieldCheck className="w-3.5 h-3.5 text-[#075985] dark:text-sky-400" />
                <span>Sincronizado con Tasks</span>
              </div>
            </div>

            {/* Cuerpo Scrolleable de Google Keep */}
            <div className="flex-1 overflow-y-auto p-5 space-y-4">
              {/* Creador de Nota Keep con Checklist */}
              <div className="p-4 rounded-xl bg-slate-50/80 dark:bg-slate-800/40 border border-slate-200/90 dark:border-slate-800 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                    Nueva Nota Rápida / Checklist en Google Keep
                  </span>
                  <div className="flex items-center gap-2">
                    <select
                      value={noteCategory}
                      onChange={(e) =>
                        setNoteCategory(e.target.value as ClinicalKeepNote["category"])
                      }
                      className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg px-2.5 py-1 text-xs font-medium text-slate-700 dark:text-slate-200 outline-none"
                    >
                      <option value="Protocolo COSAM">Protocolo COSAM</option>
                      <option value="Farmacovigilancia">Farmacovigilancia</option>
                      <option value="Interconsulta APS">Interconsulta APS</option>
                      <option value="Nota de Box">Nota de Box</option>
                    </select>
                    <button
                      type="button"
                      onClick={() => setNotePinned((p) => !p)}
                      className={`px-2.5 py-1 rounded-lg border text-xs font-medium flex items-center gap-1 cursor-pointer ${
                        notePinned
                          ? "bg-sky-500/10 border-sky-500/30 text-[#075985] dark:text-sky-300"
                          : "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-500"
                      }`}
                    >
                      <Pin className="w-3 h-3" />
                      <span>{notePinned ? "Fijada" : "Fijar"}</span>
                    </button>
                  </div>
                </div>

                <input
                  type="text"
                  value={noteTitle}
                  onChange={(e) => setNoteTitle(e.target.value)}
                  placeholder="Título de la nota (ej: Criterios derivación Psiquiatría / Litemia)..."
                  className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 text-xs font-semibold text-slate-900 dark:text-slate-100 focus:border-[#075985] outline-none"
                />

                <textarea
                  rows={2}
                  value={noteBody}
                  onChange={(e) => setNoteBody(e.target.value)}
                  placeholder="Nota clínica o síntesis de box..."
                  className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg p-2.5 text-xs text-slate-800 dark:text-slate-200 focus:border-[#075985] outline-none resize-none"
                />

                {/* Constructor de Checklist */}
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={checklistInput}
                      onChange={(e) => setChecklistInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") {
                          e.preventDefault();
                          handleAddChecklistItem();
                        }
                      }}
                      placeholder="Agregar ítem de lista de chequeo (Enter)..."
                      className="flex-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-800 dark:text-slate-200 outline-none"
                    />
                    <button
                      type="button"
                      onClick={handleAddChecklistItem}
                      className="px-3 py-1.5 rounded-lg bg-slate-200/80 hover:bg-slate-300/80 dark:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-semibold cursor-pointer whitespace-nowrap"
                    >
                      + Ítem
                    </button>
                  </div>

                  {noteChecklist.length > 0 && (
                    <div className="space-y-1 pt-1">
                      {noteChecklist.map((item) => (
                        <div
                          key={item.id}
                          className="flex items-center justify-between gap-2 px-2.5 py-1 rounded-md bg-white dark:bg-slate-900 border border-slate-200/70 dark:border-slate-800 text-xs"
                        >
                          <span className="text-slate-700 dark:text-slate-300 truncate">
                            • {item.text}
                          </span>
                          <button
                            type="button"
                            onClick={() =>
                              setNoteChecklist((prev) => prev.filter((c) => c.id !== item.id))
                            }
                            className="text-slate-400 hover:text-rose-600 cursor-pointer"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                  <label className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-400 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={noteSyncToTasks}
                      onChange={(e) => setNoteSyncToTasks(e.target.checked)}
                      className="rounded border-slate-300 text-[#075985] focus:ring-[#075985]"
                    />
                    <span>Crear también como tarea en Google Tasks al guardar</span>
                  </label>

                  <button
                    type="button"
                    onClick={handleRequestCreateKeepNote}
                    disabled={isSubmitting}
                    className="px-4 py-2 rounded-lg bg-[#075985] hover:bg-[#0c4a6e] text-white text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Guardar Nota Keep</span>
                  </button>
                </div>
              </div>

              {/* Filtros de Notas Keep */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2">
                <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0">
                  {["Todas", "Protocolo COSAM", "Farmacovigilancia", "Interconsulta APS", "Nota de Box"].map(
                    (cat) => (
                      <button
                        key={cat}
                        type="button"
                        onClick={() => setKeepCategoryFilter(cat)}
                        className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-colors whitespace-nowrap cursor-pointer ${
                          keepCategoryFilter === cat
                            ? "bg-[#075985] text-white"
                            : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-900"
                        }`}
                      >
                        {cat}
                      </button>
                    )
                  )}
                </div>

                <div className="relative flex-1 max-w-xs">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={keepSearch}
                    onChange={(e) => setKeepSearch(e.target.value)}
                    placeholder="Buscar en notas Keep..."
                    className="w-full pl-8 pr-3 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-800 dark:text-slate-200 outline-none"
                  />
                </div>
              </div>

              {/* Grilla de Tarjetas de Notas Keep con Headers Glassmorphism */}
              <div className="grid grid-cols-1 gap-3">
                {filteredKeepNotes.map((note) => (
                  <div
                    key={note.name}
                    className="rounded-xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden shadow-2xs"
                  >
                    <div className="clinical-glass-header px-4 py-2.5 flex items-center justify-between gap-2">
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5 text-[10px] font-medium text-slate-500 dark:text-slate-400">
                          <span>{note.category}</span>
                          <span aria-hidden="true">·</span>
                          <span className="font-mono">
                            {new Date(note.updateTime).toLocaleDateString("es-CL")}
                          </span>
                        </div>
                        <h4 className="text-xs font-bold text-slate-900 dark:text-white truncate">
                          {note.title}
                        </h4>
                      </div>

                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          type="button"
                          onClick={() => handleTogglePinKeepNote(note)}
                          title={note.pinned ? "Desfijar nota" : "Fijar nota"}
                          className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                            note.pinned
                              ? "text-[#075985] dark:text-sky-400 bg-sky-500/10"
                              : "text-slate-400 hover:text-slate-700"
                          }`}
                        >
                          <Pin className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleRequestConvertKeepToTask(note)}
                          title="Enviar como tarea a Google Tasks"
                          className="px-2 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-[11px] font-semibold text-[#075985] dark:text-sky-400 flex items-center gap-1 cursor-pointer whitespace-nowrap"
                        >
                          <span>Enviar a Tasks</span>
                          <ArrowUpRight className="w-3 h-3" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleRequestDeleteKeepNote(note)}
                          title="Eliminar nota Keep"
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    <div className="p-4 space-y-2.5">
                      {note.bodyText && (
                        <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-line">
                          {note.bodyText}
                        </p>
                      )}

                      {note.checklist.length > 0 && (
                        <div className="space-y-1.5 pt-1">
                          {note.checklist.map((item) => (
                            <label
                              key={item.id}
                              className="flex items-start gap-2.5 text-xs cursor-pointer select-none group"
                            >
                              <input
                                type="checkbox"
                                checked={item.checked}
                                onChange={() => handleToggleKeepChecklistItem(note, item.id)}
                                className="mt-0.5 rounded border-slate-300 text-[#075985] focus:ring-[#075985]"
                              />
                              <span
                                className={`leading-snug ${
                                  item.checked
                                    ? "line-through text-slate-400 dark:text-slate-500"
                                    : "text-slate-800 dark:text-slate-200 group-hover:text-slate-950"
                                }`}
                              >
                                {item.text}
                              </span>
                            </label>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Modal de Confirmación Explícita para Operaciones en Google Tasks y Google Keep */}
      {confirmModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-md w-full overflow-hidden shadow-xl animate-in zoom-in-95 duration-150">
            <div className="clinical-glass-header px-5 py-3.5 flex items-center justify-between">
              <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                {confirmModal.title}
              </h4>
              <button
                type="button"
                onClick={() => setConfirmModal(null)}
                className="text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-5 space-y-4">
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                {confirmModal.description}
              </p>
              <div className="rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200/80 dark:border-slate-700 p-3 space-y-1.5">
                {confirmModal.details.map((detail, idx) => (
                  <p
                    key={idx}
                    className="text-xs text-slate-700 dark:text-slate-200 font-medium"
                  >
                    • {detail}
                  </p>
                ))}
              </div>
              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setConfirmModal(null)}
                  disabled={isSubmitting}
                  className="px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={async () => {
                    const action = confirmModal.onConfirm;
                    setConfirmModal(null);
                    await action();
                  }}
                  disabled={isSubmitting}
                  className={`px-4 py-2 rounded-lg text-xs font-semibold text-white cursor-pointer ${
                    confirmModal.variant === "danger"
                      ? "bg-rose-600 hover:bg-rose-700"
                      : "bg-[#075985] hover:bg-[#0c4a6e]"
                  }`}
                >
                  {confirmModal.confirmLabel}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
