import { useState, useEffect } from "react";
import { Plus, Trash2, Printer, Sparkles, RefreshCw, CheckCircle, FileText, BookOpen, AlertCircle } from "lucide-react";
import { DerivacionRecord } from "../../types";
import { generateClinicalAI } from "../../services/geminiService";
import { exportElementToPdf } from "../../utils/pdfExport";
import { GoogleDriveService } from "../../services/googleDriveService";
import { GoogleDocsService, PersonalDocExportRecord } from "../../services/googleDocsService";
import { PersonalDocsAutoExportBar } from "./PersonalDocsAutoExportBar";

export function DerivacionesAltas() {
  const [records, setRecords] = useState<DerivacionRecord[]>([]);
  const [activeRecord, setActiveRecord] = useState<DerivacionRecord | null>(null);

  // Form Fields
  const [nombre, setNombre] = useState("");
  const [rut, setRut] = useState("");
  const [edad, setEdad] = useState("");
  const [sexo, setSexo] = useState("masculino");
  const [direccion, setDireccion] = useState("");
  const [telefono, setTelefono] = useState("");
  const [correo, setCorreo] = useState("");
  const [destino, setDestino] = useState<"Alta a APS" | "Hospitalización" | "Especialidad">("Alta a APS");
  const [especialidad, setEspecialidad] = useState("");
  const [diagnostico, setDiagnostico] = useState("");
  const [tratamiento, setTratamiento] = useState("");
  const [resumenMedico, setResumenMedico] = useState("");
  const [logrosEquipo, setLogrosEquipo] = useState("");
  const [indicacionesAlta, setIndicacionesAlta] = useState("");
  const [sugerenciasAps, setSugerenciasAps] = useState("");
  const [documentoGenerado, setDocumentoGenerado] = useState("");

  // UI States
  const [loadingAI, setLoadingAI] = useState(false);
  const [errorAI, setErrorAI] = useState<string | null>(null);
  const [lastExportedPersonalDoc, setLastExportedPersonalDoc] = useState<PersonalDocExportRecord | null>(null);

  useEffect(() => {
    const stored = localStorage.getItem("cosam_derivaciones");
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        setRecords(parsed);
        if (parsed.length > 0) {
          loadRecord(parsed[0]);
        }
      } catch (e) {
        console.error("Failed to load referrals:", e);
      }
    }
  }, []);

  const saveToLocal = (updatedList: DerivacionRecord[]) => {
    setRecords(updatedList);
    localStorage.setItem("cosam_derivaciones", JSON.stringify(updatedList));
  };

  const loadRecord = (rec: DerivacionRecord) => {
    setActiveRecord(rec);
    setNombre(rec.nombre);
    setRut(rec.rut);
    setEdad(rec.edad);
    setSexo(rec.sexo);
    setDireccion(rec.direccion);
    setTelefono(rec.telefono);
    setCorreo(rec.correo);
    setDestino(rec.destino);
    setEspecialidad(rec.especialidad);
    setDiagnostico(rec.diagnostico);
    setTratamiento(rec.tratamiento);
    setResumenMedico(rec.resumenMedico);
    setLogrosEquipo(rec.logrosEquipo);
    setIndicacionesAlta(rec.indicacionesAlta);
    setSugerenciasAps(rec.sugerenciasAps);
    setDocumentoGenerado(rec.documentoGenerado);
  };

  const handleNewRecord = () => {
    setActiveRecord(null);
    setNombre("");
    setRut("");
    setEdad("");
    setSexo("masculino");
    setDireccion("");
    setTelefono("");
    setCorreo("");
    setDestino("Alta a APS");
    setEspecialidad("");
    setDiagnostico("");
    setTratamiento("");
    setResumenMedico("");
    setLogrosEquipo("");
    setIndicacionesAlta("");
    setSugerenciasAps("");
    setDocumentoGenerado("");
  };

  const handleDeleteRecord = (id: string) => {
    const updated = records.filter((r) => r.id !== id);
    saveToLocal(updated);
    if (activeRecord?.id === id) {
      if (updated.length > 0) {
        loadRecord(updated[0]);
      } else {
        handleNewRecord();
      }
    }
  };

  const handleSaveRecord = () => {
    if (!nombre.trim()) return;

    const id = activeRecord?.id || `deriv_${Date.now()}`;
    const newRecord: DerivacionRecord = {
      id,
      nombre,
      rut,
      edad,
      sexo,
      direccion,
      telefono,
      correo,
      destino,
      especialidad,
      diagnostico,
      tratamiento,
      resumenMedico,
      logrosEquipo,
      indicacionesAlta,
      sugerenciasAps,
      documentoGenerado: documentoGenerado || generatePlainTextSummary(),
      fecha: activeRecord?.fecha || new Date().toISOString().split("T")[0],
    };

    let updatedList;
    if (activeRecord) {
      updatedList = records.map((r) => (r.id === id ? newRecord : r));
    } else {
      updatedList = [newRecord, ...records];
    }

    saveToLocal(updatedList);
    setActiveRecord(newRecord);
  };

  const generatePlainTextSummary = (): string => {
    return `FOLIO: COSAM-DERIV-${Date.now()}\nDOCUMENTO DE: ${destino.toUpperCase()}\nPACIENTE: ${nombre}\nRUT: ${rut}\nDESTINO: ${destino}\nDIAGNÓSTICO: ${diagnostico}\n\n=========================================\nRESUMEN DE ATENCIONES Y EVOLUCIÓN:\n${resumenMedico}\n\nLOGROS ALCANZADOS:\n${logrosEquipo}\n\nINDICACIONES DE ALTA/SUGERENCIAS:\n${indicacionesAlta || sugerenciasAps}\n=========================================\n`;
  };

  const handleAIStructure = async () => {
    setLoadingAI(true);
    setErrorAI(null);
    try {
      const prompt = `Por favor redacta y estructura de forma clínica un informe oficial de ${destino} para el paciente del COSAM Rinconada.
DATOS DEL PACIENTE:
Nombre: ${nombre}
RUT: ${rut}
Edad: ${edad}
Sexo: ${sexo}

TIPO DE SOLICITUD: ${destino} ${especialidad ? `a la especialidad de ${especialidad}` : ""}
DIAGNÓSTICO PRINCIPAL: ${diagnostico}
TRATAMIENTO RECIBIDO: ${tratamiento}

RESUMEN DE SÍNTOMAS Y EVOLUCIÓN: ${resumenMedico || "No especificado"}
LOGROS DEL EQUIPO MULTIDISCIPLINARIO: ${logrosEquipo || "No especificado"}
INDICACIONES CLÍNICAS DE ALTA: ${indicacionesAlta || "No especificado"}
SUGERENCIAS PARA APS (Cesfam de referencia): ${sugerenciasAps || "No especificado"}

Por favor, formatea todo en un informe de contra-derivación u hoja de contrarreferencia clínica oficial y rigurosa, siguiendo las pautas de comunicación inter-niveles del Servicio de Salud en Chile. Usa terminología médica precisa y un tono de respeto profesional.`;

      const result = await generateClinicalAI({
        prompt,
        systemInstruction: "Eres un asesor en gestión de redes asistenciales de salud y especialista en psiquiatría forense y de enlace. Tu tarea es pulir, formalizar e integrar fichas de derivación e informes de alta inter-niveles con el máximo estándar clínico.",
      });

      setDocumentoGenerado(result);

      // Exportación automática al Documento Personal del Médico en Google Docs (Firebase Auth)
      if (
        GoogleDriveService.isConnected() &&
        GoogleDocsService.isAutoExportEnabled() &&
        GoogleDocsService.getExportMode() === "new_doc_per_report"
      ) {
        try {
          const exportedDoc = await GoogleDocsService.exportClinicalReportToPersonalDoc({
            reportType: `Informe de ${destino}`,
            patientName: nombre || "Paciente",
            patientRut: rut || "Sin RUT",
            content: result,
            modeOverride: "new_doc_per_report",
          });
          setLastExportedPersonalDoc(exportedDoc);
        } catch (docErr) {
          console.warn("Auto-export to personal Google Doc warning:", docErr);
        }
      }
    } catch (err: any) {
      setErrorAI(err.message || "Error al estructurar informe por IA.");
    } finally {
      setLoadingAI(false);
    }
  };

  const handleExportPDF = async () => {
    handleSaveRecord();
    try {
      await exportElementToPdf("printable-deriv-area", {
        filename: `Derivacion_Alta_${nombre.replace(/\s+/g, "_")}.pdf`,
      });
    } catch (err) {
      console.error("Failed to generate PDF:", err);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="derivaciones-altas-module">
      {/* Sidebar list panel */}
      <div className="lg:col-span-4 bg-white rounded-xl border border-slate-200 shadow-sm flex flex-col h-[700px] overflow-hidden">
        <div className="p-4 border-b border-slate-100 bg-slate-50/70 flex items-center justify-between">
          <h3 className="font-bold text-slate-800 text-xs md:text-sm">Informes Generados ({records.length})</h3>
          <button
            onClick={handleNewRecord}
            className="p-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold transition-colors flex items-center gap-1 shadow-sm"
          >
            <Plus className="w-3.5 h-3.5" /> Nuevo
          </button>
        </div>
        <div className="flex-1 overflow-y-auto divide-y divide-slate-100 text-xs">
          {records.length > 0 ? (
            records.map((rec) => (
              <div
                key={rec.id}
                className={`p-4 hover:bg-slate-50 transition-colors flex justify-between items-start group ${
                  activeRecord?.id === rec.id ? "bg-indigo-50/40 border-l-4 border-indigo-600" : ""
                }`}
              >
                <button onClick={() => loadRecord(rec)} className="flex-1 text-left min-w-0 pr-2">
                  <p className="font-bold text-slate-800 truncate">{rec.nombre}</p>
                  <p className="text-[10px] text-indigo-600 font-semibold mt-1">{rec.destino}</p>
                  <p className="text-[10px] text-slate-400 mt-0.5">{rec.fecha}</p>
                </button>
                <button
                  onClick={() => handleDeleteRecord(rec.id)}
                  className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded opacity-0 group-hover:opacity-100 transition-all shrink-0"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))
          ) : (
            <div className="p-8 text-center text-slate-400">No hay informes guardados.</div>
          )}
        </div>
      </div>

      {/* Main Workspace form panel */}
      <div className="lg:col-span-8 space-y-6">
        <PersonalDocsAutoExportBar
          reportType={`Informe de ${destino}`}
          patientName={nombre || "Paciente"}
          patientRut={rut || "Sin RUT"}
          generatedContent={documentoGenerado}
          lastExportedRecord={lastExportedPersonalDoc}
          onExportSuccess={(rec) => setLastExportedPersonalDoc(rec)}
        />
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 space-y-5">
          <div className="flex justify-between items-center border-b border-slate-100 pb-4">
            <h2 className="text-base font-bold text-slate-800">
              {activeRecord ? "Editar Solicitud / Informe" : "Generar Contra-Derivación u Hoja de Alta"}
            </h2>
            <div className="flex items-center gap-2">
              <button
                onClick={handleExportPDF}
                className="px-3 py-1.5 border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1"
              >
                <Printer className="w-3.5 h-3.5" /> Exportar PDF
              </button>
              <button
                onClick={handleSaveRecord}
                className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold transition-colors"
              >
                Guardar Local
              </button>
            </div>
          </div>

          {/* Form metadata */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs">
            <div className="space-y-1">
              <span className="text-[10px] text-slate-400 font-bold uppercase">Nombre Completo:</span>
              <input
                type="text"
                placeholder="Ej: Marcos Orellana Castro"
                value={nombre}
                onChange={(e) => setNombre(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none"
              />
            </div>
            <div className="space-y-1">
              <span className="text-[10px] text-slate-400 font-bold uppercase">RUT:</span>
              <input
                type="text"
                placeholder="10.234.567-k"
                value={rut}
                onChange={(e) => setRut(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none"
              />
            </div>
            <div className="space-y-1">
              <span className="text-[10px] text-slate-400 font-bold uppercase">Edad (Años):</span>
              <input
                type="number"
                placeholder="Ej: 33"
                value={edad}
                onChange={(e) => setEdad(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none"
              />
            </div>
            <div className="space-y-1">
              <span className="text-[10px] text-slate-400 font-bold uppercase">Sexo Biológico:</span>
              <select
                value={sexo}
                onChange={(e) => setSexo(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg bg-white focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div className="space-y-1">
              <span className="text-[10px] text-slate-400 font-bold uppercase">Tipo de Documento:</span>
              <select
                value={destino}
                onChange={(e) => setDestino(e.target.value as any)}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg bg-white focus:outline-none font-semibold text-indigo-700"
              >
                <option value="Alta a APS">Contra-referencia / Alta a APS (CESFAM)</option>
                <option value="Hospitalización">Solicitud de Hospitalización (Urgencias / UHC)</option>
                <option value="Especialidad">Interconsulta / Derivación de Especialidad</option>
              </select>
            </div>
            <div className="space-y-1">
              <span className="text-[10px] text-slate-400 font-bold uppercase">Establecimiento / Especialidad Destino:</span>
              <input
                type="text"
                placeholder="Ej: CESFAM Rinconada o Psiquiatría Hospital El Pino"
                value={especialidad}
                onChange={(e) => setEspecialidad(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none"
              />
            </div>
            <div className="space-y-1">
              <span className="text-[10px] text-slate-400 font-bold uppercase">Diagnóstico Clínico (CIE-10):</span>
              <input
                type="text"
                placeholder="Ej: F10.2 Dependencia, F31.3 Bipolar..."
                value={diagnostico}
                onChange={(e) => setDiagnostico(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none"
              />
            </div>
          </div>

          {/* Grid fields */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div className="space-y-1">
              <span className="font-bold text-slate-700">Resumen de Atenciones Clínicas y Evolución:</span>
              <textarea
                placeholder="Resumen del proceso en el box, nivel de adherencia, evolución psicopatológica..."
                value={resumenMedico}
                onChange={(e) => setResumenMedico(e.target.value)}
                rows={3}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none text-slate-800"
              />
            </div>
            <div className="space-y-1">
              <span className="font-bold text-slate-700">Logros del Equipo Multidisciplinario:</span>
              <textarea
                placeholder="Estabilización afectiva, abstinencia mantenida por 6 meses, reinserción familiar..."
                value={logrosEquipo}
                onChange={(e) => setLogrosEquipo(e.target.value)}
                rows={3}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none text-slate-800"
              />
            </div>
            <div className="space-y-1">
              <span className="font-bold text-slate-700">Indicaciones Médicas de Alta:</span>
              <textarea
                placeholder="Pauta de psicofármacos vigentes, recomendaciones para situaciones de crisis..."
                value={indicacionesAlta}
                onChange={(e) => setIndicacionesAlta(e.target.value)}
                rows={3}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none text-slate-800"
              />
            </div>
            <div className="space-y-1">
              <span className="font-bold text-slate-700">Sugerencias para APS (CESFAM de referencia):</span>
              <textarea
                placeholder="Controles periódicos de litemia, psicoterapia de mantenimiento en APS, control médico..."
                value={sugerenciasAps}
                onChange={(e) => setSugerenciasAps(e.target.value)}
                rows={3}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none text-slate-800"
              />
            </div>
          </div>

          <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
            <div className="flex items-center gap-1 text-[11px] text-slate-400 italic">
              <BookOpen className="w-4.5 h-4.5 text-indigo-500" />
              Sincroniza y presiona "Estructurar por IA" para formalizar el documento oficial
            </div>
            <button
              onClick={handleAIStructure}
              disabled={loadingAI || (!resumenMedico && !logrosEquipo && !indicacionesAlta)}
              className="px-4.5 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-400 text-white rounded-lg font-semibold flex items-center gap-1.5 shadow-sm"
            >
              {loadingAI ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
              Estructurar por IA
            </button>
          </div>
        </div>

        {/* Generated document preview */}
        {(documentoGenerado || loadingAI || errorAI) && (
          <div className="bg-slate-50 rounded-xl border border-slate-200 p-6 space-y-4" id="printable-deriv-area">
            <div className="flex justify-between items-center pb-3 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-indigo-600" />
                <h3 className="font-bold text-slate-800 text-xs md:text-sm">Informe Oficial de {destino}</h3>
              </div>
              <span className="text-[9px] bg-indigo-100 text-indigo-700 font-extrabold px-2.5 py-0.5 rounded-full uppercase">
                COSAM Rinconada
              </span>
            </div>

            {loadingAI && (
              <div className="py-8 flex flex-col items-center gap-2">
                <RefreshCw className="w-8 h-8 text-indigo-600 animate-spin" />
                <p className="text-xs text-slate-500 font-medium animate-pulse">Redactando hoja técnica e interconsultas de especialidad...</p>
              </div>
            )}

            {errorAI && (
              <div className="p-4 bg-rose-50 border border-rose-100 text-rose-700 text-xs rounded-lg">
                {errorAI}
              </div>
            )}

            {documentoGenerado && !loadingAI && (
              <div className="text-slate-800 text-xs leading-relaxed space-y-4 font-mono select-all whitespace-pre-wrap bg-white p-5 rounded-lg border border-slate-200">
                {documentoGenerado}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
