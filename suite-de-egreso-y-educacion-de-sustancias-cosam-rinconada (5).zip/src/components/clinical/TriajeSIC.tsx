import React, { useState, useEffect } from "react";
import {
  Ambulance,
  Lock,
  Unlock,
  CheckCircle2,
  XCircle,
  Clock,
  FileSpreadsheet,
  Mail,
  HardDrive,
  Copy,
  Sparkles,
  Wand2,
  RotateCcw,
  Check,
  Shield,
  Search,
} from "lucide-react";
import { TriageRecord } from "../../types";
import { generateClinicalAI } from "../../services/geminiService";
import { GoogleDriveService } from "../../services/googleDriveService";

interface TriajeSICProps {
  onShowToast?: (msg: string, type?: "success" | "error" | "info") => void;
  onOpenDriveModal?: () => void;
  isDriveConnected?: boolean;
}

export function TriajeSIC({
  onShowToast = () => {},
  onOpenDriveModal = () => {},
  isDriveConnected = false,
}: TriajeSICProps) {
  // Security PIN
  const [isUnlocked, setIsUnlocked] = useState<boolean>(true);
  const [pinInput, setPinInput] = useState<string>("");
  const [pinError, setPinError] = useState<boolean>(false);

  // Form Fields
  const [nombre, setNombre] = useState<string>("");
  const [rut, setRut] = useState<string>("");
  const [edad, setEdad] = useState<number>(35);
  const [sexo, setSexo] = useState<string>("Masculino");
  const [prevision, setPrevision] = useState<string>("FONASA D");
  const [validacion, setValidacion] = useState<"Validado" | "No Validado">("Validado");
  const [origen, setOrigen] = useState<string>("CESFAM La Bandera");
  const [fechaDerivacion, setFechaDerivacion] = useState<string>(
    new Date().toISOString().split("T")[0]
  );
  const [fechaValoracion, setFechaValoracion] = useState<string>(
    new Date().toISOString().split("T")[0]
  );
  const [cie10, setCie10] = useState<string>(
    "F10 - Trastornos mentales y del comportamiento debidos al uso de alcohol"
  );
  const [estado, setEstado] = useState<"Aceptado" | "Rechazado" | "No Pertinente">("Aceptado");
  const [observaciones, setObservaciones] = useState<string>("");

  // Outputs
  const [filaExcel, setFilaExcel] = useState<string>("");
  const [cartaCesfam, setCartaCesfam] = useState<string>("");
  const [isGeneratingCarta, setIsGeneratingCarta] = useState<boolean>(false);
  const [isSuggestingObs, setIsSuggestingObs] = useState<boolean>(false);

  // Records Table
  const [records, setRecords] = useState<TriageRecord[]>([]);

  useEffect(() => {
    const saved = localStorage.getItem("cosam_triaje_records");
    if (saved) {
      try {
        setRecords(JSON.parse(saved));
      } catch (e) {
        console.error("Error loading triaje records:", e);
      }
    }
  }, []);

  const saveRecordsToStorage = (newRecords: TriageRecord[]) => {
    setRecords(newRecords);
    localStorage.setItem("cosam_triaje_records", JSON.stringify(newRecords));
  };

  const handleUnlock = () => {
    if (pinInput === "8060" || pinInput === "1234" || pinInput === "") {
      setIsUnlocked(true);
      setPinError(false);
      onShowToast("Acceso desbloqueado", "success");
    } else {
      setPinError(true);
      setPinInput("");
    }
  };

  const handleSugerirObsIA = async () => {
    if (!cie10 || !estado) {
      onShowToast("Seleccione Diagnóstico y Resolución primero", "error");
      return;
    }
    setIsSuggestingObs(true);
    const prompt = `Actúa como psiquiatra en Chile evaluando una solicitud de interconsulta (SIC) para el programa de adicciones de COSAM Rinconada. Genera una justificación clínica breve (máximo 2 líneas) para registrar en el triaje.
- Diagnóstico CIE-10: ${cie10}
- Resolución tomada: ${estado}
- Establecimiento derivador: ${origen}
Sé muy directo, técnico y conciso.`;
    try {
      const result = await generateClinicalAI({
        prompt,
        systemInstruction: "Eres un psiquiatra evaluador de triaje en Chile.",
        temperature: 0.2,
      });
      setObservaciones(result.trim());
      onShowToast("Observación sugerida por IA", "success");
    } catch (err: any) {
      onShowToast(err.message || "Error al generar sugerencia", "error");
    } finally {
      setIsSuggestingObs(false);
    }
  };

  const handleGenerarFilaExcel = () => {
    const fecha = new Date().toLocaleDateString("es-CL");
    const row = `${fecha}\t${rut || "Sin RUT"}\t${nombre || "Sin Nombre"}\t${origen}\t${cie10}\t${estado}\t${observaciones}`;
    setFilaExcel(row);
    navigator.clipboard.writeText(row).then(() => {
      onShowToast("Fila copiada en formato Excel Dra. Rodríguez", "success");
    });
  };

  const handleRedactarCartaCesfam = async () => {
    if (!nombre || !origen || !cie10) {
      onShowToast("Complete Nombre, Origen y Diagnóstico", "error");
      return;
    }
    setIsGeneratingCarta(true);
    const prompt = `Como psiquiatra de COSAM Rinconada, redacta un párrafo formal dirigido al colega derivador de ${origen}. El caso fue clasificado en el triaje de COSAM como: "${estado}". Diagnóstico considerado: ${cie10}. Observaciones clínicas: ${observaciones || "Evaluación según criterios de pertinencia de nivel secundario."}
Reglas:
- Explica la justificación clínica de la decisión de manera técnica.
- Al referirte al paciente, usa estrictamente la etiqueta [NOMBRE_PACIENTE].`;
    try {
      const result = await generateClinicalAI({
        prompt,
        systemInstruction: "Eres un médico psiquiatra de COSAM Rinconada emitiendo una respuesta formal a APS.",
        temperature: 0.2,
      });
      const cartaFinal = result
        .replace(/\[NOMBRE_PACIENTE\]/g, nombre)
        .replace(/\*\*(.*?)\*\*/g, "$1")
        .trim();
      setCartaCesfam(cartaFinal);
      onShowToast("Carta a CESFAM redactada", "success");
    } catch (err: any) {
      onShowToast(err.message || "Error al redactar carta", "error");
    } finally {
      setIsGeneratingCarta(false);
    }
  };

  const handleGuardarCaso = () => {
    if (!nombre || !rut) {
      onShowToast("Ingrese al menos Nombre y RUT", "error");
      return;
    }
    const d1 = new Date(fechaDerivacion);
    const d2 = new Date(fechaValoracion);
    const diffTime = Math.abs(d2.getTime() - d1.getTime());
    const diasEspera = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    const newRecord: TriageRecord = {
      id: Date.now().toString(),
      fecha: new Date().toLocaleDateString("es-CL"),
      rut,
      nombre,
      edad,
      sexo,
      prevision,
      validacion,
      origen,
      fechaDerivacion,
      fechaValoracion,
      cie10,
      estado,
      observaciones,
      cartaCesfam,
      diasEspera,
    };
    saveRecordsToStorage([newRecord, ...records]);
    handleGenerarFilaExcel();
    onShowToast("Caso registrado en historial de triaje", "success");
  };

  const totalCasos = records.length;
  const totalAceptados = records.filter((r) => r.estado === "Aceptado").length;
  const totalRechazados = records.filter((r) => r.estado === "Rechazado").length;
  const totalNoPertinentes = records.filter((r) => r.estado === "No Pertinente").length;
  const esperaPromedio =
    totalCasos > 0
      ? Math.round(
          records.reduce((acc, r) => acc + (r.diasEspera || 0), 0) / totalCasos
        )
      : 0;

  if (!isUnlocked) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] max-w-md mx-auto p-6">
        <div className="bg-slate-900/80 border border-purple-500/30 rounded-3xl p-8 text-center w-full shadow-2xl backdrop-blur-xl">
          <div className="w-16 h-16 rounded-full bg-purple-950/60 border border-purple-500/40 text-purple-400 flex items-center justify-center mx-auto mb-4 text-2xl">
            <Lock className="w-8 h-8" />
          </div>
          <h3 className="text-lg font-bold text-white uppercase tracking-wider mb-1">
            Acceso Triaje Clínico
          </h3>
          <p className="text-xs text-slate-400 mb-6">
            Ingrese su PIN de seguridad de box (8060 / 1234)
          </p>
          <input
            type="password"
            maxLength={4}
            value={pinInput}
            onChange={(e) => setPinInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleUnlock()}
            placeholder="••••"
            className="w-full text-center text-3xl font-mono tracking-[0.5em] bg-slate-950 border border-slate-800 focus:border-purple-500 rounded-2xl py-3 text-white outline-none mb-3"
          />
          {pinError && (
            <p className="text-xs text-rose-400 font-bold mb-4">PIN incorrecto. Intente nuevamente.</p>
          )}
          <button
            onClick={handleUnlock}
            className="w-full py-3 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-xl shadow-lg transition-all text-xs uppercase tracking-wider"
          >
            Desbloquear Módulo
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header Bar */}
      <div className="bg-slate-900/60 backdrop-blur-xl border border-amber-500/20 rounded-3xl p-6 shadow-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
            <Ambulance className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold text-amber-400 uppercase tracking-widest bg-amber-950/60 px-2 py-0.5 rounded border border-amber-800/40">
                Gestión de Demanda
              </span>
            </div>
            <h2 className="text-xl font-bold text-white tracking-tight">
              Recepción y Triaje de Interconsultas (SIC)
            </h2>
          </div>
        </div>
        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setIsUnlocked(false)}
            className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5"
            title="Bloquear pantalla"
          >
            <Lock className="w-3.5 h-3.5" />
            <span>Bloquear</span>
          </button>
        </div>
      </div>

      {/* KPI Stats Banner */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-3.5 text-center">
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Total Casos</p>
          <p className="text-2xl font-black text-white mt-0.5">{totalCasos}</p>
        </div>
        <div className="bg-slate-900/70 border border-emerald-500/30 rounded-2xl p-3.5 text-center">
          <p className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider">Aceptados</p>
          <p className="text-2xl font-black text-emerald-300 mt-0.5">{totalAceptados}</p>
        </div>
        <div className="bg-slate-900/70 border border-rose-500/30 rounded-2xl p-3.5 text-center">
          <p className="text-[10px] font-bold text-rose-400 uppercase tracking-wider">Rechazados</p>
          <p className="text-2xl font-black text-rose-300 mt-0.5">{totalRechazados}</p>
        </div>
        <div className="bg-slate-900/70 border border-amber-500/30 rounded-2xl p-3.5 text-center">
          <p className="text-[10px] font-bold text-amber-400 uppercase tracking-wider">No Pertinentes</p>
          <p className="text-2xl font-black text-amber-300 mt-0.5">{totalNoPertinentes}</p>
        </div>
        <div className="bg-slate-900/70 border border-cyan-500/30 rounded-2xl p-3.5 text-center col-span-2 sm:col-span-1">
          <p className="text-[10px] font-bold text-cyan-400 uppercase tracking-wider">Espera Media</p>
          <p className="text-2xl font-black text-cyan-300 mt-0.5">
            {esperaPromedio} <span className="text-xs font-medium text-slate-400">días</span>
          </p>
        </div>
      </div>

      {/* Main Grid: Form vs Export Outputs */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Form Column */}
        <div className="lg:col-span-7 bg-slate-900/70 backdrop-blur-2xl border border-purple-500/20 rounded-3xl p-6 shadow-xl space-y-4 relative overflow-hidden">
          <div className="absolute top-0 left-0 w-1.5 h-full bg-amber-500" />
          <h3 className="text-xs font-bold text-amber-300 uppercase tracking-wider flex items-center gap-1.5">
            <Ambulance className="w-3.5 h-3.5" />
            <span>Datos Demográficos y de Derivación</span>
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2">
              <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">
                Nombre Completo
              </label>
              <input
                type="text"
                value={nombre}
                onChange={(e) => setNombre(e.target.value)}
                placeholder="Ej: Juan Pérez Soto"
                className="w-full bg-slate-950/70 border border-slate-800 rounded-xl p-2 text-xs text-slate-200 outline-none"
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">RUT</label>
              <input
                type="text"
                value={rut}
                onChange={(e) => setRut(e.target.value)}
                placeholder="Ej: 12.345.678-9"
                className="w-full bg-slate-950/70 border border-slate-800 rounded-xl p-2 text-xs text-slate-200 outline-none"
              />
            </div>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div>
              <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">Edad</label>
              <input
                type="number"
                value={edad}
                onChange={(e) => setEdad(Number(e.target.value))}
                className="w-full bg-slate-950/70 border border-slate-800 rounded-xl p-2 text-xs text-slate-200 outline-none"
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">Sexo</label>
              <select
                value={sexo}
                onChange={(e) => setSexo(e.target.value)}
                className="w-full bg-slate-950/70 border border-slate-800 rounded-xl p-2 text-xs text-slate-200 outline-none"
              >
                <option value="Masculino">Masculino</option>
                <option value="Femenino">Femenino</option>
              </select>
            </div>
            <div>
              <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">Previsión</label>
              <select
                value={prevision}
                onChange={(e) => setPrevision(e.target.value)}
                className="w-full bg-slate-950/70 border border-slate-800 rounded-xl p-2 text-xs text-slate-200 outline-none"
              >
                <option value="FONASA A">FONASA A</option>
                <option value="FONASA B">FONASA B</option>
                <option value="FONASA C">FONASA C</option>
                <option value="FONASA D">FONASA D</option>
                <option value="PRAIS">PRAIS</option>
                <option value="ISAPRE">ISAPRE</option>
              </select>
            </div>
            <div>
              <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">Validación</label>
              <select
                value={validacion}
                onChange={(e) => setValidacion(e.target.value as any)}
                className="w-full bg-slate-950/70 border border-slate-800 rounded-xl p-2 text-xs text-slate-200 outline-none"
              >
                <option value="Validado">Validado</option>
                <option value="No Validado">No Validado</option>
              </select>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">
                Origen Derivación
              </label>
              <select
                value={origen}
                onChange={(e) => setOrigen(e.target.value)}
                className="w-full bg-slate-950/70 border border-slate-800 rounded-xl p-2 text-xs text-slate-200 outline-none"
              >
                <option value="CESFAM La Bandera">CESFAM La Bandera</option>
                <option value="CESFAM Salvador Allende">CESFAM Salvador Allende</option>
                <option value="CESFAM Gabriela Mistral">CESFAM Gabriela Mistral</option>
                <option value="CECOSF Odesa">CECOSF Odesa</option>
                <option value="Hospital Padre Hurtado">Hospital Padre Hurtado</option>
                <option value="Tribunales">Tribunales</option>
                <option value="Otros">Otros</option>
              </select>
            </div>
            <div>
              <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">
                Fecha Derivación
              </label>
              <input
                type="date"
                value={fechaDerivacion}
                onChange={(e) => setFechaDerivacion(e.target.value)}
                className="w-full bg-slate-950/70 border border-slate-800 rounded-xl p-2 text-xs text-slate-200 outline-none"
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">
                Fecha Valoración COSAM
              </label>
              <input
                type="date"
                value={fechaValoracion}
                onChange={(e) => setFechaValoracion(e.target.value)}
                className="w-full bg-slate-950/70 border border-slate-800 rounded-xl p-2 text-xs text-slate-200 outline-none"
              />
            </div>
          </div>
          <div>
            <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">
              Diagnóstico CIE-10 Principal
            </label>
            <select
              value={cie10}
              onChange={(e) => setCie10(e.target.value)}
              className="w-full bg-slate-950/70 border border-slate-800 rounded-xl p-2.5 text-xs text-amber-200 font-bold outline-none"
            >
              <option value="F10 - Trastornos mentales y del comportamiento debidos al uso de alcohol">
                F10 - Consumo de Alcohol
              </option>
              <option value="F11 - Trastornos debidos al uso de opioides">F11 - Opioides</option>
              <option value="F12 - Trastornos debidos al uso de cannabinoides">
                F12 - Cannabinoides (Marihuana)
              </option>
              <option value="F13 - Trastornos debidos al uso de sedantes o hipnóticos">
                F13 - Sedantes / Benzodiacepinas
              </option>
              <option value="F14 - Trastornos debidos al uso de cocaína">
                F14 - Cocaína / Pasta Base
              </option>
              <option value="F15 - Trastornos debidos al uso de otros estimulantes">
                F15 - Otros Estimulantes
              </option>
              <option value="F19 - Trastornos debidos al uso de múltiples drogas">
                F19 - Policonsumo
              </option>
            </select>
          </div>
          {/* Resolution buttons */}
          <div>
            <label className="block text-[10px] font-bold uppercase text-slate-400 mb-2">
              Resolución de Triaje
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(["Aceptado", "Rechazado", "No Pertinente"] as const).map((opt) => (
                <button
                  key={opt}
                  type="button"
                  onClick={() => setEstado(opt)}
                  className={`py-2 rounded-xl text-xs font-bold transition-all border ${
                    estado === opt
                      ? opt === "Aceptado"
                        ? "bg-emerald-600 text-white border-emerald-400 shadow-md shadow-emerald-950/40"
                        : opt === "Rechazado"
                        ? "bg-rose-600 text-white border-rose-400 shadow-md shadow-rose-950/40"
                        : "bg-amber-600 text-white border-amber-400 shadow-md shadow-amber-950/40"
                      : "bg-slate-950/60 text-slate-400 border-slate-800 hover:text-white"
                  }`}
                >
                  {opt}
                </button>
              ))}
            </div>
          </div>
          {/* Observations */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-[10px] font-bold uppercase text-slate-400">
                Observaciones Clínicas
              </label>
              <button
                type="button"
                onClick={handleSugerirObsIA}
                disabled={isSuggestingObs}
                className="text-[10px] font-bold text-amber-300 hover:text-amber-200 flex items-center gap-1 cursor-pointer"
              >
                <Sparkles className="w-3 h-3" />
                <span>{isSuggestingObs ? "Generando..." : "Sugerir con IA"}</span>
              </button>
            </div>
            <textarea
              value={observaciones}
              onChange={(e) => setObservaciones(e.target.value)}
              rows={2}
              placeholder="Justificación del triaje o condiciones de ingreso..."
              className="w-full bg-slate-950/70 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-200 outline-none resize-none"
            />
          </div>
          <div className="flex gap-3 pt-2">
            <button
              onClick={handleGuardarCaso}
              className="flex-1 py-3 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-xl text-xs uppercase tracking-wider transition-all shadow-lg shadow-amber-950/40 cursor-pointer"
            >
              Guardar en Registro de Triaje
            </button>
          </div>
        </div>
        {/* Output Column: Excel row + Carta CESFAM */}
        <div className="lg:col-span-5 space-y-4">
          {/* Excel Copy box */}
          <div className="bg-slate-900/70 backdrop-blur-2xl border border-emerald-500/20 rounded-3xl p-5 shadow-xl space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                <FileSpreadsheet className="w-4 h-4" />
                <span>Fila Excel Dra. Rodríguez (Tabulada)</span>
              </h4>
              <button
                onClick={handleGenerarFilaExcel}
                className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-[10px] font-bold transition-colors flex items-center gap-1 cursor-pointer"
              >
                <Copy className="w-3 h-3" />
                <span>Copiar Fila</span>
              </button>
            </div>
            <textarea
              readOnly
              value={filaExcel || `${new Date().toLocaleDateString("es-CL")}\t${rut || "RUT"}\t${nombre || "Nombre"}\t${origen}\t${cie10}\t${estado}\t${observaciones}`}
              rows={2}
              className="w-full bg-slate-950/90 border border-slate-800 rounded-xl p-2.5 text-[11px] font-mono text-emerald-300 outline-none resize-none"
            />
          </div>
          {/* Carta CESFAM box */}
          <div className="bg-slate-900/70 backdrop-blur-2xl border border-purple-500/20 rounded-3xl p-5 shadow-xl space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-purple-300 uppercase tracking-wider flex items-center gap-1.5">
                <Mail className="w-4 h-4 text-purple-400" />
                <span>Respuesta Formal a CESFAM (IA)</span>
              </h4>
              <button
                onClick={handleRedactarCartaCesfam}
                disabled={isGeneratingCarta}
                className="px-2.5 py-1 bg-purple-600 hover:bg-purple-500 text-white rounded-lg text-[10px] font-bold transition-colors flex items-center gap-1 disabled:opacity-50 cursor-pointer"
              >
                <Wand2 className="w-3 h-3" />
                <span>{isGeneratingCarta ? "Redactando..." : "Redactar"}</span>
              </button>
            </div>
            <textarea
              readOnly
              value={cartaCesfam}
              rows={7}
              placeholder="Presione 'Redactar' para generar el oficio o carta de contrarreferencia hacia el consultorio de origen..."
              className="w-full bg-slate-950/90 border border-slate-800 rounded-xl p-3 text-xs font-medium text-slate-200 leading-relaxed outline-none resize-none"
            />
          </div>
        </div>
      </div>
    </div>
  );
}
