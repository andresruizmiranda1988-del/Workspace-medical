import React, { useState } from 'react';
import { 
  BookOpen, FileText, CheckCircle2, AlertTriangle, ShieldAlert, 
  Stethoscope, Brain, Users, ArrowRight, Search, Sparkles, 
  Loader2, Scale, Network, ClipboardCheck, Activity, HelpCircle,
  Download, Building2, UserCheck, Flame, ShieldCheck, Layers
} from 'lucide-react';
import { GoogleGenAI } from '@google/genai';

interface ProtocolSection {
  id: string;
  code: string;
  title: string;
  subtitle: string;
  category: 'Contexto y Roles' | 'Farmacología y Seguimiento' | 'Urgencias y Derivación' | 'Gestión Red y Anexos';
  icon: React.ElementType;
  summary: string;
  mgRole: string[];
  psiqRole: string[];
  redFlags: string[];
  normativa: string[];
  extraTable?: {
    headers: string[];
    rows: string[][];
  };
}

const PROTOCOLOS_DATA: ProtocolSection[] = [
  {
    id: 'contextualizacion-equipo',
    code: 'SECC. 1 - 2',
    title: 'Contextualización Territorial y Equipo Médico COSAM',
    subtitle: 'Determinantes Sociales en San Ramón (SSMSO) y Gobernanza Asistencial',
    category: 'Contexto y Roles',
    icon: Building2,
    summary: 'El COSAM Rinconada opera en la comuna de San Ramón bajo la jurisdicción del Servicio de Salud Metropolitano Sur Oriente (SSMSO), atendiendo una alta prevalencia de Patología Dual (TUS severo por pasta base de cocaína, clorhidrato, alcohol y policonsumo acoplado a comorbilidades del Eje I y Eje II). La arquitectura clínica exige delimitar con precisión las competencias del Médico General con formación en Salud Mental (MG-SM) y del Médico Psiquiatra Especialista.',
    mgRole: [
      'Puerta de entrada médica al programa (Evaluación Médica Inicial del PAI) y filtro diagnóstico somático-psiquiátrico.',
      'Pesquisa y tratamiento de patologías médicas generales concurrentes (hepatopatías, síndrome metabólico, infecciones, carencias nutricionales).',
      'Inicio y titulación de psicofarmacoterapia de primera línea en síndromes afectivos y ansiosos de complejidad leve a moderada.',
      'Ejecución y monitoreo clínico de desintoxicaciones ambulatorias para síndromes de abstinencia leves a moderados (CIWA-Ar < 15).'
    ],
    psiqRole: [
      'Liderazgo clínico-técnico en casos de alta complejidad psicopatológica, refractariedad terapéutica y psicosis.',
      'Diagnóstico diferencial definitivo en Patología Dual severa (diferenciación entre trastornos inducidos por sustancias y trastornos psiquiátricos primarios).',
      'Prescripción y ajuste de esquemas psicofarmacológicos complejos (estabilizadores del ánimo con rango estrecho, antipsicóticos atípicos o de depósito, polifarmacia racional).',
      'Consultoría Psiquiátrica interna para el equipo transdisciplinario y enlace directo con Servicios de Hospitalización de Corta Estadía (HCE) del Hospital Padre Hurtado.'
    ],
    redFlags: [
      'Brecha socioeconómica, hacinamiento, violencia territorial y microtráfico activo que comprometen la adherencia al PAI.',
      'Falta de red de apoyo primaria o situación de calle que impide manejo ambulatorio seguro en abstinencias moderadas.',
      'Polifarmacia no supervisada o automedicación con benzodiacepinas de vida media corta en el territorio.'
    ],
    normativa: [
      'Orientaciones Técnicas MINSAL para Centros de Salud Mental Comunitaria (COSAM) - Red SSMSO.',
      'Convenio Programático SENDA - MINSAL (Programas Ambulatorios Básicos e Intensivos PAI).',
      'Ley N° 20.584 (Derechos y Deberes de los Pacientes) y Ley N° 21.331 (Protección de la Salud Mental).'
    ]
  },
  {
    id: 'roles-mg-psiquiatra',
    code: 'SECC. 3 - 4',
    title: 'Delimitación de Competencias: Médico General vs. Psiquiatra',
    subtitle: 'Protocolo de Evaluación Médica Inicial (MG-SM) y Especializada (Psiquiatría)',
    category: 'Contexto y Roles',
    icon: Stethoscope,
    summary: 'Establece el estándar operativo para los primeros 15 días de ingreso al PAI (Evaluación por MG-SM) y los criterios estrictos de escalamiento hacia Evaluación Psiquiátrica Especializada, evitando duplicidad de prestaciones y optimizando la hora-especialista.',
    mgRole: [
      'Anamnesis toxicológica detallada: patrón de consumo, vía de administración, dosis diaria, edad de inicio y períodos de abstinencia.',
      'Examen físico segmentario obligatorio: estigmas de daño hepático crónico, signos de venopunción, evaluación cardiovascular y examen neurológico basal.',
      'Solicitud de Batería de Laboratorio Basal al Ingreso: Hemograma-VHS, Perfil Bioquímico, Perfil Hepático (GOT, GPT, GGT, FA, Bilirrubina), Perfil Lipídico, Creatininemia, TSH/T4L, Orina completa y Serologías (VIH, VDRL/RPR, VHB, VHC) + ECG (si QTc de riesgo).',
      'Diagnóstico sindromático inicial CIE-10 (F10-F19) y formulación preliminar del Plan de Tratamiento Individual (PTI).'
    ],
    psiqRole: [
      'Entrevista psiquiátrica semiestructurada tras ventana de estabilización o desintoxicación inicial.',
      'Evaluación de Trastornos de la Personalidad severos (Eje II: TLP con desregulación conductual grave, Antisocial) que sabotean el encuadre terapéutico.',
      'Abordaje de Trastornos Afectivos Bipolares (TAB I y II), Esquizofrenia, Trastorno Esquizoafectivo y Depresión Mayor Resistente.',
      'Indicación de hospitalización psiquiátrica administrativa o judicial cuando se cumplen criterios de riesgo vital.'
    ],
    redFlags: [
      'Antecedente personal de Delirium Tremens o convulsiones por privación de alcohol o benzodiacepinas.',
      'Sintomatología psicótica persistente tras > 2 a 4 semanas de abstinencia verificada.',
      'Francas ideas suicidas estructuradas con plan o antecedentes de intentos de alta letalidad.',
      'Embarazo cursando con Trastorno por Uso de Sustancias activo (prioridad absoluta de evaluación conjunta).'
    ],
    normativa: [
      'Guía Clínica GES Consumo Perjudicial y Dependencia de Alcohol y Drogas en menores de 20 años y adultos.',
      'Protocolo de Exámenes de Laboratorio Básicos SSMSO - Red Sur Oriente.'
    ],
    extraTable: {
      headers: ['Dimensión Clínica', 'Médico General en Salud Mental (MG-SM)', 'Médico Psiquiatra Especialista'],
      rows: [
        ['Foco Primario', 'Puerta de entrada médica, salud somática, abstinencia leve-moderada y patología dual estable.', 'Alta complejidad psicopatológica, psicosis, refractariedad, bipolaridad y riesgo suicida alto.'],
        ['Evaluación de Ingreso', 'Universal (100% de ingresos PAI en primeros 15 días).', 'Selectiva por derivación interna según criterios de severidad o duda diagnóstica.'],
        ['Batería Diagnóstica', 'Laboratorio basal completo, serologías, ECG, escalas CIWA-Ar / PhQ-9 / GAD-7.', 'Entrevista psicopatológica profunda, escalas PANSS / YMRS / Columbia (C-SSRS).'],
        ['Frecuencia de Control', 'Semanal en desintoxicación; cada 3 a 4 semanas en fase de mantenimiento.', 'Quincenal en estabilización aguda; mensual o bimensual en seguimiento dual complejo.']
      ]
    }
  },
  {
    id: 'prescripcion-seguimiento',
    code: 'SECC. 5',
    title: 'Prescripción Farmacológica y Seguimiento Clínico',
    subtitle: 'Arsenal Farmacológico Diferenciado, Antídotos de Craving y Monitoreo Metabólico',
    category: 'Farmacología y Seguimiento',
    icon: Brain,
    summary: 'Regula el uso racional de psicofármacos en usuarios con TUS, previniendo la iatrogenia (especialmente el abuso cruzado de benzodiacepinas) y sistematizando la farmacoterapia anti-craving, aversiva y de comorbilidad psiquiátrica.',
    mgRole: [
      'Prescripción de ISRS de primera línea (Sertralina 50-200 mg/día, Escitalopram 10-20 mg/día, Fluoxetina 20-60 mg/día) e IRSN (Venlafaxina, Duloxetina).',
      'Fármacos para Trastorno por Uso de Alcohol: Naltrexona (50 mg/día tras verificar ausencia de opioides y transaminasas < 3x LSN), Acamprosato (1998 mg/día si función renal conservada) y Disulfiram (250-500 mg/día solo con consentimiento informado firmado y red supervisora).',
      'Esquemas de desintoxicación con Diazepam o Lorazepam (en hepatopatía) por tiempo estrictamente acotado (7 a 10 días) con pauta de descenso escalonado.',
      'Suplementación obligatoria con Tiamina (Vitamina B1) 100-300 mg/día VO o IM para profilaxis de Encefalopatía de Wernicke.'
    ],
    psiqRole: [
      'Prescripción de Antipsicóticos de Segunda Generación (Quetiapina en dosis antipsicóticas, Olanzapina, Risperidona, Aripiprazol) y Antipsicóticos de Depósito de Larga Duración (Paliperidona, Haloperidol decanoato, Flufenazina) en baja adherencia.',
      'Uso de Clozapina en psicosis refractaria o patología dual grave con protocolo estricto de farmacovigilancia hematológica semanal.',
      'Estabilizadores del ánimo: Carbonato de Litio (con litemias seriadas, función renal y tiroidea), Ácido Valproico / Divalproato, Lamotrigina y Topiramato (off-label anti-craving en cocaína/alcohol).',
      'Manejo de TDAH comórbido en adultos con TUS (preferencia por Atomoxetina o Bupropión; uso restringido de psicoestimulantes bajo custodia).'
    ],
    redFlags: [
      'Contraindicación absoluta de Disulfiram en cardiopatía isquémica, psicosis activa o ausencia de familiar supervisor.',
      'Suspensión inmediata de Naltrexona o Ácido Valproico si transaminasas (GOT/GPT) superan 3 veces el límite superior normal.',
      'Prohibición de prescribir Benzodiacepinas crónicas (especialmente Alprazolam o Clonazepam sin plan de deshabituación) por alto potencial adictivo.',
      'Prolongación del intervalo QTc > 500 ms en ECG por combinación de antipsicóticos, antidepresivos e hidroelectrolitos alterados.'
    ],
    normativa: [
      'Formulario Nacional de Medicamentos y Arsenal Farmacológico SSMSO.',
      'Norma Técnica de Receta Retenida y Receta Cheque (Decreto Supremo N° 404 y N° 405 MINSAL).'
    ]
  },
  {
    id: 'urgencias-crisis',
    code: 'SECC. 6',
    title: 'Protocolo de Manejo de Urgencias y Crisis en COSAM',
    subtitle: 'Intoxicación Aguda, Abstinencia Grave, Riesgo Suicida y Psicosis Activa',
    category: 'Urgencias y Derivación',
    icon: Flame,
    summary: 'Actuación médica inmediata ante descompensaciones agudas dentro del dispositivo comunitario. Prioriza la contención verbal, la seguridad del paciente y del equipo, la estabilización farmacológica de emergencia y el traslado asistido a Urgencia Hospitalaria (Hospital Padre Hurtado).',
    mgRole: [
      'Evaluación primaria ABCDE, control de signos vitales, glicemia capilar (hemoglucotest) y oximetría de pulso en todo paciente con alteración de conciencia o agitación.',
      'Aplicación inmediata de escala CIWA-Ar en abstinencia alcohólica; administración de carga inicial de Diazepam VO/IM y Tiamina IM antes de traslado si CIWA-Ar ≥ 15.',
      'Contención verbal (Desescalada) en primer lugar; indicación y supervisión médica de contención farmacológica intramuscular si hay riesgo inminente de heteroagresión (ej. Haloperidol 5 mg + Lorazepam 2-4 mg IM o Midazolam según disponibilidad).',
      'Coordinación directa con SAMU (131) y redacción de Hoja de Derivación de Urgencia detallada.'
    ],
    psiqRole: [
      'Evaluación de letalidad e intencionalidad en Riesgo Suicida Severo (Columbia C-SSRS) y activación de código de hospitalización psiquiátrica.',
      'Diagnóstico diferencial de emergencia en Agitación Psicomotora (Psicosis tóxica por cocaína/PBC vs. Descompensación maníaca/esquizofrénica vs. Delirium orgánico).',
      'Gestión de cama crítica psiquiátrica con Unidad de Hospitalización de Corta Estadía (UHCE) y dictamen técnico para Internación Administrativa No Voluntaria si procede.'
    ],
    redFlags: [
      'CIWA-Ar > 15 puntos, convulsiones tónico-clónicas o signos de Delirium Tremens (fiebre, taquicardia, alucinaciones visuales/táctiles, confusión).',
      'Intoxicación aguda por Cocaína/PBC con dolor torácico opresivo, crisis hipertensiva o hipertermia (PROHIBIDO usar Betabloqueadores puros como Propranolol por efecto alfa-adrenérgico paradójico).',
      'Agitación psicomotora con porte de armas u objetos cortopunzantes (activar protocolo de seguridad institucional y Carabineros antes de intervenir).',
      'Conducta suicida activa con rechazo absoluto a medidas de protección ambulatoria.'
    ],
    normativa: [
      'Norma General Técnica N° 213 sobre Contención en Psiquiatría y Ley N° 21.331 (Artículos sobre hospitalización involuntaria y medidas de último recurso).',
      'Protocolo de Red de Urgencia Psiquiátrica SSMSO - Hospital Padre Hurtado.'
    ]
  },
  {
    id: 'coordinacion-redes-rem',
    code: 'SECC. 7 - 8',
    title: 'Coordinación de Red (APS San Ramón / SSMSO) y Gestión REM',
    subtitle: 'Referencia/Contrarreferencia, Consultorías y Marco Regulatorio SENDA/SEREMI',
    category: 'Gestión Red y Anexos',
    icon: Network,
    summary: 'Integra el quehacer médico del COSAM Rinconada con los CESFAM de San Ramón (APS), el nivel terciario del SSMSO y los sistemas de información estadística oficial (REM, SISTRAT y GES).',
    mgRole: [
      'Participación activa en Consultorías de Salud Mental hacia los CESFAM del territorio de San Ramón, recibiendo o contrarreferenciando pacientes estabilizados.',
      'Registro clínico electrónico oportuno en Ficha Clínica (RAYEN / Sistema Institucional) cumpliendo estándares de auditoría MINSAL.',
      'Notificación obligatoria de patologías GES asociadas (Depresión en personas de 15 años y más, Consumo perjudicial/dependencia en < 20 años, Bipolaridad, Esquizofrenia).',
      'Cierre estadístico mensual de prestaciones para serie REM (Registro Estadístico Mensual) y actualización de plataforma SISTRAT (SENDA).'
    ],
    psiqRole: [
      'Liderazgo de las Consultorías Psiquiátricas mensuales con médicos de APS de San Ramón para transferencia tecnológica y resolución de casos en red.',
      'Emisión de informes médicos psiquiátricos especializados para COMPIN (licencias médicas prolongadas, pensiones de invalidez), Tribunales de Familia y Fiscalía (Ley 20.000 / Tribunales de Tratamiento de Drogas - TTD).',
      'Supervisión de indicadores de calidad clínica del PAI: tasa de retención a 90 días, reingresos hospitalarios y polifarmacia.'
    ],
    redFlags: [
      'Subregistro de prestaciones médicas en REM o SISTRAT que impacta el financiamiento y cumplimiento de metas sanitarias del COSAM.',
      'Contrarreferencia prematura a APS sin hoja de enlace farmacológico clara o sin disponibilidad del fármaco en el arsenal del CESFAM.',
      'Incumplimiento de plazos legales GES o falta de firma de Consentimiento Informado PAI al ingreso.'
    ],
    normativa: [
      'Manual de Series REM (Registro Estadístico Mensual) DEIS - MINSAL vigente.',
      'Normas Técnicas SISTRAT - SENDA y Estándares de Autorización Sanitaria SEREMI de Salud RM.'
    ]
  },
  {
    id: 'anexos-operativos',
    code: 'SECC. 9 (ANEXOS)',
    title: 'Anexos Operativos: Flujo PAI, Algoritmo y Checklist',
    subtitle: 'Herramientas de Decisión Rápida para derivación MG-SM ↔ Psiquiatría',
    category: 'Gestión Red y Anexos',
    icon: ClipboardCheck,
    summary: 'Instrumentos estandarizados del protocolo institucional para la toma de decisiones clínicas en tiempo real: Flujo de Derivación Territorial, Algoritmo de Derivación Interna y Lista de Chequeo de la Primera Consulta Médica.',
    mgRole: [
      'ANEXO 1 (Flujo Territorial): Recepción desde APS San Ramón / Demanda Espontánea / Tribunales → Triaje Multidisciplinario → Evaluación MG-SM (< 15 días) → Definición de Complejidad.',
      'ANEXO 2 (Algoritmo de Decisión): Si el usuario presenta TUS + Comorbilidad Leve/Moderada sin psicosis ni riesgo vital → Continúa en control por MG-SM + Dupla Psicosocial.',
      'ANEXO 3 (Checklist Consulta Inicial): 1. Signos vitales + IMC | 2. Historia toxicológica completa | 3. Examen físico y neurológico | 4. Solicitud de Laboratorio + Serologías + ECG | 5. Tamizaje CIWA-Ar / Riesgo Suicida | 6. Suplementación con Tiamina | 7. Registro CIE-10 y firma de Consentimiento.'
    ],
    psiqRole: [
      'Activación del Brazo de Alta Complejidad del Algoritmo (Anexo 2) ante cualquiera de los 5 gatillantes críticos: (1) Psicosis activa o inducida refractaria, (2) Bipolaridad I/II descompensada, (3) Riesgo suicida moderado-alto persistente, (4) Fracaso a ≥ 2 esquemas farmacológicos bien llevados por MG-SM, o (5) Patología dual grave en gestante.',
      'Co-manejo escalonado: una vez lograda la estabilización psicopatológica por Psiquiatría (3 a 6 meses), el usuario puede retornar a seguimiento compartido con MG-SM.'
    ],
    redFlags: [
      'Derivación a Psiquiatría sin contar con evaluación médica general previa ni batería de exámenes de laboratorio solicitada (salvo urgencia psiquiátrica vital).',
      'Omisión del tamizaje de riesgo suicida en la primera consulta médica de ingreso.'
    ],
    normativa: [
      'Protocolo Clínico Operativo: Rol del Médico General y del Médico Psiquiatra en el Tratamiento de Adicciones y Salud Mental - COSAM Rinconada (San Ramón, SSMSO).'
    ]
  }
];

const CATEGORIES = [
  'Todos',
  'Contexto y Roles',
  'Farmacología y Seguimiento',
  'Urgencias y Derivación',
  'Gestión Red y Anexos'
] as const;

export const ProtocolosIngreso: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('Todos');
  const [selectedProtocol, setSelectedProtocol] = useState<ProtocolSection>(PROTOCOLOS_DATA[0]);
  const [searchQuery, setSearchQuery] = useState('');
  
  // AI Consultant State
  const [clinicalCase, setClinicalCase] = useState('');
  const [aiResponse, setAiResponse] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const filteredProtocols = PROTOCOLOS_DATA.filter(p => {
    const matchesCat = selectedCategory === 'Todos' || p.category === selectedCategory;
    const matchesSearch = 
      p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.subtitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.summary.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const handleAnalyzeCase = async () => {
    if (!clinicalCase.trim()) return;
    setIsAnalyzing(true);
    setAiResponse(null);

    try {
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        throw new Error('API Key de Gemini no configurada.');
      }

      const ai = new GoogleGenAI({ apiKey });
      const prompt = `
        Actúa como el Comité Médico-Psiquiátrico del COSAM Rinconada (Comuna de San Ramón, Servicio de Salud Metropolitano Sur Oriente - SSMSO, Chile).
        Evalúa la siguiente viñeta clínica aplicando estrictamente el "Protocolo Clínico Operativo: Rol del Médico General y del Médico Psiquiatra en el Tratamiento de Adicciones y Salud Mental":

        VIÑETA CLÍNICA:
        "${clinicalCase}"

        Entrega una respuesta estructurada y ejecutiva con los siguientes 4 puntos:
        1. **Asignación de Nivel Médico**: ¿Corresponde manejo por Médico General en Salud Mental (MG-SM), Derivación a Psiquiatra Especialista del COSAM, o Traslado de Urgencia a Hospital Padre Hurtado? Justifica según el Algoritmo del Protocolo.
        2. **Conducta Médica y Exámenes Iniciales**: Qué batería de laboratorio, escalas (ej. CIWA-Ar, Columbia) o profilaxis (ej. Tiamina) se deben indicar hoy.
        3. **Lineamiento Farmacológico Seguro**: Qué fármacos están indicados y cuáles están contraindicados (alertas de seguridad o interacciones con consumo activo).
        4. **Hitos Normativos y Registro**: Requisitos de Ley 20.584 / 21.331, GES, SISTRAT o REM aplicables al caso.
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
      });

      setAiResponse(response.text || 'No se pudo generar el análisis normativo.');
    } catch (error: any) {
      console.error('Error en consultor de protocolos:', error);
      setAiResponse(`Error al consultar el asistente normativo: ${error.message || 'Intente nuevamente.'}`);
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Encabezado Principal Unificado con Glassmorphism */}
      <div className="clinical-card">
        <div className="clinical-glass-header px-6 py-4 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-[#075985]/10 border border-[#075985]/20 flex items-center justify-center text-[#075985] shrink-0">
              <Scale className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono font-bold uppercase tracking-widest px-2 py-0.5 rounded bg-sky-50 text-[#075985] border border-sky-200/80">
                  DOCUMENTO OFICIAL COSAM RINCONADA • SSMSO
                </span>
                <span className="text-[11px] font-mono text-slate-400">San Ramón</span>
              </div>
              <h2 className="text-lg font-bold tracking-tight text-slate-900 mt-0.5">
                Protocolo Clínico Operativo: Médico General y Psiquiatra en Adicciones y Salud Mental
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <a
              href="/assets/aistudio/Protocolo_M_dico_General_y_Psiquiatra_COSAM_50966fc7"
              download="Protocolo_Medico_General_y_Psiquiatra_COSAM_Rinconada.md"
              className="flex items-center gap-2 px-3.5 py-2 rounded-lg bg-slate-100 hover:bg-slate-200/80 text-slate-700 border border-slate-200/90 text-xs font-semibold transition-all"
            >
              <Download className="w-3.5 h-3.5 text-[#075985]" />
              Descargar Protocolo Íntegro (.MD)
            </a>
          </div>
        </div>

        {/* Barra de Filtros y Búsqueda */}
        <div className="px-6 py-3.5 bg-slate-50/70 border-b border-slate-200/70 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
            {CATEGORIES.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all whitespace-nowrap ${
                  selectedCategory === cat
                    ? 'bg-[#075985] text-white shadow-xs'
                    : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200/80'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="relative min-w-[260px]">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Filtrar sección, fármaco o criterio..."
              className="w-full pl-8 pr-3 py-1.5 text-xs bg-white border border-slate-200/90 rounded-lg focus:outline-none focus:border-[#075985] text-slate-800"
            />
          </div>
        </div>
      </div>

      {/* Grilla Principal 12 Columnas: Índice (4 cols) + Visor Detallado (8 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Columna Izquierda: Índice Jerárquico de Secciones */}
        <div className="lg:col-span-4 clinical-card max-h-[760px] overflow-y-auto">
          <div className="clinical-glass-header px-5 py-3.5 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-[#075985]" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                Estructura del Protocolo
              </h3>
            </div>
            <span className="text-[11px] font-mono font-semibold text-slate-500">
              {filteredProtocols.length} bloques
            </span>
          </div>

          <div className="divide-y divide-slate-200/70">
            {filteredProtocols.map((item) => {
              const Icon = item.icon;
              const isSelected = selectedProtocol.id === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setSelectedProtocol(item)}
                  className={`w-full text-left p-4 transition-all flex items-start gap-3.5 ${
                    isSelected
                      ? 'bg-sky-50/70 border-l-4 border-l-[#075985]'
                      : 'hover:bg-slate-50/80'
                  }`}
                >
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 mt-0.5 ${
                    isSelected
                      ? 'bg-[#075985] text-white'
                      : 'bg-slate-100 text-slate-500 border border-slate-200/80'
                  }`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-[#075985]">
                        {item.code}
                      </span>
                      <span className="text-[10px] text-slate-400 font-medium truncate">
                        {item.category}
                      </span>
                    </div>
                    <h4 className={`text-xs font-bold mt-0.5 leading-snug ${
                      isSelected ? 'text-slate-900' : 'text-slate-700'
                    }`}>
                      {item.title}
                    </h4>
                    <p className="text-[11px] text-slate-500 mt-1 line-clamp-2 leading-relaxed">
                      {item.subtitle}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Columna Derecha: Visor Normativo con Encabezado Glassmorphism */}
        <div className="lg:col-span-8 space-y-6">
          <div className="clinical-card max-h-[760px] overflow-y-auto">
            {/* Sticky Glassmorphism Card Header */}
            <div className="clinical-glass-header px-6 py-4 flex items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono font-bold uppercase tracking-widest px-2 py-0.5 rounded bg-sky-100/80 text-[#075985]">
                    {selectedProtocol.code}
                  </span>
                  <span className="text-xs font-medium text-slate-500">
                    • {selectedProtocol.category}
                  </span>
                </div>
                <h3 className="text-base font-bold text-slate-900 mt-1">
                  {selectedProtocol.title}
                </h3>
              </div>
              <ShieldCheck className="w-5 h-5 text-[#075985] shrink-0" />
            </div>

            <div className="p-6 space-y-6">
              {/* Síntesis Ejecutiva */}
              <div className="p-4 rounded-xl bg-slate-50/90 border border-slate-200/80">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                  Síntesis Operativa
                </span>
                <p className="text-xs text-slate-700 leading-relaxed">
                  {selectedProtocol.summary}
                </p>
              </div>

              {/* Matriz Comparativa MG-SM vs Psiquiatra */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Competencias Médico General */}
                <div className="rounded-xl border border-slate-200/90 bg-white overflow-hidden">
                  <div className="px-4 py-3 bg-slate-50 border-b border-slate-200/80 flex items-center gap-2">
                    <Stethoscope className="w-4 h-4 text-[#075985]" />
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                      Rol Médico General (MG-SM)
                    </h4>
                  </div>
                  <ul className="p-4 space-y-2.5">
                    {selectedProtocol.mgRole.map((point, idx) => (
                      <li key={idx} className="flex items-start gap-2.5 text-xs text-slate-700 leading-relaxed">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                        <span>{point}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Competencias Médico Psiquiatra */}
                <div className="rounded-xl border border-slate-200/90 bg-white overflow-hidden">
                  <div className="px-4 py-3 bg-sky-50/60 border-b border-slate-200/80 flex items-center gap-2">
                    <Brain className="w-4 h-4 text-[#075985]" />
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                      Rol Médico Psiquiatra Especialista
                    </h4>
                  </div>
                  <ul className="p-4 space-y-2.5">
                    {selectedProtocol.psiqRole.map((point, idx) => (
                      <li key={idx} className="flex items-start gap-2.5 text-xs text-slate-700 leading-relaxed">
                        <UserCheck className="w-3.5 h-3.5 text-[#075985] shrink-0 mt-0.5" />
                        <span>{point}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Tabla Comparativa Estructurada (si aplica) */}
              {selectedProtocol.extraTable && (
                <div className="rounded-xl border border-slate-200/90 overflow-hidden">
                  <div className="px-4 py-2.5 bg-slate-100/80 border-b border-slate-200/80">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-slate-700">
                      Matriz de Diferenciación Clínica y Asistencial
                    </span>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-bold text-slate-600">
                          {selectedProtocol.extraTable.headers.map((h, i) => (
                            <th key={i} className="py-2.5 px-4">{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200/70 text-xs text-slate-700">
                        {selectedProtocol.extraTable.rows.map((row, rIdx) => (
                          <tr key={rIdx} className="hover:bg-slate-50/60">
                            <td className="py-2.5 px-4 font-semibold text-slate-900">{row[0]}</td>
                            <td className="py-2.5 px-4">{row[1]}</td>
                            <td className="py-2.5 px-4">{row[2]}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* Banderas Rojas / Criterios de Alerta y Marco Normativo */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="rounded-xl border border-rose-200/90 bg-rose-50/40 p-4">
                  <div className="flex items-center gap-2 mb-2.5">
                    <AlertTriangle className="w-4 h-4 text-rose-600" />
                    <h4 className="text-xs font-bold uppercase tracking-wider text-rose-900">
                      Banderas Rojas y Criterios de Escalada
                    </h4>
                  </div>
                  <ul className="space-y-2">
                    {selectedProtocol.redFlags.map((flag, idx) => (
                      <li key={idx} className="text-xs text-rose-900/90 leading-relaxed flex items-start gap-2">
                        <span className="text-rose-500 font-bold">•</span>
                        <span>{flag}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="rounded-xl border border-slate-200/90 bg-slate-50/60 p-4">
                  <div className="flex items-center gap-2 mb-2.5">
                    <BookOpen className="w-4 h-4 text-[#075985]" />
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                      Marco Regulatorio MINSAL / SENDA
                    </h4>
                  </div>
                  <ul className="space-y-2">
                    {selectedProtocol.normativa.map((norm, idx) => (
                      <li key={idx} className="text-xs text-slate-600 leading-relaxed flex items-start gap-2">
                        <span className="text-[#075985] font-bold">§</span>
                        <span>{norm}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>

          {/* Asistente de Decisión de Derivación (MG-SM ↔ Psiquiatra) */}
          <div className="clinical-card">
            <div className="clinical-glass-header px-6 py-3.5 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <Sparkles className="w-4 h-4 text-[#075985]" />
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                  Evaluador de Casos según Algoritmo COSAM Rinconada (MG-SM ↔ Psiquiatría)
                </h3>
              </div>
              <span className="text-[11px] font-mono text-slate-500">Asistencia Normativa</span>
            </div>

            <div className="p-6 space-y-4">
              <p className="text-xs text-slate-600 leading-relaxed">
                Ingrese una viñeta clínica breve (sustancia principal, puntaje CIWA-Ar, comorbilidad psiquiátrica o hallazgos de laboratorio) para determinar si el caso debe mantenerse en control con Médico General (MG-SM), derivarse a Psiquiatría del COSAM o trasladarse a Urgencia del Hospital Padre Hurtado.
              </p>

              <textarea
                value={clinicalCase}
                onChange={(e) => setClinicalCase(e.target.value)}
                rows={3}
                placeholder="Ej: Paciente masculino 34 años, consumo diario de pasta base y alcohol, ingresa con CIWA-Ar de 12 puntos, transaminasas en 2x LSN y ánimo depresivo reactivo sin ideación suicida estructurada..."
                className="w-full p-3.5 text-xs bg-slate-50/80 border border-slate-200/90 rounded-xl focus:outline-none focus:border-[#075985] text-slate-800 leading-relaxed"
              />

              <div className="flex justify-end">
                <button
                  onClick={handleAnalyzeCase}
                  disabled={isAnalyzing || !clinicalCase.trim()}
                  className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[#075985] hover:bg-[#0c4a6e] disabled:opacity-50 text-white text-xs font-semibold transition-all shadow-xs"
                >
                  {isAnalyzing ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      Evaluando con Protocolo COSAM...
                    </>
                  ) : (
                    <>
                      <ClipboardCheck className="w-3.5 h-3.5" />
                      Aplicar Algoritmo de Derivación
                    </>
                  )}
                </button>
              </div>

              {aiResponse && (
                <div className="p-4 rounded-xl bg-sky-50/50 border border-sky-200/80 text-xs text-slate-800 whitespace-pre-wrap leading-relaxed">
                  {aiResponse}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
export default ProtocolosIngreso;
