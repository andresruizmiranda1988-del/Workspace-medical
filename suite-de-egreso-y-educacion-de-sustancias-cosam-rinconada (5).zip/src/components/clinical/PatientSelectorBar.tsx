import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  User,
  ChevronDown,
  ShieldAlert,
  CheckCircle2,
  Copy,
  Check,
  AlertTriangle,
  Heart,
  Pill,
  Sparkles,
  FileText,
  Clock
} from "lucide-react";

export interface PatientProfile {
  id: string;
  name: string;
  rut: string;
  age: number;
  gender: string;
  prevision: "FONASA A" | "FONASA B" | "FONASA C" | "FONASA D" | "PRAIS" | "ISAPRE";
  diagnostic: string;
  substance: string;
  fucDays: number;
  cravingLevel: number;
  alerts: { text: string; severity: "urgent" | "warning" | "info" }[];
  activeMedications: string[];
}

export const PRESET_PATIENTS: PatientProfile[] = [
  {
    id: "p1",
    name: "Carlos Morales V.",
    rut: "14.892.110-3",
    age: 38,
    gender: "Masculino",
    prevision: "FONASA B",
    diagnostic: "F10.2 Trastorno por Dependencia de Alcohol (TUA Moderado-Severo)",
    substance: "Alcohol (Etanol)",
    fucDays: 14,
    cravingLevel: 4,
    alerts: [
      { text: "En desescalada Ashton / Diazepam 10mg", severity: "warning" },
      { text: "Monitoreo Litemia 0.82 mEq/L basal", severity: "urgent" },
    ],
    activeMedications: ["Disulfiram 250mg", "Sertralina 100mg", "Citrato Magnesio 400mg", "Tiamina 100mg"],
  },
  {
    id: "p2",
    name: "Valentina Reyes S.",
    rut: "19.340.551-8",
    age: 24,
    gender: "Femenino",
    prevision: "FONASA D",
    diagnostic: "F14.2 Trastorno por Uso de Estimulantes (PBC / Pasta Base)",
    substance: "Pasta Base de Cocaína",
    fucDays: 7,
    cravingLevel: 7,
    alerts: [
      { text: "Alergia confirmada a Penicilina", severity: "urgent" },
      { text: "Taquicardia en reposo (102 lpm) - Solicitar ECG", severity: "warning" },
    ],
    activeMedications: ["Topiramato 50mg noche", "Quetiapina 25mg SOS", "Complejo B forte"],
  },
  {
    id: "p3",
    name: "Patricio González M.",
    rut: "12.784.092-1",
    age: 45,
    gender: "Masculino",
    prevision: "PRAIS",
    diagnostic: "Patología Dual (Trastorno Bipolar II + TUA en Remisión)",
    substance: "Polisustancia (Alcohol + BZD)",
    fucDays: 60,
    cravingLevel: 2,
    alerts: [
      { text: "Beneficiario Programa PRAIS", severity: "info" },
      { text: "Control Función Renal & Tiroidea Vigente", severity: "info" },
    ],
    activeMedications: ["Carbonato de Litio 300mg c/12h", "Lamotrigina 100mg/día", "Ácido Fólico 5mg"],
  },
  {
    id: "p4",
    name: "Elena Salinas T.",
    rut: "17.502.993-K",
    age: 31,
    gender: "Femenino",
    prevision: "ISAPRE",
    diagnostic: "F13.2 Dependencia a Benzodiacepinas / Iatrogénica",
    substance: "Clonazepam / Zolpidem",
    fucDays: 21,
    cravingLevel: 3,
    alerts: [
      { text: "Protocolo de Switch a Diazepam (Semana 3 de 8)", severity: "warning" },
    ],
    activeMedications: ["Diazepam 15mg noche (en descenso)", "Melatonina 5mg", "Magnesio Bisglicinato 400mg"],
  },
];

interface PatientSelectorBarProps {
  activePatient?: PatientProfile | null;
  selectedPatient?: PatientProfile | null;
  onSelectPatient?: (patient: PatientProfile) => void;
}

export function PatientSelectorBar({
  activePatient,
  selectedPatient,
  onSelectPatient,
}: PatientSelectorBarProps = {}) {
  const [internalPatient, setInternalPatient] = useState<PatientProfile>(PRESET_PATIENTS[0]);
  const [isOpen, setIsOpen] = useState(false);
  const [copied, setCopied] = useState(false);

  const currentPatient: PatientProfile =
    activePatient ?? selectedPatient ?? internalPatient ?? PRESET_PATIENTS[0];
  const alerts = currentPatient.alerts ?? [];
  const activeMedications = currentPatient.activeMedications ?? [];

  const handleSelect = (patient: PatientProfile) => {
    setInternalPatient(patient);
    onSelectPatient?.(patient);
    setIsOpen(false);
  };

  const handleCopyFicha = () => {
    const summary = `FICHA PACIENTE COSAM RINCONADA:
Nombre: ${currentPatient.name} | RUT: ${currentPatient.rut} | Edad: ${currentPatient.age}a (${currentPatient.gender})
Previsión: ${currentPatient.prevision} | Diagnóstico: ${currentPatient.diagnostic}
FUC: ${currentPatient.fucDays} días | Craving: ${currentPatient.cravingLevel}/10
Fármacos Activos: ${activeMedications.join(", ")}
Alertas: ${alerts.map((a) => `[${a.severity.toUpperCase()}] ${a.text}`).join(" | ")}`;

    navigator.clipboard.writeText(summary);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const getPrevisionColor = (prev: string = "") => {
    if (prev === "PRAIS") return "bg-purple-100 dark:bg-purple-950 text-purple-800 dark:text-purple-300 border-purple-300 dark:border-purple-800";
    if (prev.startsWith("FONASA")) return "bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 border-emerald-300 dark:border-emerald-800";
    return "bg-sky-100 dark:bg-sky-950 text-[#075985] dark:text-sky-300 border-sky-300 dark:border-sky-800";
  };

  return (
    <div className="relative">
      {/* Patient Bar Trigger */}
      <div className="p-2.5 rounded-2xl bg-white/95 dark:bg-slate-850/95 border border-slate-200/80 dark:border-slate-750 shadow-2xs flex items-center justify-between gap-3 transition-all hover:border-[#075985]/40 dark:hover:border-sky-700">
        
        {/* Patient Core Info with Dropdown Trigger */}
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="flex items-center gap-2.5 text-left focus:outline-none cursor-pointer group min-w-0"
        >
          <div className="w-8 h-8 rounded-xl bg-[#075985] text-white flex items-center justify-center font-black text-xs shadow-xs shrink-0 group-hover:scale-105 transition-transform">
            <User size={15} />
          </div>

          <div className="min-w-0">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-xs font-black text-slate-900 dark:text-white truncate">
                {currentPatient.name}
              </span>
              <span className="text-[9.5px] font-bold text-slate-500 dark:text-slate-400">
                ({currentPatient.age}a)
              </span>
              <span className={`text-[8.5px] font-black px-1.5 py-0.2 rounded uppercase border ${getPrevisionColor(currentPatient.prevision)}`}>
                {currentPatient.prevision}
              </span>
            </div>

            <div className="flex items-center gap-2 text-[10px] text-slate-600 dark:text-slate-400 truncate mt-0.5">
              <span className="font-semibold text-slate-700 dark:text-slate-300 truncate">RUT: {currentPatient.rut}</span>
              <span className="hidden md:inline text-slate-300 dark:text-slate-700">•</span>
              <span className="hidden md:inline font-bold text-emerald-700 dark:text-emerald-400 truncate">
                FUC: {currentPatient.fucDays}d
              </span>
            </div>
          </div>

          <div className="p-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 group-hover:text-slate-900 dark:group-hover:text-white transition-colors shrink-0 ml-1">
            <ChevronDown size={13} className={`transition-transform duration-200 ${isOpen ? "rotate-180" : ""}`} />
          </div>
        </button>

        {/* Action: Copy Mini Ficha */}
        <div className="flex items-center gap-1.5 shrink-0">
          {alerts.length > 0 && (
            <div
              className={`hidden sm:flex items-center gap-1 text-[9.5px] font-black px-2 py-1 rounded-xl border ${
                alerts[0].severity === "urgent"
                  ? "bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border-rose-200 dark:border-rose-800 animate-pulse"
                  : "bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800"
              }`}
              title={alerts.map((a) => a.text).join(" • ")}
            >
              <ShieldAlert size={11} />
              <span className="max-w-[130px] truncate">{alerts[0].text}</span>
            </div>
          )}

          <button
            onClick={handleCopyFicha}
            className="p-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 transition-colors cursor-pointer border border-slate-200/80 dark:border-slate-700 text-[10px] font-bold flex items-center gap-1"
            title="Copiar datos rápidos del paciente al portapapeles"
          >
            {copied ? <Check size={12} className="text-emerald-600" /> : <Copy size={12} />}
            <span className="hidden lg:inline">{copied ? "¡Copiado!" : "Ficha"}</span>
          </button>
        </div>
      </div>

      {/* Dropdown Menu for Patient Switcher */}
      <AnimatePresence>
        {isOpen && (
          <>
            <div className="fixed inset-0 z-40" onClick={() => setIsOpen(false)} />
            <motion.div
              initial={{ opacity: 0, y: 6, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 6, scale: 0.96 }}
              transition={{ duration: 0.15 }}
              className="absolute left-0 top-full mt-2 w-96 max-w-[92vw] p-4 rounded-2xl bg-white/95 dark:bg-slate-900/95 border border-slate-200 dark:border-slate-750 shadow-2xl backdrop-blur-md z-50 space-y-3.5"
            >
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
                <div className="flex items-center gap-1.5 text-xs font-black text-slate-900 dark:text-white">
                  <User size={14} className="text-[#075985] dark:text-sky-400" />
                  <span>Selector Rápido de Pacientes en Box</span>
                </div>
                <span className="text-[9.5px] font-black uppercase text-[#075985] dark:text-sky-400 bg-sky-50 dark:bg-sky-950 px-2 py-0.5 rounded">
                  4 Pacientes Simulados
                </span>
              </div>

              <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
                {PRESET_PATIENTS.map((p) => {
                  const isSelected = p.id === currentPatient.id;
                  return (
                    <button
                      key={p.id}
                      onClick={() => handleSelect(p)}
                      className={`w-full p-3 rounded-xl text-left transition-all flex flex-col gap-1.5 cursor-pointer border ${
                        isSelected
                          ? "bg-sky-50/80 dark:bg-sky-950/60 border-sky-300 dark:border-sky-800 shadow-2xs"
                          : "bg-slate-50/70 dark:bg-slate-800/50 border-slate-200/60 dark:border-slate-700/60 hover:bg-slate-100 dark:hover:bg-slate-800"
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-black text-slate-900 dark:text-white">
                            {p.name}
                          </span>
                          <span className="text-[9px] font-semibold text-slate-500">
                            {p.age}a • RUT: {p.rut}
                          </span>
                        </div>
                        <span className={`text-[8.5px] font-black px-1.5 py-0.2 rounded border ${getPrevisionColor(p.prevision)}`}>
                          {p.prevision}
                        </span>
                      </div>

                      <div className="text-[10px] text-slate-600 dark:text-slate-400 font-medium leading-tight">
                        {p.diagnostic}
                      </div>

                      {p.alerts.length > 0 && (
                        <div className="flex items-center gap-1.5 text-[9px] font-bold text-amber-700 dark:text-amber-400 pt-0.5">
                          <AlertTriangle size={10} />
                          <span className="truncate">{p.alerts[0].text}</span>
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>

              <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200/60 dark:border-slate-700/60 text-[10px] text-slate-600 dark:text-slate-300 flex items-center justify-between">
                <span className="font-semibold">El paciente seleccionado se sincroniza en SOAP, PAI y Vademécum.</span>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
