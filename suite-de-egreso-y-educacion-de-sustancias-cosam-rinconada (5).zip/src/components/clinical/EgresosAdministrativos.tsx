import { useState, useEffect } from "react";
import { Plus, Trash2, Printer, Sparkles, RefreshCw, CheckCircle, FileText, BookOpen, AlertCircle } from "lucide-react";
import { EgresoRecord } from "../../types";
import { generateClinicalAI } from "../../services/geminiService";
import { exportElementToPdf } from "../../utils/pdfExport";
import { GoogleDriveService } from "../../services/googleDriveService";
import { GoogleDocsService, PersonalDocExportRecord } from "../../services/googleDocsService";
import { PersonalDocsAutoExportBar } from "./PersonalDocsAutoExportBar";

export function EgresosAdministrativos() {
  const [records, setRecords] = useState<EgresoRecord[]>([]);
  const [activeRecord, setActiveRecord] = useState<EgresoRecord | null>(null);

  // Form Fields
  const [nombre, setNombre] = useState("");
  const [rut, setRut] = useState("");
  const [domicilio, setDomicilio] = useState("");
  const [fechaNacimiento, setFechaNacimiento] = useState("");
  const [edad, setEdad] = useState<number | "">("");
  const [fechaIngreso, setFechaIngreso] = useState("");
  const [fechaEgreso, setFechaEgreso] = useState("");
  const [motivoEgreso, setMotivoEgreso] = useState<"Alta Terapéutica" | "Alta Administrativa" | "Abandono" | "Derivación">("Alta Terapéutica");
  const [evalGeneralLogro, setEvalGeneralLogro] = useState<"Logro Alto" | "Logro Medio" | "Logro Bajo">("Logro Alto");
  const [evalGeneralObs, setEvalGeneralObs] = useState("");
  const [consumoPatron, setConsumoPatron] = useState<"Abstinencia" | "Disminución de Consumo" | "Mantención de Consumo">("Abstinencia");
  const [consumoObs, setConsumoObs] = useState("");
  const [familiarLogro, setFamiliarLogro] = useState<"Logro Alto" | "Logro Medio" | "Logro Bajo">("Logro Alto");
  const [familiarObs, setFamiliarObs] = useState("");
  const [interpersonalLogro, setInterpersonalLogro] = useState<"Logro Alto" | "Logro Medio" | "Logro Bajo">("Logro Alto");
  const [interpersonalObs, setInterpersonalObs] = useState("");
  const [normaLogro, setNormaLogro] = useState<"Logro Alto" | "Logro Medio" | "Logro Bajo">("Logro Alto");
  const [normaObs, setNormaObs] = useState("");
  const [ocupacionalLogro, setOcupacionalLogro] = useState<"Logro Alto" | "Logro Medio" | "Logro Bajo">("Logro Alto");
  const [ocupacionalObs, setOcupacionalObs] = useState("");
  const [pronosticoObs, setPronosticoObs] = useState("");
  const [documentoGenerado, setDocumentoGenerado] = useState("");

  // UI States
  const [loadingAI, setLoadingAI] = useState(false);
  const [errorAI, setErrorAI] = useState<string | null>(null);
  const [lastExportedPersonalDoc, setLastExportedPersonalDoc] = useState<PersonalDocExportRecord | null>(null);

  useEffect(() => {
    const stored = localStorage.getItem("cosam_egresos");
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        setRecords(parsed);
        if (parsed.length > 0) {
          loadRecord(parsed[0]);
        }
      } catch (e) {
        console.error("Failed to load egresos:", e);
      }
    }
  }, []);

  const saveToLocal = (updatedList: EgresoRecord[]) => {
    setRecords(updatedList);
    localStorage.setItem("cosam_egresos", JSON.stringify(updatedList));
  };

  const loadRecord = (rec: EgresoRecord) => {
    setActiveRecord(rec);
    setNombre(rec.nombre);
    setRut(rec.rut);
    setDomicilio(rec.domicilio);
    setFechaNacimiento(rec.fechaNacimiento);
    setEdad(rec.edad);
    setFechaIngreso(rec.fechaIngreso);
    setFechaEgreso(rec.fechaEgreso);
    setMotivoEgreso(rec.motivoEgreso);
    setEvalGeneralLogro(rec.evalGeneralLogro);
    setEvalGeneralObs(rec.evalGeneralObs);
    setConsumoPatron(rec.consumoPatron);
    setConsumoObs(rec.consumoObs);
    setFamiliarLogro(rec.familiarLogro);
    setFamiliarObs(rec.familiarObs);
    setInterpersonalLogro(rec.interpersonalLogro);
    setInterpersonalObs(rec.interpersonalObs);
    setNormaLogro(rec.normaLogro);
    setNormaObs(rec.normaObs);
    setOcupacionalLogro(rec.ocupacionalLogro);
    setOcupacionalObs(rec.ocupacionalObs);
    setPronosticoObs(rec.pronosticoObs);
    setDocumentoGenerado(rec.documentoGenerado || "");
  };

  const handleNewRecord = () => {
    setActiveRecord(null);
    setNombre("");
    setRut("");
    setDomicilio("");
    setFechaNacimiento("");
    setEdad("");
    setFechaIngreso("");
    setFechaEgreso("");
    setMotivoEgreso("Alta Terapéutica");
    setEvalGeneralLogro("Logro Alto");
    setEvalGeneralObs("");
    setConsumoPatron("Abstinencia");
    setConsumoObs("");
    setFamiliarLogro("Logro Alto");
    setFamiliarObs("");
    setInterpersonalLogro("Logro Alto");
    setInterpersonalObs("");
    setNormaLogro("Logro Alto");
    setNormaObs("");
    setOcupacionalLogro("Logro Alto");
    setOcupacionalObs("");
    setPronosticoObs("");
    setDocumentoGenerado("");
  };

  const handleDeleteRecord = (id: string) => {
    const updated = records.filter((r) => r.id !== id);
    saveToLocal(updated);
    if (activeRecord?.id === id) {
      if (updated.length > 0) {
        loadRecord(updated[0]);
      } else {
        handleNewRecord();
      }
    }
  };

  const handleSaveRecord = () => {
    if (!nombre.trim()) return;

    const id = activeRecord?.id || `egr_${Date.now()}`;
    const newRecord: EgresoRecord = {
      id,
      nombre,
      rut,
      domicilio,
      fechaNacimiento,
      edad: Number(edad) || 0,
      fechaIngreso,
      fechaEgreso,
      motivoEgreso,
      evalGeneralLogro,
      evalGeneralObs,
      consumoPatron,
      consumoObs,
      familiarLogro,
      familiarObs,
      interpersonalLogro,
      interpersonalObs,
      normaLogro,
      normaObs,
      ocupacionalLogro,
      ocupacionalObs,
      pronosticoObs,
      documentoGenerado: documentoGenerado || generatePlainTextSummary(),
    };

    let updatedList;
    if (activeRecord) {
      updatedList = records.map((r) => (r.id === id ? newRecord : r));
    } else {
      updatedList = [newRecord, ...records];
    }

    saveToLocal(updatedList);
    setActiveRecord(newRecord);
  };

  const generatePlainTextSummary = (): string => {
    return `FOLIO: COSAM-EGRESO-${Date.now()}\nINFORME DE EGRESO CLÍNICO\nPACIENTE: ${nombre}\nRUT: ${rut}\nMOTIVO: ${motivoEgreso}\nPATRÓN DE CONSUMO AL EGRESO: ${consumoPatron}\n\n=========================================\nEVALUACIÓN GENERAL:\n${evalGeneralObs}\n\nPRONÓSTICO DE PREVENCIÓN DE RECAÍDAS:\n${pronosticoObs}\n=========================================\n`;
  };

  const handleAIStructure = async () => {
    setLoadingAI(true);
    setErrorAI(null);
    try {
      const prompt = `Por favor redacta y estructura un informe formal de egreso clínico para el siguiente paciente del COSAM Rinconada.
DATOS DEL PACIENTE:
Nombre: ${nombre}
RUT: ${rut}
Domicilio: ${domicilio || "No especificado"}
Edad: ${edad}
Fecha Ingreso: ${fechaIngreso}
Fecha Egreso: ${fechaEgreso}

MOTIVO DEL EGRESO: ${motivoEgreso}
EVALUACIÓN GENERAL DE LOGRO: ${evalGeneralLogro} - Observación: ${evalGeneralObs || "No especificada"}

EVOLUCIÓN POR ÁREAS:
1. ÁREA DE CONSUMO: Nivel de Logro: ${consumoPatron}. Observaciones: ${consumoObs || "No anotada"}
2. ÁREA FAMILIAR: Nivel de Logro: ${familiarLogro}. Observaciones: ${familiarObs || "No anotada"}
3. ÁREA INTERPERSONAL: Nivel de Logro: ${interpersonalLogro}. Observaciones: ${interpersonalObs || "No anotada"}
4. ÁREA NORMATIVA/CIVICA: Nivel de Logro: ${normaLogro}. Observaciones: ${normaObs || "No anotada"}
5. ÁREA OCUPACIONAL/LABORAL: Nivel de Logro: ${ocupacionalLogro}. Observaciones: ${ocupacionalObs || "No anotada"}

PRONÓSTICO Y PLAN DE SEGUIMIENTO: ${pronosticoObs || "No especificado"}

Por favor formatea todo en una Ficha de Egreso Oficial para la Red de Salud Pública, estructurando cada una de las dimensiones de manera profesional, técnica, objetiva e impecable.`;

      const result = await generateClinicalAI({
        prompt,
        systemInstruction: "Eres un asesor en psicología clínica y psiquiatría de adicciones en el servicio público de salud en Chile. Tu labor consiste en redactar informes y fichas técnicas de egresos de máxima calidad institucional.",
      });

      setDocumentoGenerado(result);

      // Exportación automática al Documento Personal del Médico en Google Docs (Firebase Auth)
      if (
        GoogleDriveService.isConnected() &&
        GoogleDocsService.isAutoExportEnabled() &&
        GoogleDocsService.getExportMode() === "new_doc_per_report"
      ) {
        try {
          const exportedDoc = await GoogleDocsService.exportClinicalReportToPersonalDoc({
            reportType: `Ficha de Egreso (${motivoEgreso})`,
            patientName: nombre || "Paciente",
            patientRut: rut || "Sin RUT",
            content: result,
            modeOverride: "new_doc_per_report",
          });
          setLastExportedPersonalDoc(exportedDoc);
        } catch (docErr) {
          console.warn("Auto-export to personal Google Doc warning:", docErr);
        }
      }
    } catch (err: any) {
      setErrorAI(err.message || "Error al estructurar informe de egreso por IA.");
    } finally {
      setLoadingAI(false);
    }
  };

  const handleExportPDF = async () => {
    handleSaveRecord();
    try {
      await exportElementToPdf("printable-egreso-area", {
        filename: `Ficha_Egreso_${nombre.replace(/\s+/g, "_")}.pdf`,
      });
    } catch (err) {
      console.error("Failed to generate PDF:", err);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="egresos-administrativos-module">
      {/* Sidebar list panel */}
      <div className="lg:col-span-4 bg-white rounded-xl border border-slate-200 shadow-sm flex flex-col h-[750px] overflow-hidden">
        <div className="p-4 border-b border-slate-100 bg-slate-50/70 flex items-center justify-between">
          <h3 className="font-bold text-slate-800 text-xs md:text-sm">Egresos Clínicos ({records.length})</h3>
          <button
            onClick={handleNewRecord}
            className="p-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold transition-colors flex items-center gap-1 shadow-sm"
          >
            <Plus className="w-3.5 h-3.5" /> Nuevo
          </button>
        </div>
        <div className="flex-1 overflow-y-auto divide-y divide-slate-100 text-xs">
          {records.length > 0 ? (
            records.map((rec) => (
              <div
                key={rec.id}
                className={`p-4 hover:bg-slate-50 transition-colors flex justify-between items-start group ${
                  activeRecord?.id === rec.id ? "bg-indigo-50/40 border-l-4 border-indigo-600" : ""
                }`}
              >
                <button onClick={() => loadRecord(rec)} className="flex-1 text-left min-w-0 pr-2">
                  <p className="font-bold text-slate-800 truncate">{rec.nombre}</p>
                  <p className="text-[10px] text-indigo-600 font-semibold mt-1">{rec.motivoEgreso}</p>
                  <p className="text-[10px] text-slate-400 mt-0.5">Egreso: {rec.fechaEgreso}</p>
                </button>
                <button
                  onClick={() => handleDeleteRecord(rec.id)}
                  className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded opacity-0 group-hover:opacity-100 transition-all shrink-0"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))
          ) : (
            <div className="p-8 text-center text-slate-400">No hay egresos guardados.</div>
          )}
        </div>
      </div>

      {/* Main Workspace form panel */}
      <div className="lg:col-span-8 space-y-6">
        <PersonalDocsAutoExportBar
          reportType={`Ficha de Egreso (${motivoEgreso})`}
          patientName={nombre || "Paciente"}
          patientRut={rut || "Sin RUT"}
          generatedContent={documentoGenerado}
          lastExportedRecord={lastExportedPersonalDoc}
          onExportSuccess={(rec) => setLastExportedPersonalDoc(rec)}
        />
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 space-y-5 h-[750px] overflow-y-auto text-xs">
          <div className="flex justify-between items-center border-b border-slate-100 pb-4">
            <h2 className="text-sm font-bold text-slate-800">
              {activeRecord ? "Editar Ficha de Egreso" : "Registrar Ficha de Egreso Clínico / Alta PAI"}
            </h2>
            <div className="flex items-center gap-2">
              <button
                onClick={handleExportPDF}
                className="px-3 py-1.5 border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-lg font-semibold transition-colors flex items-center gap-1"
              >
                <Printer className="w-3.5 h-3.5" /> Exportar PDF
              </button>
              <button
                onClick={handleSaveRecord}
                className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-semibold transition-colors"
              >
                Guardar Local
              </button>
            </div>
          </div>

          {/* Form fields */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="space-y-1">
              <span className="text-[10px] text-slate-400 font-bold uppercase">Nombre Completo:</span>
              <input
                type="text"
                placeholder="Ej: Sofía Vera Salazar"
                value={nombre}
                onChange={(e) => setNombre(e.target.value)}
                className="w-full px-2.5 py-1.5 border border-slate-200 rounded focus:outline-none"
              />
            </div>
            <div className="space-y-1">
              <span className="text-[10px] text-slate-400 font-bold uppercase">RUT:</span>
              <input
                type="text"
                placeholder="15.678.910-1"
                value={rut}
                onChange={(e) => setRut(e.target.value)}
                className="w-full px-2.5 py-1.5 border border-slate-200 rounded focus:outline-none"
              />
            </div>
            <div className="space-y-1">
              <span className="text-[10px] text-slate-400 font-bold uppercase">Edad (Anos):</span>
              <input
                type="number"
                placeholder="Ej: 29"
                value={edad}
                onChange={(e) => setEdad(e.target.value === "" ? "" : Number(e.target.value))}
                className="w-full px-2.5 py-1.5 border border-slate-200 rounded focus:outline-none"
              />
            </div>
            <div className="space-y-1">
              <span className="text-[10px] text-slate-400 font-bold uppercase">Domicilio:</span>
              <input
                type="text"
                placeholder="Ej: Pje El Parrón 123"
                value={domicilio}
                onChange={(e) => setDomicilio(e.target.value)}
                className="w-full px-2.5 py-1.5 border border-slate-200 rounded focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="space-y-1">
              <span className="text-[10px] text-slate-400 font-bold uppercase">Fecha de Ingreso:</span>
              <input
                type="date"
                value={fechaIngreso}
                onChange={(e) => setFechaIngreso(e.target.value)}
                className="w-full px-2.5 py-1.5 border border-slate-200 rounded bg-white focus:outline-none"
              />
            </div>
            <div className="space-y-1">
              <span className="text-[10px] text-slate-400 font-bold uppercase">Fecha de Egreso:</span>
              <input
                type="date"
                value={fechaEgreso}
                onChange={(e) => setFechaEgreso(e.target.value)}
                className="w-full px-2.5 py-1.5 border border-slate-200 rounded bg-white focus:outline-none"
              />
            </div>
            <div className="space-y-1">
              <span className="text-[10px] text-slate-400 font-bold uppercase">Motivo del Egreso:</span>
              <select
                value={motivoEgreso}
                onChange={(e) => setMotivoEgreso(e.target.value as any)}
                className="w-full px-2.5 py-1.5 border border-slate-200 rounded bg-white focus:outline-none font-bold text-slate-700"
              >
                <option value="Alta Terapéutica">Alta Terapéutica</option>
                <option value="Alta Administrativa">Alta Administrativa</option>
                <option value="Abandono">Abandono de Tratamiento</option>
                <option value="Derivación">Derivación Extra-Sistema</option>
              </select>
            </div>
            <div className="space-y-1">
              <span className="text-[10px] text-slate-400 font-bold uppercase">Evaluación de Metas:</span>
              <select
                value={evalGeneralLogro}
                onChange={(e) => setEvalGeneralLogro(e.target.value as any)}
                className="w-full px-2.5 py-1.5 border border-slate-200 rounded bg-white focus:outline-none"
              >
                <option value="Logro Alto">Logro Alto (Cumplido)</option>
                <option value="Logro Medio">Logro Medio (Parcial)</option>
                <option value="Logro Bajo">Logro Bajo (Sin cambios)</option>
              </select>
            </div>
          </div>

          <div className="space-y-1">
            <span className="font-bold text-slate-700">Resumen y Observaciones de la Evaluación de Logros PAI:</span>
            <textarea
              placeholder="Describa de forma sintética cómo respondió el paciente a las metas fijadas en su PAI..."
              value={evalGeneralObs}
              onChange={(e) => setEvalGeneralObs(e.target.value)}
              rows={2}
              className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none text-slate-800"
            />
          </div>

          {/* Detailed areas */}
          <div className="space-y-3.5 pt-2">
            <h3 className="font-bold text-indigo-600 uppercase tracking-wide">Evaluación de Resultados por Dimensiones</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Consumo */}
              <div className="p-3 bg-slate-50/70 border border-slate-150 rounded-xl space-y-2">
                <div className="flex justify-between items-center">
                  <span className="font-bold text-slate-700">Área Consumo (Abstinencia/Reducción):</span>
                  <select
                    value={consumoPatron}
                    onChange={(e) => setConsumoPatron(e.target.value as any)}
                    className="px-2 py-0.5 border border-slate-200 rounded bg-white text-[10px]"
                  >
                    <option value="Abstinencia">Abstinencia</option>
                    <option value="Disminución de Consumo">Disminución</option>
                    <option value="Mantención de Consumo">Mantención</option>
                  </select>
                </div>
                <textarea
                  placeholder="Observaciones de patrones de consumo..."
                  value={consumoObs}
                  onChange={(e) => setConsumoObs(e.target.value)}
                  rows={2}
                  className="w-full px-2.5 py-1.5 border border-slate-200 rounded bg-white"
                />
              </div>

              {/* Familiar */}
              <div className="p-3 bg-slate-50/70 border border-slate-150 rounded-xl space-y-2">
                <div className="flex justify-between items-center">
                  <span className="font-bold text-slate-700">Área Familiar (Redes y Co-dependencia):</span>
                  <select
                    value={familiarLogro}
                    onChange={(e) => setFamiliarLogro(e.target.value as any)}
                    className="px-2 py-0.5 border border-slate-200 rounded bg-white text-[10px]"
                  >
                    <option value="Logro Alto">Logro Alto</option>
                    <option value="Logro Medio">Logro Medio</option>
                    <option value="Logro Bajo">Logro Bajo</option>
                  </select>
                </div>
                <textarea
                  placeholder="Resolución de dinámicas familiares conflictivas..."
                  value={familiarObs}
                  onChange={(e) => setFamiliarObs(e.target.value)}
                  rows={2}
                  className="w-full px-2.5 py-1.5 border border-slate-200 rounded bg-white"
                />
              </div>

              {/* Interpersonal */}
              <div className="p-3 bg-slate-50/70 border border-slate-150 rounded-xl space-y-2">
                <div className="flex justify-between items-center">
                  <span className="font-bold text-slate-700">Área Interpersonal (Pares y Amigos):</span>
                  <select
                    value={interpersonalLogro}
                    onChange={(e) => setInterpersonalLogro(e.target.value as any)}
                    className="px-2 py-0.5 border border-slate-200 rounded bg-white text-[10px]"
                  >
                    <option value="Logro Alto">Logro Alto</option>
                    <option value="Logro Medio">Logro Medio</option>
                    <option value="Logro Bajo">Logro Bajo</option>
                  </select>
                </div>
                <textarea
                  placeholder="Distanciamiento de pares consumidores y desarrollo de amistades sobrias..."
                  value={interpersonalObs}
                  onChange={(e) => setInterpersonalObs(e.target.value)}
                  rows={2}
                  className="w-full px-2.5 py-1.5 border border-slate-200 rounded bg-white"
                />
              </div>

              {/* Norma/Civica */}
              <div className="p-3 bg-slate-50/70 border border-slate-150 rounded-xl space-y-2">
                <div className="flex justify-between items-center">
                  <span className="font-bold text-slate-700">Área Cívica (Situación Judicial/Norma):</span>
                  <select
                    value={normaLogro}
                    onChange={(e) => setNormaLogro(e.target.value as any)}
                    className="px-2 py-0.5 border border-slate-200 rounded bg-white text-[10px]"
                  >
                    <option value="Logro Alto">Logro Alto</option>
                    <option value="Logro Medio">Logro Medio</option>
                    <option value="Logro Bajo">Logro Bajo</option>
                  </select>
                </div>
                <textarea
                  placeholder="Resolución de causas pendientes, cumplimiento de condenas, infracciones..."
                  value={normaObs}
                  onChange={(e) => setNormaObs(e.target.value)}
                  rows={2}
                  className="w-full px-2.5 py-1.5 border border-slate-200 rounded bg-white"
                />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs pt-1">
            <div className="space-y-1">
              <span className="font-bold text-slate-700">Área Laboral / Ocupacional:</span>
              <textarea
                placeholder="Reinserción en el mercado laboral formal o informal estable..."
                value={ocupacionalObs}
                onChange={(e) => setOcupacionalObs(e.target.value)}
                rows={2}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none"
              />
            </div>
            <div className="space-y-1">
              <span className="font-bold text-slate-700">Pronóstico y Recomendaciones para Prevención de Recaídas:</span>
              <textarea
                placeholder="Nivel de insight del paciente, estrategias aprendidas ante ansia, pauta farmacológica de resguardo..."
                value={pronosticoObs}
                onChange={(e) => setPronosticoObs(e.target.value)}
                rows={2}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none"
              />
            </div>
          </div>

          <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-[10px] text-slate-400 italic">
              <BookOpen className="w-3.5 h-3.5 text-indigo-500" />
              Sincroniza y presiona "Estructurar Egreso por IA" para formalizar la salida del paciente
            </div>
            <button
              onClick={handleAIStructure}
              disabled={loadingAI || (!evalGeneralObs && !consumoObs && !pronosticoObs)}
              className="px-4.5 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-400 text-white rounded-lg font-semibold flex items-center gap-1.5 shadow-sm"
            >
              {loadingAI ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
              Estructurar Egreso por IA
            </button>
          </div>
        </div>

        {/* Generated output area */}
        {(documentoGenerado || loadingAI || errorAI) && (
          <div className="bg-slate-50 rounded-xl border border-slate-200 p-6 space-y-4 shadow-sm" id="printable-egreso-area">
            <div className="flex justify-between items-center pb-3 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-indigo-600" />
                <h3 className="font-bold text-slate-800 text-xs md:text-sm">Ficha Clínica de Egreso y Alta Multidisciplinaria</h3>
              </div>
              <span className="text-[9px] bg-indigo-100 text-indigo-700 font-extrabold px-2.5 py-0.5 rounded-full uppercase">
                COSAM Rinconada
              </span>
            </div>

            {loadingAI && (
              <div className="py-8 flex flex-col items-center gap-2">
                <RefreshCw className="w-8 h-8 text-indigo-600 animate-spin" />
                <p className="text-xs text-slate-500 font-medium animate-pulse">Redactando Ficha Oficial de Egreso COSAM...</p>
              </div>
            )}

            {errorAI && (
              <div className="p-4 bg-rose-50 border border-rose-100 text-rose-700 text-xs rounded-lg">
                {errorAI}
              </div>
            )}

            {documentoGenerado && !loadingAI && (
              <div className="text-slate-800 text-xs leading-relaxed space-y-4 font-mono select-all whitespace-pre-wrap bg-white p-5 rounded-lg border border-slate-200">
                {documentoGenerado}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
