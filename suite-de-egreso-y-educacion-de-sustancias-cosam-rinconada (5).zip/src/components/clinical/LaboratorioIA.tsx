import React, { useState } from "react";
import {
  FlaskConical,
  Wand2,
  Copy,
  Printer,
  HardDrive,
  MessageSquare,
  Sparkles,
  AlertTriangle,
  RotateCcw,
  Send,
  Check,
  Languages,
  Activity,
  Heart,
  Droplet,
  Globe,
  Mic,
  Radio,
  FileDown,
} from "lucide-react";
import { generateClinicalAI, chatClinicalAI } from "../../services/geminiService";
import { GoogleDriveService } from "../../services/googleDriveService";
import { SearchGroundingPanel } from "./SearchGroundingPanel";
import { exportElementToPdf } from "../../utils/pdfExport";

interface LaboratorioIAProps {
  onShowToast?: (msg: string, type?: "success" | "error" | "info") => void;
  onOpenDriveModal?: () => void;
  isDriveConnected?: boolean;
  onOpenTranscribeModal?: () => void;
  onOpenLiveVoiceModal?: () => void;
}

export function LaboratorioIA({
  onShowToast = () => {},
  onOpenDriveModal = () => {},
  isDriveConnected = false,
  onOpenTranscribeModal,
  onOpenLiveVoiceModal,
}: LaboratorioIAProps) {
  // Clinical Context
  const [edad, setEdad] = useState<string>("45");
  const [sexo, setSexo] = useState<string>("Masculino");
  const [diagnostico, setDiagnostico] = useState<string>("Trastorno por consumo de alcohol crónico");
  const [farmacos, setFarmacos] = useState<string>("Quetiapina 100mg, Sertralina 100mg");

  // Lab Values
  // 1. Hepático
  const [got, setGot] = useState<string>("");
  const [gpt, setGpt] = useState<string>("");
  const [ggt, setGgt] = useState<string>("");
  const [bili, setBili] = useState<string>("");
  const [fa, setFa] = useState<string>("");

  // 2. Hemograma & Vitaminas
  const [hemoglobina, setHemoglobina] = useState<string>("");
  const [vcm, setVcm] = useState<string>("");
  const [plaquetas, setPlaquetas] = useState<string>("");
  const [leucocitos, setLeucocitos] = useState<string>("");
  const [b12, setB12] = useState<string>("");
  const [folico, setFolico] = useState<string>("");

  // 3. Renal & Electrólitos
  const [bun, setBun] = useState<string>("");
  const [creatinina, setCreatinina] = useState<string>("");
  const [sodio, setSodio] = useState<string>("");
  const [potasio, setPotasio] = useState<string>("");

  // 4. Perfil Metabólico & Glicemia
  const [glicemia, setGlicemia] = useState<string>("");
  const [hba1c, setHba1c] = useState<string>("");
  const [insulina, setInsulina] = useState<string>("");

  // 5. Perfil Lipídico Completo
  const [colesterolTotal, setColesterolTotal] = useState<string>("");
  const [colesterolHdl, setColesterolHdl] = useState<string>("");
  const [colesterolLdl, setColesterolLdl] = useState<string>("");
  const [trigliceridos, setTrigliceridos] = useState<string>("");

  // 6. Perfil Tiroideo
  const [tsh, setTsh] = useState<string>("");
  const [t4l, setT4l] = useState<string>("");
  const [t3, setT3] = useState<string>("");

  // 7. Niveles Plasmáticos y Endocrinos
  const [litemia, setLitemia] = useState<string>("");
  const [valproemia, setValproemia] = useState<string>("");
  const [prolactina, setProlactina] = useState<string>("");

  // Sub-view toggle (Lab Analysis vs Search Grounding)
  const [activeLabTab, setActiveLabTab] = useState<"analysis" | "searchGrounding">("analysis");

  // Results & States
  const [reporteText, setReporteText] = useState<string>("");
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isSavingDrive, setIsSavingDrive] = useState<boolean>(false);
  const [isExportingPdf, setIsExportingPdf] = useState<boolean>(false);
  const [isCopied, setIsCopied] = useState<boolean>(false);

  // Patient Translation Modal State
  const [isPatientModalOpen, setIsPatientModalOpen] = useState<boolean>(false);
  const [patientExplanation, setPatientExplanation] = useState<string>("");
  const [isTranslatingPatient, setIsTranslatingPatient] = useState<boolean>(false);

  // Interactive Lab Chat State
  const [chatMessages, setChatMessages] = useState<Array<{ role: "user" | "model"; text: string }>>([]);
  const [chatInput, setChatInput] = useState<string>("");
  const [isChatLoading, setIsChatLoading] = useState<boolean>(false);

  const handleAnalizar = async () => {
    const labItems: string[] = [];
    if (got) labItems.push(`AST/GOT: ${got} U/L`);
    if (gpt) labItems.push(`ALT/GPT: ${gpt} U/L`);
    if (ggt) labItems.push(`GGT: ${ggt} U/L (Marcador consumo)`);
    if (bili) labItems.push(`Bilirrubina Total: ${bili} mg/dL`);
    if (fa) labItems.push(`Fosfatasa Alcalina: ${fa} U/L`);

    if (hemoglobina) labItems.push(`Hemoglobina: ${hemoglobina} g/dL`);
    if (vcm) labItems.push(`VCM: ${vcm} fL (>95 alerta consumo/macrocitosis)`);
    if (plaquetas) labItems.push(`Plaquetas: ${plaquetas} mil/uL`);
    if (leucocitos) labItems.push(`Leucocitos: ${leucocitos} mil/uL`);
    if (b12) labItems.push(`Vitamina B12: ${b12} pg/mL`);
    if (folico) labItems.push(`Ácido Fólico: ${folico} ng/mL`);

    if (bun) labItems.push(`BUN/Urea: ${bun} mg/dL`);
    if (creatinina) labItems.push(`Creatinina: ${creatinina} mg/dL`);
    if (sodio) labItems.push(`Sodio (Na): ${sodio} mEq/L`);
    if (potasio) labItems.push(`Potasio (K): ${potasio} mEq/L`);

    // Glicemia & Metabólico
    if (glicemia) labItems.push(`Glicemia en ayunas: ${glicemia} mg/dL`);
    if (hba1c) labItems.push(`HbA1c (Hemoglobina Glicosilada): ${hba1c} %`);
    if (insulina) labItems.push(`Insulina basal: ${insulina} uIU/mL`);

    // Perfil Lipídico
    if (colesterolTotal) labItems.push(`Colesterol Total: ${colesterolTotal} mg/dL`);
    if (colesterolHdl) labItems.push(`Colesterol HDL: ${colesterolHdl} mg/dL`);
    if (colesterolLdl) labItems.push(`Colesterol LDL: ${colesterolLdl} mg/dL`);
    if (trigliceridos) labItems.push(`Triglicéridos: ${trigliceridos} mg/dL`);

    // Perfil Tiroideo
    if (tsh) labItems.push(`TSH: ${tsh} uUI/mL`);
    if (t4l) labItems.push(`T4 Libre: ${t4l} ng/dL`);
    if (t3) labItems.push(`T3: ${t3} ng/dL`);

    // Niveles plasmáticos
    if (litemia) labItems.push(`Litemia: ${litemia} mEq/L`);
    if (valproemia) labItems.push(`Valproemia (Ácido Valproico): ${valproemia} ug/mL`);
    if (prolactina) labItems.push(`Prolactina: ${prolactina} ng/mL`);

    if (labItems.length === 0 && !diagnostico && !farmacos) {
      onShowToast("Ingrese algunos valores de laboratorio o contexto clínico", "error");
      return;
    }

    setIsLoading(true);
    const prompt = `Actúa como Médico Hepatólogo, Internista, Endocrinólogo y Psiquiatra de enlace experto en Adicciones y Psicofarmacología. Estás asesorando en la lectura e interpretación cruzada de un panel completo de exámenes de laboratorio para el COSAM Rinconada.

CONTEXTO DEL PACIENTE:
- Edad: ${edad} años | Sexo: ${sexo}
- Diagnóstico base: ${diagnostico || "En estudio"}
- Fármacos actuales: ${farmacos || "Ninguno"}

VALORES DE LABORATORIO REPORTADOS:
${labItems.length > 0 ? labItems.join("\n") : "Sin valores numéricos específicos ingresados."}

INSTRUCCIONES CLÍNICAS Y DE ENLACE:
1. BANDERAS ROJAS Y HALLAZGOS CRÍTICOS:
   - Razón AST/ALT (De Ritis >2 sugestiva de hepatopatía por alcohol), GGT elevada, VCM >95 fL.
   - Perfil Lipídico & Glicemia / HbA1c: Detección de Síndrome Metabólico, resistencia insulínica, dislipidemia aterogénica por Antipsicóticos Atípicos (Quetiapina, Olanzapina, Risperidona, Clozapina).
   - Eje Tiroideo (TSH, T4L, T3): Descarte de hipotiroidismo primario/subclínico (simulador de depresión, o secundario a Litio) o hipertiroidismo (simulador de manía/ansiedad).
   - Deficiencias vitamínicas (B12, Folato) y riesgo de Encefalopatía de Wernicke o neuropatía alcohólica.
   - Función renal (Creatinina, BUN) y Electrolitos (Sodio Na, Potasio K) con énfasis en riesgo de toxicidad por Litio o hiponatremia inducida por ISRS/Carbamazepina.
   - Niveles plasmáticos terapéuticos vs tóxicos (Litemia meta 0.6-0.8 mEq/L en mantenimiento o 0.8-1.0 mEq/L agudo; Valproemia 50-100 ug/mL; Prolactina por bloqueo D2).

2. IMPLICANCIAS PSIQUIÁTRICAS Y FARMACOLÓGICAS:
   - Correlación causal o agravante de los hallazgos biológicos con el cuadro psiquiátrico del paciente y sus fármacos actuales.

3. RECOMENDACIONES DE CONDUCTA EN BOX COSAM (APS/Especialidad):
   - Ajustes farmacológicos sugeridos (cambio a antipsicótico metabólicamente neutro como Aripiprazol, desescalada, suplementación con Tiamina/B12, etc.).
   - Solicitud de interconsultas (Medicina Interna, Nutrición) o exámenes de control.

Estructura tu reporte de forma textual limpia y ordenada:
==================================================
REPORTE ANALÍTICO DE LABORATORIO Y TOXICOLOGÍA
COSAM RINCONADA - PROGRAMA DE ADICCIONES & SALUD MENTAL
==================================================
1. BANDERAS ROJAS Y CORRELACIÓN METABÓLICA / HEPÁTICA / TIROIDEA
2. IMPLICANCIAS PSIQUIÁTRICAS Y FARMACOLÓGICAS
3. RECOMENDACIONES DE MANEJO EN BOX Y PLAN DE SEGUIMIENTO`;

    try {
      const response = await generateClinicalAI({
        prompt,
        systemInstruction: "Eres un internista y toxicólogo especialista en adicciones en Chile.",
        temperature: 0.2,
      });
      setReporteText(response.trim());
      setChatMessages([
        { role: "user", text: `Panel analizado:\n${labItems.join(", ")}` },
        { role: "model", text: response.trim() },
      ]);
      onShowToast("Análisis de laboratorio completado", "success");
    } catch (err: any) {
      console.error(err);
      onShowToast(err.message || "Error al analizar panel de laboratorio", "error");
    } finally {
      setIsLoading(false);
    }
  };

  const handleExplicarAPaciente = async () => {
    if (!reporteText) {
      onShowToast("Primero genere el análisis de laboratorio", "error");
      return;
    }
    setIsPatientModalOpen(true);
    setIsTranslatingPatient(true);

    const prompt = `Eres un médico de familia empático y cercano en COSAM Rinconada. Basándote en el siguiente reporte técnico de laboratorio:
"${reporteText}"

Traduce los hallazgos a un discurso cálido, empático, sin jerga médica incomprensible y tranquilizador, pero claro en las metas de salud para explicárselo cara a cara al paciente en el box.

Estructura la explicación en 3 puntos sencillos:
1. Cómo están sus defensas, hígado y riñones hoy.
2. Por qué es importante cuidar la alimentación y evitar el consumo.
3. Tres tareas prácticas sencillas que haremos juntos.`;

    try {
      const result = await generateClinicalAI({
        prompt,
        systemInstruction: "Eres un médico de familia chileno muy empático y claro en su comunicación.",
        temperature: 0.3,
      });
      setPatientExplanation(result.trim());
    } catch (err: any) {
      setPatientExplanation("Error al generar traducción para el paciente: " + err.message);
    } finally {
      setIsTranslatingPatient(false);
    }
  };

  const handleSendFollowUpChat = async () => {
    if (!chatInput.trim()) return;
    const userText = chatInput.trim();
    setChatInput("");
    const newMessages = [...chatMessages, { role: "user" as const, text: userText }];
    setChatMessages(newMessages);
    setIsChatLoading(true);

    try {
      const result = await chatClinicalAI({
        messages: newMessages,
        systemInstruction:
          "Eres un toxicólogo clínico y psiquiatra en adicciones respondiendo dudas puntuales del médico sobre este paciente.",
        temperature: 0.2,
      });
      setChatMessages([...newMessages, { role: "model" as const, text: result }]);
    } catch (err: any) {
      onShowToast(err.message || "Error al consultar toxicólogo IA", "error");
    } finally {
      setIsChatLoading(false);
    }
  };

  const handleGuardarDrive = async () => {
    if (!reporteText) return;
    if (!isDriveConnected) {
      onOpenDriveModal();
      return;
    }
    setIsSavingDrive(true);
    try {
      const fecha = new Date().toISOString().split("T")[0];
      const fileName = `Reporte_Laboratorio_IA_${edad}a_${fecha}.txt`;
      await GoogleDriveService.saveClinicalDocument({
        fileName,
        content: reporteText,
      });
      onShowToast(`Reporte guardado en Google Drive: ${fileName}`, "success");
    } catch (err: any) {
      onShowToast(err.message || "Error al guardar en Google Drive", "error");
    } finally {
      setIsSavingDrive(false);
    }
  };

  const handleExportarPDF = async () => {
    if (!reporteText) {
      onShowToast("Primero genere el análisis de laboratorio", "error");
      return;
    }
    setIsExportingPdf(true);
    try {
      const fecha = new Date().toISOString().split("T")[0];
      const filename = `Informe_Laboratorio_Toxicologico_${edad}a_${fecha}.pdf`;
      await exportElementToPdf("laboratorio-print-document", { filename });
      onShowToast(`PDF del informe de laboratorio descargado: ${filename}`, "success");
    } catch (err: any) {
      console.error(err);
      onShowToast("Error al generar PDF del informe", "error");
    } finally {
      setIsExportingPdf(false);
    }
  };

  const handleCopiarReporte = () => {
    if (!reporteText) return;
    navigator.clipboard.writeText(reporteText).then(() => {
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2000);
      onShowToast("Copiado al portapapeles para Rayen", "success");
    });
  };

  const handleLimpiar = () => {
    setGot("");
    setGpt("");
    setGgt("");
    setBili("");
    setFa("");
    setHemoglobina("");
    setVcm("");
    setPlaquetas("");
    setLeucocitos("");
    setB12("");
    setFolico("");
    setBun("");
    setCreatinina("");
    setSodio("");
    setPotasio("");
    setGlicemia("");
    setHba1c("");
    setInsulina("");
    setColesterolTotal("");
    setColesterolHdl("");
    setColesterolLdl("");
    setTrigliceridos("");
    setTsh("");
    setT4l("");
    setT3("");
    setLitemia("");
    setValproemia("");
    setProlactina("");
    setReporteText("");
    onShowToast("Panel de laboratorio limpiado", "info");
  };

  const handleCargarPreset = (tipo: "metabolico" | "alcohol" | "litio") => {
    handleLimpiar();
    if (tipo === "metabolico") {
      setEdad("38");
      setSexo("Femenino");
      setDiagnostico("Trastorno Bipolar tipo I / Depresión severa");
      setFarmacos("Quetiapina 300mg/noche, Olanzapina 10mg, Sertralina 100mg");
      setGlicemia("126");
      setHba1c("6.8");
      setColesterolTotal("248");
      setColesterolHdl("36");
      setColesterolLdl("158");
      setTrigliceridos("270");
      setGot("32");
      setGpt("45");
      setTsh("2.4");
      setT4l("1.1");
      setProlactina("38");
      onShowToast("Preset cargado: Síndrome Metabólico por Antipsicóticos", "success");
    } else if (tipo === "alcohol") {
      setEdad("49");
      setSexo("Masculino");
      setDiagnostico("Dependencia severa de alcohol con patrón de consumo diario");
      setFarmacos("Disulfiram 250mg (irregular), Clonazepam 2mg");
      setGot("142");
      setGpt("64");
      setGgt("280");
      setBili("1.9");
      setFa("160");
      setHemoglobina("12.1");
      setVcm("104");
      setPlaquetas("115");
      setB12("180");
      setFolico("2.1");
      setSodio("133");
      setPotasio("3.4");
      onShowToast("Preset cargado: Marcadores de Hepatopatía y Consumo Alcohólico", "success");
    } else if (tipo === "litio") {
      setEdad("42");
      setSexo("Masculino");
      setDiagnostico("Trastorno Afectivo Bipolar I en fase eutímica");
      setFarmacos("Carbonato de Litio 900mg/día, Lamotrigina 100mg");
      setLitemia("0.78");
      setCreatinina("1.15");
      setBun("22");
      setSodio("141");
      setPotasio("4.2");
      setTsh("6.8");
      setT4l("0.75");
      setGlicemia("92");
      onShowToast("Preset cargado: Control de Litio y Eje Tiroideo/Renal", "success");
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header Bar */}
      <div className="bg-slate-900/60 backdrop-blur-xl border border-rose-500/20 rounded-3xl p-6 shadow-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400">
            <FlaskConical className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold text-rose-400 uppercase tracking-widest bg-rose-950/60 px-2 py-0.5 rounded border border-rose-800/40">
                Toxicología & Medicina Interna
              </span>
            </div>
            <h2 className="text-xl font-bold text-white tracking-tight">
              Detective de Laboratorio e Interacciones
            </h2>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {onOpenLiveVoiceModal && (
            <button
              onClick={onOpenLiveVoiceModal}
              className="px-3.5 py-2 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white rounded-xl text-xs font-bold transition-all shadow-md flex items-center gap-1.5 cursor-pointer"
            >
              <Radio className="w-3.5 h-3.5 animate-pulse text-pink-200" />
              <span>Voz en Vivo</span>
            </button>
          )}
          <button
            onClick={handleLimpiar}
            className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Limpiar Panel</span>
          </button>
        </div>
      </div>

      {/* Sub-tab Navigation */}
      <div className="flex bg-slate-900/60 border border-slate-800 rounded-2xl p-1.5 max-w-md">
        <button
          onClick={() => setActiveLabTab("analysis")}
          className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
            activeLabTab === "analysis"
              ? "bg-rose-600 text-white shadow-md shadow-rose-950/40"
              : "text-slate-400 hover:text-slate-200"
          }`}
        >
          <FlaskConical className="w-3.5 h-3.5" />
          <span>Matriz de Laboratorio</span>
        </button>
        <button
          onClick={() => setActiveLabTab("searchGrounding")}
          className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
            activeLabTab === "searchGrounding"
              ? "bg-indigo-600 text-white shadow-md shadow-indigo-950/40"
              : "text-slate-400 hover:text-slate-200"
          }`}
        >
          <Globe className="w-3.5 h-3.5" />
          <span>Evidencia Web (Grounding)</span>
        </button>
      </div>

      {activeLabTab === "searchGrounding" ? (
        <SearchGroundingPanel
          defaultQuery="Toxicología e interferencias de laboratorio en pacientes psiquiátricos con consumo problemático"
          onShowToast={onShowToast}
          onInsertText={(text) => {
            setReporteText((prev) => (prev ? `${prev}\n\n--- EVIDENCIA CONSULTADA ---\n${text}` : text));
            setActiveLabTab("analysis");
            onShowToast("Evidencia incorporada al reporte", "success");
          }}
        />
      ) : (
        /* Main Grid: Inputs Panels vs Results View */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Multi-panel Inputs */}
          <div className="lg:col-span-6 space-y-4">
            {/* Preset Buttons for Fast Clinical Scenarios */}
            <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-3 flex flex-wrap items-center gap-2">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mr-1 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-amber-400" />
                <span>Plantillas Rápidas:</span>
              </span>
              <button
                onClick={() => handleCargarPreset("metabolico")}
                className="px-2.5 py-1 bg-amber-950/60 hover:bg-amber-900 border border-amber-500/30 text-amber-300 rounded-lg text-[10px] font-bold transition-colors cursor-pointer"
              >
                Sd. Metabólico / Antipsicóticos
              </button>
              <button
                onClick={() => handleCargarPreset("alcohol")}
                className="px-2.5 py-1 bg-rose-950/60 hover:bg-rose-900 border border-rose-500/30 text-rose-300 rounded-lg text-[10px] font-bold transition-colors cursor-pointer"
              >
                Consumo Crónico / Hepatopatía
              </button>
              <button
                onClick={() => handleCargarPreset("litio")}
                className="px-2.5 py-1 bg-cyan-950/60 hover:bg-cyan-900 border border-cyan-500/30 text-cyan-300 rounded-lg text-[10px] font-bold transition-colors cursor-pointer"
              >
                Bipolar / Litio & Tiroides
              </button>
            </div>

            {/* 1. Contexto Clínico */}
            <div className="bg-slate-900/70 backdrop-blur-2xl border border-purple-500/20 rounded-3xl p-5 shadow-xl space-y-3 relative overflow-hidden">
              <div className="absolute top-0 left-0 w-1.5 h-full bg-purple-500" />
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-purple-300 uppercase tracking-wider flex items-center gap-1.5">
                  <Activity className="w-3.5 h-3.5" />
                  <span>1. Contexto Clínico y Farmacológico</span>
                </h3>
                {onOpenTranscribeModal && (
                  <button
                    type="button"
                    onClick={onOpenTranscribeModal}
                    title="Dictar contexto por voz"
                    className="flex items-center gap-1 px-2.5 py-1 bg-purple-950/60 hover:bg-purple-900 border border-purple-500/40 text-purple-300 rounded-lg text-[10px] font-bold transition-colors cursor-pointer"
                  >
                    <Mic className="w-3 h-3 text-purple-400" />
                    <span>Dictar</span>
                  </button>
                )}
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                    Edad
                  </label>
                  <input
                    type="number"
                    value={edad}
                    onChange={(e) => setEdad(e.target.value)}
                    className="w-full bg-slate-950/70 border border-slate-800 rounded-xl p-2 text-xs text-slate-200 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                    Sexo Biológico
                  </label>
                  <select
                    value={sexo}
                    onChange={(e) => setSexo(e.target.value)}
                    className="w-full bg-slate-950/70 border border-slate-800 rounded-xl p-2 text-xs text-slate-200 outline-none"
                  >
                    <option value="Masculino">Masculino</option>
                    <option value="Femenino">Femenino</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                  Diagnóstico Principal / Sustancia
                </label>
                <input
                  type="text"
                  value={diagnostico}
                  onChange={(e) => setDiagnostico(e.target.value)}
                  placeholder="Ej: Alcoholismo crónico, Bipolaridad..."
                  className="w-full bg-slate-950/70 border border-slate-800 rounded-xl p-2 text-xs text-slate-200 outline-none"
                />
              </div>
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                  Fármacos Actuales
                </label>
                <input
                  type="text"
                  value={farmacos}
                  onChange={(e) => setFarmacos(e.target.value)}
                  placeholder="Ej: Quetiapina 100mg, Sertralina 50mg..."
                  className="w-full bg-slate-950/70 border border-slate-800 rounded-xl p-2 text-xs text-slate-200 outline-none"
                />
              </div>
            </div>

            {/* 2. Perfil Hepático */}
            <div className="bg-slate-900/70 backdrop-blur-2xl border border-amber-500/20 rounded-3xl p-5 shadow-xl space-y-3 relative overflow-hidden">
              <div className="absolute top-0 left-0 w-1.5 h-full bg-amber-500" />
              <h3 className="text-xs font-bold text-amber-300 uppercase tracking-wider flex items-center gap-1.5">
                <Droplet className="w-3.5 h-3.5" />
                <span>2. Perfil Hepático (GOT, GPT, GGT, Bili, FA)</span>
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 mb-0.5">AST / GOT</label>
                  <input
                    type="number"
                    value={got}
                    onChange={(e) => setGot(e.target.value)}
                    placeholder="U/L"
                    className="w-full bg-slate-950/70 border border-slate-800 rounded-xl p-2 text-xs text-slate-200 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 mb-0.5">ALT / GPT</label>
                  <input
                    type="number"
                    value={gpt}
                    onChange={(e) => setGpt(e.target.value)}
                    placeholder="U/L"
                    className="w-full bg-slate-950/70 border border-slate-800 rounded-xl p-2 text-xs text-slate-200 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-amber-400 mb-0.5">GGT (OH)</label>
                  <input
                    type="number"
                    value={ggt}
                    onChange={(e) => setGgt(e.target.value)}
                    placeholder="U/L (>50)"
                    className="w-full bg-amber-950/40 border border-amber-500/40 rounded-xl p-2 text-xs text-amber-200 outline-none font-bold"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 mb-0.5">Bilirrubina T.</label>
                  <input
                    type="number"
                    step="0.1"
                    value={bili}
                    onChange={(e) => setBili(e.target.value)}
                    placeholder="mg/dL"
                    className="w-full bg-slate-950/70 border border-slate-800 rounded-xl p-2 text-xs text-slate-200 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 mb-0.5">Fosf. Alcalina</label>
                  <input
                    type="number"
                    value={fa}
                    onChange={(e) => setFa(e.target.value)}
                    placeholder="U/L"
                    className="w-full bg-slate-950/70 border border-slate-800 rounded-xl p-2 text-xs text-slate-200 outline-none"
                  />
                </div>
              </div>
            </div>

            {/* 3. Hemograma & Vitaminas */}
            <div className="bg-slate-900/70 backdrop-blur-2xl border border-rose-500/20 rounded-3xl p-5 shadow-xl space-y-3 relative overflow-hidden">
              <div className="absolute top-0 left-0 w-1.5 h-full bg-rose-500" />
              <h3 className="text-xs font-bold text-rose-300 uppercase tracking-wider flex items-center gap-1.5">
                <Heart className="w-3.5 h-3.5" />
                <span>3. Hemograma, VCM y Vitaminas</span>
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 mb-0.5">Hemoglobina</label>
                  <input
                    type="number"
                    step="0.1"
                    value={hemoglobina}
                    onChange={(e) => setHemoglobina(e.target.value)}
                    placeholder="g/dL"
                    className="w-full bg-slate-950/70 border border-slate-800 rounded-xl p-2 text-xs text-slate-200 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-rose-400 mb-0.5">VCM (&gt;95 fL)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={vcm}
                    onChange={(e) => setVcm(e.target.value)}
                    placeholder="fL"
                    className="w-full bg-rose-950/40 border border-rose-500/40 rounded-xl p-2 text-xs text-rose-200 outline-none font-bold"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 mb-0.5">Plaquetas</label>
                  <input
                    type="number"
                    value={plaquetas}
                    onChange={(e) => setPlaquetas(e.target.value)}
                    placeholder="mil/uL"
                    className="w-full bg-slate-950/70 border border-slate-800 rounded-xl p-2 text-xs text-slate-200 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 mb-0.5">Leucocitos</label>
                  <input
                    type="number"
                    step="0.1"
                    value={leucocitos}
                    onChange={(e) => setLeucocitos(e.target.value)}
                    placeholder="mil/uL"
                    className="w-full bg-slate-950/70 border border-slate-800 rounded-xl p-2 text-xs text-slate-200 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 mb-0.5">Vitamina B12</label>
                  <input
                    type="number"
                    value={b12}
                    onChange={(e) => setB12(e.target.value)}
                    placeholder="pg/mL"
                    className="w-full bg-slate-950/70 border border-slate-800 rounded-xl p-2 text-xs text-slate-200 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 mb-0.5">Ácido Fólico</label>
                  <input
                    type="number"
                    step="0.1"
                    value={folico}
                    onChange={(e) => setFolico(e.target.value)}
                    placeholder="ng/mL"
                    className="w-full bg-slate-950/70 border border-slate-800 rounded-xl p-2 text-xs text-slate-200 outline-none"
                  />
                </div>
              </div>
            </div>

            {/* 4. Perfil Metabólico & Glicemia */}
            <div className="bg-slate-900/70 backdrop-blur-2xl border border-emerald-500/20 rounded-3xl p-5 shadow-xl space-y-3 relative overflow-hidden">
              <div className="absolute top-0 left-0 w-1.5 h-full bg-emerald-500" />
              <h3 className="text-xs font-bold text-emerald-300 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                <span>4. Perfil Metabólico & Glicemia</span>
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 mb-0.5">Glicemia en Ayunas</label>
                  <input
                    type="number"
                    value={glicemia}
                    onChange={(e) => setGlicemia(e.target.value)}
                    placeholder="mg/dL (70-100)"
                    className="w-full bg-slate-950/70 border border-slate-800 rounded-xl p-2 text-xs text-slate-200 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-emerald-400 mb-0.5">HbA1c Glicosilada</label>
                  <input
                    type="number"
                    step="0.1"
                    value={hba1c}
                    onChange={(e) => setHba1c(e.target.value)}
                    placeholder="% (<5.7)"
                    className="w-full bg-emerald-950/40 border border-emerald-500/40 rounded-xl p-2 text-xs text-emerald-200 outline-none font-bold"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 mb-0.5">Insulina Basal</label>
                  <input
                    type="number"
                    step="0.1"
                    value={insulina}
                    onChange={(e) => setInsulina(e.target.value)}
                    placeholder="uIU/mL"
                    className="w-full bg-slate-950/70 border border-slate-800 rounded-xl p-2 text-xs text-slate-200 outline-none"
                  />
                </div>
              </div>
            </div>

            {/* 5. Perfil Lipídico Completo */}
            <div className="bg-slate-900/70 backdrop-blur-2xl border border-yellow-500/20 rounded-3xl p-5 shadow-xl space-y-3 relative overflow-hidden">
              <div className="absolute top-0 left-0 w-1.5 h-full bg-yellow-500" />
              <h3 className="text-xs font-bold text-yellow-300 uppercase tracking-wider flex items-center gap-1.5">
                <Activity className="w-3.5 h-3.5" />
                <span>5. Perfil Lipídico Completo</span>
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 mb-0.5">Colesterol Total</label>
                  <input
                    type="number"
                    value={colesterolTotal}
                    onChange={(e) => setColesterolTotal(e.target.value)}
                    placeholder="mg/dL (<200)"
                    className="w-full bg-slate-950/70 border border-slate-800 rounded-xl p-2 text-xs text-slate-200 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 mb-0.5">Colesterol HDL</label>
                  <input
                    type="number"
                    value={colesterolHdl}
                    onChange={(e) => setColesterolHdl(e.target.value)}
                    placeholder="mg/dL (>40/50)"
                    className="w-full bg-slate-950/70 border border-slate-800 rounded-xl p-2 text-xs text-slate-200 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 mb-0.5">Colesterol LDL</label>
                  <input
                    type="number"
                    value={colesterolLdl}
                    onChange={(e) => setColesterolLdl(e.target.value)}
                    placeholder="mg/dL (<100)"
                    className="w-full bg-slate-950/70 border border-slate-800 rounded-xl p-2 text-xs text-slate-200 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-yellow-400 mb-0.5">Triglicéridos</label>
                  <input
                    type="number"
                    value={trigliceridos}
                    onChange={(e) => setTrigliceridos(e.target.value)}
                    placeholder="mg/dL (<150)"
                    className="w-full bg-yellow-950/40 border border-yellow-500/40 rounded-xl p-2 text-xs text-yellow-200 outline-none font-bold"
                  />
                </div>
              </div>
            </div>

            {/* 6. Perfil Tiroideo Completo */}
            <div className="bg-slate-900/70 backdrop-blur-2xl border border-indigo-500/20 rounded-3xl p-5 shadow-xl space-y-3 relative overflow-hidden">
              <div className="absolute top-0 left-0 w-1.5 h-full bg-indigo-500" />
              <h3 className="text-xs font-bold text-indigo-300 uppercase tracking-wider flex items-center gap-1.5">
                <FlaskConical className="w-3.5 h-3.5" />
                <span>6. Perfil Tiroideo Completo (TSH, T4L, T3)</span>
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                <div>
                  <label className="block text-[10px] font-bold text-indigo-400 mb-0.5">TSH (Tirotrofina)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={tsh}
                    onChange={(e) => setTsh(e.target.value)}
                    placeholder="uUI/mL (0.4 - 4.0)"
                    className="w-full bg-indigo-950/40 border border-indigo-500/40 rounded-xl p-2 text-xs text-indigo-200 outline-none font-bold"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 mb-0.5">T4 Libre (T4L)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={t4l}
                    onChange={(e) => setT4l(e.target.value)}
                    placeholder="ng/dL (0.8 - 1.8)"
                    className="w-full bg-slate-950/70 border border-slate-800 rounded-xl p-2 text-xs text-slate-200 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 mb-0.5">T3 (Triyodotironina)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={t3}
                    onChange={(e) => setT3(e.target.value)}
                    placeholder="ng/dL o pg/mL"
                    className="w-full bg-slate-950/70 border border-slate-800 rounded-xl p-2 text-xs text-slate-200 outline-none"
                  />
                </div>
              </div>
            </div>

            {/* 7. Renal, Electrolitos, Litio & Fármacos */}
            <div className="bg-slate-900/70 backdrop-blur-2xl border border-cyan-500/20 rounded-3xl p-5 shadow-xl space-y-3 relative overflow-hidden">
              <div className="absolute top-0 left-0 w-1.5 h-full bg-cyan-500" />
              <h3 className="text-xs font-bold text-cyan-300 uppercase tracking-wider flex items-center gap-1.5">
                <Activity className="w-3.5 h-3.5" />
                <span>7. Renal, Electrolitos y Niveles de Fármacos</span>
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 mb-0.5">BUN / Urea</label>
                  <input
                    type="number"
                    value={bun}
                    onChange={(e) => setBun(e.target.value)}
                    placeholder="mg/dL"
                    className="w-full bg-slate-950/70 border border-slate-800 rounded-xl p-2 text-xs text-slate-200 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 mb-0.5">Creatinina</label>
                  <input
                    type="number"
                    step="0.01"
                    value={creatinina}
                    onChange={(e) => setCreatinina(e.target.value)}
                    placeholder="mg/dL"
                    className="w-full bg-slate-950/70 border border-slate-800 rounded-xl p-2 text-xs text-slate-200 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 mb-0.5">Sodio (Na)</label>
                  <input
                    type="number"
                    value={sodio}
                    onChange={(e) => setSodio(e.target.value)}
                    placeholder="mEq/L (135-145)"
                    className="w-full bg-slate-950/70 border border-slate-800 rounded-xl p-2 text-xs text-slate-200 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 mb-0.5">Potasio (K)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={potasio}
                    onChange={(e) => setPotasio(e.target.value)}
                    placeholder="mEq/L (3.5-5.0)"
                    className="w-full bg-slate-950/70 border border-slate-800 rounded-xl p-2 text-xs text-slate-200 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-cyan-400 mb-0.5">Litemia</label>
                  <input
                    type="number"
                    step="0.01"
                    value={litemia}
                    onChange={(e) => setLitemia(e.target.value)}
                    placeholder="mEq/L (0.6-1.0)"
                    className="w-full bg-cyan-950/40 border border-cyan-500/40 rounded-xl p-2 text-xs text-cyan-200 outline-none font-bold"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 mb-0.5">Valproemia</label>
                  <input
                    type="number"
                    value={valproemia}
                    onChange={(e) => setValproemia(e.target.value)}
                    placeholder="ug/mL (50-100)"
                    className="w-full bg-slate-950/70 border border-slate-800 rounded-xl p-2 text-xs text-slate-200 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 mb-0.5">Prolactina</label>
                  <input
                    type="number"
                    step="0.1"
                    value={prolactina}
                    onChange={(e) => setProlactina(e.target.value)}
                    placeholder="ng/mL (<25)"
                    className="w-full bg-slate-950/70 border border-slate-800 rounded-xl p-2 text-xs text-slate-200 outline-none"
                  />
                </div>
              </div>
            </div>

            <button
              onClick={handleAnalizar}
              disabled={isLoading}
              className="w-full bg-gradient-to-r from-rose-600 via-purple-600 to-indigo-600 hover:from-rose-500 hover:to-indigo-500 text-white font-bold py-3.5 rounded-2xl shadow-lg shadow-rose-950/50 transition-all flex items-center justify-center gap-2 text-sm uppercase tracking-wider disabled:opacity-50 cursor-pointer"
            >
              {isLoading ? (
                <>
                  <Sparkles className="w-4 h-4 animate-spin" />
                  <span>Analizando Panel y Cruce Farmacológico...</span>
                </>
              ) : (
                <>
                  <Wand2 className="w-4 h-4" />
                  <span>Analizar Panel Toxicológico con IA</span>
                </>
              )}
            </button>
          </div>

          {/* Right Column: AI Report & Interactive Chat */}
          <div className="lg:col-span-6 space-y-4">
            <div className="bg-slate-900/70 backdrop-blur-2xl border border-purple-500/20 rounded-3xl p-6 shadow-xl space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3 flex-wrap gap-2">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-rose-400" />
                  <span>Reporte Toxicológico Integral</span>
                </h3>
                <div className="flex items-center gap-2 flex-wrap">
                  <button
                    onClick={handleExplicarAPaciente}
                    disabled={!reporteText}
                    className="px-3 py-1.5 bg-emerald-950/70 hover:bg-emerald-900 border border-emerald-500/30 text-emerald-300 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 disabled:opacity-40 cursor-pointer"
                    title="Traducir a lenguaje cálido y sin jerga"
                  >
                    <Languages className="w-3.5 h-3.5" />
                    <span>Traductor Paciente</span>
                  </button>
                  <button
                    onClick={handleExportarPDF}
                    disabled={!reporteText || isExportingPdf}
                    className="px-3 py-1.5 bg-rose-950/80 hover:bg-rose-900 border border-rose-500/40 text-rose-200 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 disabled:opacity-40 shadow-sm cursor-pointer"
                    title="Exportar informe de laboratorio en PDF"
                  >
                    {isExportingPdf ? (
                      <Sparkles className="w-3.5 h-3.5 text-rose-400 animate-spin" />
                    ) : (
                      <FileDown className="w-3.5 h-3.5 text-rose-400" />
                    )}
                    <span>{isExportingPdf ? "Generando..." : "Exportar PDF"}</span>
                  </button>
                  <button
                    onClick={() => window.print()}
                    disabled={!reporteText}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 disabled:opacity-40 cursor-pointer"
                    title="Imprimir informe con membrete"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>Imprimir</span>
                  </button>
                  <button
                    onClick={handleGuardarDrive}
                    disabled={!reporteText || isSavingDrive}
                    className="px-3 py-1.5 bg-purple-950/70 hover:bg-purple-900 border border-purple-500/30 text-purple-200 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 disabled:opacity-40 cursor-pointer"
                  >
                    <HardDrive className="w-3.5 h-3.5 text-purple-400" />
                    <span>{isSavingDrive ? "Guardando..." : "Guardar en Drive"}</span>
                  </button>
                  <button
                    onClick={handleCopiarReporte}
                    disabled={!reporteText}
                    className="px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 disabled:opacity-40 shadow-sm cursor-pointer"
                  >
                    {isCopied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{isCopied ? "✓ Copiado!" : "Copiar a Rayen"}</span>
                  </button>
                </div>
              </div>

              <textarea
                readOnly
                value={reporteText}
                rows={14}
                placeholder="El informe de toxicología clínica, índice AST/ALT, advertencias de Wernicke e interacciones con fármacos aparecerá aquí..."
                className="w-full bg-slate-950/90 border border-slate-800 rounded-2xl p-4 text-xs font-mono text-rose-200 leading-relaxed resize-none focus:outline-none shadow-inner"
              />
            </div>

            {/* Interactive Toxicologist Follow-up Chat */}
            {reporteText && (
              <div className="bg-slate-900/70 backdrop-blur-2xl border border-purple-500/20 rounded-3xl p-5 shadow-xl space-y-3">
                <h4 className="text-xs font-bold text-purple-300 uppercase tracking-wider flex items-center gap-1.5">
                  <MessageSquare className="w-3.5 h-3.5 text-purple-400" />
                  <span>Preguntas de Seguimiento al Toxicólogo IA</span>
                </h4>
                <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-3 max-h-[160px] overflow-y-auto space-y-2 text-xs">
                  {chatMessages.map((m, idx) => (
                    <div
                      key={idx}
                      className={`p-2 rounded-xl text-[11px] ${
                        m.role === "user"
                          ? "bg-purple-950/60 text-purple-200 border border-purple-800/40 text-right ml-6"
                          : "bg-slate-900 text-slate-300 border border-slate-800 mr-6"
                      }`}
                    >
                      {m.text}
                    </div>
                  ))}
                  {isChatLoading && (
                    <div className="text-[10px] text-slate-400 italic flex items-center gap-1.5">
                      <Sparkles className="w-3 h-3 animate-spin text-purple-400" />
                      <span>El toxicólogo está analizando su consulta...</span>
                    </div>
                  )}
                </div>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handleSendFollowUpChat()}
                    placeholder="Ej: ¿Requiere suspender Quetiapina por este valor de transaminasas?"
                    className="flex-1 bg-slate-950 border border-slate-800 rounded-xl p-2 text-xs text-slate-200 outline-none focus:border-purple-500/50"
                  />
                  <button
                    onClick={handleSendFollowUpChat}
                    disabled={isChatLoading}
                    className="px-3 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-bold transition-colors flex items-center justify-center disabled:opacity-50 cursor-pointer"
                  >
                    <Send className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Modal: Traductor Paciente */}
      {isPatientModalOpen && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-emerald-500/30 rounded-3xl w-full max-w-2xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden">
            <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-slate-950/80">
              <div className="flex items-center gap-2">
                <Languages className="w-5 h-5 text-emerald-400" />
                <h3 className="text-base font-bold text-white">
                  Traductor Clínico-Paciente (Discurso Empático)
                </h3>
              </div>
              <button
                onClick={() => setIsPatientModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg cursor-pointer"
              >
                ✕
              </button>
            </div>
            <div className="p-6 overflow-y-auto flex-1 text-xs leading-relaxed space-y-4">
              {isTranslatingPatient ? (
                <div className="flex flex-col items-center justify-center py-12 text-slate-400 gap-3">
                  <Sparkles className="w-8 h-8 text-emerald-400 animate-spin" />
                  <p className="font-bold">Adaptando terminología a lenguaje comprensivo y motivador...</p>
                </div>
              ) : (
                <div className="bg-slate-950 border border-slate-800 rounded-2xl p-5 text-slate-200 font-medium whitespace-pre-line leading-relaxed">
                  {patientExplanation}
                </div>
              )}
            </div>
            <div className="p-4 border-t border-slate-800 bg-slate-950 flex justify-end gap-2">
              <button
                onClick={() => {
                  navigator.clipboard.writeText(patientExplanation);
                  onShowToast("Discurso copiado al portapapeles", "success");
                }}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold text-xs flex items-center gap-1.5 cursor-pointer"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>Copiar Discurso</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Hidden Print Container for Toxicology Lab Report */}
      <div id="laboratorio-print-document" className="print-only print-area hidden">
        <div style={{ borderBottom: "2px solid #334155", paddingBottom: "10px", marginBottom: "16px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
            <div>
              <h2 style={{ fontSize: "16px", fontWeight: "900", color: "#0f172a", margin: 0, textTransform: "uppercase" }}>
                Cosem Rinconada
              </h2>
              <p style={{ fontSize: "11px", color: "#475569", margin: "2px 0 0 0", fontWeight: 600 }}>
                San Ramón, Santiago de Chile
              </p>
              <p style={{ fontSize: "12px", color: "#334155", margin: "4px 0 0 0", fontWeight: "bold" }}>
                INFORME TOXICOLÓGICO Y LABORATORIO
              </p>
            </div>
            <div style={{ textAlign: "right", fontSize: "11px", color: "#64748b" }}>
              <p style={{ margin: 0, fontWeight: "bold", color: "#334155" }}>FECHA DE ANÁLISIS</p>
              <p style={{ margin: "2px 0 0 0" }}>{new Date().toLocaleDateString("es-CL")}</p>
            </div>
          </div>
        </div>

        {/* Patient / Doctor Summary Box */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px", padding: "10px 14px", backgroundColor: "#f8fafc", border: "1px solid #cbd5e1", borderRadius: "6px", fontSize: "12px", marginBottom: "16px" }}>
          <div>
            <p style={{ margin: "2px 0" }}><strong>Contexto Clínico:</strong> {diagnostico || "Evaluación Toxicológica"}</p>
            <p style={{ margin: "2px 0" }}><strong>Edad / Sexo:</strong> {edad} años ({sexo})</p>
          </div>
          <div>
            <p style={{ margin: "2px 0" }}><strong>Fármacos Actuales:</strong> {farmacos || "Ninguno reportado"}</p>
            <p style={{ margin: "2px 0" }}><strong>Médico:</strong> Dr. Andrés Ruiz Miranda</p>
          </div>
        </div>

        <div style={{ whiteSpace: "pre-wrap", fontSize: "12px", lineHeight: "1.6", color: "#111", marginBottom: "30px" }}>
          {reporteText}
        </div>

        <div style={{ textAlign: "center", width: "260px", marginLeft: "auto", marginRight: "auto" }}>
          <div style={{ borderTop: "1.5px solid #000", paddingTop: "6px", fontWeight: "bold", fontSize: "13px", color: "#0f172a" }}>
            Dr. Andrés Ruiz Miranda
          </div>
          <div style={{ fontSize: "11px", color: "#334155" }}>Médico Programa de Tratamiento en Adicciones</div>
          <div style={{ fontSize: "10px", color: "#64748b" }}>Cosem Rinconada, San Ramón</div>
        </div>
      </div>
    </div>
  );
}

export default LaboratorioIA;
