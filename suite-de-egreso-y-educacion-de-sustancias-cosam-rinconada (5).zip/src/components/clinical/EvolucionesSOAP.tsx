import React, { useState, useEffect } from "react";
import {
  FileText,
  Wand2,
  Copy,
  Printer,
  Shield,
  RotateCcw,
  Check,
  HardDrive,
  User,
  CreditCard,
  Sparkles,
  Download,
  FileDown,
  BookmarkPlus,
  Layers,
  Trash2,
  Plus,
  CheckCircle2,
  Cpu,
  Bot,
  ExternalLink,
  Folder,
} from "lucide-react";
import { generateClinicalAI } from "../../services/geminiService";
import {
  GoogleDriveService,
  DEFAULT_SOAP_FOLDER,
} from "../../services/googleDriveService";
import {
  GoogleDocsService,
  PersonalDocExportRecord,
} from "../../services/googleDocsService";
import { exportElementToPdf } from "../../utils/pdfExport";
import { DriveUploadProgress } from "../../types";
import { DriveUploadProgressModal } from "./DriveUploadProgressModal";
import { PersonalDocsAutoExportBar } from "./PersonalDocsAutoExportBar";

interface EvolucionesSOAPProps {
  onShowToast?: (msg: string, type?: "success" | "error" | "info") => void;
  onOpenDriveModal?: () => void;
  isDriveConnected?: boolean;
}

interface SoapTemplate {
  id: string;
  title: string;
  category: "predefinida" | "personalizada";
  subjetivo: string;
  objetivo: string;
  analisis: string;
  plan: string;
}

const DEFAULT_TEMPLATES: SoapTemplate[] = [
  {
    id: "tpl_control_estable",
    title: "1. Control Estable / Abstinencia Sostenida",
    category: "predefinida",
    subjetivo:
      "Paciente acude a control programado en box PAI. Refiere abstinencia sostenida a sustancias diana desde último control. Sueño reparador de 6 a 8 horas, sin craving significativo ni pesadillas de consumo. Buena tolerancia y adherencia a fármacos indicados. Asiste a talleres y cuenta con red de apoyo continente.",
    objetivo:
      "Vigil, orientado témporo-espacialmente. Afecto eutímico, reactivo y modulado. Pensamiento con curso lineal y coherente, sin ideación autolítica ni psicosis. Psicomotricidad normal, sin temblor distal ni signos de abstinencia/intoxicación. Signos vitales estables.",
    analisis:
      "Trastorno por consumo de sustancias en remisión temprana/sostenida. Estabilidad afectiva con adecuada adherencia a la psicofarmacoterapia y alianza terapéutica sólida.",
    plan:
      "1. Mantener esquema psicofarmacológico actual.\n2. Continuar intervenciones con dupla psicosocial / Terapia Ocupacional.\n3. Refuerzo de técnicas de prevención de recaídas.\n4. Próximo control médico en 4 semanas.",
  },
  {
    id: "tpl_recaida_craving",
    title: "2. Descompensación / Recaída con Craving",
    category: "predefinida",
    subjetivo:
      "Acude por aumento marcado de ansiedad y craving en contexto de estresor vital reciente. Relata episodio de consumo (desliz/recaída) hace 48 horas. Refiere insomnio de conciliación, angustia diurna y sentimientos de culpa.",
    objetivo:
      "Inquietud psicomotora leve a moderada, facies ansiosa. Vigil, orientado. Afecto ansioso, hipotímico con labilidad emocional reactiva. Discurso coherente centrado en angustia por el consumo. Sin ideación suicida estructurada. Temblor distal fino leve.",
    analisis:
      "Trastorno por consumo de sustancias con recaída activa y descompensación ansioso-depresiva reactiva. Riesgo de escalada en consumo sin contención intensificada.",
    plan:
      "1. Contención en box y psicoeducación en manejo de recaídas.\n2. Ajuste transitorio de ansiolisis / rescate para manejo de craving e insomnio.\n3. Solicitud de panel toxicológico y perfil hepático de control.\n4. Coordinación prioritaria con dupla psicosocial.\n5. Control médico abreviado en 7-14 días.",
  },
  {
    id: "tpl_ajuste_farmacos",
    title: "3. Ajuste Farmacológico / Titulación",
    category: "predefinida",
    subjetivo:
      "Consulta para evaluación de respuesta a inicio/titulación de psicofármaco. Refiere mejoría parcial en impulsividad y estabilización del ánimo. Refiere adecuada tolerancia gástrica, sin sedación diurna invalidante ni otros efectos adversos.",
    objetivo:
      "Vigil, colaborador. Eutímico a sub-eutímico. Sin rigidez extrapiramidal, temblor ni signos de disfunción autonómica. Presión arterial y frecuencia cardíaca en rangos normales.",
    analisis:
      "Trastorno por consumo en tratamiento activo. Buena tolerancia y respuesta favorable a la farmacoterapia en curso.",
    plan:
      "1. Titulación progresiva de dosis según esquema acordado.\n2. Indicaciones escritas de pautas de alarma y números de urgencia.\n3. Control médico en 4 semanas.",
  },
  {
    id: "tpl_sospecha_intox",
    title: "4. Sospecha de Intoxicación / Evaluación Urgencia",
    category: "predefinida",
    subjetivo:
      "Paciente asiste en condiciones no óptimas o acompañado. Relato confuso o evasivo sobre consumo reciente de sustancias (alcohol / estimulantes / sedantes). Refiere malestar general, cefalea o temblores.",
    objetivo:
      "Vigilancia fluctuante, lenguaje disártrico o hiperverbal. Marcha inestable, temblor evidente, midriasis/miosis reactiva. Sudoración profusa. Signos vitales con taquicardia o variaciones tensionales.",
    analisis:
      "Cuadro clínico compatible con intoxicación aguda por sustancias / síndrome de abstinencia no complicado en evolución.",
    plan:
      "1. Monitorización de signos vitales en box. Reposo y vía aérea despejada.\n2. Hidratación oral según tolerancia.\n3. Derivación inmediata a Servicio de Urgencia (SAR / Hospital) en caso de inestabilidad autonómica.\n4. Suspensión transitoria de sedantes hasta aclaramiento clínico.",
  },
  {
    id: "tpl_egreso_alta",
    title: "5. Evaluación de Egreso PAI (Alta Médica)",
    category: "predefinida",
    subjetivo:
      "Paciente culmina proceso terapéutico integral en PAI. Manifiesta alta satisfacción con los logros alcanzados. Abstinencia sostenida por más de 12 meses, reinserción sociolaboral efectiva y resolución de factores mantenedores.",
    objetivo:
      "Excelente presentación personal, comunicativo, afecto eutímico modulado. Pensamiento estructurado con metas a futuro claras y estilo de vida saludable consolidado.",
    analisis:
      "Trastorno por consumo de sustancias en remisión completa sostenida. Cumplimiento exitoso de objetivos del Plan de Tratamiento Individual.",
    plan:
      "1. Alta médica de COSEM Rinconada.\n2. Contrarreferencia y derivación formal a CESFAM de origen para controles preventivos.\n3. Entrega de pauta de prevención de recaídas y vía de reingreso directo si lo requiere.",
  },
  {
    id: "tpl_ingreso_eval",
    title: "6. Primera Evaluación / Ingreso PAI",
    category: "predefinida",
    subjetivo:
      "Paciente derivado desde APS para ingreso a Programa de Tratamiento en Adicciones. Refiere historia de consumo problemático de larga data. Manifiesta motivación para iniciar tratamiento ambulatorio.",
    objetivo:
      "Vigil, orientado, aspecto cuidado. Examen mental inicial sin ideación autolítica activa ni fenómenos psicóticos. Signos vitales dentro de parámetros normales.",
    analisis:
      "Ingreso a Programa PAI. Paciente en etapa de preparación/acción. Requiere formulación dinámica de caso (4P) y plan integral.",
    plan:
      "1. Solicitud de batería de exámenes generales (hemograma, perfil hepático, función renal, orina toxicológica).\n2. Inicio de esquema psicofarmacológico base.\n3. Ingreso a talleres y evaluación por equipo multidisciplinario.\n4. Control médico en 2 semanas.",
  },
];

export function EvolucionesSOAP({
  onShowToast = () => {},
  onOpenDriveModal = () => {},
  isDriveConnected = false,
}: EvolucionesSOAPProps) {
  const [nombre, setNombre] = useState<string>("");
  const [rut, setRut] = useState<string>("");
  const [subjetivo, setSubjetivo] = useState<string>("");
  const [objetivo, setObjetivo] = useState<string>("");
  const [analisis, setAnalisis] = useState<string>("");
  const [plan, setPlan] = useState<string>("");
  const [resultado, setResultado] = useState<string>("");
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isSavingDrive, setIsSavingDrive] = useState<boolean>(false);
  const [isExportingPdf, setIsExportingPdf] = useState<boolean>(false);
  const [isCopied, setIsCopied] = useState<boolean>(false);

  // Google Drive Sync & Progress state
  const [autoSync, setAutoSync] = useState<boolean>(() =>
    GoogleDriveService.getAutoSync("soap")
  );
  const [targetFolder, setTargetFolder] = useState<string>(() =>
    GoogleDriveService.getModuleFolder("soap", DEFAULT_SOAP_FOLDER)
  );
  const [driveProgress, setDriveProgress] = useState<DriveUploadProgress | null>(
    null
  );
  const [isProgressModalOpen, setIsProgressModalOpen] = useState<boolean>(false);
  const [lastUploadedDoc, setLastUploadedDoc] = useState<{
    fileName: string;
    folderName: string;
    url?: string;
    time: string;
  } | null>(null);
  const [lastExportedPersonalDoc, setLastExportedPersonalDoc] =
    useState<PersonalDocExportRecord | null>(null);

  // Plantillas Rápidas State
  const [customTemplates, setCustomTemplates] = useState<SoapTemplate[]>([]);
  const [isTemplatesOpen, setIsTemplatesOpen] = useState<boolean>(false);
  const [newTemplateTitle, setNewTemplateTitle] = useState<string>("");
  const [isSavingCustomTpl, setIsSavingCustomTpl] = useState<boolean>(false);

  // Load custom templates from localStorage
  useEffect(() => {
    try {
      const saved = localStorage.getItem("cosem_custom_soap_templates");
      if (saved) {
        setCustomTemplates(JSON.parse(saved));
      }
    } catch (e) {
      console.error("Error loading custom templates:", e);
    }
  }, []);

  const handleSaveCustomTemplate = () => {
    if (!newTemplateTitle.trim()) {
      onShowToast("Escriba un título para la plantilla", "error");
      return;
    }
    if (!subjetivo && !objetivo && !analisis && !plan) {
      onShowToast("Complete al menos un campo SOAP para guardar la plantilla", "error");
      return;
    }
    const newTpl: SoapTemplate = {
      id: `custom_${Date.now()}`,
      title: newTemplateTitle.trim(),
      category: "personalizada",
      subjetivo,
      objetivo,
      analisis,
      plan,
    };
    const updated = [newTpl, ...customTemplates];
    setCustomTemplates(updated);
    try {
      localStorage.setItem("cosem_custom_soap_templates", JSON.stringify(updated));
      onShowToast(`Plantilla "${newTpl.title}" guardada exitosamente`, "success");
      setNewTemplateTitle("");
      setIsSavingCustomTpl(false);
    } catch (e) {
      onShowToast("Error al guardar en memoria local", "error");
    }
  };

  const handleDeleteCustomTemplate = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = customTemplates.filter((t) => t.id !== id);
    setCustomTemplates(updated);
    try {
      localStorage.setItem("cosem_custom_soap_templates", JSON.stringify(updated));
      onShowToast("Plantilla personalizada eliminada", "info");
    } catch (e) {
      console.error(e);
    }
  };

  const handleLoadTemplate = (tpl: SoapTemplate) => {
    setSubjetivo(tpl.subjetivo);
    setObjetivo(tpl.objetivo);
    setAnalisis(tpl.analisis);
    setPlan(tpl.plan);
    onShowToast(`Plantilla "${tpl.title}" cargada en el formulario`, "success");
  };

  // Upload document to Google Drive with real-time progress indicator
  const uploadDocumentToDrive = async (
    contentToUpload: string,
    isAutomatic = false
  ) => {
    if (!contentToUpload.trim()) {
      onShowToast("No hay contenido para enviar a Google Drive", "error");
      return;
    }
    if (!isDriveConnected) {
      if (!isAutomatic) {
        onOpenDriveModal();
      }
      return;
    }
    setIsSavingDrive(true);
    setIsProgressModalOpen(true);
    const fecha = new Date().toISOString().split("T")[0];
    const nombreLimpio = (nombre.trim() || "Paciente").replace(/\s+/g, "_");
    const rutLimpio = (rut.trim() || "SR").replace(/\./g, "").replace(/-/g, "_");
    const fileName = `Evolucion_SOAP_${nombreLimpio}_${rutLimpio}_${fecha}.txt`;

    try {
      const uploadedFile = await GoogleDriveService.saveClinicalDocument({
        fileName,
        content: contentToUpload,
        folderName: targetFolder,
        onProgress: (prog) => {
          setDriveProgress(prog);
        },
      });
      setLastUploadedDoc({
        fileName: uploadedFile.name,
        folderName: targetFolder,
        url: uploadedFile.webViewLink,
        time: new Date().toLocaleTimeString("es-CL", {
          hour: "2-digit",
          minute: "2-digit",
        }),
      });
      onShowToast(
        isAutomatic
          ? `Auto-sincronizado en Drive: ${uploadedFile.name}`
          : `Guardado en Google Drive: ${uploadedFile.name}`,
        "success"
      );
    } catch (err: any) {
      console.error("Drive upload error:", err);
      onShowToast(err.message || "Error al enviar documento a Google Drive", "error");
    } finally {
      setIsSavingDrive(false);
    }
  };

  const handleEstructurar = async () => {
    if (!subjetivo && !objetivo && !analisis && !plan) {
      onShowToast("Escriba apuntes en al menos una sección (S, O, A, P)", "error");
      return;
    }
    setIsLoading(true);

    // ESCUDO DE PRIVACIDAD: Datos personales no se transmiten a la nube
    const nombreSeguro = nombre.trim() || "Paciente";
    const rutSeguro = rut.trim() || "Sin RUT";

    const prompt = `Actúa como un médico psiquiatra en Chile redactando una evolución clínica formal para el registro electrónico Rayen APS. Toma los siguientes apuntes rápidos y dales estructura profesional SOAP (Subjetivo, Objetivo, Análisis, Plan).
Reglas estrictas:
- Corrige ortografía y redacta con terminología médica técnica de psiquiatría.
- Nunca inventes síntomas o medicamentos que no estén presentes en los apuntes.
- Al referirte al paciente en el texto, usa estrictamente la etiqueta [NOMBRE_PACIENTE].
- Redacta de forma clara, directa y limpia.

Apuntes recibidos:
S (Subjetivo): ${subjetivo || "Sin información reportada."}
O (Objetivo): ${objetivo || "Sin hallazgos físicos o examen mental específico reportado."}
A (Análisis): ${analisis || "Impresión clínica y evolución en estudio."}
P (Plan): ${plan || "Continuar controles programados y farmacoterapia."}`;

    try {
      const aiResponse = await generateClinicalAI({
        prompt,
        systemInstruction: "Eres un médico especialista en psiquiatría y adicciones en Chile.",
        temperature: 0.2,
      });

      // Restauración Local de Datos Protegidos
      const fechaHoy = new Date().toLocaleDateString("es-CL");
      const encabezado = `EVOLUCIÓN CLÍNICA - COSEM RINCONADA\nPaciente: ${nombreSeguro}\nRUT: ${rutSeguro}\nFecha: ${fechaHoy}\n----------------------------------------\n\n`;
      const textoFinal = aiResponse
        .replace(/\[NOMBRE_PACIENTE\]/g, nombreSeguro)
        .replace(/\*\*(.*?)\*\*/g, "$1");
      const documentoCompleto = encabezado + textoFinal;

      setResultado(documentoCompleto);
      onShowToast("Evolución SOAP estructurada con éxito", "success");

      // Exportación automática a Documento Personal en Google Docs (autenticado con Firebase Auth)
      if (
        GoogleDriveService.isConnected() &&
        GoogleDocsService.isAutoExportEnabled() &&
        GoogleDocsService.getExportMode() === "new_doc_per_report"
      ) {
        try {
          const exportedDoc = await GoogleDocsService.exportClinicalReportToPersonalDoc({
            reportType: "Evolución SOAP",
            patientName: nombreSeguro,
            patientRut: rutSeguro,
            content: documentoCompleto,
            modeOverride: "new_doc_per_report",
          });
          setLastExportedPersonalDoc(exportedDoc);
          onShowToast(
            `Exportado automáticamente a Google Docs: ${exportedDoc.documentTitle}`,
            "success"
          );
        } catch (docErr: any) {
          console.warn("Auto-export to personal Google Doc warning:", docErr);
        }
      }

      // Auto-envío a Google Drive si está habilitado y conectado
      if (autoSync && isDriveConnected) {
        uploadDocumentToDrive(documentoCompleto, true);
      }
    } catch (err: any) {
      console.error(err);
      onShowToast(err.message || "Error al estructurar evolución clínica", "error");
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopiar = () => {
    if (!resultado) {
      onShowToast("No hay evolución generada para copiar", "error");
      return;
    }
    navigator.clipboard.writeText(resultado).then(() => {
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2000);
      onShowToast("Copiado al portapapeles en formato Rayen", "success");
    });
  };

  const handleImprimir = () => {
    if (!resultado) {
      onShowToast("No hay evolución para imprimir", "error");
      return;
    }
    window.print();
  };

  const handleExportarPDF = async () => {
    if (!resultado) {
      onShowToast("Genere o escriba la evolución primero", "error");
      return;
    }
    setIsExportingPdf(true);
    try {
      const fecha = new Date().toISOString().split("T")[0];
      const nombreLimpio = (nombre.trim() || "Paciente").replace(/\s+/g, "_");
      const filename = `Evolucion_SOAP_${nombreLimpio}_${fecha}.pdf`;
      await exportElementToPdf("soap-documento-impresion", {
        filename,
      });
      onShowToast(`PDF descargado exitosamente: ${filename}`, "success");
    } catch (err: any) {
      console.error("Error al exportar PDF:", err);
      onShowToast(err.message || "Error al generar archivo PDF", "error");
    } finally {
      setIsExportingPdf(false);
    }
  };

  const handleGuardarEnDrive = async () => {
    if (!resultado) {
      onShowToast("Genere la evolución primero", "error");
      return;
    }
    uploadDocumentToDrive(resultado, false);
  };

  const handleLimpiar = () => {
    setNombre("");
    setRut("");
    setSubjetivo("");
    setObjetivo("");
    setAnalisis("");
    setPlan("");
    setResultado("");
    setLastUploadedDoc(null);
    onShowToast("Formulario reiniciado", "info");
  };

  const allTemplates = [...DEFAULT_TEMPLATES, ...customTemplates];

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Drive Upload Progress Modal */}
      <DriveUploadProgressModal
        isOpen={isProgressModalOpen}
        progress={driveProgress}
        onClose={() => setIsProgressModalOpen(false)}
        onRetry={() => uploadDocumentToDrive(resultado, false)}
      />

      {/* Header Bar con Glassmorphism */}
      <div className="clinical-card overflow-hidden">
        <div className="clinical-glass-header px-5 py-3.5 flex flex-col md:flex-row justify-between items-start md:items-center gap-3">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#075985]/10 border border-[#075985]/20 flex items-center justify-center text-[#075985] dark:text-sky-400">
              <FileText className="w-4 h-4" strokeWidth={1.85} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-[#075985] dark:text-sky-300 bg-sky-50 dark:bg-sky-950/60 px-2 py-0.5 rounded border border-sky-200/80 dark:border-sky-800/60">
                  EVOLUCIÓN CLÍNICA • RAYEN
                </span>
                <span className="text-[10px] font-medium text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-200/70 dark:border-emerald-800/50 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                  Asistencia IA
                </span>
              </div>
              <h2 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white tracking-tight mt-0.5">
                Redactor Clínico Estructurado (Formato SOAP)
              </h2>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {/* Toggle Plantillas Button */}
            <button
              onClick={() => setIsTemplatesOpen(!isTemplatesOpen)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 border cursor-pointer ${
                isTemplatesOpen
                  ? "bg-[#075985] text-white border-[#075985] shadow-xs"
                  : "bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-750 text-slate-700 dark:text-slate-200 border-slate-200/90 dark:border-slate-700"
              }`}
            >
              <Layers className="w-3.5 h-3.5" strokeWidth={1.75} />
              <span>Plantillas Rápidas ({allTemplates.length})</span>
            </button>
            <button
              onClick={handleLimpiar}
              className="px-3 py-1.5 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-750 text-slate-700 dark:text-slate-200 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 border border-slate-200/90 dark:border-slate-700 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" strokeWidth={1.75} />
              <span>Limpiar</span>
            </button>
          </div>
        </div>
      </div>

      {/* Barra de Exportación Automática a Documento Personal en Google Docs (Firebase Auth) */}
      <PersonalDocsAutoExportBar
        reportType="Evolución SOAP"
        patientName={nombre || "Paciente"}
        patientRut={rut || "Sin RUT"}
        generatedContent={resultado}
        lastExportedRecord={lastExportedPersonalDoc}
        onExportSuccess={(rec) => setLastExportedPersonalDoc(rec)}
        onShowToast={onShowToast}
      />

      {/* Plantillas Rápidas Drawer / Panel */}
      {isTemplatesOpen && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 sm:p-5 shadow-xs space-y-4 transition-colors">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-3">
            <div>
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white flex items-center gap-2">
                <Layers className="w-4 h-4 text-slate-600 dark:text-slate-300" strokeWidth={1.75} />
                <span>Plantillas Rápidas de Evolución</span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Seleccione una plantilla para autocompletar las secciones SOAP del box.
              </p>
            </div>
            <button
              onClick={() => setIsSavingCustomTpl(!isSavingCustomTpl)}
              className="px-3 py-1.5 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-750 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors shrink-0 cursor-pointer"
            >
              <BookmarkPlus className="w-3.5 h-3.5" strokeWidth={1.75} />
              <span>{isSavingCustomTpl ? "Cancelar" : "Guardar como Plantilla"}</span>
            </button>
          </div>

          {/* Form to save current text as custom template */}
          {isSavingCustomTpl && (
            <div className="bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl p-3 flex flex-col sm:flex-row items-center gap-2.5">
              <input
                type="text"
                value={newTemplateTitle}
                onChange={(e) => setNewTemplateTitle(e.target.value)}
                placeholder="Nombre de su plantilla (ej: Control Semanal BZD / Deshabituación Alcohol)..."
                className="flex-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-800 dark:text-slate-200 outline-hidden focus:ring-1 focus:ring-slate-400"
              />
              <button
                onClick={handleSaveCustomTemplate}
                className="w-full sm:w-auto px-3.5 py-1.5 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-lg text-xs font-medium transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
              >
                <Plus className="w-3.5 h-3.5" strokeWidth={1.75} />
                <span>Guardar</span>
              </button>
            </div>
          )}

          {/* Templates Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 max-h-[320px] overflow-y-auto pr-1">
            {allTemplates.map((tpl) => (
              <div
                key={tpl.id}
                onClick={() => handleLoadTemplate(tpl)}
                className="bg-slate-50 hover:bg-slate-100 dark:bg-slate-800/60 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3.5 cursor-pointer transition-colors flex flex-col justify-between group"
              >
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-semibold text-slate-900 dark:text-white line-clamp-1">
                      {tpl.title}
                    </span>
                    {tpl.category === "personalizada" && (
                      <button
                        onClick={(e) => handleDeleteCustomTemplate(tpl.id, e)}
                        title="Eliminar plantilla"
                        className="text-slate-400 hover:text-rose-500 p-0.5 transition-colors cursor-pointer"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-600 dark:text-slate-400 line-clamp-2 leading-relaxed">
                    <strong>S:</strong> {tpl.subjetivo}
                  </p>
                </div>
                <div className="mt-2 pt-2 border-t border-slate-200/80 dark:border-slate-700/80 flex items-center justify-between">
                  <span className="text-[10px] text-slate-500">
                    {tpl.category === "personalizada" ? "Personalizada" : "Estándar"}
                  </span>
                  <span className="text-[11px] font-medium text-slate-700 dark:text-slate-300 flex items-center gap-1">
                    <span>Cargar</span>
                    <span>→</span>
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Main Grid: Two-Pane Viewport with Sticky Glassmorphism Headers */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 lg:h-[calc(100vh-13rem)] lg:min-h-[580px]">
        {/* Left Column: Input Sections */}
        <div className="clinical-card flex flex-col justify-between transition-colors overflow-hidden lg:h-full">
          {/* Sticky Glassmorphism Header de la columna */}
          <div className="clinical-glass-header shrink-0 px-5 py-3.5">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800 dark:text-slate-200 flex items-center gap-2">
                <FileText className="w-4 h-4 text-[#075985] dark:text-sky-400" strokeWidth={1.85} />
                <span>Borrador Clínico de Box (S-O-A-P)</span>
              </h3>
              <span className="text-[10px] font-mono text-slate-500 dark:text-slate-400 font-semibold">
                Apuntes de Consulta
              </span>
            </div>
          </div>

          {/* Formulario scrolleable independientemente */}
          <div className="flex-1 overflow-y-auto p-5 space-y-3">
            {/* Identification */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-300 mb-1 flex items-center gap-1">
                  <User className="w-3 h-3 text-slate-400" /> Nombre del Paciente
                </label>
                <input
                  type="text"
                  value={nombre}
                  onChange={(e) => setNombre(e.target.value)}
                  placeholder="Ej: Juan Pérez Soto"
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg p-2 text-xs text-slate-800 dark:text-slate-200 placeholder:text-slate-400 outline-hidden focus:ring-1 focus:ring-slate-400 transition-colors"
                />
              </div>
              <div>
                <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-300 mb-1 flex items-center gap-1">
                  <CreditCard className="w-3 h-3 text-slate-400" /> RUT / Ficha
                </label>
                <input
                  type="text"
                  value={rut}
                  onChange={(e) => setRut(e.target.value)}
                  placeholder="Ej: 12.345.678-9"
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg p-2 text-xs text-slate-800 dark:text-slate-200 placeholder:text-slate-400 outline-hidden focus:ring-1 focus:ring-slate-400 transition-colors"
                />
              </div>
            </div>

            {/* SOAP Sections */}
            <div className="space-y-2.5">
              <div className="bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl p-3 focus-within:ring-1 focus-within:ring-slate-400 transition-colors">
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1">
                  S - Subjetivo (Relato del paciente / craving / sueño / ánimo)
                </label>
                <textarea
                  value={subjetivo}
                  onChange={(e) => setSubjetivo(e.target.value)}
                  rows={2}
                  placeholder="Refiere mantenerse limpio, duerme mejor pero persiste ansiedad nocturna..."
                  className="w-full bg-transparent text-xs text-slate-800 dark:text-slate-200 outline-hidden resize-none placeholder:text-slate-400"
                />
              </div>
              <div className="bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl p-3 focus-within:ring-1 focus-within:ring-slate-400 transition-colors">
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1">
                  O - Objetivo (Examen mental / signos vitales / psicomotricidad)
                </label>
                <textarea
                  value={objetivo}
                  onChange={(e) => setObjetivo(e.target.value)}
                  rows={2}
                  placeholder="Vigil, orientado, eutímico, sin temblor distal, PA 120/80..."
                  className="w-full bg-transparent text-xs text-slate-800 dark:text-slate-200 outline-hidden resize-none placeholder:text-slate-400"
                />
              </div>
              <div className="bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl p-3 focus-within:ring-1 focus-within:ring-slate-400 transition-colors">
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1">
                  A - Análisis (Impresión clínica / adherencia / riesgo / estabilidad)
                </label>
                <textarea
                  value={analisis}
                  onChange={(e) => setAnalisis(e.target.value)}
                  rows={2}
                  placeholder="F10.2 en remisión temprana. Buena respuesta a Sertralina..."
                  className="w-full bg-transparent text-xs text-slate-800 dark:text-slate-200 outline-hidden resize-none placeholder:text-slate-400"
                />
              </div>
              <div className="bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl p-3 focus-within:ring-1 focus-within:ring-slate-400 transition-colors">
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1">
                  P - Plan (Ajuste farmacológico / citas / indicaciones / derivación)
                </label>
                <textarea
                  value={plan}
                  onChange={(e) => setPlan(e.target.value)}
                  rows={2}
                  placeholder="Mantener Sertralina 100mg. Bajar Clonazepam a 0.5mg noche. Control en 4 semanas..."
                  className="w-full bg-transparent text-xs text-slate-800 dark:text-slate-200 outline-hidden resize-none placeholder:text-slate-400"
                />
              </div>
            </div>
          </div>

          {/* Botón de acción anclado permanentemente al fondo de la columna izquierda */}
          <div className="shrink-0 px-5 py-3.5 border-t border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/60">
            <button
              onClick={handleEstructurar}
              disabled={isLoading || isSavingDrive}
              className="w-full bg-[#075985] hover:bg-[#0c4a6e] text-white font-semibold py-2.5 rounded-xl shadow-xs transition-colors flex items-center justify-center gap-2 text-xs uppercase tracking-wider disabled:opacity-50 cursor-pointer"
            >
              {isLoading ? (
                <>
                  <Sparkles className="w-4 h-4 animate-spin" />
                  <span>Estructurando SOAP con IA...</span>
                </>
              ) : (
                <>
                  <Wand2 className="w-4 h-4" strokeWidth={1.75} />
                  <span>Estructurar Evolución SOAP</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right Column: Result Box & Actions (Sticky Glassmorphism Header) */}
        <div className="clinical-card flex flex-col justify-between transition-colors overflow-hidden lg:h-full">
          {/* Barra de herramientas superior anclada con Glassmorphism */}
          <div className="clinical-glass-header shrink-0 px-5 py-3 flex items-center justify-between flex-wrap gap-2">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800 dark:text-slate-200 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-[#075985] dark:text-sky-400" strokeWidth={1.85} />
              <span>Evolución Final Estructurada</span>
            </h3>
            <div className="flex items-center gap-2 flex-wrap">
              <button
                id="btn-guardar-drive-soap"
                onClick={handleGuardarEnDrive}
                disabled={!resultado || isSavingDrive}
                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-750 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5 disabled:opacity-40 cursor-pointer shadow-xs"
                title="Enviar documento a Google Drive"
              >
                <HardDrive className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" strokeWidth={1.75} />
                <span>{isSavingDrive ? "Enviando..." : "Enviar a Drive"}</span>
              </button>
              <button
                onClick={handleCopiar}
                disabled={!resultado}
                className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-900 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5 disabled:opacity-40 shadow-xs cursor-pointer"
              >
                {isCopied ? <Check className="w-3.5 h-3.5" strokeWidth={2} /> : <Copy className="w-3.5 h-3.5" strokeWidth={1.75} />}
                <span>{isCopied ? "Copiado" : "Copiar a Rayen"}</span>
              </button>
              <button
                onClick={handleExportarPDF}
                disabled={!resultado || isExportingPdf}
                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-750 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5 disabled:opacity-40 cursor-pointer shadow-xs"
                title="Exportar archivo PDF oficial formateado"
              >
                {isExportingPdf ? (
                  <Sparkles className="w-3.5 h-3.5 text-slate-500 animate-spin" />
                ) : (
                  <FileDown className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" strokeWidth={1.75} />
                )}
                <span>{isExportingPdf ? "Generando..." : "PDF"}</span>
              </button>
              <button
                onClick={handleImprimir}
                disabled={!resultado}
                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-750 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5 disabled:opacity-40 cursor-pointer shadow-xs"
              >
                <Printer className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" strokeWidth={1.75} />
                <span>Imprimir</span>
              </button>
            </div>
          </div>

          {/* Last Uploaded Document Banner */}
          {lastUploadedDoc && (
            <div className="shrink-0 mb-2 p-2.5 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl flex items-center justify-between gap-2 text-xs">
              <div className="flex items-center gap-2 truncate">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                <span className="text-slate-700 dark:text-slate-300 font-medium truncate text-[11px]">
                  Sincronizado en <strong>{lastUploadedDoc.folderName}</strong> a las {lastUploadedDoc.time}
                </span>
              </div>
              {lastUploadedDoc.url && (
                <a
                  href={lastUploadedDoc.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="py-1 px-2.5 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-lg font-medium text-[10px] flex items-center gap-1 shrink-0 transition-colors shadow-xs"
                >
                  <span>Abrir</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              )}
            </div>
          )}

          {/* Área de texto que se expande para llenar la altura y scrollea internamente */}
          <div className="flex-1 flex flex-col min-h-[220px] overflow-hidden px-5 pt-3">
            <textarea
              value={resultado}
              onChange={(e) => setResultado(e.target.value)}
              placeholder="El resultado estructurado por la IA aparecerá aquí... Puede editar el texto libremente antes de copiarlo a la ficha Rayen o guardarlo en Google Drive."
              className="w-full flex-1 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 focus:border-[#075985] rounded-xl p-3.5 text-xs font-mono text-slate-800 dark:text-slate-200 leading-relaxed resize-none outline-hidden overflow-y-auto"
            />
          </div>

          {/* Privacy Shield & AI Status Indicator anclado al pie */}
          <div className="shrink-0 px-5 py-3">
            <div className="bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 flex items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-lg bg-white dark:bg-slate-800 text-[#075985] dark:text-sky-400 flex items-center justify-center shrink-0 border border-slate-200 dark:border-slate-700">
                  <Shield className="w-3 h-3" strokeWidth={1.75} />
                </div>
                <div>
                  <p className="text-[11px] font-semibold text-slate-800 dark:text-slate-200">
                    Escudo de Privacidad Local • Ley N° 20.584
                  </p>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400">
                    Anonimización previa según normativa de salud mental.
                  </p>
                </div>
              </div>
              <span className="text-[10px] font-mono text-slate-600 dark:text-slate-400 bg-white dark:bg-slate-900 px-2 py-0.5 rounded border border-slate-200 dark:border-slate-700 shrink-0">
                gemini-3-flash
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Print & PDF Document Container with Exact Official Letterhead & Signature */}
      <div id="soap-documento-impresion" className="print-only print-area hidden">
        <div style={{ borderBottom: "2px solid #334155", paddingBottom: "12px", marginBottom: "20px", display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
          <div>
            <h2 style={{ fontSize: "16px", fontWeight: "bold", color: "#0f172a", margin: 0, textTransform: "uppercase", letterSpacing: "0.5px" }}>
              Cosem Rinconada
            </h2>
            <p style={{ fontSize: "11px", color: "#475569", margin: "3px 0 0 0", fontWeight: 600 }}>
              San Ramón, Santiago de Chile
            </p>
          </div>
          <div style={{ textAlign: "right", fontSize: "10px", color: "#64748b" }}>
            <p style={{ margin: 0, fontWeight: "bold", color: "#334155" }}>REGISTRO CLÍNICO SOAP</p>
            <p style={{ margin: "2px 0 0 0" }}>Fecha: {new Date().toLocaleDateString("es-CL")}</p>
          </div>
        </div>
        <div style={{ whiteSpace: "pre-wrap", fontSize: "12.5px", lineHeight: "1.65", color: "#0f172a", fontFamily: "'Plus Jakarta Sans', Arial, sans-serif" }}>
          {resultado}
        </div>
        <div style={{ marginTop: "50px", paddingTop: "15px", display: "flex", justifyContent: "space-between", alignItems: "flex-end", borderTop: "1px dashed #cbd5e1" }}>
          <div style={{ fontSize: "9.5px", color: "#64748b", maxWidth: "340px", lineHeight: "1.4" }}>
            <p style={{ margin: 0, fontWeight: "bold" }}>Documento Clínico Confidencial</p>
            <p style={{ margin: "2px 0 0 0" }}>
              Ley N° 21.331 y Ley N° 20.584 de Derechos y Deberes de los Pacientes. Registro electrónico para ficha Rayen APS.
            </p>
          </div>
          <div style={{ textAlign: "center", width: "260px" }}>
            <div style={{ borderTop: "1px solid #334155", paddingTop: "6px", fontWeight: "bold", fontSize: "12px", color: "#0f172a" }}>
              Dr. Andrés Ruiz Miranda
            </div>
            <div style={{ fontSize: "10.5px", color: "#475569" }}>Médico Programa de Tratamiento en Adicciones</div>
            <div style={{ fontSize: "9.5px", color: "#64748b" }}>Cosem Rinconada, San Ramón</div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default EvolucionesSOAP;
