import { useState, useEffect } from "react";
import {
  FileText,
  Plus,
  Trash2,
  Sparkles,
  RefreshCw,
  ExternalLink,
  CheckCircle2,
  AlertCircle,
  FolderOpen,
  Eye,
  FilePlus2,
  ClipboardList,
  Users,
  Send,
  X,
} from "lucide-react";
import { GoogleDriveService, DEFAULT_DOCS_FOLDER } from "../../services/googleDriveService";
import {
  GoogleDocsService,
  DocsDocumentSummary,
  DocsDocumentDetails,
  DocsSectionInput,
  PersonalDocExportRecord,
} from "../../services/googleDocsService";
import { generateClinicalAI } from "../../services/geminiService";
import { ClinicalMeetingCase, PaiRecord, SoapRecord } from "../../types";
import { GoogleSignInButton } from "./GoogleSignInButton";

export function DocumentosDocs() {
  const [isConnected, setIsConnected] = useState(() => GoogleDriveService.isConnected());
  const [isConnecting, setIsConnecting] = useState(false);

  const [activeTab, setActiveTab] = useState<"builder" | "browser">("builder");

  // Estado del constructor de documentos
  const [docTitle, setDocTitle] = useState(
    `Informe Clínico COSAM Rinconada - ${new Date().toLocaleDateString("es-CL")}`
  );
  const [docSubtitle, setDocSubtitle] = useState(
    "Unidad de Salud Mental Comunitaria · Servicio de Salud Metropolitano Sur"
  );
  const [metadataHeader, setMetadataHeader] = useState(
    `Fecha de emisión: ${new Date().toLocaleDateString("es-CL")} | Médico Tratante: Box Psiquiatría Adultos`
  );
  const [sections, setSections] = useState<DocsSectionInput[]>([
    {
      heading: "1. Identificación y Motivo de Evaluación",
      body: "Paciente en seguimiento regular en COSAM Rinconada. Se emite presente documento para registro clínico y coordinación de red asistencial.",
    },
    {
      heading: "2. Síntesis Diagnóstica Multi-axial (CIE-10 / DSM-5)",
      body: "- Eje Clínico Principal:\n- Comorbilidades Médicas / Psicosociales:\n- Nivel de Funcionalidad Global:",
    },
    {
      heading: "3. Plan Farmacológico y Terapéutico Actual",
      body: "Esquema psicofarmacológico conciliado, adherencia reportada, control de exámenes y pauta de seguimiento multidisciplinario.",
    },
    {
      heading: "4. Indicaciones y Acuerdos de Continuidad de Cuidados",
      body: "Coordinación con APS / CESFAM, educación sobre signos de alerta y fecha de próximo control médico.",
    },
  ]);

  const [aiTopic, setAiTopic] = useState("");
  const [isGeneratingAI, setIsGeneratingAI] = useState(false);
  const [isCreatingDoc, setIsCreatingDoc] = useState(false);

  // Estado del explorador de documentos existentes en Google Docs
  const [existingDocs, setExistingDocs] = useState<DocsDocumentSummary[]>([]);
  const [isLoadingDocs, setIsLoadingDocs] = useState(false);
  const [selectedDocDetails, setSelectedDocDetails] = useState<DocsDocumentDetails | null>(null);
  const [isLoadingDetails, setIsLoadingDetails] = useState(false);

  // Estado para anexar sección a un Google Doc existente (con confirmación obligatoria)
  const [appendHeading, setAppendHeading] = useState("Adenda / Evolución Complementaria");
  const [appendBody, setAppendBody] = useState("");
  const [isAppending, setIsAppending] = useState(false);

  // Modal de confirmación obligatoria para operaciones mutables/destructivas
  const [confirmDialog, setConfirmDialog] = useState<{
    title: string;
    description: string;
    confirmLabel: string;
    variant: "danger" | "primary";
    onConfirm: () => Promise<void>;
  } | null>(null);

  const [statusBanner, setStatusBanner] = useState<{
    type: "success" | "error" | "info";
    message: string;
    link?: string;
  } | null>(null);

  // Registros locales para importar con 1 clic
  const [savedMeetings, setSavedMeetings] = useState<ClinicalMeetingCase[]>([]);
  const [savedPAIs, setSavedPAIs] = useState<PaiRecord[]>([]);
  const [savedSOAPs, setSavedSOAPs] = useState<SoapRecord[]>([]);
  const [exportHistory, setExportHistory] = useState<PersonalDocExportRecord[]>(() =>
    GoogleDocsService.getExportHistory()
  );

  useEffect(() => {
    const syncAuth = () => {
      const connected = GoogleDriveService.isConnected();
      setIsConnected(connected);
      if (connected) {
        fetchDocuments();
      }
    };
    window.addEventListener("cosam:gdrive-auth-changed", syncAuth);

    try {
      const mRaw = localStorage.getItem("cosam_reuniones_v2");
      if (mRaw) setSavedMeetings(JSON.parse(mRaw));
      const pRaw = localStorage.getItem("cosam_pai_ingresos");
      if (pRaw) setSavedPAIs(JSON.parse(pRaw));
      const sRaw = localStorage.getItem("cosam_soap_notes_v2");
      if (sRaw) setSavedSOAPs(JSON.parse(sRaw));
    } catch {
      // Ignore storage errors
    }

    if (GoogleDriveService.isConnected()) {
      fetchDocuments();
    }

    const handleExportHistoryUpdate = () => {
      setExportHistory(GoogleDocsService.getExportHistory());
    };
    window.addEventListener("cosam:gdocs-export-completed", handleExportHistoryUpdate);

    return () => {
      window.removeEventListener("cosam:gdrive-auth-changed", syncAuth);
      window.removeEventListener("cosam:gdocs-export-completed", handleExportHistoryUpdate);
    };
  }, []);

  const handleConnectGoogle = async () => {
    setIsConnecting(true);
    setStatusBanner(null);
    try {
      await GoogleDriveService.requestAuth();
      setIsConnected(true);
      setStatusBanner({
        type: "success",
        message: "Cuenta de Google conectada con permisos para Google Docs, Gmail, Slides y Drive.",
      });
      await fetchDocuments();
    } catch (err: any) {
      setStatusBanner({
        type: "error",
        message: err.message || "Error al conectar con Google Workspace.",
      });
    } finally {
      setIsConnecting(false);
    }
  };

  const fetchDocuments = async () => {
    if (!GoogleDriveService.isConnected()) return;
    setIsLoadingDocs(true);
    try {
      const list = await GoogleDocsService.listDocuments(25);
      setExistingDocs(list);
    } catch (err: any) {
      console.warn("Error listing Google Docs:", err);
    } finally {
      setIsLoadingDocs(false);
    }
  };

  const handleInspectDocument = async (docId: string) => {
    setIsLoadingDetails(true);
    setStatusBanner(null);
    try {
      const details = await GoogleDocsService.getDocumentDetails(docId);
      setSelectedDocDetails(details);
    } catch (err: any) {
      setStatusBanner({
        type: "error",
        message: err.message || "No se pudo leer el documento seleccionado.",
      });
    } finally {
      setIsLoadingDetails(false);
    }
  };

  const handleLoadTemplate = (
    templateType: "certificado" | "contraderivacion" | "acta_comite" | "epicrisis_pai"
  ) => {
    const today = new Date().toLocaleDateString("es-CL");
    if (templateType === "certificado") {
      setDocTitle(`Informe Médico Psiquiátrico - ${today}`);
      setDocSubtitle("Certificación Clínica Especializada · COSAM Rinconada");
      setSections([
        {
          heading: "1. Antecedentes de Identificación",
          body: "Nombre Completo:\nRUT:\nEdad:\nComuna: San Ramón",
        },
        {
          heading: "2. Síntesis Clínica y Diagnóstica",
          body: "Paciente en control especializado de psiquiatría adulto en COSAM Rinconada. Cuadro clínico compatible con:",
        },
        {
          heading: "3. Tratamiento Actual e Indicaciones",
          body: "Mantiene esquema psicofarmacológico regular y controles periódicos por equipo multidisciplinario.",
        },
        {
          heading: "4. Conclusión y Propósito del Informe",
          body: "Se extiende el presente informe médico a solicitud del paciente para los fines pertinentes de evaluación laboral, previsional o educacional.",
        },
      ]);
    } else if (templateType === "contraderivacion") {
      setDocTitle(`Contra-Derivación Clínica a APS (CESFAM) - ${today}`);
      setDocSubtitle("Continuidad de Cuidados en Red · SSMS");
      setSections([
        {
          heading: "1. Paciente y Centro de Destino",
          body: "Paciente:\nRUT:\nCESFAM de Destino:\nSector:",
        },
        {
          heading: "2. Evolución en Especialidad (COSAM)",
          body: "Cumplió objetivos del Plan de Tratamiento Integral (PAI) con estabilización sintomática sostenida.",
        },
        {
          heading: "3. Esquema Farmacológico de Mantención",
          body: "Fármacos, posología diaria y consideraciones de despacho en Farmacia APS:",
        },
        {
          heading: "4. Criterios de Re-Derivación a Especialidad",
          body: "Descompensación afectiva o psicótica aguda, refractariedad a ajuste inicial o riesgo suicida.",
        },
      ]);
    } else if (templateType === "acta_comite") {
      setDocTitle(`Acta de Reunión Clínica Multiprofesional - ${today}`);
      setDocSubtitle("Comité Clínico COSAM Rinconada");
      setSections([
        {
          heading: "1. Asistentes y Caso Analizado",
          body: "Equipo participante: Psiquiatría, Psicología, Trabajo Social, Terapia Ocupacional.\nPaciente / Caso:",
        },
        {
          heading: "2. Síntesis del Problema Clínico y Psicosocial",
          body: "Factores clínicos, familiares y territoriales discutidos en sesión:",
        },
        {
          heading: "3. Acuerdos del Equipo y Responsables",
          body: "1. Ajuste farmacológico:\n2. Intervención psicosocial / visita domiciliaria:\n3. Próxima evaluación:",
        },
      ]);
    } else if (templateType === "epicrisis_pai") {
      setDocTitle(`Formulación Clínica Integral PAI (5Ps) - ${today}`);
      setDocSubtitle("Plan de Atención Individualizado · Salud Mental Comunitaria");
      setSections([
        {
          heading: "1. Problema Actual y Factores Precipitantes",
          body: "Motivo de consulta actual y gatillantes recientes:",
        },
        {
          heading: "2. Factores Predisponentes y Perpetuantes",
          body: "Vulnerabilidades biográficas, médicas y mantenedores ambientales:",
        },
        {
          heading: "3. Factores Protectores y Recursos de Red",
          body: "Adherencia, soporte familiar y factores resilientes:",
        },
        {
          heading: "4. Metas Terapéuticas y Plazos",
          body: "Objetivos a corto y mediano plazo consensuados con el usuario:",
        },
      ]);
    }
  };

  const handleImportSOAP = (note: SoapRecord) => {
    setDocTitle(`Evolución SOAP - ${note.patientName || "Paciente"} (${note.date})`);
    setDocSubtitle(`RUT: ${note.rut || "S/R"} · Registro Clínico Estructurado`);
    setMetadataHeader(
      `Paciente: ${note.patientName} | RUT: ${note.rut || "No especificado"} | Fecha: ${note.date}`
    );
    setSections([
      { heading: "S — Subjetivo", body: note.s || "Sin registro." },
      { heading: "O — Objetivo / Examen Mental", body: note.o || "Sin registro." },
      { heading: "A — Análisis y Diagnóstico", body: note.a || "Sin registro." },
      { heading: "P — Plan Terapéutico e Indicaciones", body: note.p || "Sin registro." },
    ]);
    setStatusBanner({
      type: "info",
      message: `Evolución SOAP de "${note.patientName}" cargada en el editor de Google Docs.`,
    });
  };

  const handleImportPAI = (pai: PaiRecord) => {
    setDocTitle(`Plan Integral PAI - ${pai.patientName || "Paciente"} (${pai.date})`);
    setDocSubtitle(`Diagnóstico: ${pai.diagnosis || "S/R"} · Modelo Biopsicosocial 5Ps`);
    setMetadataHeader(
      `Paciente: ${pai.patientName} | Diagnóstico: ${pai.diagnosis || "S/R"} | Fecha: ${pai.date}`
    );
    setSections([
      { heading: "1. Motivo de Consulta / Problema Actual (P1)", body: pai.motive || "Sin registro." },
      {
        heading: "2. Factores Predisponentes y Precipitantes (P2 - P3)",
        body: `Predisponentes:\n${pai.predisposing || "N/A"}\n\nPrecipitantes:\n${pai.precipitating || "N/A"}`,
      },
      {
        heading: "3. Factores Perpetuantes y Protectores (P4 - P5)",
        body: `Perpetuantes:\n${pai.perpetuating || "N/A"}\n\nProtectores:\n${pai.protective || "N/A"}`,
      },
      {
        heading: "4. Diagnóstico Multiaxial y Plan PAI",
        body: `${pai.structuredResult || pai.diagnosis || "Por definir."}`,
      },
    ]);
    setStatusBanner({
      type: "info",
      message: `Ingreso PAI de "${pai.patientName}" cargado en el editor de Google Docs.`,
    });
  };

  const handleImportMeeting = (meeting: ClinicalMeetingCase) => {
    setDocTitle(`Acta Clínica: ${meeting.titulo} (${meeting.fecha})`);
    setDocSubtitle(`Reunión Clínica de Equipo · COSAM Rinconada`);
    setMetadataHeader(
      `Caso: ${meeting.titulo} | Fecha: ${meeting.fecha}`
    );
    setSections([
      { heading: "1. Presentación y Resumen del Caso", body: meeting.contenido || "Sin registro." },
      {
        heading: "2. Tareas y Acuerdos del Equipo",
        body:
          meeting.acuerdos ||
          (meeting.tareas || []).map((t) => `- ${t.texto}`).join("\n") ||
          "Sin acuerdos registrados.",
      },
      ...(meeting.preguntasSugeridas
        ? [{ heading: "3. Líneas de Discusión Clínica", body: meeting.preguntasSugeridas }]
        : []),
    ]);
    setStatusBanner({
      type: "info",
      message: `Caso de reunión "${meeting.titulo}" cargado para exportar a Google Docs.`,
    });
  };

  const handleGenerateWithAI = async () => {
    if (!aiTopic.trim()) return;
    setIsGeneratingAI(true);
    setStatusBanner(null);
    try {
      const prompt = `Eres un médico psiquiatra senior del COSAM Rinconada (San Ramón, Chile).
Redacta el contenido de un documento clínico formal para Google Docs sobre el siguiente requerimiento:
"${aiTopic}"

Devuelve EXCLUSIVAMENTE un JSON válido (sin bloques markdown \`\`\`json) con esta estructura exacta:
{
  "title": "Título formal del documento",
  "subtitle": "Subtítulo institucional",
  "sections": [
    {
      "heading": "1. Encabezado de sección",
      "body": "Desarrollo clínico claro, técnico y estructurado"
    }
  ]
}
Genera entre 4 y 5 secciones clínicas completas.`;

      const raw = await generateClinicalAI({ prompt });
      const cleaned = raw.replace(/```json/gi, "").replace(/```/g, "").trim();
      const parsed = JSON.parse(cleaned);
      if (parsed.title) setDocTitle(parsed.title);
      if (parsed.subtitle) setDocSubtitle(parsed.subtitle);
      if (Array.isArray(parsed.sections) && parsed.sections.length > 0) {
        setSections(
          parsed.sections.map((s: any) => ({
            heading: s.heading || "Sección Clínica",
            body: s.body || "",
          }))
        );
      }
      setStatusBanner({
        type: "success",
        message: "Estructura del documento generada. Puedes revisarla antes de crear el Google Doc.",
      });
    } catch (err: any) {
      setStatusBanner({
        type: "error",
        message: "No se pudo estructurar automáticamente el borrador. Intente nuevamente.",
      });
    } finally {
      setIsGeneratingAI(false);
    }
  };

  const handleCreateGoogleDoc = async () => {
    if (!docTitle.trim() || sections.length === 0) return;
    setIsCreatingDoc(true);
    setStatusBanner(null);
    try {
      const created = await GoogleDocsService.createClinicalDocument({
        title: docTitle,
        subtitle: docSubtitle,
        metadataHeader,
        sections,
        folderName: DEFAULT_DOCS_FOLDER,
      });

      setStatusBanner({
        type: "success",
        message: `¡Documento "${created.title}" creado exitosamente en Google Docs!`,
        link: created.webViewLink,
      });

      await fetchDocuments();
      await handleInspectDocument(created.documentId);
      setActiveTab("browser");
    } catch (err: any) {
      setStatusBanner({
        type: "error",
        message: err.message || "Error al crear el documento en Google Docs.",
      });
    } finally {
      setIsCreatingDoc(false);
    }
  };

  const requestAppendSection = () => {
    if (!selectedDocDetails || !appendHeading.trim() || !appendBody.trim()) return;
    setConfirmDialog({
      title: "¿Anexar nueva sección al documento de Google Docs?",
      description: `Se añadirá la sección "${appendHeading}" al final del documento "${selectedDocDetails.title}" en tu cuenta de Google Docs.`,
      confirmLabel: "Confirmar y Anexar Texto",
      variant: "primary",
      onConfirm: async () => {
        setIsAppending(true);
        try {
          await GoogleDocsService.appendSectionToDocument(selectedDocDetails.documentId, {
            heading: appendHeading,
            body: appendBody,
          });
          setAppendBody("");
          await handleInspectDocument(selectedDocDetails.documentId);
          setStatusBanner({
            type: "success",
            message: "Sección anexada correctamente en el documento de Google Docs.",
            link: selectedDocDetails.webViewLink,
          });
        } catch (err: any) {
          setStatusBanner({
            type: "error",
            message: err.message || "No se pudo actualizar el documento.",
          });
        } finally {
          setIsAppending(false);
        }
      },
    });
  };

  const requestTrashDocument = (doc: DocsDocumentSummary) => {
    setConfirmDialog({
      title: "¿Mover documento de Google Docs a la papelera?",
      description: `El documento "${doc.name}" será enviado a la papelera de tu Google Drive.`,
      confirmLabel: "Mover a la Papelera",
      variant: "danger",
      onConfirm: async () => {
        try {
          await GoogleDocsService.trashDocument(doc.id);
          if (selectedDocDetails?.documentId === doc.id) {
            setSelectedDocDetails(null);
          }
          await fetchDocuments();
          setStatusBanner({
            type: "info",
            message: `Documento "${doc.name}" movido a la papelera de Google Drive.`,
          });
        } catch (err: any) {
          setStatusBanner({
            type: "error",
            message: err.message || "Error al eliminar el documento.",
          });
        }
      },
    });
  };

  return (
    <div className="space-y-4">
      {/* Barra superior de estado OAuth y pestañas */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800/60 flex items-center justify-center text-blue-600 dark:text-blue-400">
            <FileText size={18} strokeWidth={1.75} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                Google Docs Clínico · Informes y Actas
              </h3>
              <span
                className={`text-[10px] font-medium px-2 py-0.5 rounded-md border ${
                  isConnected
                    ? "bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800/60"
                    : "bg-amber-50 dark:bg-amber-950/50 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800/60"
                }`}
              >
                {isConnected ? "Google Docs Conectado" : "Requiere Autorización"}
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Carpeta en Drive:{" "}
              <span className="font-mono text-slate-700 dark:text-slate-300">
                {DEFAULT_DOCS_FOLDER}
              </span>
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <div className="flex items-center bg-slate-100 dark:bg-slate-800 p-0.5 rounded-lg border border-slate-200 dark:border-slate-700">
            <button
              onClick={() => setActiveTab("builder")}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors flex items-center gap-1.5 cursor-pointer ${
                activeTab === "builder"
                  ? "bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs"
                  : "text-slate-600 dark:text-slate-400 hover:text-slate-900"
              }`}
            >
              <FilePlus2 size={13} />
              <span>Redactar Nuevo Doc</span>
            </button>
            <button
              onClick={() => {
                setActiveTab("browser");
                if (isConnected) fetchDocuments();
              }}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors flex items-center gap-1.5 cursor-pointer ${
                activeTab === "browser"
                  ? "bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs"
                  : "text-slate-600 dark:text-slate-400 hover:text-slate-900"
              }`}
            >
              <FolderOpen size={13} />
              <span>Mis Google Docs ({existingDocs.length})</span>
            </button>
          </div>

          {!isConnected ? (
            <GoogleSignInButton
              onClick={handleConnectGoogle}
              isLoading={isConnecting}
              label="Sign in with Google"
              compact
            />
          ) : (
            <button
              onClick={handleConnectGoogle}
              disabled={isConnecting}
              className="px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-900 hover:bg-slate-800 dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-900 transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              {isConnecting ? <RefreshCw size={13} className="animate-spin" /> : <FileText size={13} />}
              <span>Reconectar Firebase Auth</span>
            </button>
          )}
        </div>
      </div>

      {/* Historial de Informes Clínicos Auto-Exportados al Documento Personal del Médico */}
      {exportHistory.length > 0 && (
        <div className="bg-blue-50/60 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800/70 rounded-2xl p-4 space-y-2.5">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
              <CheckCircle2 size={14} className="text-emerald-600" />
              <span>Informes Clínicos Exportados al Google Docs Personal del Médico ({exportHistory.length})</span>
            </h4>
            <span className="text-[10px] text-blue-700 dark:text-blue-300 font-medium">
              Autenticado vía Firebase Auth
            </span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
            {exportHistory.slice(0, 6).map((item) => (
              <div
                key={item.id}
                className="bg-white dark:bg-slate-900 border border-blue-100 dark:border-slate-800 rounded-xl p-2.5 flex items-center justify-between gap-2 text-xs"
              >
                <div className="min-w-0">
                  <p className="font-semibold text-slate-800 dark:text-slate-200 truncate text-[11px]">
                    {item.reportType} · {item.patientName}
                  </p>
                  <p className="text-[10px] text-slate-500 truncate">
                    {item.documentTitle} · {item.exportedAt}
                  </p>
                </div>
                <a
                  href={item.webViewLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-2 py-1 rounded-md bg-blue-600 hover:bg-blue-700 text-white text-[10px] font-medium flex items-center gap-1 shrink-0"
                >
                  <span>Abrir</span>
                  <ExternalLink size={10} />
                </a>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Notificaciones */}
      {statusBanner && (
        <div
          className={`p-3.5 rounded-xl border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-xs ${
            statusBanner.type === "success"
              ? "bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800/60 text-emerald-800 dark:text-emerald-200"
              : statusBanner.type === "error"
              ? "bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-800/60 text-rose-800 dark:text-rose-200"
              : "bg-blue-50 dark:bg-blue-950/40 border-blue-200 dark:border-blue-800/60 text-blue-800 dark:text-blue-200"
          }`}
        >
          <div className="flex items-center gap-2">
            {statusBanner.type === "success" ? (
              <CheckCircle2 size={15} className="shrink-0" />
            ) : (
              <AlertCircle size={15} className="shrink-0" />
            )}
            <span className="font-medium">{statusBanner.message}</span>
          </div>
          {statusBanner.link && (
            <a
              href={statusBanner.link}
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-1 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-semibold flex items-center gap-1.5 shrink-0"
            >
              <span>Abrir en Google Docs</span>
              <ExternalLink size={12} />
            </a>
          )}
        </div>
      )}

      {activeTab === "builder" ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* Columna Izquierda: Plantillas e Importación desde registros */}
          <div className="lg:col-span-4 space-y-4">
            {/* Plantillas Clínicas */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 space-y-3">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                Plantillas Oficiales Google Docs
              </h4>
              <div className="grid grid-cols-1 gap-2">
                <button
                  onClick={() => handleLoadTemplate("certificado")}
                  className="text-left p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors cursor-pointer"
                >
                  <div className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                    Informe / Certificado Psiquiátrico
                  </div>
                  <div className="text-[11px] text-slate-500">
                    Síntesis diagnóstica, tratamiento y fines previsionales/laborales.
                  </div>
                </button>
                <button
                  onClick={() => handleLoadTemplate("contraderivacion")}
                  className="text-left p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors cursor-pointer"
                >
                  <div className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                    Contra-Derivación a CESFAM (APS)
                  </div>
                  <div className="text-[11px] text-slate-500">
                    Indicaciones de mantención farmacológica y criterios de reingreso.
                  </div>
                </button>
                <button
                  onClick={() => handleLoadTemplate("epicrisis_pai")}
                  className="text-left p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors cursor-pointer"
                >
                  <div className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                    Formulación PAI (5Ps) en Documento
                  </div>
                  <div className="text-[11px] text-slate-500">
                    Plan de Tratamiento Integral consensuado para ficha clínica.
                  </div>
                </button>
                <button
                  onClick={() => handleLoadTemplate("acta_comite")}
                  className="text-left p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors cursor-pointer"
                >
                  <div className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                    Acta de Reunión Clínica de Equipo
                  </div>
                  <div className="text-[11px] text-slate-500">
                    Acuerdos multiprofesionales y seguimiento de casos complejos.
                  </div>
                </button>
              </div>
            </div>

            {/* Asistente IA para redactar borrador */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 space-y-2.5">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-800 dark:text-slate-200">
                <Sparkles size={14} className="text-blue-600 dark:text-blue-400" />
                <span>Estructurar Informe con IA Clínica</span>
              </div>
              <textarea
                rows={3}
                value={aiTopic}
                onChange={(e) => setAiTopic(e.target.value)}
                placeholder="Ej: Informe de evolución favorable de paciente con Trastorno Bipolar Tipo I en eutimia con Litio 900mg/día..."
                className="w-full p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-800 dark:text-slate-200 focus:outline-hidden"
              />
              <button
                onClick={handleGenerateWithAI}
                disabled={isGeneratingAI || !aiTopic.trim()}
                className="w-full py-2 px-3 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-xs font-medium flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                {isGeneratingAI ? (
                  <RefreshCw size={13} className="animate-spin" />
                ) : (
                  <Sparkles size={13} />
                )}
                <span>Generar Secciones del Documento</span>
              </button>
            </div>

            {/* Importar desde registros guardados en el Box */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 space-y-2.5">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                Importar desde Registros del Box
              </h4>

              {savedSOAPs.length === 0 && savedPAIs.length === 0 && savedMeetings.length === 0 ? (
                <p className="text-xs text-slate-400">
                  No hay evoluciones SOAP, planes PAI o actas guardadas localmente aún.
                </p>
              ) : (
                <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                  {savedSOAPs.slice(0, 4).map((s) => (
                    <button
                      key={s.id}
                      onClick={() => handleImportSOAP(s)}
                      className="w-full text-left p-2 rounded-lg bg-slate-50 dark:bg-slate-800/70 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200/80 dark:border-slate-700 text-xs flex items-center justify-between gap-2 cursor-pointer"
                    >
                      <div className="truncate">
                        <span className="font-semibold text-slate-800 dark:text-slate-200">
                          SOAP: {s.patientName}
                        </span>
                        <span className="text-[10px] text-slate-500 block">{s.date}</span>
                      </div>
                      <FileText size={13} className="text-slate-400 shrink-0" />
                    </button>
                  ))}
                  {savedPAIs.slice(0, 3).map((p) => (
                    <button
                      key={p.id}
                      onClick={() => handleImportPAI(p)}
                      className="w-full text-left p-2 rounded-lg bg-slate-50 dark:bg-slate-800/70 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200/80 dark:border-slate-700 text-xs flex items-center justify-between gap-2 cursor-pointer"
                    >
                      <div className="truncate">
                        <span className="font-semibold text-slate-800 dark:text-slate-200">
                          PAI: {p.patientName}
                        </span>
                        <span className="text-[10px] text-slate-500 block">{p.date}</span>
                      </div>
                      <ClipboardList size={13} className="text-slate-400 shrink-0" />
                    </button>
                  ))}
                  {savedMeetings.slice(0, 3).map((m) => (
                    <button
                      key={m.id}
                      onClick={() => handleImportMeeting(m)}
                      className="w-full text-left p-2 rounded-lg bg-slate-50 dark:bg-slate-800/70 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200/80 dark:border-slate-700 text-xs flex items-center justify-between gap-2 cursor-pointer"
                    >
                      <div className="truncate">
                        <span className="font-semibold text-slate-800 dark:text-slate-200">
                          Comité: {m.titulo}
                        </span>
                        <span className="text-[10px] text-slate-500 block">{m.fecha}</span>
                      </div>
                      <Users size={13} className="text-slate-400 shrink-0" />
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Columna Derecha: Editor de Secciones de Google Docs */}
          <div className="lg:col-span-8 bg-white dark:bg-slate-900 rounded-2xl p-4 sm:p-5 border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
                  Título del Documento en Google Docs
                </label>
                <input
                  type="text"
                  value={docTitle}
                  onChange={(e) => setDocTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-900 dark:text-white"
                />
              </div>
              <div>
                <label className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
                  Subtítulo / Unidad Clínica
                </label>
                <input
                  type="text"
                  value={docSubtitle}
                  onChange={(e) => setDocSubtitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-800 dark:text-slate-200"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
                Encabezado de Metadatos Clínicos
              </label>
              <input
                type="text"
                value={metadataHeader}
                onChange={(e) => setMetadataHeader(e.target.value)}
                className="w-full px-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-700 dark:text-slate-300"
              />
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                  Secciones del Documento ({sections.length})
                </h4>
                <button
                  onClick={() =>
                    setSections([
                      ...sections,
                      {
                        heading: `${sections.length + 1}. Nueva Sección Clínica`,
                        body: "",
                      },
                    ])
                  }
                  className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-xs font-medium text-slate-700 dark:text-slate-300 flex items-center gap-1 cursor-pointer"
                >
                  <Plus size={13} />
                  <span>Añadir Sección</span>
                </button>
              </div>

              <div className="space-y-3 max-h-[420px] overflow-y-auto pr-1">
                {sections.map((sec, idx) => (
                  <div
                    key={idx}
                    className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/80 space-y-2"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <input
                        type="text"
                        value={sec.heading}
                        onChange={(e) => {
                          const updated = [...sections];
                          updated[idx] = { ...updated[idx], heading: e.target.value };
                          setSections(updated);
                        }}
                        className="flex-1 px-2.5 py-1 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-900 dark:text-white"
                      />
                      {sections.length > 1 && (
                        <button
                          onClick={() => setSections(sections.filter((_, i) => i !== idx))}
                          className="p-1 text-slate-400 hover:text-rose-600 transition-colors cursor-pointer"
                          title="Quitar sección"
                        >
                          <Trash2 size={14} />
                        </button>
                      )}
                    </div>
                    <textarea
                      rows={3}
                      value={sec.body}
                      onChange={(e) => {
                        const updated = [...sections];
                        updated[idx] = { ...updated[idx], body: e.target.value };
                        setSections(updated);
                      }}
                      className="w-full p-2.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-800 dark:text-slate-200 leading-relaxed"
                    />
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-2 border-t border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
              <span className="text-[11px] text-slate-500">
                Se creará un archivo nativo de Google Docs en tu unidad de Google Drive.
              </span>
              <button
                onClick={handleCreateGoogleDoc}
                disabled={isCreatingDoc || !docTitle.trim()}
                className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-xs font-semibold flex items-center justify-center gap-2 shadow-xs transition-colors cursor-pointer"
              >
                {isCreatingDoc ? (
                  <RefreshCw size={14} className="animate-spin" />
                ) : (
                  <Send size={14} />
                )}
                <span>Crear Documento en Google Docs</span>
              </button>
            </div>
          </div>
        </div>
      ) : (
        /* Pestaña Explorador de Google Docs existentes */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          <div className="lg:col-span-5 bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-semibold text-slate-900 dark:text-white">
                Documentos en Google Docs ({existingDocs.length})
              </h4>
              <button
                onClick={fetchDocuments}
                disabled={isLoadingDocs}
                className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-300 cursor-pointer"
                title="Actualizar lista"
              >
                <RefreshCw size={13} className={isLoadingDocs ? "animate-spin" : ""} />
              </button>
            </div>

            {!isConnected ? (
              <div className="p-6 text-center space-y-2">
                <p className="text-xs text-slate-500">
                  Conecta tu cuenta de Google para listar y editar tus documentos de Google Docs.
                </p>
                <button
                  onClick={handleConnectGoogle}
                  className="px-3 py-1.5 rounded-lg bg-blue-600 text-white text-xs font-medium"
                >
                  Conectar Google Docs
                </button>
              </div>
            ) : existingDocs.length === 0 ? (
              <div className="p-6 text-center text-xs text-slate-400">
                No se encontraron documentos de Google Docs recientes.
              </div>
            ) : (
              <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
                {existingDocs.map((doc) => {
                  const isSelected = selectedDocDetails?.documentId === doc.id;
                  return (
                    <div
                      key={doc.id}
                      className={`p-3 rounded-xl border transition-colors flex items-center justify-between gap-2 ${
                        isSelected
                          ? "bg-blue-50/70 dark:bg-blue-950/40 border-blue-300 dark:border-blue-800"
                          : "bg-slate-50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700/70 hover:bg-slate-100 dark:hover:bg-slate-800"
                      }`}
                    >
                      <button
                        onClick={() => handleInspectDocument(doc.id)}
                        className="flex-1 text-left truncate cursor-pointer"
                      >
                        <div className="text-xs font-semibold text-slate-900 dark:text-white truncate">
                          {doc.name}
                        </div>
                        {doc.modifiedTime && (
                          <div className="text-[10px] text-slate-500">
                            Modificado: {new Date(doc.modifiedTime).toLocaleString("es-CL")}
                          </div>
                        )}
                      </button>

                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          onClick={() => handleInspectDocument(doc.id)}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-blue-600 hover:bg-white dark:hover:bg-slate-900 cursor-pointer"
                          title="Previsualizar contenido"
                        >
                          <Eye size={14} />
                        </button>
                        <a
                          href={doc.webViewLink}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="p-1.5 rounded-lg text-slate-500 hover:text-emerald-600 hover:bg-white dark:hover:bg-slate-900"
                          title="Abrir en Google Docs"
                        >
                          <ExternalLink size={14} />
                        </a>
                        <button
                          onClick={() => requestTrashDocument(doc)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-white dark:hover:bg-slate-900 cursor-pointer"
                          title="Mover a la papelera"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Visor de contenido y adenda en vivo */}
          <div className="lg:col-span-7 bg-white dark:bg-slate-900 rounded-2xl p-4 sm:p-5 border border-slate-200 dark:border-slate-800 space-y-4">
            {isLoadingDetails ? (
              <div className="py-16 flex flex-col items-center justify-center gap-2 text-slate-400">
                <RefreshCw size={20} className="animate-spin" />
                <span className="text-xs">Leyendo contenido desde Google Docs API...</span>
              </div>
            ) : !selectedDocDetails ? (
              <div className="py-16 text-center space-y-2">
                <FileText size={28} className="mx-auto text-slate-300 dark:text-slate-700" />
                <p className="text-xs text-slate-500">
                  Selecciona un documento de la izquierda para leer su contenido o anexar una evolución clínica.
                </p>
              </div>
            ) : (
              <>
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 pb-3 border-b border-slate-200 dark:border-slate-800">
                  <div>
                    <h4 className="text-sm font-semibold text-slate-900 dark:text-white">
                      {selectedDocDetails.title}
                    </h4>
                    <span className="text-[11px] text-slate-500">
                      ID: {selectedDocDetails.documentId} · {selectedDocDetails.paragraphCount} párrafos
                    </span>
                  </div>
                  <a
                    href={selectedDocDetails.webViewLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-medium flex items-center gap-1.5 shrink-0"
                  >
                    <span>Editar en Google Docs</span>
                    <ExternalLink size={13} />
                  </a>
                </div>

                {/* Texto extraído del Google Doc */}
                <div>
                  <label className="block text-[11px] font-medium text-slate-500 mb-1">
                    Contenido del Documento (Lectura directa API v1)
                  </label>
                  <pre className="w-full max-h-64 overflow-y-auto p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-xs text-slate-800 dark:text-slate-200 whitespace-pre-wrap font-sans leading-relaxed">
                    {selectedDocDetails.plainText || "(Documento vacío)"}
                  </pre>
                </div>

                {/* Formulario para anexar sección al documento existente */}
                <div className="pt-3 border-t border-slate-200 dark:border-slate-800 space-y-2.5">
                  <h5 className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                    Anexar Adenda / Evolución al Final del Documento
                  </h5>
                  <input
                    type="text"
                    value={appendHeading}
                    onChange={(e) => setAppendHeading(e.target.value)}
                    placeholder="Título del anexo"
                    className="w-full px-3 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
                  />
                  <textarea
                    rows={3}
                    value={appendBody}
                    onChange={(e) => setAppendBody(e.target.value)}
                    placeholder="Escribe el texto clínico que deseas agregar al final de este Google Doc..."
                    className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-800 dark:text-slate-200"
                  />
                  <div className="flex justify-end">
                    <button
                      onClick={requestAppendSection}
                      disabled={isAppending || !appendBody.trim()}
                      className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 dark:bg-white dark:hover:bg-slate-100 disabled:opacity-50 text-white dark:text-slate-900 text-xs font-medium flex items-center gap-1.5 cursor-pointer"
                    >
                      {isAppending ? (
                        <RefreshCw size={13} className="animate-spin" />
                      ) : (
                        <Plus size={13} />
                      )}
                      <span>Anexar al Google Doc</span>
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* Modal de Confirmación Obligatoria para Operaciones Mutables/Destructivas */}
      {confirmDialog && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xl p-5 space-y-4">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-2">
                <AlertCircle
                  size={18}
                  className={
                    confirmDialog.variant === "danger" ? "text-rose-600" : "text-blue-600"
                  }
                />
                <h4 className="text-sm font-semibold text-slate-900 dark:text-white">
                  {confirmDialog.title}
                </h4>
              </div>
              <button
                onClick={() => setConfirmDialog(null)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X size={16} />
              </button>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              {confirmDialog.description}
            </p>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setConfirmDialog(null)}
                className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-medium cursor-pointer"
              >
                Cancelar
              </button>
              <button
                onClick={async () => {
                  const fn = confirmDialog.onConfirm;
                  setConfirmDialog(null);
                  await fn();
                }}
                className={`px-3.5 py-1.5 rounded-lg text-white text-xs font-semibold cursor-pointer ${
                  confirmDialog.variant === "danger"
                    ? "bg-rose-600 hover:bg-rose-500"
                    : "bg-blue-600 hover:bg-blue-500"
                }`}
              >
                {confirmDialog.confirmLabel}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
