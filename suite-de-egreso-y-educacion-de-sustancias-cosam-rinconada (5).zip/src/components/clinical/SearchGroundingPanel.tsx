import React, { useState, useEffect } from "react";
import { Search, ExternalLink, RefreshCw, BookOpen, PlusCircle, Sparkles } from "lucide-react";
import { searchGroundingClinicalAI, SearchGroundingResult } from "../../services/geminiService";

interface SearchGroundingPanelProps {
  defaultQuery?: string;
  onShowToast?: (msg: string, type?: "success" | "error" | "info") => void;
  onInsertText?: (text: string) => void;
}

export function SearchGroundingPanel({
  defaultQuery = "",
  onShowToast,
  onInsertText,
}: SearchGroundingPanelProps) {
  const [query, setQuery] = useState(defaultQuery);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<SearchGroundingResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (defaultQuery && !query) {
      setQuery(defaultQuery);
    }
  }, [defaultQuery]);

  const handleSearch = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!query.trim()) return;

    setLoading(true);
    setError(null);
    try {
      const res = await searchGroundingClinicalAI({
        prompt: query,
        systemInstruction:
          "Eres un consultor de medicina basada en evidencia y psiquiatría clínica para profesionales de COSAM Rinconada. Proporciona resúmenes profesionales, precisos y siempre respaldados con citas del motor de búsqueda de Google.",
      });
      setResult(res);
      if (onShowToast) {
        onShowToast("Búsqueda con evidencia completada", "success");
      }
    } catch (err: any) {
      setError(err.message || "Error al realizar la búsqueda.");
      if (onShowToast) {
        onShowToast(err.message || "Error en búsqueda", "error");
      }
    } finally {
      setLoading(false);
    }
  };

  const sources = (result?.groundingChunks || [])
    .map((chunk) => chunk.web)
    .filter((web): web is { uri: string; title: string } => !!web && !!web.uri);

  return (
    <div
      className="bg-slate-900/80 backdrop-blur-xl rounded-2xl border border-slate-800 shadow-xl overflow-hidden"
      id="search-grounding-panel"
    >
      <div className="p-5 border-b border-slate-800 bg-slate-950/70 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-indigo-950/80 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-white text-sm md:text-base">
              Buscador Clínico con Evidencia Médica (Google Search Grounding)
            </h3>
            <p className="text-xs text-slate-400">
              Respaldado con Google Search y fuentes en tiempo real para COSAM Rinconada
            </p>
          </div>
        </div>
      </div>

      <div className="p-5 space-y-4">
        <form onSubmit={handleSearch} className="flex gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Ej: Interacciones farmacológicas entre Litio e Ibuprofeno..."
              className="w-full pl-10 pr-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
            />
          </div>
          <button
            type="submit"
            disabled={loading || !query.trim()}
            className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-2 shadow-sm cursor-pointer"
          >
            {loading ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                <span>Buscando...</span>
              </>
            ) : (
              <>
                <Search className="w-3.5 h-3.5" />
                <span>Consultar</span>
              </>
            )}
          </button>
        </form>

        {error && (
          <div className="p-3.5 bg-rose-950/50 border border-rose-800/60 rounded-xl text-xs text-rose-300">
            {error}
          </div>
        )}

        {result && (
          <div className="space-y-4 pt-2">
            <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl">
              <div className="flex items-center justify-between mb-3 border-b border-slate-800/80 pb-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-400 flex items-center gap-1.5">
                  <Sparkles className="w-3 h-3" />
                  <span>Resumen de Evidencia Clínica</span>
                </span>
                {onInsertText && (
                  <button
                    onClick={() => onInsertText(result.text)}
                    className="text-xs text-emerald-400 hover:text-emerald-300 font-semibold flex items-center gap-1 bg-emerald-950/60 px-2.5 py-1 rounded-lg border border-emerald-800/40 transition-colors cursor-pointer"
                  >
                    <PlusCircle className="w-3.5 h-3.5" />
                    <span>Insertar en Reporte</span>
                  </button>
                )}
              </div>
              <div className="text-xs text-slate-300 leading-relaxed whitespace-pre-line">
                {result.text}
              </div>
            </div>

            {sources.length > 0 && (
              <div className="space-y-2">
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                  Fuentes Consultadas ({sources.length})
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {sources.map((source, index) => (
                    <a
                      key={index}
                      href={source.uri}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-3 bg-slate-950/60 hover:bg-slate-950 border border-slate-800 hover:border-indigo-500/50 rounded-xl transition-all flex items-start justify-between gap-2 group"
                    >
                      <div className="truncate">
                        <p className="text-xs font-bold text-slate-200 group-hover:text-indigo-300 truncate">
                          {source.title || "Fuente Web"}
                        </p>
                        <p className="text-[10px] text-slate-500 truncate mt-0.5">{source.uri}</p>
                      </div>
                      <ExternalLink className="w-3.5 h-3.5 text-slate-500 group-hover:text-indigo-400 shrink-0 mt-0.5" />
                    </a>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

export default SearchGroundingPanel;
