import React, { useState, useEffect } from "react";
import {
  Calendar,
  Clock,
  Plus,
  Trash2,
  Edit3,
  ExternalLink,
  RefreshCw,
  Search,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  MapPin,
  Users,
  CalendarPlus,
  X,
  UserCheck,
  ShieldAlert,
} from "lucide-react";
import { GoogleDriveService } from "../../services/googleDriveService";
import {
  GoogleCalendarService,
  CalendarListItem,
  CalendarEventItem,
  BusySlot,
} from "../../services/googleCalendarService";
import { getCurrentAuthUser } from "../../services/firebaseAuthService";
import { GoogleSignInButton } from "./GoogleSignInButton";
import { generateClinicalAI } from "../../services/geminiService";

const CLINICAL_EVENT_TEMPLATES = [
  {
    id: "control_psiquiatria",
    label: "Control Psiquiátrico",
    defaultTitle: "Control Psiquiátrico Ambulatorio — ",
    durationMinutes: 30,
    location: "COSAM Rinconada — Box Médico 1",
    defaultDesc:
      "Control médico de especialidad en salud mental comunitaria.\n• Revisión de adherencia farmacológica y RAM\n• Evaluación psicopatológica evolutiva\n• Ajuste de plan terapéutico PAI",
  },
  {
    id: "ingreso_pai",
    label: "Ingreso Integral PAI 5Ps",
    defaultTitle: "Evaluación e Ingreso PAI — ",
    durationMinutes: 60,
    location: "COSAM Rinconada — Box Multiprofesional",
    defaultDesc:
      "Evaluación diagnóstica integral e ingreso a Plan de Atención Individual (PAI).\n• Formulación clínica 5Ps\n• Definición de metas terapéuticas a 3 y 6 meses\n• Coordinación con dupla psicosocial",
  },
  {
    id: "reunion_comite",
    label: "Comité Clínico de Equipo",
    defaultTitle: "Reunión Clínica de Equipo: Caso ",
    durationMinutes: 45,
    location: "COSAM Rinconada — Sala de Reuniones",
    defaultDesc:
      "Presentación y discusión clínica multidisciplinaria.\n• Revisión de nudos críticos diagnóstico-terapéuticos\n• Acuerdos de intervención conjunta (Psiquiatría, Psicología, T. Social, T. Ocupacional)",
  },
  {
    id: "control_farmacovigilancia",
    label: "Control Litemia / Clozapina",
    defaultTitle: "Control Farmacovigilancia (Litemia / Hemograma) — ",
    durationMinutes: 20,
    location: "COSAM Rinconada — Box Médico / Toma de Muestras",
    defaultDesc:
      "Control prioritario de niveles plasmáticos y seguridad hematológica/renal.\n• Verificación de litemia / hemograma ANC\n• Chequeo de signos de toxicidad y función tiroidea/renal",
  },
];

export function AgendaCalendarClinico() {
  const [isConnected, setIsConnected] = useState(() => GoogleDriveService.isConnected());
  const [isConnecting, setIsConnecting] = useState(false);
  const [authUser, setAuthUser] = useState(() => getCurrentAuthUser());

  // Calendars & Filtering
  const [calendars, setCalendars] = useState<CalendarListItem[]>([]);
  const [selectedCalendarId, setSelectedCalendarId] = useState<string>("primary");
  const [rangeFilter, setRangeFilter] = useState<"today" | "7d" | "30d">("7d");
  const [searchQuery, setSearchQuery] = useState("");

  // Events & FreeBusy
  const [events, setEvents] = useState<CalendarEventItem[]>([]);
  const [isLoadingEvents, setIsLoadingEvents] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState<CalendarEventItem | null>(null);
  const [busySlotsToday, setBusySlotsToday] = useState<BusySlot[]>([]);

  // Form states (Create or Edit Event)
  const [formMode, setFormMode] = useState<"create" | "edit">("create");
  const [editingEventId, setEditingEventId] = useState<string | null>(null);
  const [eventTitle, setEventTitle] = useState("");
  const [patientName, setPatientName] = useState("");
  const [eventDate, setEventDate] = useState(() => new Date().toISOString().split("T")[0]);
  const [startTime, setStartTime] = useState("09:00");
  const [endTime, setEndTime] = useState("09:30");
  const [eventLocation, setEventLocation] = useState("COSAM Rinconada — Box Médico 1");
  const [attendeesInput, setAttendeesInput] = useState("");
  const [eventDescription, setEventDescription] = useState("");
  const [isGeneratingAI, setIsGeneratingAI] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Secondary calendar creation
  const [newCalendarName, setNewCalendarName] = useState("COSAM Rinconada - Agenda Box Médico");
  const [showNewCalendarBar, setShowNewCalendarBar] = useState(false);

  // Mandatory confirmation dialog for mutating / destructive operations
  const [confirmModal, setConfirmModal] = useState<{
    title: string;
    description: string;
    details: string[];
    confirmLabel: string;
    variant: "primary" | "danger";
    onConfirm: () => Promise<void>;
  } | null>(null);

  const [statusBanner, setStatusBanner] = useState<{
    type: "success" | "error" | "info";
    message: string;
    link?: string;
  } | null>(null);

  useEffect(() => {
    const syncAuth = () => {
      const connected = GoogleDriveService.isConnected();
      setIsConnected(connected);
      setAuthUser(getCurrentAuthUser());
      if (connected) {
        loadCalendarWorkspace("primary", rangeFilter, searchQuery);
      }
    };

    window.addEventListener("cosam:gdrive-auth-changed", syncAuth);
    if (GoogleDriveService.isConnected()) {
      loadCalendarWorkspace("primary", rangeFilter, searchQuery);
    }

    return () => {
      window.removeEventListener("cosam:gdrive-auth-changed", syncAuth);
    };
  }, []);

  const computeTimeWindow = (range: "today" | "7d" | "30d") => {
    const now = new Date();
    const start = new Date(now);
    start.setHours(0, 0, 0, 0);

    const end = new Date(start);
    if (range === "today") {
      end.setHours(23, 59, 59, 999);
    } else if (range === "7d") {
      end.setDate(end.getDate() + 7);
      end.setHours(23, 59, 59, 999);
    } else {
      end.setDate(end.getDate() + 30);
      end.setHours(23, 59, 59, 999);
    }

    return {
      timeMin: start.toISOString(),
      timeMax: end.toISOString(),
    };
  };

  const loadCalendarWorkspace = async (
    calId = selectedCalendarId,
    range = rangeFilter,
    query = searchQuery
  ) => {
    if (!GoogleDriveService.isConnected()) return;
    setIsLoadingEvents(true);
    try {
      const { timeMin, timeMax } = computeTimeWindow(range);
      const todayWindow = computeTimeWindow("today");

      const [cals, evs, busy] = await Promise.all([
        GoogleCalendarService.listCalendars(),
        GoogleCalendarService.listEvents({
          calendarId: calId,
          timeMin,
          timeMax,
          query,
          maxResults: 40,
        }),
        GoogleCalendarService.getFreeBusy(calId, todayWindow.timeMin, todayWindow.timeMax).catch(
          () => []
        ),
      ]);

      setCalendars(cals);
      setEvents(evs);
      setBusySlotsToday(busy);
      if (evs.length > 0 && !selectedEvent) {
        setSelectedEvent(evs[0]);
      }
    } catch (err: any) {
      setStatusBanner({
        type: "error",
        message: err.message || "Error al cargar eventos de Google Calendar.",
      });
    } finally {
      setIsLoadingEvents(false);
    }
  };

  const handleConnectGoogle = async () => {
    setIsConnecting(true);
    setStatusBanner(null);
    try {
      await GoogleDriveService.requestAuth();
      setIsConnected(true);
      setAuthUser(getCurrentAuthUser());
      setStatusBanner({
        type: "success",
        message: "Google Calendar conectado exitosamente mediante Firebase Auth.",
      });
      await loadCalendarWorkspace(selectedCalendarId, rangeFilter, searchQuery);
    } catch (err: any) {
      setStatusBanner({
        type: "error",
        message: err.message || "No se pudo autenticar con Google Calendar.",
      });
    } finally {
      setIsConnecting(false);
    }
  };

  const handleApplyTemplate = (tpl: (typeof CLINICAL_EVENT_TEMPLATES)[number]) => {
    setFormMode("create");
    setEditingEventId(null);
    const fullTitle = patientName.trim()
      ? `${tpl.defaultTitle}${patientName.trim()}`
      : tpl.defaultTitle;
    setEventTitle(fullTitle);
    setEventLocation(tpl.location);
    setEventDescription(tpl.defaultDesc);

    // Calculate endTime from startTime + durationMinutes
    const [h, m] = startTime.split(":").map(Number);
    if (!isNaN(h) && !isNaN(m)) {
      const totalMins = h * 60 + m + tpl.durationMinutes;
      const endH = String(Math.floor(totalMins / 60) % 24).padStart(2, "0");
      const endM = String(totalMins % 60).padStart(2, "0");
      setEndTime(`${endH}:${endM}`);
    }
  };

  const handleGenerateAIClinicalPrep = async () => {
    setIsGeneratingAI(true);
    setStatusBanner(null);
    try {
      const prompt = `Genera una pauta clínica breve y estructurada para la descripción de una cita médica en Google Calendar en el COSAM Rinconada.
Título de la cita: ${eventTitle || "Control de Salud Mental"}
Paciente / Caso: ${patientName || "Por confirmar"}
Ubicación: ${eventLocation}
Notas actuales: ${eventDescription || "Sin notas adicionales"}

Incluye:
1. Objetivos clínicos de la sesión (máximo 3 puntos concisos)
2. Exámenes o escalas clínicas sugeridas a revisar en box
3. Recordatorio de coordinación con el equipo multiprofesional.`;

      const generated = await generateClinicalAI({
        prompt,
        systemInstruction:
          "Eres un psiquiatra jefe de unidad en COSAM Rinconada. Redacta notas preparatorias breves, claras y clínicamente útiles para eventos de agenda médica.",
      });
      setEventDescription(generated.trim());
    } catch (err: any) {
      setStatusBanner({
        type: "error",
        message: err.message || "Error al generar preparación clínica con IA.",
      });
    } finally {
      setIsGeneratingAI(false);
    }
  };

  const handleStartEditEvent = (ev: CalendarEventItem) => {
    setSelectedEvent(ev);
    setFormMode("edit");
    setEditingEventId(ev.id);
    setEventTitle(ev.summary || "");
    setEventLocation(ev.location || "COSAM Rinconada — Box Médico 1");
    setEventDescription(ev.description || "");
    setAttendeesInput(
      (ev.attendees || [])
        .map((a) => a.email)
        .filter(Boolean)
        .join(", ")
    );

    const startRaw = ev.start?.dateTime || ev.start?.date;
    const endRaw = ev.end?.dateTime || ev.end?.date;
    if (startRaw) {
      const d = new Date(startRaw);
      if (!isNaN(d.getTime())) {
        setEventDate(d.toISOString().split("T")[0]);
        setStartTime(
          `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`
        );
      }
    }
    if (endRaw) {
      const dEnd = new Date(endRaw);
      if (!isNaN(dEnd.getTime())) {
        setEndTime(
          `${String(dEnd.getHours()).padStart(2, "0")}:${String(dEnd.getMinutes()).padStart(2, "0")}`
        );
      }
    }
  };

  const handleResetForm = () => {
    setFormMode("create");
    setEditingEventId(null);
    setEventTitle("");
    setPatientName("");
    setEventDescription("");
    setAttendeesInput("");
  };

  const requestSaveEventConfirmation = () => {
    if (!eventTitle.trim()) {
      setStatusBanner({
        type: "error",
        message: "Ingrese un título para el evento clínico antes de guardar.",
      });
      return;
    }

    const startIso = new Date(`${eventDate}T${startTime}:00`).toISOString();
    const endIso = new Date(`${eventDate}T${endTime}:00`).toISOString();

    if (new Date(endIso) <= new Date(startIso)) {
      setStatusBanner({
        type: "error",
        message: "La hora de término debe ser posterior a la hora de inicio.",
      });
      return;
    }

    const attendeeList = attendeesInput
      .split(",")
      .map((e) => e.trim())
      .filter((e) => e.includes("@"));

    const targetCalendarName =
      calendars.find((c) => c.id === selectedCalendarId)?.summary || "Calendario Principal";

    if (formMode === "edit" && editingEventId) {
      setConfirmModal({
        title: "Confirmar actualización de evento en Google Calendar",
        description:
          "Esta acción modificará los datos del evento existente en su calendario de Google Workspace.",
        details: [
          `Calendario: ${targetCalendarName}`,
          `Evento: ${eventTitle.trim()}`,
          `Fecha y Horario: ${eventDate} · ${startTime} a ${endTime}`,
          `Ubicación: ${eventLocation || "COSAM Rinconada"}`,
          ...(attendeeList.length > 0 ? [`Participantes: ${attendeeList.join(", ")}`] : []),
        ],
        confirmLabel: "Confirmar y Actualizar Evento",
        variant: "primary",
        onConfirm: async () => {
          setIsSubmitting(true);
          try {
            const updated = await GoogleCalendarService.updateEvent({
              calendarId: selectedCalendarId,
              eventId: editingEventId,
              summary: eventTitle.trim(),
              description: eventDescription,
              location: eventLocation,
              startDateTime: startIso,
              endDateTime: endIso,
              attendeeEmails: attendeeList,
            });
            setStatusBanner({
              type: "success",
              message: `Evento "${updated.summary}" actualizado en Google Calendar.`,
              link: updated.htmlLink,
            });
            handleResetForm();
            await loadCalendarWorkspace(selectedCalendarId, rangeFilter, searchQuery);
          } catch (err: any) {
            setStatusBanner({
              type: "error",
              message: err.message || "No se pudo actualizar el evento.",
            });
          } finally {
            setIsSubmitting(false);
          }
        },
      });
    } else {
      setConfirmModal({
        title: "Confirmar agendamiento en Google Calendar",
        description:
          "Se creará un nuevo evento clínico en su cuenta de Google Calendar con los siguientes datos:",
        details: [
          `Calendario: ${targetCalendarName}`,
          `Título: ${eventTitle.trim()}`,
          `Fecha y Horario: ${eventDate} · ${startTime} a ${endTime}`,
          `Ubicación: ${eventLocation || "COSAM Rinconada"}`,
          ...(attendeeList.length > 0 ? [`Invitados: ${attendeeList.join(", ")}`] : []),
        ],
        confirmLabel: "Confirmar y Agendar Cita",
        variant: "primary",
        onConfirm: async () => {
          setIsSubmitting(true);
          try {
            const created = await GoogleCalendarService.createEvent({
              calendarId: selectedCalendarId,
              summary: eventTitle.trim(),
              description: eventDescription,
              location: eventLocation,
              startDateTime: startIso,
              endDateTime: endIso,
              attendeeEmails: attendeeList,
            });
            setStatusBanner({
              type: "success",
              message: `Cita "${created.summary}" agendada exitosamente en Google Calendar.`,
              link: created.htmlLink,
            });
            handleResetForm();
            await loadCalendarWorkspace(selectedCalendarId, rangeFilter, searchQuery);
          } catch (err: any) {
            setStatusBanner({
              type: "error",
              message: err.message || "Error al crear evento en Google Calendar.",
            });
          } finally {
            setIsSubmitting(false);
          }
        },
      });
    }
  };

  const requestDeleteEventConfirmation = (ev: CalendarEventItem) => {
    const targetCalendarName =
      calendars.find((c) => c.id === selectedCalendarId)?.summary || "Calendario Principal";

    setConfirmModal({
      title: "Confirmar eliminación de evento en Google Calendar",
      description:
        "¿Está seguro de que desea eliminar permanentemente este evento de su Google Calendar? Esta acción no se puede deshacer.",
      details: [
        `Calendario: ${targetCalendarName}`,
        `Evento a eliminar: ${ev.summary}`,
        `Horario: ${formatEventDateTime(ev)}`,
      ],
      confirmLabel: "Eliminar Evento",
      variant: "danger",
      onConfirm: async () => {
        setIsSubmitting(true);
        try {
          await GoogleCalendarService.deleteEvent(selectedCalendarId, ev.id);
          setStatusBanner({
            type: "info",
            message: `Evento "${ev.summary}" eliminado de Google Calendar.`,
          });
          if (selectedEvent?.id === ev.id) {
            setSelectedEvent(null);
          }
          if (editingEventId === ev.id) {
            handleResetForm();
          }
          await loadCalendarWorkspace(selectedCalendarId, rangeFilter, searchQuery);
        } catch (err: any) {
          setStatusBanner({
            type: "error",
            message: err.message || "No se pudo eliminar el evento.",
          });
        } finally {
          setIsSubmitting(false);
        }
      },
    });
  };

  const requestCreateSecondaryCalendarConfirmation = () => {
    if (!newCalendarName.trim()) return;
    setConfirmModal({
      title: "Crear calendario clínico secundario en Google Calendar",
      description:
        "Se creará un nuevo calendario secundario en su cuenta de Google para organizar separadamente las citas y comités del COSAM Rinconada.",
      details: [`Nombre del nuevo calendario: ${newCalendarName.trim()}`],
      confirmLabel: "Crear Calendario",
      variant: "primary",
      onConfirm: async () => {
        setIsSubmitting(true);
        try {
          const created = await GoogleCalendarService.createSecondaryCalendar(newCalendarName);
          setShowNewCalendarBar(false);
          setSelectedCalendarId(created.id);
          setStatusBanner({
            type: "success",
            message: `Calendario secundario "${created.summary}" creado y seleccionado.`,
          });
          await loadCalendarWorkspace(created.id, rangeFilter, searchQuery);
        } catch (err: any) {
          setStatusBanner({
            type: "error",
            message: err.message || "Error al crear calendario secundario.",
          });
        } finally {
          setIsSubmitting(false);
        }
      },
    });
  };

  const formatEventDateTime = (ev: CalendarEventItem): string => {
    const startStr = ev.start?.dateTime || ev.start?.date;
    const endStr = ev.end?.dateTime || ev.end?.date;
    if (!startStr) return "Fecha por definir";
    const startDate = new Date(startStr);
    if (isNaN(startDate.getTime())) return startStr;

    const dateFormatted = startDate.toLocaleDateString("es-CL", {
      weekday: "short",
      day: "2-digit",
      month: "short",
    });

    if (!ev.start?.dateTime) {
      return `${dateFormatted} (Todo el día)`;
    }

    const startTimeStr = startDate.toLocaleTimeString("es-CL", {
      hour: "2-digit",
      minute: "2-digit",
    });

    if (endStr) {
      const endDate = new Date(endStr);
      const endTimeStr = endDate.toLocaleTimeString("es-CL", {
        hour: "2-digit",
        minute: "2-digit",
      });
      return `${dateFormatted} · ${startTimeStr} – ${endTimeStr}`;
    }

    return `${dateFormatted} · ${startTimeStr}`;
  };

  return (
    <div className="space-y-4" id="agenda-calendar-clinico-module">
      {/* Top Connection & Calendar Selector Bar */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4 shadow-xs flex flex-col lg:flex-row items-start lg:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800/60 flex items-center justify-center text-emerald-600 dark:text-emerald-400 shrink-0">
            <Calendar className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Agenda Clínica Google Calendar — COSAM Rinconada
              </h3>
              <span
                className={`text-[10px] font-semibold px-2 py-0.5 rounded-md border ${
                  isConnected
                    ? "bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/50 dark:text-emerald-300 dark:border-emerald-800"
                    : "bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/50 dark:text-amber-300 dark:border-amber-800"
                }`}
              >
                {isConnected ? "Sincronizado con Google Calendar" : "Requiere autenticación"}
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Programación de controles psiquiátricos, ingresos PAI 5Ps, farmacovigilancia y comités clínicos multiprofesionales.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap self-stretch lg:self-auto justify-end">
          {!isConnected ? (
            <GoogleSignInButton
              onClick={handleConnectGoogle}
              isLoading={isConnecting}
              label="Sign in with Google"
            />
          ) : (
            <>
              {authUser && (
                <span className="inline-flex items-center gap-1.5 text-[11px] text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700">
                  <UserCheck className="w-3.5 h-3.5 text-emerald-600" />
                  <span className="truncate max-w-[180px]">
                    {authUser.displayName || authUser.email}
                  </span>
                </span>
              )}

              <select
                value={selectedCalendarId}
                onChange={(e) => {
                  const newId = e.target.value;
                  setSelectedCalendarId(newId);
                  loadCalendarWorkspace(newId, rangeFilter, searchQuery);
                }}
                className="px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-800 dark:text-slate-200"
                title="Seleccionar Calendario de Google"
              >
                {calendars.length === 0 ? (
                  <option value="primary">Calendario Principal</option>
                ) : (
                  calendars.map((cal) => (
                    <option key={cal.id} value={cal.id}>
                      {cal.primary ? `Principal (${cal.summary})` : cal.summary}
                    </option>
                  ))
                )}
              </select>

              <button
                onClick={() => setShowNewCalendarBar((prev) => !prev)}
                className="px-2.5 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-medium flex items-center gap-1 border border-slate-200 dark:border-slate-700 cursor-pointer"
                title="Crear calendario secundario exclusivo para Box Médico"
              >
                <CalendarPlus className="w-3.5 h-3.5 text-emerald-600" />
                <span>Nuevo Calendario Box</span>
              </button>

              <button
                onClick={() => loadCalendarWorkspace(selectedCalendarId, rangeFilter, searchQuery)}
                disabled={isLoadingEvents}
                className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 cursor-pointer"
                title="Actualizar agenda"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isLoadingEvents ? "animate-spin" : ""}`} />
              </button>
            </>
          )}
        </div>
      </div>

      {/* Secondary Calendar Creation Bar */}
      {isConnected && showNewCalendarBar && (
        <div className="bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/70 rounded-xl p-3 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
          <div className="flex items-center gap-2 text-xs text-emerald-900 dark:text-emerald-200">
            <CalendarPlus className="w-4 h-4 text-emerald-600 shrink-0" />
            <span className="font-medium">Crear calendario secundario en su cuenta:</span>
          </div>
          <div className="flex items-center gap-2 flex-1 max-w-md">
            <input
              type="text"
              value={newCalendarName}
              onChange={(e) => setNewCalendarName(e.target.value)}
              placeholder="Ej: COSAM Rinconada - Agenda Box Médico"
              className="flex-1 px-3 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-emerald-300 dark:border-emerald-700 text-xs text-slate-800 dark:text-slate-100"
            />
            <button
              onClick={requestCreateSecondaryCalendarConfirmation}
              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold cursor-pointer whitespace-nowrap"
            >
              Crear Calendario
            </button>
            <button
              onClick={() => setShowNewCalendarBar(false)}
              className="p-1 text-slate-400 hover:text-slate-600"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Status Notification Banner */}
      {statusBanner && (
        <div
          className={`rounded-xl px-4 py-2.5 border text-xs flex items-center justify-between gap-3 ${
            statusBanner.type === "success"
              ? "bg-emerald-50 border-emerald-200 text-emerald-900 dark:bg-emerald-950/50 dark:border-emerald-800 dark:text-emerald-200"
              : statusBanner.type === "error"
              ? "bg-rose-50 border-rose-200 text-rose-900 dark:bg-rose-950/50 dark:border-rose-800 dark:text-rose-200"
              : "bg-blue-50 border-blue-200 text-blue-900 dark:bg-blue-950/50 dark:border-blue-800 dark:text-blue-200"
          }`}
        >
          <div className="flex items-center gap-2">
            {statusBanner.type === "success" ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            )}
            <span>{statusBanner.message}</span>
            {statusBanner.link && (
              <a
                href={statusBanner.link}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 font-semibold underline ml-2"
              >
                <span>Ver en Google Calendar</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            )}
          </div>
          <button onClick={() => setStatusBanner(null)} className="text-slate-400 hover:text-slate-600">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Main Grid: Left Event List & FreeBusy | Right Appointment Scheduler */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left Column: Agenda Events List (5 cols) */}
        <div className="lg:col-span-5 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col h-[700px] overflow-hidden">
          <div className="p-3.5 border-b border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-800/40 space-y-2.5">
            <div className="flex items-center justify-between gap-2">
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-emerald-600" />
                Próximas Citas y Comités ({events.length})
              </span>

              <div className="flex items-center gap-1 bg-slate-200/70 dark:bg-slate-800 p-0.5 rounded-lg text-[11px]">
                <button
                  onClick={() => {
                    setRangeFilter("today");
                    loadCalendarWorkspace(selectedCalendarId, "today", searchQuery);
                  }}
                  className={`px-2 py-0.5 rounded-md font-medium cursor-pointer ${
                    rangeFilter === "today"
                      ? "bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-2xs"
                      : "text-slate-600 dark:text-slate-400"
                  }`}
                >
                  Hoy
                </button>
                <button
                  onClick={() => {
                    setRangeFilter("7d");
                    loadCalendarWorkspace(selectedCalendarId, "7d", searchQuery);
                  }}
                  className={`px-2 py-0.5 rounded-md font-medium cursor-pointer ${
                    rangeFilter === "7d"
                      ? "bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-2xs"
                      : "text-slate-600 dark:text-slate-400"
                  }`}
                >
                  7 días
                </button>
                <button
                  onClick={() => {
                    setRangeFilter("30d");
                    loadCalendarWorkspace(selectedCalendarId, "30d", searchQuery);
                  }}
                  className={`px-2 py-0.5 rounded-md font-medium cursor-pointer ${
                    rangeFilter === "30d"
                      ? "bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-2xs"
                      : "text-slate-600 dark:text-slate-400"
                  }`}
                >
                  30 días
                </button>
              </div>
            </div>

            {/* Search bar */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    loadCalendarWorkspace(selectedCalendarId, rangeFilter, searchQuery);
                  }
                }}
                placeholder="Buscar paciente, control, litemia o comité..."
                className="w-full pl-8 pr-7 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-800 dark:text-slate-200"
              />
              {searchQuery && (
                <button
                  onClick={() => {
                    setSearchQuery("");
                    loadCalendarWorkspace(selectedCalendarId, rangeFilter, "");
                  }}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* FreeBusy summary today */}
            {isConnected && (
              <div className="flex items-center justify-between text-[11px] bg-white dark:bg-slate-900 px-2.5 py-1.5 rounded-lg border border-slate-200/80 dark:border-slate-800">
                <span className="text-slate-500 dark:text-slate-400">
                  Disponibilidad Hoy (Free/Busy):
                </span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">
                  {busySlotsToday.length === 0
                    ? "Agenda despejada hoy"
                    : `${busySlotsToday.length} bloque(s) ocupado(s) hoy`}
                </span>
              </div>
            )}
          </div>

          {/* Events list body */}
          <div className="flex-1 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
            {!isConnected ? (
              <div className="p-8 text-center space-y-3">
                <Calendar className="w-8 h-8 text-slate-300 mx-auto" />
                <p className="text-xs font-medium text-slate-600 dark:text-slate-400">
                  Inicie sesión con su cuenta de Google para visualizar y gestionar su agenda médica en tiempo real.
                </p>
                <div className="flex justify-center pt-1">
                  <GoogleSignInButton
                    onClick={handleConnectGoogle}
                    isLoading={isConnecting}
                    label="Sign in with Google"
                  />
                </div>
              </div>
            ) : isLoadingEvents ? (
              <div className="p-8 text-center text-xs text-slate-400 space-y-2">
                <RefreshCw className="w-5 h-5 animate-spin mx-auto text-emerald-600" />
                <p>Sincronizando eventos con Google Calendar...</p>
              </div>
            ) : events.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-400 space-y-1">
                <p className="font-medium text-slate-600 dark:text-slate-300">
                  No hay citas registradas en este rango.
                </p>
                <p>Utilice el panel derecho para agendar un control psiquiátrico, ingreso PAI o reunión clínica.</p>
              </div>
            ) : (
              events.map((ev) => {
                const isSelected = selectedEvent?.id === ev.id;
                return (
                  <div
                    key={ev.id}
                    onClick={() => setSelectedEvent(ev)}
                    className={`p-3.5 transition-colors cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/50 ${
                      isSelected
                        ? "bg-emerald-50/50 dark:bg-emerald-950/30 border-l-4 border-emerald-600"
                        : ""
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0 flex-1">
                        <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                          {ev.summary}
                        </p>
                        <p className="text-[11px] font-medium text-emerald-700 dark:text-emerald-400 mt-0.5 flex items-center gap-1">
                          <Clock className="w-3 h-3 shrink-0" />
                          <span>{formatEventDateTime(ev)}</span>
                        </p>
                        {ev.location && (
                          <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5 truncate flex items-center gap-1">
                            <MapPin className="w-3 h-3 shrink-0" />
                            <span>{ev.location}</span>
                          </p>
                        )}
                      </div>

                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleStartEditEvent(ev);
                          }}
                          className="p-1 rounded hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-500 hover:text-slate-800 dark:hover:text-white"
                          title="Editar o reprogramar cita"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            requestDeleteEventConfirmation(ev);
                          }}
                          className="p-1 rounded hover:bg-rose-100 dark:hover:bg-rose-950/60 text-slate-400 hover:text-rose-600"
                          title="Eliminar evento de Google Calendar"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    {ev.description && (
                      <p className="text-[11px] text-slate-600 dark:text-slate-400 mt-2 line-clamp-2 whitespace-pre-line bg-slate-50 dark:bg-slate-800/60 p-2 rounded border border-slate-100 dark:border-slate-800">
                        {ev.description}
                      </p>
                    )}
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right Column: Clinical Appointment & Committee Scheduler (7 cols) */}
        <div className="lg:col-span-7 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs p-5 flex flex-col justify-between space-y-4">
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div>
                <h4 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  {formMode === "edit" ? (
                    <>
                      <Edit3 className="w-4 h-4 text-amber-600" />
                      <span>Reprogramar / Editar Evento en Google Calendar</span>
                    </>
                  ) : (
                    <>
                      <Plus className="w-4 h-4 text-emerald-600" />
                      <span>Agendar Nueva Cita Clínica o Reunión de Equipo</span>
                    </>
                  )}
                </h4>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  Seleccione una plantilla rápida de atención o complete los datos del bloque horario.
                </p>
              </div>
              {formMode === "edit" && (
                <button
                  onClick={handleResetForm}
                  className="px-2.5 py-1 rounded-lg text-xs font-medium bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 cursor-pointer"
                >
                  Cancelar edición
                </button>
              )}
            </div>

            {/* Clinical Event Quick Templates */}
            <div className="space-y-1.5">
              <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400">
                Plantillas Clínicas Rápidas (COSAM):
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {CLINICAL_EVENT_TEMPLATES.map((tpl) => (
                  <button
                    key={tpl.id}
                    type="button"
                    onClick={() => handleApplyTemplate(tpl)}
                    className="p-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50/70 hover:bg-emerald-50/60 hover:border-emerald-300 dark:bg-slate-800/60 dark:hover:bg-emerald-950/30 text-left transition-colors cursor-pointer"
                  >
                    <p className="text-xs font-semibold text-slate-800 dark:text-slate-200 truncate">
                      {tpl.label}
                    </p>
                    <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">
                      Duración: {tpl.durationMinutes} min
                    </p>
                  </button>
                ))}
              </div>
            </div>

            {/* Form Fields */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Paciente / Caso Clínico (Opcional)
                </label>
                <input
                  type="text"
                  value={patientName}
                  onChange={(e) => setPatientName(e.target.value)}
                  placeholder="Ej: Juan Pérez (RUT 15.342.112-K)"
                  className="w-full px-3 py-2 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Título del Evento en Google Calendar *
                </label>
                <input
                  type="text"
                  value={eventTitle}
                  onChange={(e) => setEventTitle(e.target.value)}
                  placeholder="Ej: Control Psiquiátrico — Juan Pérez"
                  className="w-full px-3 py-2 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Fecha de Atención *
                </label>
                <input
                  type="date"
                  value={eventDate}
                  onChange={(e) => setEventDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Hora Inicio *
                </label>
                <input
                  type="time"
                  value={startTime}
                  onChange={(e) => setStartTime(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Hora Término *
                </label>
                <input
                  type="time"
                  value={endTime}
                  onChange={(e) => setEndTime(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-slate-400" />
                  <span>Box / Ubicación</span>
                </label>
                <input
                  type="text"
                  value={eventLocation}
                  onChange={(e) => setEventLocation(e.target.value)}
                  placeholder="COSAM Rinconada — Box Médico 1"
                  className="w-full px-3 py-2 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1">
                  <Users className="w-3.5 h-3.5 text-slate-400" />
                  <span>Invitados / Equipo (Correos separados por coma)</span>
                </label>
                <input
                  type="text"
                  value={attendeesInput}
                  onChange={(e) => setAttendeesInput(e.target.value)}
                  placeholder="psicologia@cosam.cl, tsocial@cosam.cl"
                  className="w-full px-3 py-2 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                />
              </div>
            </div>

            {/* Clinical Description & AI Assistant */}
            <div className="space-y-1.5 text-xs">
              <div className="flex items-center justify-between">
                <label className="font-semibold text-slate-700 dark:text-slate-300">
                  Objetivos Clínicos y Notas de Preparación de Box
                </label>
                <button
                  type="button"
                  onClick={handleGenerateAIClinicalPrep}
                  disabled={isGeneratingAI}
                  className="px-2.5 py-1 rounded-lg bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 font-semibold flex items-center gap-1 border border-indigo-200 dark:border-indigo-800/60 cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>{isGeneratingAI ? "Redactando pauta..." : "Sugerir Pauta con IA"}</span>
                </button>
              </div>
              <textarea
                rows={5}
                value={eventDescription}
                onChange={(e) => setEventDescription(e.target.value)}
                placeholder="Detalle objetivos clínicos del control, fármacos o laboratorios a revisar (ej. Litemia, Hemograma Clozapina, pauta PAI)..."
                className="w-full p-3 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white text-xs leading-relaxed"
              />
            </div>
          </div>

          {/* Action Footer */}
          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
            <div className="text-[11px] text-slate-500 dark:text-slate-400">
              Toda creación, modificación o eliminación en su agenda solicita confirmación explícita.
            </div>
            <div className="flex items-center gap-2 justify-end">
              {!isConnected ? (
                <GoogleSignInButton
                  onClick={handleConnectGoogle}
                  isLoading={isConnecting}
                  label="Sign in with Google"
                />
              ) : (
                <button
                  type="button"
                  onClick={requestSaveEventConfirmation}
                  disabled={isSubmitting}
                  className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold flex items-center gap-1.5 shadow-xs cursor-pointer"
                >
                  <Calendar className="w-3.5 h-3.5" />
                  <span>
                    {formMode === "edit"
                      ? "Actualizar Evento en Google Calendar"
                      : "Agendar en Google Calendar"}
                  </span>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Explicit Confirmation Modal for Mutating / Destructive Operations */}
      {confirmModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xl p-5 space-y-4">
            <div className="flex items-start gap-3">
              <div
                className={`p-2 rounded-xl shrink-0 ${
                  confirmModal.variant === "danger"
                    ? "bg-rose-100 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300"
                    : "bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300"
                }`}
              >
                <ShieldAlert className="w-5 h-5" />
              </div>
              <div className="space-y-1">
                <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                  {confirmModal.title}
                </h4>
                <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                  {confirmModal.description}
                </p>
              </div>
            </div>

            <div className="bg-slate-50 dark:bg-slate-800/70 rounded-xl p-3 border border-slate-200/80 dark:border-slate-700 space-y-1 text-xs text-slate-700 dark:text-slate-300">
              {confirmModal.details.map((line, idx) => (
                <p key={idx} className="truncate font-medium">
                  • {line}
                </p>
              ))}
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setConfirmModal(null)}
                disabled={isSubmitting}
                className="px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                disabled={isSubmitting}
                onClick={async () => {
                  const action = confirmModal.onConfirm;
                  setConfirmModal(null);
                  await action();
                }}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold text-white cursor-pointer ${
                  confirmModal.variant === "danger"
                    ? "bg-rose-600 hover:bg-rose-700"
                    : "bg-emerald-600 hover:bg-emerald-700"
                }`}
              >
                {confirmModal.confirmLabel}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
