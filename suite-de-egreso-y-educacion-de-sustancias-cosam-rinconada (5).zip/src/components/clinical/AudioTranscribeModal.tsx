import { useState, useEffect, useRef } from "react";
import { X, Mic, Square, Loader2, Play, AlertCircle, Check } from "lucide-react";
import { transcribeClinicalAudio } from "../../services/geminiService";

interface AudioTranscribeModalProps {
  onClose: () => void;
  onTranscriptionComplete: (text: string) => void;
  promptHint?: string;
}

export function AudioTranscribeModal({ onClose, onTranscriptionComplete, promptHint }: AudioTranscribeModalProps) {
  const [recording, setRecording] = useState(false);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [duration, setDuration] = useState(0);
  const [transcribing, setTranscribing] = useState(false);
  const [resultText, setResultText] = useState("");
  const [error, setError] = useState<string | null>(null);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    return () => {
      stopTimer();
      if (audioUrl) URL.revokeObjectURL(audioUrl);
    };
  }, [audioUrl]);

  const startTimer = () => {
    setDuration(0);
    timerRef.current = setInterval(() => {
      setDuration((prev) => prev + 1);
    }, 1000);
  };

  const stopTimer = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  };

  const startRecording = async () => {
    setError(null);
    setAudioBlob(null);
    setAudioUrl(null);
    setResultText("");
    audioChunksRef.current = [];

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream, { mimeType: "audio/webm" });
      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(audioChunksRef.current, { type: "audio/webm" });
        setAudioBlob(blob);
        setAudioUrl(URL.createObjectURL(blob));
        // stop mic tracks
        stream.getTracks().forEach((track) => track.stop());
      };

      mediaRecorder.start();
      setRecording(true);
      startTimer();
    } catch (err: any) {
      console.error("Mic access denied or error:", err);
      setError("No se pudo acceder al micrófono. Por favor otorgue permisos en su navegador.");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && recording) {
      mediaRecorderRef.current.stop();
      setRecording(false);
      stopTimer();
    }
  };

  const handleTranscribe = async () => {
    if (!audioBlob) return;
    setTranscribing(true);
    setError(null);

    try {
      // Convert blob to base64 string
      const reader = new FileReader();
      reader.readAsDataURL(audioBlob);
      reader.onloadend = async () => {
        const base64data = (reader.result as string).split(",")[1];
        try {
          const text = await transcribeClinicalAudio({
            audioData: base64data,
            mimeType: "audio/webm",
            prompt: promptHint || "Transcribe exactamente el dictado médico clínico del profesional de COSAM.",
          });
          setResultText(text);
        } catch (err: any) {
          setError(err.message || "Fallo al transcribir el dictado por IA.");
        } finally {
          setTranscribing(false);
        }
      };
    } catch (err: any) {
      setError("Error al leer el archivo de audio grabado.");
      setTranscribing(false);
    }
  };

  const handleConfirm = () => {
    onTranscriptionComplete(resultText);
    onClose();
  };

  const formatDuration = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const rSecs = secs % 60;
    return `${mins}:${rSecs < 10 ? "0" : ""}${rSecs}`;
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fadeIn" id="audio-transcribe-modal">
      <div className="bg-white rounded-2xl shadow-xl border border-slate-100 max-w-md w-full overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Mic className="w-5 h-5 text-indigo-600" />
            <h3 className="font-bold text-slate-800 text-sm md:text-base">Dictado Clínico por IA</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-50 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 text-center space-y-5">
          {!audioBlob && !recording && (
            <div className="py-8">
              <button
                onClick={startRecording}
                className="w-16 h-16 rounded-full bg-rose-50 text-rose-600 hover:bg-rose-100 flex items-center justify-center mx-auto transition-colors shadow-sm hover:scale-105"
              >
                <Mic className="w-7 h-7" />
              </button>
              <p className="text-sm font-semibold text-slate-700 mt-4">Iniciar Dictado</p>
              <p className="text-xs text-slate-400 mt-1 max-w-xs mx-auto">
                El sistema transcribirá tus observaciones de forma precisa con vocabulario médico
              </p>
            </div>
          )}

          {recording && (
            <div className="py-8 space-y-4">
              <div className="relative w-16 h-16 mx-auto flex items-center justify-center">
                <span className="absolute inset-0 rounded-full bg-rose-500/20 animate-ping" />
                <button
                  onClick={stopRecording}
                  className="relative w-12 h-12 rounded-full bg-rose-600 text-white flex items-center justify-center shadow"
                >
                  <Square className="w-5 h-5" />
                </button>
              </div>
              <div>
                <p className="text-base font-bold text-slate-800">{formatDuration(duration)}</p>
                <p className="text-xs text-rose-600 font-semibold uppercase tracking-wider animate-pulse mt-1">Grabando Audio</p>
              </div>
            </div>
          )}

          {audioBlob && !transcribing && !resultText && (
            <div className="py-5 space-y-4">
              <div className="flex justify-center gap-4">
                <button
                  onClick={startRecording}
                  className="px-3 py-1.5 border border-slate-200 hover:bg-slate-50 rounded-lg text-slate-600 text-xs font-semibold transition-colors"
                >
                  Grabar de Nuevo
                </button>
                <button
                  onClick={handleTranscribe}
                  className="px-4.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold transition-colors flex items-center gap-1"
                >
                  <Play className="w-3.5 h-3.5" /> Transcribir
                </button>
              </div>
              <audio src={audioUrl || ""} controls className="mx-auto max-w-xs w-full" />
            </div>
          )}

          {transcribing && (
            <div className="py-10 flex flex-col items-center gap-3">
              <Loader2 className="w-10 h-10 text-indigo-600 animate-spin" />
              <p className="text-xs text-slate-500 font-medium">Analizando fonemas y vocabulario médico por IA...</p>
            </div>
          )}

          {resultText && (
            <div className="space-y-4 text-left animate-fadeIn">
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-150">
                <p className="text-[10px] text-indigo-600 font-bold uppercase tracking-wider mb-1.5">Texto Transcrito:</p>
                <p className="text-xs text-slate-700 leading-relaxed max-h-40 overflow-y-auto whitespace-pre-line">{resultText}</p>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => setResultText("")}
                  className="flex-1 py-2 border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-semibold rounded-lg transition-colors"
                >
                  Re-grabar
                </button>
                <button
                  onClick={handleConfirm}
                  className="flex-1 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-1"
                >
                  <Check className="w-4 h-4" /> Insertar en Formulario
                </button>
              </div>
            </div>
          )}

          {error && (
            <div className="p-3 bg-rose-50 border border-rose-100 rounded-lg text-rose-700 text-xs flex items-center gap-2 text-left">
              <AlertCircle className="w-4.5 h-4.5 shrink-0" />
              <span>{error}</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
