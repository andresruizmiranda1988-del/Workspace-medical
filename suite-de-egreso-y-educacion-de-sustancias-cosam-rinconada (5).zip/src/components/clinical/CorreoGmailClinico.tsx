import { useState, useEffect } from "react";
import {
  Mail,
  Send,
  Inbox,
  FileEdit,
  Trash2,
  RefreshCw,
  Search,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  Reply,
  X,
} from "lucide-react";
import { GoogleDriveService } from "../../services/googleDriveService";
import {
  GmailService,
  GmailMessageSummary,
  GmailProfileInfo,
} from "../../services/gmailService";
import { generateClinicalAI } from "../../services/geminiService";

export function CorreoGmailClinico() {
  const [isConnected, setIsConnected] = useState(() => GoogleDriveService.isConnected());
  const [isConnecting, setIsConnecting] = useState(false);
  const [profile, setProfile] = useState<GmailProfileInfo | null>(null);

  const [activeTab, setActiveTab] = useState<"inbox" | "compose">("inbox");

  // Bandeja de entrada y búsqueda
  const [messages, setMessages] = useState<GmailMessageSummary[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [isLoadingMessages, setIsLoadingMessages] = useState(false);
  const [selectedMessage, setSelectedMessage] = useState<GmailMessageSummary | null>(null);

  // Redacción de correo clínico
  const [toEmail, setToEmail] = useState("");
  const [ccEmail, setCcEmail] = useState("");
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");
  const [aiDraftPrompt, setAiDraftPrompt] = useState("");
  const [isGeneratingAI, setIsGeneratingAI] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [isSavingDraft, setIsSavingDraft] = useState(false);

  // Confirmación obligatoria antes de enviar o eliminar correos
  const [confirmModal, setConfirmModal] = useState<{
    title: string;
    description: string;
    confirmLabel: string;
    variant: "primary" | "danger";
    onConfirm: () => Promise<void>;
  } | null>(null);

  const [statusBanner, setStatusBanner] = useState<{
    type: "success" | "error" | "info";
    message: string;
  } | null>(null);

  useEffect(() => {
    const syncAuth = () => {
      const connected = GoogleDriveService.isConnected();
      setIsConnected(connected);
      if (connected) {
        loadGmailData();
      }
    };
    window.addEventListener("cosam:gdrive-auth-changed", syncAuth);

    if (GoogleDriveService.isConnected()) {
      loadGmailData();
    }

    return () => {
      window.removeEventListener("cosam:gdrive-auth-changed", syncAuth);
    };
  }, []);

  const loadGmailData = async (customQuery?: string) => {
    if (!GoogleDriveService.isConnected()) return;
    setIsLoadingMessages(true);
    try {
      const [prof, msgs] = await Promise.all([
        GmailService.getProfile(),
        GmailService.listMessages(customQuery !== undefined ? customQuery : searchQuery, 15),
      ]);
      if (prof) setProfile(prof);
      setMessages(msgs);
      if (msgs.length > 0 && !selectedMessage) {
        setSelectedMessage(msgs[0]);
      }
    } catch (err: any) {
      console.warn("Error loading Gmail messages:", err);
    } finally {
      setIsLoadingMessages(false);
    }
  };

  const handleConnectGoogle = async () => {
    setIsConnecting(true);
    setStatusBanner(null);
    try {
      await GoogleDriveService.requestAuth();
      setIsConnected(true);
      setStatusBanner({
        type: "success",
        message: "Cuenta de Gmail conectada exitosamente.",
      });
      await loadGmailData();
    } catch (err: any) {
      setStatusBanner({
        type: "error",
        message: err.message || "No se pudo conectar con Gmail.",
      });
    } finally {
      setIsConnecting(false);
    }
  };

  const handleLoadQuickTemplate = (
    type: "farmacia_rut" | "interconsulta_aps" | "citacion_equipo" | "coordinacion_urgencia"
  ) => {
    const today = new Date().toLocaleDateString("es-CL");
    if (type === "farmacia_rut") {
      setSubject(`[Farmacia COSAM Rinconada] Verificación de Receta y RUT - ${today}`);
      setBody(
        `Estimado equipo de Farmacia Comunal / COSAM Rinconada:\n\nJunto con saludar, remito confirmación de datos de prescripción médica verificados en Box para evitar rechazo de despacho:\n\n- Nombre del Paciente:\n- RUT verificado (doble chequeo):\n- Fármacos e indicación:\n- Médico Prescriptor: Dr. Andrés Ruiz Miranda\n\nQuedo atento a cualquier observación.\nSaludos cordiales,\nCOSAM Rinconada · San Ramón`
      );
    } else if (type === "interconsulta_aps") {
      setSubject(`[Coordinación Red APS - COSAM] Contra-derivación / Interconsulta - ${today}`);
      setBody(
        `Estimado equipo de Salud Mental CESFAM:\n\nJunto con saludar, envío síntesis clínica de coordinación de red para continuidad de cuidados del paciente:\n\n- Paciente / RUT:\n- Diagnóstico actual:\n- Esquema farmacológico conciliado:\n- Sugerencias de seguimiento en APS:\n\nSaludos cordiales,\nEquipo Médico COSAM Rinconada`
      );
    } else if (type === "citacion_equipo") {
      setSubject(`[Comité Clínico COSAM] Presentación de Caso y Acuerdos - ${today}`);
      setBody(
        `Estimado equipo multiprofesional:\n\nComparto síntesis y acuerdos de reunión clínica para seguimiento conjunto:\n\n- Caso / Iniciales:\n- Acuerdos terapéuticos:\n- Próximo control y responsables:\n\nAtentamente,\nBox Psiquiatría Adultos · COSAM Rinconada`
      );
    } else if (type === "coordinacion_urgencia") {
      setSubject(`[URGENTE - Red SSMS] Derivación Prioritaria Salud Mental - ${today}`);
      setBody(
        `Estimado equipo de Urgencia Psiquiátrica / Hospital Barros Luco:\n\nSe coordina derivación asistida de paciente evaluado hoy en COSAM Rinconada:\n\n- Identificación y RUT:\n- Cuadro clínico actual y criterios de gravedad:\n- Manejo inicial realizado en Box:\n\nAtentamente,\nCOSAM Rinconada · Servicio de Salud Metropolitano Sur`
      );
    }
    setActiveTab("compose");
  };

  const handleGenerateEmailWithAI = async () => {
    if (!aiDraftPrompt.trim()) return;
    setIsGeneratingAI(true);
    setStatusBanner(null);
    try {
      const prompt = `Eres un médico psiquiatra del COSAM Rinconada (San Ramón, Chile).
Redacta un correo electrónico clínico formal y conciso según la siguiente instrucción:
"${aiDraftPrompt}"

Devuelve EXCLUSIVAMENTE un JSON válido (sin bloques markdown) con:
{
  "subject": "Asunto claro e institucional",
  "body": "Cuerpo completo del correo formal"
}`;
      const raw = await generateClinicalAI({ prompt });
      const cleaned = raw.replace(/```json/gi, "").replace(/```/g, "").trim();
      const parsed = JSON.parse(cleaned);
      if (parsed.subject) setSubject(parsed.subject);
      if (parsed.body) setBody(parsed.body);
      setStatusBanner({
        type: "info",
        message: "Borrador redactado con IA. Revisa el destinatario y contenido antes de enviar.",
      });
    } catch {
      setStatusBanner({
        type: "error",
        message: "No se pudo generar el borrador con IA.",
      });
    } finally {
      setIsGeneratingAI(false);
    }
  };

  const requestSendEmail = () => {
    if (!toEmail.trim() || !subject.trim() || !body.trim()) return;
    setConfirmModal({
      title: "¿Confirmar envío de correo electrónico por Gmail?",
      description: `Se enviará un correo desde tu cuenta (${profile?.emailAddress || "Gmail"}) a "${toEmail}" con el asunto "${subject}".`,
      confirmLabel: "Enviar Correo Ahora",
      variant: "primary",
      onConfirm: async () => {
        setIsSending(true);
        setStatusBanner(null);
        try {
          await GmailService.sendEmail({
            to: toEmail,
            cc: ccEmail,
            subject,
            body,
          });
          setStatusBanner({
            type: "success",
            message: `Correo enviado exitosamente a ${toEmail}.`,
          });
          setToEmail("");
          setCcEmail("");
          setSubject("");
          setBody("");
          await loadGmailData();
        } catch (err: any) {
          setStatusBanner({
            type: "error",
            message: err.message || "Error al enviar el correo mediante Gmail.",
          });
        } finally {
          setIsSending(false);
        }
      },
    });
  };

  const handleSaveDraft = async () => {
    if (!subject.trim() && !body.trim()) return;
    setIsSavingDraft(true);
    setStatusBanner(null);
    try {
      await GmailService.createDraft({
        to: toEmail,
        cc: ccEmail,
        subject,
        body,
      });
      setStatusBanner({
        type: "success",
        message: "Borrador guardado directamente en tu cuenta de Gmail.",
      });
    } catch (err: any) {
      setStatusBanner({
        type: "error",
        message: err.message || "No se pudo guardar el borrador.",
      });
    } finally {
      setIsSavingDraft(false);
    }
  };

  const requestTrashMessage = (msg: GmailMessageSummary) => {
    setConfirmModal({
      title: "¿Mover este correo a la papelera de Gmail?",
      description: `El mensaje "${msg.subject}" de ${msg.from} será movido a la papelera de tu cuenta de Gmail.`,
      confirmLabel: "Mover a Papelera",
      variant: "danger",
      onConfirm: async () => {
        try {
          await GmailService.trashMessage(msg.id);
          if (selectedMessage?.id === msg.id) {
            setSelectedMessage(null);
          }
          await loadGmailData();
          setStatusBanner({
            type: "info",
            message: `Correo "${msg.subject}" movido a la papelera.`,
          });
        } catch (err: any) {
          setStatusBanner({
            type: "error",
            message: err.message || "No se pudo eliminar el correo.",
          });
        }
      },
    });
  };

  const handleReplyMessage = (msg: GmailMessageSummary) => {
    const emailMatch = msg.from.match(/<([^>]+)>/);
    const replyAddress = emailMatch ? emailMatch[1] : msg.from;
    setToEmail(replyAddress);
    setSubject(msg.subject.startsWith("Re:") ? msg.subject : `Re: ${msg.subject}`);
    setBody(
      `\n\n--- En respuesta al mensaje del ${msg.date} de ${msg.from} ---\n> ${msg.snippet}`
    );
    setActiveTab("compose");
  };

  return (
    <div className="space-y-4">
      {/* Cabecera de conexión Gmail */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800/60 flex items-center justify-center text-rose-600 dark:text-rose-400">
            <Mail size={18} strokeWidth={1.75} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                Gmail Clínico · Coordinación de Red y Farmacia
              </h3>
              <span
                className={`text-[10px] font-medium px-2 py-0.5 rounded-md border ${
                  isConnected
                    ? "bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800/60"
                    : "bg-amber-50 dark:bg-amber-950/50 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800/60"
                }`}
              >
                {isConnected
                  ? profile?.emailAddress
                    ? `Conectado: ${profile.emailAddress}`
                    : "Gmail Conectado"
                  : "Sin Conexión"}
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Bandeja clínica, coordinación con Farmacia Comunal, CESFAM y derivaciones SSMS.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <div className="flex items-center bg-slate-100 dark:bg-slate-800 p-0.5 rounded-lg border border-slate-200 dark:border-slate-700">
            <button
              onClick={() => setActiveTab("inbox")}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors flex items-center gap-1.5 cursor-pointer ${
                activeTab === "inbox"
                  ? "bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs"
                  : "text-slate-600 dark:text-slate-400 hover:text-slate-900"
              }`}
            >
              <Inbox size={13} />
              <span>Bandeja ({messages.length})</span>
            </button>
            <button
              onClick={() => setActiveTab("compose")}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors flex items-center gap-1.5 cursor-pointer ${
                activeTab === "compose"
                  ? "bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs"
                  : "text-slate-600 dark:text-slate-400 hover:text-slate-900"
              }`}
            >
              <FileEdit size={13} />
              <span>Redactar Correo</span>
            </button>
          </div>

          <button
            onClick={handleConnectGoogle}
            disabled={isConnecting}
            className="px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-900 hover:bg-slate-800 dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-900 transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            {isConnecting ? <RefreshCw size={13} className="animate-spin" /> : <Mail size={13} />}
            <span>{isConnected ? "Actualizar Cuenta" : "Conectar Gmail"}</span>
          </button>
        </div>
      </div>

      {/* Banner de estado */}
      {statusBanner && (
        <div
          className={`p-3.5 rounded-xl border flex items-center justify-between gap-2 text-xs ${
            statusBanner.type === "success"
              ? "bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800/60 text-emerald-800 dark:text-emerald-200"
              : statusBanner.type === "error"
              ? "bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-800/60 text-rose-800 dark:text-rose-200"
              : "bg-blue-50 dark:bg-blue-950/40 border-blue-200 dark:border-blue-800/60 text-blue-800 dark:text-blue-200"
          }`}
        >
          <div className="flex items-center gap-2">
            {statusBanner.type === "success" ? (
              <CheckCircle2 size={15} className="shrink-0" />
            ) : (
              <AlertCircle size={15} className="shrink-0" />
            )}
            <span className="font-medium">{statusBanner.message}</span>
          </div>
          <button onClick={() => setStatusBanner(null)} className="text-slate-400 hover:text-slate-600">
            <X size={14} />
          </button>
        </div>
      )}

      {activeTab === "inbox" ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* Lista de mensajes */}
          <div className="lg:col-span-5 bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 space-y-3">
            <div className="flex items-center gap-2">
              <div className="relative flex-1">
                <Search
                  size={13}
                  className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400"
                />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") loadGmailData(searchQuery);
                  }}
                  placeholder="Buscar en Gmail (ej: farmacia, interconsulta, RUT)..."
                  className="w-full pl-8 pr-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-800 dark:text-slate-200"
                />
              </div>
              <button
                onClick={() => loadGmailData(searchQuery)}
                disabled={isLoadingMessages}
                className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 cursor-pointer"
                title="Buscar / Actualizar"
              >
                <RefreshCw size={14} className={isLoadingMessages ? "animate-spin" : ""} />
              </button>
            </div>

            {!isConnected ? (
              <div className="p-8 text-center space-y-2">
                <p className="text-xs text-slate-500">
                  Conecta tu cuenta de Google para consultar y responder correos clínicos desde el Box.
                </p>
                <button
                  onClick={handleConnectGoogle}
                  className="px-3.5 py-1.5 rounded-lg bg-rose-600 text-white text-xs font-medium"
                >
                  Conectar Gmail Ahora
                </button>
              </div>
            ) : messages.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-400">
                {isLoadingMessages
                  ? "Cargando mensajes de Gmail..."
                  : "No se encontraron mensajes con ese criterio."}
              </div>
            ) : (
              <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
                {messages.map((msg) => {
                  const isSelected = selectedMessage?.id === msg.id;
                  return (
                    <div
                      key={msg.id}
                      onClick={() => setSelectedMessage(msg)}
                      className={`p-3 rounded-xl border transition-colors cursor-pointer ${
                        isSelected
                          ? "bg-rose-50/70 dark:bg-rose-950/30 border-rose-300 dark:border-rose-800"
                          : "bg-slate-50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700/70 hover:bg-slate-100 dark:hover:bg-slate-800"
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span
                          className={`text-xs truncate ${
                            msg.isUnread
                              ? "font-bold text-slate-900 dark:text-white"
                              : "font-medium text-slate-700 dark:text-slate-300"
                          }`}
                        >
                          {msg.from}
                        </span>
                        {msg.isUnread && (
                          <span className="w-2 h-2 rounded-full bg-rose-500 shrink-0" />
                        )}
                      </div>
                      <div className="text-xs font-semibold text-slate-900 dark:text-white truncate mt-0.5">
                        {msg.subject}
                      </div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-2 mt-1">
                        {msg.snippet}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Visor de correo seleccionado */}
          <div className="lg:col-span-7 bg-white dark:bg-slate-900 rounded-2xl p-4 sm:p-5 border border-slate-200 dark:border-slate-800 space-y-4">
            {!selectedMessage ? (
              <div className="py-16 text-center space-y-2">
                <Mail size={28} className="mx-auto text-slate-300 dark:text-slate-700" />
                <p className="text-xs text-slate-500">
                  Selecciona un correo de la bandeja para leer su contenido completo.
                </p>
              </div>
            ) : (
              <>
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 pb-3 border-b border-slate-200 dark:border-slate-800">
                  <div className="space-y-0.5">
                    <h4 className="text-sm font-semibold text-slate-900 dark:text-white">
                      {selectedMessage.subject}
                    </h4>
                    <div className="text-xs text-slate-600 dark:text-slate-300">
                      <span className="font-medium">De:</span> {selectedMessage.from}
                    </div>
                    {selectedMessage.to && (
                      <div className="text-[11px] text-slate-500">
                        <span className="font-medium">Para:</span> {selectedMessage.to} ·{" "}
                        {selectedMessage.date}
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => handleReplyMessage(selectedMessage)}
                      className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-900 text-xs font-medium flex items-center gap-1.5 cursor-pointer"
                    >
                      <Reply size={13} />
                      <span>Responder</span>
                    </button>
                    <button
                      onClick={() => requestTrashMessage(selectedMessage)}
                      className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/50 text-rose-600 dark:text-rose-400 cursor-pointer"
                      title="Mover a la papelera"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>

                <div className="max-h-[420px] overflow-y-auto p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 text-xs text-slate-800 dark:text-slate-200 whitespace-pre-wrap leading-relaxed font-sans">
                  {selectedMessage.bodyText || selectedMessage.snippet || "(Sin contenido de texto)"}
                </div>
              </>
            )}
          </div>
        </div>
      ) : (
        /* Pestaña Redactar Correo Clínico */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          <div className="lg:col-span-4 space-y-4">
            <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 space-y-2.5">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                Plantillas de Correo COSAM
              </h4>
              <div className="grid grid-cols-1 gap-2">
                <button
                  onClick={() => handleLoadQuickTemplate("farmacia_rut")}
                  className="text-left p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors cursor-pointer"
                >
                  <div className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                    Farmacia Comunal · Rectificación / Doble Chequeo RUT
                  </div>
                  <div className="text-[11px] text-slate-500">
                    Evita rechazo de receta médica validando RUT y posología.
                  </div>
                </button>
                <button
                  onClick={() => handleLoadQuickTemplate("interconsulta_aps")}
                  className="text-left p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors cursor-pointer"
                >
                  <div className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                    Coordinación Red APS / CESFAM
                  </div>
                  <div className="text-[11px] text-slate-500">
                    Contra-derivación e indicaciones de continuidad terapéutica.
                  </div>
                </button>
                <button
                  onClick={() => handleLoadQuickTemplate("citacion_equipo")}
                  className="text-left p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors cursor-pointer"
                >
                  <div className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                    Acuerdos de Reunión Clínica de Equipo
                  </div>
                  <div className="text-[11px] text-slate-500">
                    Resumen de tareas para psicólogo, TS y terapeuta ocupacional.
                  </div>
                </button>
                <button
                  onClick={() => handleLoadQuickTemplate("coordinacion_urgencia")}
                  className="text-left p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors cursor-pointer"
                >
                  <div className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                    Derivación Prioritaria a Urgencia / Hospital
                  </div>
                  <div className="text-[11px] text-slate-500">
                    Aviso clínico formal a red de urgencia psiquiátrica SSMS.
                  </div>
                </button>
              </div>
            </div>

            <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 space-y-2.5">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-800 dark:text-slate-200">
                <Sparkles size={14} className="text-rose-600 dark:text-rose-400" />
                <span>Redactar Borrador con IA</span>
              </div>
              <textarea
                rows={3}
                value={aiDraftPrompt}
                onChange={(e) => setAiDraftPrompt(e.target.value)}
                placeholder="Ej: Correo a Farmacia confirmando RUT y dosis de Quetiapina 100mg noche para paciente en control..."
                className="w-full p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-800 dark:text-slate-200"
              />
              <button
                onClick={handleGenerateEmailWithAI}
                disabled={isGeneratingAI || !aiDraftPrompt.trim()}
                className="w-full py-2 px-3 rounded-xl bg-rose-600 hover:bg-rose-500 disabled:opacity-50 text-white text-xs font-medium flex items-center justify-center gap-1.5 cursor-pointer"
              >
                {isGeneratingAI ? (
                  <RefreshCw size={13} className="animate-spin" />
                ) : (
                  <Sparkles size={13} />
                )}
                <span>Generar Correo Clínico</span>
              </button>
            </div>
          </div>

          <div className="lg:col-span-8 bg-white dark:bg-slate-900 rounded-2xl p-4 sm:p-5 border border-slate-200 dark:border-slate-800 space-y-3.5">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-medium text-slate-500 mb-1">
                  Para (Destinatario) *
                </label>
                <input
                  type="email"
                  value={toEmail}
                  onChange={(e) => setToEmail(e.target.value)}
                  placeholder="ejemplo@redsalud.gob.cl"
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
                />
              </div>
              <div>
                <label className="block text-[11px] font-medium text-slate-500 mb-1">
                  CC (Copia opcional)
                </label>
                <input
                  type="text"
                  value={ccEmail}
                  onChange={(e) => setCcEmail(e.target.value)}
                  placeholder="equipo@cosam.cl"
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-medium text-slate-500 mb-1">
                Asunto del Correo *
              </label>
              <input
                type="text"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="[COSAM Rinconada] Coordinación Clínica..."
                className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-[11px] font-medium text-slate-500 mb-1">
                Cuerpo del Mensaje *
              </label>
              <textarea
                rows={10}
                value={body}
                onChange={(e) => setBody(e.target.value)}
                placeholder="Escribe el contenido del correo clínico..."
                className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-800 dark:text-slate-200 leading-relaxed"
              />
            </div>

            <div className="pt-2 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2">
              <button
                onClick={handleSaveDraft}
                disabled={isSavingDraft || (!subject.trim() && !body.trim())}
                className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-medium flex items-center gap-1.5 cursor-pointer"
              >
                {isSavingDraft ? (
                  <RefreshCw size={13} className="animate-spin" />
                ) : (
                  <FileEdit size={13} />
                )}
                <span>Guardar Borrador en Gmail</span>
              </button>

              <button
                onClick={requestSendEmail}
                disabled={isSending || !toEmail.trim() || !subject.trim() || !body.trim()}
                className="px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 disabled:opacity-50 text-white text-xs font-semibold flex items-center gap-2 shadow-xs cursor-pointer"
              >
                {isSending ? <RefreshCw size={14} className="animate-spin" /> : <Send size={14} />}
                <span>Enviar por Gmail</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal de Confirmación Obligatoria para Envío / Eliminación */}
      {confirmModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xl p-5 space-y-4">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-2">
                <AlertCircle
                  size={18}
                  className={
                    confirmModal.variant === "danger" ? "text-rose-600" : "text-blue-600"
                  }
                />
                <h4 className="text-sm font-semibold text-slate-900 dark:text-white">
                  {confirmModal.title}
                </h4>
              </div>
              <button
                onClick={() => setConfirmModal(null)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X size={16} />
              </button>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              {confirmModal.description}
            </p>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setConfirmModal(null)}
                className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-medium cursor-pointer"
              >
                Cancelar
              </button>
              <button
                onClick={async () => {
                  const fn = confirmModal.onConfirm;
                  setConfirmModal(null);
                  await fn();
                }}
                className={`px-3.5 py-1.5 rounded-lg text-white text-xs font-semibold cursor-pointer ${
                  confirmModal.variant === "danger"
                    ? "bg-rose-600 hover:bg-rose-500"
                    : "bg-rose-600 hover:bg-rose-500"
                }`}
              >
                {confirmModal.confirmLabel}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
