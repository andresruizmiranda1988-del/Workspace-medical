import React, { useState } from "react";
import {
  Brain,
  Dna,
  Zap,
  Link,
  ShieldCheck,
  Wand2,
  Copy,
  Printer,
  HardDrive,
  RotateCcw,
  Check,
  Sparkles,
  PhoneCall,
  CheckCircle2,
  ExternalLink,
  FileDown,
} from "lucide-react";
import { generateClinicalAI } from "../../services/geminiService";
import {
  GoogleDriveService,
  DEFAULT_PAI_FOLDER,
} from "../../services/googleDriveService";
import {
  GoogleDocsService,
  PersonalDocExportRecord,
} from "../../services/googleDocsService";
import { exportElementToPdf } from "../../utils/pdfExport";
import { DriveUploadProgress } from "../../types";
import { DriveUploadProgressModal } from "./DriveUploadProgressModal";
import { PersonalDocsAutoExportBar } from "./PersonalDocsAutoExportBar";

interface IngresoPAIProps {
  onShowToast?: (msg: string, type?: "success" | "error" | "info") => void;
  onOpenDriveModal?: () => void;
  isDriveConnected?: boolean;
}

export function IngresoPAI({
  onShowToast = () => {},
  onOpenDriveModal = () => {},
  isDriveConnected = false,
}: IngresoPAIProps) {
  const [nombre, setNombre] = useState<string>("");
  const [diagnostico, setDiagnostico] = useState<string>("");
  const [motivo, setMotivo] = useState<string>("");
  const [predisponentes, setPredisponentes] = useState<string>("");
  const [precipitantes, setPrecipitantes] = useState<string>("");
  const [mantenedores, setMantenedores] = useState<string>("");
  const [protectores, setProtectores] = useState<string>("");
  const [resultadoHtml, setResultadoHtml] = useState<string>("");
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isSavingDrive, setIsSavingDrive] = useState<boolean>(false);
  const [isExportingPdf, setIsExportingPdf] = useState<boolean>(false);
  const [isCopied, setIsCopied] = useState<boolean>(false);

  // Google Drive Sync & Progress state
  const [autoSync, setAutoSync] = useState<boolean>(() =>
    GoogleDriveService.getAutoSync("pai")
  );
  const [targetFolder, setTargetFolder] = useState<string>(() =>
    GoogleDriveService.getModuleFolder("pai", DEFAULT_PAI_FOLDER)
  );
  const [driveProgress, setDriveProgress] = useState<DriveUploadProgress | null>(
    null
  );
  const [isProgressModalOpen, setIsProgressModalOpen] = useState<boolean>(false);
  const [lastUploadedDoc, setLastUploadedDoc] = useState<{
    fileName: string;
    folderName: string;
    url?: string;
    time: string;
  } | null>(null);
  const [lastExportedPersonalDoc, setLastExportedPersonalDoc] =
    useState<PersonalDocExportRecord | null>(null);

  // Upload document to Google Drive with real-time progress indicator
  const uploadDocumentToDrive = async (
    contentToUpload: string,
    isAutomatic = false
  ) => {
    if (!contentToUpload.trim()) {
      onShowToast("No hay contenido para enviar a Google Drive", "error");
      return;
    }
    if (!isDriveConnected) {
      if (!isAutomatic) {
        onOpenDriveModal();
      }
      return;
    }
    setIsSavingDrive(true);
    setIsProgressModalOpen(true);
    const fecha = new Date().toISOString().split("T")[0];
    const nombreLimpio = (nombre.trim() || "Paciente").replace(/\s+/g, "_");
    const fileName = `Ingreso_PAI_4P_${nombreLimpio}_${fecha}.txt`;

    try {
      const uploadedFile = await GoogleDriveService.saveClinicalDocument({
        fileName,
        content: contentToUpload,
        folderName: targetFolder,
        onProgress: (prog) => {
          setDriveProgress(prog);
        },
      });
      setLastUploadedDoc({
        fileName: uploadedFile.name,
        folderName: targetFolder,
        url: uploadedFile.webViewLink,
        time: new Date().toLocaleTimeString("es-CL", {
          hour: "2-digit",
          minute: "2-digit",
        }),
      });
      onShowToast(
        isAutomatic
          ? `Auto-sincronizado en Drive: ${uploadedFile.name}`
          : `Guardado en Google Drive: ${uploadedFile.name}`,
        "success"
      );
    } catch (err: any) {
      console.error("Drive upload error:", err);
      onShowToast(err.message || "Error al enviar documento a Google Drive", "error");
    } finally {
      setIsSavingDrive(false);
    }
  };

  const handleProcesarFormulacion = async () => {
    if (!predisponentes && !precipitantes && !mantenedores && !protectores) {
      onShowToast("Complete al menos algunos factores de las 4P", "error");
      return;
    }
    setIsLoading(true);

    const fechaHora = new Date().toLocaleString("es-CL", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });

    const prompt = `Actúa como el Dr. Andrés Ruiz Miranda, Médico en el Programa de Adicciones del COSAM Rinconada. Genera un documento estructurado de INGRESO Y FORMULACIÓN CLÍNICA PAI (Plan de Atención Integral) optimizado para la ficha clínica Rayen APS.

Datos del Paciente:
- Nombre / Iniciales: ${nombre || "Paciente"}
- Hipótesis Diagnóstica Principal: ${diagnostico || "En estudio (Trastorno por consumo de sustancias)"}
- Motivo de Ingreso / Consulta: ${motivo || "Ingreso a tratamiento ambulatorio en COSAM"}
- 1. Factores Predisponentes (Vulnerabilidad neurobiológica, trauma temprano, antecedentes familiares): ${predisponentes || "Sin antecedentes mayores referidos."}
- 2. Factores Precipitantes (Gatillantes agudos, quiebre afectivo, estrés): ${precipitantes || "Sin gatillantes recientes identificados."}
- 3. Factores Mantenedores (Barreras, red de consumo, codependencia, ambiente): ${mantenedores || "Sin mantenedores activos señalados."}
- 4. Factores Protectores (Motivación, familia continente, trabajo, espiritualidad): ${protectores || "Motivación al tratamiento presente."}

Genera un documento con la siguiente estructura textual formal y clara:
==================================================
EVALUACIÓN MÉDICA DE INGRESO - FORMULACIÓN PAI (4P)
COSAM RINCONADA - PROGRAMA DE ADICCIONES
Fecha de Registro: ${fechaHora}
==================================================
PACIENTE: ${nombre || "Paciente"} | DIAGNÓSTICO: ${diagnostico || "T. por Consumo"}

1. RESUMEN CLÍNICO Y MOTIVO DE INGRESO
(Sintetiza la situación del usuario en lenguaje médico psiquiátrico de especialista).

2. FORMULACIÓN DINÁMICA DE LAS 4P
A. Factores Predisponentes (Vulnerabilidad biográfica y genética):
B. Factores Precipitantes (Crisis y gatillantes de la recaída):
C. Factores Mantenedores (Perpetuadores del consumo y barreras):
D. Factores Protectores (Factores de resiliencia y recursos personales):

3. SÍNTESIS DE COMPLEJIDAD Y RIESGO
(Evalúa el balance pronóstico y nivel de riesgo bio-psico-social).

4. PROPUESTA DE PLAN DE ATENCIÓN INTEGRAL (PAI)
- Abordaje Médico-Farmacológico:
- Abordaje Psicoterapéutico:
- Abordaje Social y Ocupacional:

--------------------------------------------------
Dr. Andrés Ruiz Miranda
Médico - Programa Tratamiento en Adicciones
COSAM Rinconada`;

    try {
      const result = await generateClinicalAI({
        prompt,
        systemInstruction: "Eres un médico especialista en psiquiatría y salud mental comunitaria en Chile.",
        temperature: 0.2,
      });
      const formattedResult = result.trim();
      setResultadoHtml(formattedResult);
      onShowToast("Formulación 4P generada con éxito", "success");

      // Exportación automática a Documento Personal en Google Docs (autenticado con Firebase Auth)
      if (
        GoogleDriveService.isConnected() &&
        GoogleDocsService.isAutoExportEnabled() &&
        GoogleDocsService.getExportMode() === "new_doc_per_report"
      ) {
        try {
          const exportedDoc = await GoogleDocsService.exportClinicalReportToPersonalDoc({
            reportType: "Formulación PAI 4P",
            patientName: nombre || "Paciente",
            patientRut: diagnostico || "PAI",
            content: formattedResult,
            modeOverride: "new_doc_per_report",
          });
          setLastExportedPersonalDoc(exportedDoc);
          onShowToast(
            `Exportado automáticamente a Google Docs: ${exportedDoc.documentTitle}`,
            "success"
          );
        } catch (docErr: any) {
          console.warn("Auto-export to personal Google Doc warning:", docErr);
        }
      }

      // Auto-envío a Google Drive si está habilitado y conectado
      if (autoSync && isDriveConnected) {
        uploadDocumentToDrive(formattedResult, true);
      }
    } catch (err: any) {
      console.error(err);
      onShowToast(err.message || "Error al generar formulación PAI", "error");
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopiar = () => {
    if (!resultadoHtml) return;
    navigator.clipboard.writeText(resultadoHtml).then(() => {
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2000);
      onShowToast("Copiado al portapapeles para Rayen", "success");
    });
  };

  const handleGuardarDrive = async () => {
    if (!resultadoHtml) {
      onShowToast("Genere la formulación primero", "error");
      return;
    }
    uploadDocumentToDrive(resultadoHtml, false);
  };

  const handleExportarPDF = async () => {
    if (!resultadoHtml) {
      onShowToast("Genere la formulación primero", "error");
      return;
    }
    setIsExportingPdf(true);
    try {
      const fecha = new Date().toISOString().split("T")[0];
      const nombreLimpio = (nombre.trim() || "Paciente").replace(/\s+/g, "_");
      const filename = `Ingreso_PAI_4P_${nombreLimpio}_${fecha}.pdf`;
      await exportElementToPdf("pai-documento-impresion", {
        filename,
      });
      onShowToast(`PDF descargado: ${filename}`, "success");
    } catch (err: any) {
      console.error("Error al exportar PDF:", err);
      onShowToast(err.message || "Error al generar archivo PDF", "error");
    } finally {
      setIsExportingPdf(false);
    }
  };

  const handleLimpiar = () => {
    setNombre("");
    setDiagnostico("");
    setMotivo("");
    setPredisponentes("");
    setPrecipitantes("");
    setMantenedores("");
    setProtectores("");
    setResultadoHtml("");
    setLastUploadedDoc(null);
    onShowToast("Formulario reiniciado", "info");
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Drive Upload Progress Modal */}
      <DriveUploadProgressModal
        isOpen={isProgressModalOpen}
        progress={driveProgress}
        onClose={() => setIsProgressModalOpen(false)}
        onRetry={() => uploadDocumentToDrive(resultadoHtml, false)}
      />

      {/* Header Bar con Glassmorphism */}
      <div className="clinical-card overflow-hidden">
        <div className="clinical-glass-header px-5 py-3.5 flex flex-col md:flex-row justify-between items-start md:items-center gap-3">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#075985]/10 border border-[#075985]/20 flex items-center justify-center text-[#075985] dark:text-sky-400">
              <Brain className="w-4 h-4" strokeWidth={1.85} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-[#075985] dark:text-sky-300 bg-sky-50 dark:bg-sky-950/60 px-2 py-0.5 rounded border border-sky-200/80 dark:border-sky-800/60">
                  PLAN DE ATENCIÓN INTEGRAL • SISTRAT
                </span>
                <span className="text-[10px] font-medium text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-200/70 dark:border-emerald-800/50 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                  Matriz 4P
                </span>
              </div>
              <h2 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white tracking-tight mt-0.5">
                Ingreso PAI y Formulación Biopsicosocial 4P
              </h2>
            </div>
          </div>
          <button
            onClick={handleLimpiar}
            className="px-3 py-1.5 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-750 text-slate-700 dark:text-slate-200 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 border border-slate-200/90 dark:border-slate-700 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" strokeWidth={1.75} />
            <span>Limpiar</span>
          </button>
        </div>
      </div>

      {/* Barra de Exportación Automática a Documento Personal en Google Docs (Firebase Auth) */}
      <PersonalDocsAutoExportBar
        reportType="Formulación PAI 4P"
        patientName={nombre || "Paciente"}
        patientRut={diagnostico || "PAI"}
        generatedContent={resultadoHtml}
        lastExportedRecord={lastExportedPersonalDoc}
        onExportSuccess={(rec) => setLastExportedPersonalDoc(rec)}
        onShowToast={onShowToast}
      />

      {/* Grid: 4P Form vs Output View with Sticky Glassmorphism Headers */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 lg:h-[calc(100vh-13rem)] lg:min-h-[580px]">
        {/* Form Column */}
        <div className="clinical-card flex flex-col justify-between transition-colors overflow-hidden lg:h-full">
          {/* Sticky Glassmorphism Header de la columna */}
          <div className="clinical-glass-header shrink-0 px-5 py-3.5">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800 dark:text-slate-200 flex items-center gap-2">
                <Brain className="w-4 h-4 text-[#075985] dark:text-sky-400" strokeWidth={1.85} />
                <span>Matriz de Formulación Clínica 4P</span>
              </h3>
              <span className="text-[10px] font-mono text-slate-500 dark:text-slate-400 font-semibold">
                Evaluación Inicial
              </span>
            </div>
          </div>

          {/* Formulario scrolleable independientemente */}
          <div className="flex-1 overflow-y-auto p-5 space-y-3">
            {/* Basic patient info */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pb-2 border-b border-slate-100 dark:border-slate-800">
              <div>
                <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-300 mb-1">
                  Nombre / Iniciales
                </label>
                <input
                  type="text"
                  value={nombre}
                  onChange={(e) => setNombre(e.target.value)}
                  placeholder="Ej: J.P.S."
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg p-2 text-xs text-slate-800 dark:text-slate-200 placeholder:text-slate-400 outline-hidden focus:ring-1 focus:ring-slate-400 transition-colors"
                />
              </div>
              <div>
                <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-300 mb-1">
                  Diagnóstico Principal
                </label>
                <input
                  type="text"
                  value={diagnostico}
                  onChange={(e) => setDiagnostico(e.target.value)}
                  placeholder="Ej: F10.2 T. por consumo de alcohol"
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg p-2 text-xs text-slate-800 dark:text-slate-200 placeholder:text-slate-400 outline-hidden focus:ring-1 focus:ring-slate-400 transition-colors"
                />
              </div>
              <div className="sm:col-span-2">
                <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-300 mb-1">
                  Motivo de Consulta y Estado Actual
                </label>
                <textarea
                  value={motivo}
                  onChange={(e) => setMotivo(e.target.value)}
                  rows={2}
                  placeholder="Paciente derivado tras descompensación..."
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg p-2 text-xs text-slate-800 dark:text-slate-200 placeholder:text-slate-400 outline-hidden resize-none focus:ring-1 focus:ring-slate-400 transition-colors"
                />
              </div>
            </div>

            {/* The 4P Matrix */}
            <div className="space-y-2.5">
              {/* 1. Predisponentes */}
              <div className="bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl p-3 focus-within:ring-1 focus-within:ring-slate-400 transition-colors">
                <div className="flex items-center gap-1.5 text-slate-800 dark:text-slate-200 text-xs font-semibold mb-0.5">
                  <Dna className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" strokeWidth={1.75} />
                  <span>1. Factores Predisponentes (Vulnerabilidad)</span>
                </div>
                <p className="text-[10px] text-slate-500 dark:text-slate-400 mb-1.5">
                  Genética, antecedentes familiares, trauma temprano, temperamento.
                </p>
                <textarea
                  value={predisponentes}
                  onChange={(e) => setPredisponentes(e.target.value)}
                  rows={2}
                  placeholder="Padre con dependencia severa, negligencia afectiva..."
                  className="w-full bg-transparent text-xs text-slate-800 dark:text-slate-200 placeholder:text-slate-400 outline-hidden resize-none"
                />
              </div>

              {/* 2. Precipitantes */}
              <div className="bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl p-3 focus-within:ring-1 focus-within:ring-slate-400 transition-colors">
                <div className="flex items-center gap-1.5 text-slate-800 dark:text-slate-200 text-xs font-semibold mb-0.5">
                  <Zap className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" strokeWidth={1.75} />
                  <span>2. Factores Precipitantes (Gatillantes)</span>
                </div>
                <p className="text-[10px] text-slate-500 dark:text-slate-400 mb-1.5">
                  Duelos, separación, desempleo, estrés agudo, disponibilidad de sustancia.
                </p>
                <textarea
                  value={precipitantes}
                  onChange={(e) => setPrecipitantes(e.target.value)}
                  rows={2}
                  placeholder="Pérdida laboral reciente detonó recaída y consumo diario..."
                  className="w-full bg-transparent text-xs text-slate-800 dark:text-slate-200 placeholder:text-slate-400 outline-hidden resize-none"
                />
              </div>

              {/* 3. Mantenedores */}
              <div className="bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl p-3 focus-within:ring-1 focus-within:ring-slate-400 transition-colors">
                <div className="flex items-center gap-1.5 text-slate-800 dark:text-slate-200 text-xs font-semibold mb-0.5">
                  <Link className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" strokeWidth={1.75} />
                  <span>3. Factores Mantenedores (Perpetuadores)</span>
                </div>
                <p className="text-[10px] text-slate-500 dark:text-slate-400 mb-1.5">
                  Pares consumidores, codependencia familiar, aislamiento, desempleo.
                </p>
                <textarea
                  value={mantenedores}
                  onChange={(e) => setMantenedores(e.target.value)}
                  rows={2}
                  placeholder="Círculo de pares activo, sin actividades de ocio estructuradas..."
                  className="w-full bg-transparent text-xs text-slate-800 dark:text-slate-200 placeholder:text-slate-400 outline-hidden resize-none"
                />
              </div>

              {/* 4. Protectores */}
              <div className="bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl p-3 focus-within:ring-1 focus-within:ring-slate-400 transition-colors">
                <div className="flex items-center gap-1.5 text-slate-800 dark:text-slate-200 text-xs font-semibold mb-0.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" strokeWidth={1.75} />
                  <span>4. Factores Protectores (Resiliencia)</span>
                </div>
                <p className="text-[10px] text-slate-500 dark:text-slate-400 mb-1.5">
                  Red de apoyo continente, motivación intrínseca, oficio técnico, adherencia.
                </p>
                <textarea
                  value={protectores}
                  onChange={(e) => setProtectores(e.target.value)}
                  rows={2}
                  placeholder="Pareja comprometida, deseo expreso de recuperar vínculos filiales..."
                  className="w-full bg-transparent text-xs text-slate-800 dark:text-slate-200 placeholder:text-slate-400 outline-hidden resize-none"
                />
              </div>
            </div>
          </div>

          {/* Botón de acción anclado permanentemente al fondo */}
          <div className="shrink-0 px-5 py-3.5 border-t border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/60">
            <button
              onClick={handleProcesarFormulacion}
              disabled={isLoading || isSavingDrive}
              className="w-full bg-[#075985] hover:bg-[#0c4a6e] text-white font-semibold py-2.5 rounded-xl shadow-xs transition-colors flex items-center justify-center gap-2 text-xs uppercase tracking-wider disabled:opacity-50 cursor-pointer"
            >
              {isLoading ? (
                <>
                  <Sparkles className="w-4 h-4 animate-spin" />
                  <span>Analizando Caso y Matriz 4P...</span>
                </>
              ) : (
                <>
                  <Wand2 className="w-4 h-4" strokeWidth={1.75} />
                  <span>Procesar Formulación Clínica PAI</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Output Column (Sticky Glassmorphism Header & independent scroll) */}
        <div className="clinical-card flex flex-col justify-between transition-colors overflow-hidden lg:h-full">
          {/* Barra de herramientas superior anclada con Glassmorphism */}
          <div className="clinical-glass-header shrink-0 px-5 py-3 flex items-center justify-between flex-wrap gap-2">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800 dark:text-slate-200 flex items-center gap-2">
              <Brain className="w-4 h-4 text-[#075985] dark:text-sky-400" strokeWidth={1.85} />
              <span>Documento PAI para Rayen</span>
            </h3>
            <div className="flex items-center gap-2 flex-wrap">
              <button
                id="btn-guardar-drive-pai"
                onClick={handleGuardarDrive}
                disabled={!resultadoHtml || isSavingDrive}
                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-750 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5 disabled:opacity-40 cursor-pointer shadow-xs"
                title="Enviar documento a Google Drive"
              >
                <HardDrive className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" strokeWidth={1.75} />
                <span>{isSavingDrive ? "Enviando..." : "Enviar a Drive"}</span>
              </button>
              <button
                onClick={handleCopiar}
                disabled={!resultadoHtml}
                className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-900 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5 disabled:opacity-40 shadow-xs cursor-pointer"
              >
                {isCopied ? <Check className="w-3.5 h-3.5" strokeWidth={2} /> : <Copy className="w-3.5 h-3.5" strokeWidth={1.75} />}
                <span>{isCopied ? "Copiado" : "Copiar a Rayen"}</span>
              </button>
              <button
                onClick={handleExportarPDF}
                disabled={!resultadoHtml || isExportingPdf}
                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-750 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5 disabled:opacity-40 cursor-pointer shadow-xs"
                title="Descargar versión PDF oficial"
              >
                {isExportingPdf ? (
                  <Sparkles className="w-3.5 h-3.5 text-slate-500 animate-spin" />
                ) : (
                  <FileDown className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" strokeWidth={1.75} />
                )}
                <span>{isExportingPdf ? "Generando..." : "PDF"}</span>
              </button>
              <button
                onClick={() => window.print()}
                disabled={!resultadoHtml}
                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-750 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5 disabled:opacity-40 cursor-pointer shadow-xs"
              >
                <Printer className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" strokeWidth={1.75} />
                <span>Imprimir</span>
              </button>
            </div>
          </div>

          {/* Last Uploaded Document Banner */}
          {lastUploadedDoc && (
            <div className="shrink-0 mb-2 p-2.5 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl flex items-center justify-between gap-2 text-xs">
              <div className="flex items-center gap-2 truncate">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                <span className="text-slate-700 dark:text-slate-300 font-medium truncate text-[11px]">
                  Sincronizado en <strong>{lastUploadedDoc.folderName}</strong> a las {lastUploadedDoc.time}
                </span>
              </div>
              {lastUploadedDoc.url && (
                <a
                  href={lastUploadedDoc.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="py-1 px-2.5 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-lg font-medium text-[10px] flex items-center gap-1 shrink-0 transition-colors shadow-xs"
                >
                  <span>Abrir</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              )}
            </div>
          )}

          {/* Área de texto que se expande para llenar la altura y scrollea internamente */}
          <div className="flex-1 flex flex-col min-h-[220px] overflow-hidden">
            <textarea
              value={resultadoHtml}
              onChange={(e) => setResultadoHtml(e.target.value)}
              placeholder="El documento de ingreso PAI estructurado con las 4P aparecerá aquí tras presionar 'Procesar Formulación Clínica'."
              className="w-full flex-1 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 focus:border-slate-400 dark:focus:border-slate-600 rounded-xl p-3.5 text-xs font-mono text-slate-800 dark:text-slate-200 leading-relaxed resize-none outline-hidden overflow-y-auto"
            />
          </div>

          {/* Emergency Helpline Card anclada al pie */}
          <div className="shrink-0 pt-2.5">
            <div className="bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-6 h-6 rounded-lg bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 flex items-center justify-center shrink-0 border border-slate-200 dark:border-slate-700">
                  <PhoneCall className="w-3 h-3" strokeWidth={1.75} />
                </div>
                <div>
                  <p className="text-[11px] font-semibold text-slate-800 dark:text-slate-200">
                    Red de Urgencia Crítica
                  </p>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400">
                    Derivación inmediata ante riesgo vital o descompensación
                  </p>
                </div>
              </div>
              <div className="flex gap-2">
                <a
                  href="tel:131"
                  className="bg-slate-900 dark:bg-white hover:bg-slate-800 dark:hover:bg-slate-100 text-white dark:text-slate-900 font-medium text-[11px] px-2.5 py-1 rounded-lg transition-colors shadow-xs"
                >
                  SAMU 131
                </a>
                <a
                  href="tel:*4141"
                  className="bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-750 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 font-medium text-[11px] px-2.5 py-1 rounded-lg transition-colors"
                >
                  *4141
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Hidden Print / PDF Container */}
      <div id="pai-documento-impresion" className="print-only print-area hidden">
        <div style={{ borderBottom: "2px solid #334155", paddingBottom: "10px", marginBottom: "20px", display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
          <div>
            <h2 style={{ fontSize: "16px", fontWeight: "bold", color: "#0f172a", margin: 0, textTransform: "uppercase" }}>
              Cosem Rinconada
            </h2>
            <p style={{ fontSize: "11px", color: "#475569", margin: "3px 0 0 0", fontWeight: 600 }}>
              San Ramón, Santiago de Chile
            </p>
            <p style={{ fontSize: "12px", color: "#334155", margin: "4px 0 0 0", fontWeight: "bold" }}>
              Ingreso y Formulación Dinámica de Caso PAI (Modelo 4P)
            </p>
          </div>
          <div style={{ textAlign: "right", fontSize: "10px", color: "#64748b" }}>
            <p style={{ margin: 0, fontWeight: "bold", color: "#334155" }}>EVALUACIÓN DE INGRESO</p>
            <p style={{ margin: "2px 0 0 0" }}>Fecha: {new Date().toLocaleDateString("es-CL")}</p>
          </div>
        </div>
        <div style={{ whiteSpace: "pre-wrap", fontSize: "12px", lineHeight: "1.6", color: "#111" }}>
          {resultadoHtml}
        </div>
        <div style={{ marginTop: "40px", textAlign: "center", width: "260px", marginLeft: "auto", marginRight: "auto" }}>
          <div style={{ borderTop: "1.5px solid #000", paddingTop: "6px", fontWeight: "bold", fontSize: "12px", color: "#0f172a" }}>
            Dr. Andrés Ruiz Miranda
          </div>
          <div style={{ fontSize: "10.5px", color: "#475569" }}>Médico Programa de Tratamiento en Adicciones</div>
          <div style={{ fontSize: "9.5px", color: "#64748b" }}>Cosem Rinconada, San Ramón</div>
        </div>
      </div>
    </div>
  );
}

export default IngresoPAI;
