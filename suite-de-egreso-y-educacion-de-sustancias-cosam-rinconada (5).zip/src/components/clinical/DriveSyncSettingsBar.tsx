import React, { useState, useEffect } from "react";
import { GoogleDriveService, DEFAULT_SOAP_FOLDER, DEFAULT_PAI_FOLDER } from "../../services/googleDriveService";
import { GoogleSignInButton } from "./GoogleSignInButton";
import {
  HardDrive,
  Folder,
  Settings2,
  Check,
  Sparkles,
  ChevronDown,
  Info,
} from "lucide-react";

interface DriveSyncSettingsBarProps {
  moduleKey?: "soap" | "pai";
  moduleTitle?: string;
  isDriveConnected?: boolean;
  onOpenDriveModal?: () => void;
  autoSync?: boolean;
  onToggleAutoSync?: (enabled: boolean) => void;
  targetFolder?: string;
  onChangeTargetFolder?: (folderName: string) => void;
}

export function DriveSyncSettingsBar({
  moduleKey = "soap",
  moduleTitle = "Evoluciones SOAP",
  isDriveConnected: propIsDriveConnected,
  onOpenDriveModal,
  autoSync: propAutoSync,
  onToggleAutoSync,
  targetFolder: propTargetFolder,
  onChangeTargetFolder,
}: DriveSyncSettingsBarProps) {
  const [internalConnected, setInternalConnected] = useState(() => GoogleDriveService.isConnected());
  const [isConnecting, setIsConnecting] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [isEditingFolder, setIsEditingFolder] = useState(false);
  const defaultFolder = moduleKey === "soap" ? DEFAULT_SOAP_FOLDER : DEFAULT_PAI_FOLDER;
  const [internalTargetFolder, setInternalTargetFolder] = useState(() =>
    GoogleDriveService.getModuleFolder(moduleKey, defaultFolder)
  );
  const [internalAutoSync, setInternalAutoSync] = useState(() =>
    GoogleDriveService.getAutoSync(moduleKey)
  );
  const [tempFolder, setTempFolder] = useState(internalTargetFolder);

  useEffect(() => {
    setInternalConnected(GoogleDriveService.isConnected());

    const handleAuthChange = () => {
      setInternalConnected(GoogleDriveService.isConnected());
    };
    window.addEventListener("cosam:gdrive-auth-changed", handleAuthChange);
    return () => {
      window.removeEventListener("cosam:gdrive-auth-changed", handleAuthChange);
    };
  }, []);

  const isConnected = propIsDriveConnected !== undefined ? propIsDriveConnected : internalConnected;
  const autoSync = propAutoSync !== undefined ? propAutoSync : internalAutoSync;
  const targetFolder = propTargetFolder !== undefined ? propTargetFolder : internalTargetFolder;

  const handleToggleAutoSync = () => {
    if (!isConnected) {
      if (onOpenDriveModal) onOpenDriveModal();
      else handleConnect();
      return;
    }
    const next = !autoSync;
    if (onToggleAutoSync) {
      onToggleAutoSync(next);
    } else {
      setInternalAutoSync(next);
      GoogleDriveService.setAutoSync(moduleKey, next);
    }
  };

  const handleConnect = async () => {
    if (isConnecting) return;
    setIsConnecting(true);
    setAuthError(null);
    try {
      await GoogleDriveService.initiateAuth();
      setInternalConnected(true);
    } catch (e: any) {
      setAuthError(e?.message || "No se pudo autenticar con Firebase Auth.");
    } finally {
      setIsConnecting(false);
    }
  };

  const handleSaveCustomFolder = () => {
    const finalFolder = tempFolder.trim() || defaultFolder;
    if (onChangeTargetFolder) {
      onChangeTargetFolder(finalFolder);
    } else {
      setInternalTargetFolder(finalFolder);
      GoogleDriveService.setModuleFolder(moduleKey, finalFolder);
    }
    setIsEditingFolder(false);
  };

  const handleSelectPreset = (preset: string) => {
    setTempFolder(preset);
    if (onChangeTargetFolder) {
      onChangeTargetFolder(preset);
    } else {
      setInternalTargetFolder(preset);
      GoogleDriveService.setModuleFolder(moduleKey, preset);
    }
    setIsEditingFolder(false);
  };

  return (
    <div
      id={`drive-sync-bar-${moduleKey}`}
      className="bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl p-4 transition-colors"
    >
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
        {/* Left Side: Auto Sync toggle & status */}
        <div className="flex items-center gap-3">
          <button
            type="button"
            id={`toggle-autosync-${moduleKey}`}
            onClick={handleToggleAutoSync}
            disabled={isConnecting}
            className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-hidden disabled:opacity-50 ${
              autoSync && isConnected ? "bg-slate-900 dark:bg-white" : "bg-slate-300 dark:bg-slate-700"
            }`}
          >
            <span
              className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white dark:bg-slate-900 shadow-xs ring-0 transition duration-200 ease-in-out ${
                autoSync && isConnected ? "translate-x-4" : "translate-x-0"
              }`}
            />
          </button>
          <div className="space-y-0.5">
            <div className="flex items-center gap-2">
              <span className="font-medium text-slate-800 dark:text-slate-200 flex items-center gap-1.5 text-xs">
                <HardDrive className="w-3.5 h-3.5 text-slate-600 dark:text-slate-400" strokeWidth={1.75} />
                Envío Automático a Google Drive (Firebase Auth)
              </span>
              <span
                className={`text-[10px] px-2 py-0.5 rounded-md font-medium border ${
                  autoSync && isConnected
                    ? "bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800"
                    : isConnected
                    ? "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700"
                    : "bg-amber-50 dark:bg-amber-950/50 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800"
                }`}
              >
                {!isConnected
                  ? "Desconectado"
                  : autoSync
                  ? "Activo"
                  : "Manual"}
              </span>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 hidden sm:block">
              {autoSync && isConnected
                ? "Al estructurar con IA, se guardará y respaldará automáticamente en su carpeta de Drive."
                : !isConnected
                ? "Inicie sesión con Google mediante Firebase Auth para habilitar la sincronización directa."
                : "Se requiere pulsar 'Enviar a Drive' para respaldar cada documento manualmente."}
            </p>
            {authError && (
              <p className="text-[11px] text-amber-600 dark:text-amber-400 font-medium pt-0.5">
                {authError}
              </p>
            )}
          </div>
        </div>

        {/* Right Side: Target Folder config & account link */}
        <div className="flex items-center gap-2 self-end sm:self-center">
          {!isConnected ? (
            <GoogleSignInButton
              onClick={handleConnect}
              isLoading={isConnecting}
              label="Sign in with Google"
              compact
            />
          ) : (
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                id={`btn-configure-folder-${moduleKey}`}
                onClick={() => {
                  setTempFolder(targetFolder);
                  setIsEditingFolder(!isEditingFolder);
                }}
                className="py-1.5 px-2.5 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-750 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 rounded-lg text-xs flex items-center gap-1.5 transition-colors font-medium cursor-pointer shadow-xs"
                title="Configurar carpeta de destino en Google Drive"
              >
                <Folder className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400 shrink-0" strokeWidth={1.75} />
                <span className="max-w-[140px] sm:max-w-[200px] truncate">
                  {targetFolder}
                </span>
                <Settings2 className="w-3 h-3 text-slate-400" strokeWidth={1.75} />
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Expanded Folder Editor Popover/Accordion */}
      {isEditingFolder && (
        <div className="mt-3 pt-3 border-t border-slate-200 dark:border-slate-700 space-y-2.5 animate-in fade-in duration-150">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-medium text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
              <Folder className="w-3.5 h-3.5 text-slate-500" strokeWidth={1.75} />
              Seleccionar o editar carpeta de destino en Google Drive
            </span>
            <button
              type="button"
              onClick={() => setIsEditingFolder(false)}
              className="text-[11px] text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
            >
              ✕ Cerrar
            </button>
          </div>
          <div className="flex flex-col sm:flex-row gap-2">
            <input
              id={`input-target-folder-${moduleKey}`}
              type="text"
              value={tempFolder}
              onChange={(e) => setTempFolder(e.target.value)}
              placeholder="Nombre de la carpeta en Google Drive..."
              className="flex-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 dark:text-slate-200 placeholder:text-slate-400 outline-hidden focus:ring-1 focus:ring-slate-400 font-mono"
            />
            <button
              type="button"
              id={`btn-save-folder-${moduleKey}`}
              onClick={handleSaveCustomFolder}
              className="py-1.5 px-3 bg-slate-900 hover:bg-slate-800 dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-900 rounded-lg text-xs font-medium transition-colors shrink-0 flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
            >
              <Check className="w-3.5 h-3.5" strokeWidth={2} />
              <span>Establecer Carpeta</span>
            </button>
          </div>
          {/* Quick Presets */}
          <div className="flex flex-wrap items-center gap-1.5 text-[10px]">
            <span className="text-slate-500 dark:text-slate-400 font-medium">Sugerencias:</span>
            <button
              type="button"
              onClick={() => handleSelectPreset(defaultFolder)}
              className="px-2 py-0.5 rounded-md bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-750 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 transition-colors cursor-pointer"
            >
              {defaultFolder}
            </button>
            <button
              type="button"
              onClick={() => handleSelectPreset("COSAM Rinconada - Fichas Clínicas")}
              className="px-2 py-0.5 rounded-md bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-750 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 transition-colors cursor-pointer"
            >
              COSAM Rinconada - General
            </button>
            <button
              type="button"
              onClick={() => handleSelectPreset(`COSAM Rinconada - ${moduleTitle}`)}
              className="px-2 py-0.5 rounded-md bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-750 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 transition-colors cursor-pointer"
            >
              COSAM Rinconada - {moduleTitle}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default DriveSyncSettingsBar;
