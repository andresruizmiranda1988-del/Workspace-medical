import React, { useState } from "react";
import {
  Pill,
  Search,
  Wand2,
  Printer,
  Sparkles,
  Scale,
  ExternalLink,
  ShieldAlert,
  AlertTriangle,
  FileText,
  Activity,
  HeartPulse,
  Send,
  RotateCcw,
  Check,
  Bot,
  User,
  Globe,
  Mic,
  Radio,
  FileDown,
} from "lucide-react";
import { DrugItem } from "../../types";
import { DRUGS_DATABASE, ASHTON_EQUIVALENCE } from "../../data/drugsData";
import { generateClinicalAI, chatClinicalAI } from "../../services/geminiService";
import { SearchGroundingPanel } from "./SearchGroundingPanel";
import { exportElementToPdf } from "../../utils/pdfExport";

interface VademecumClinicoProps {
  onShowToast?: (msg: string, type?: "success" | "error" | "info") => void;
  onOpenTranscribeModal?: () => void;
  onOpenLiveVoiceModal?: () => void;
}

export interface PrintDocumentData {
  tipo: "monografia" | "switch" | "bzd" | "titulacion";
  titulo: string;
  subtitulo: string;
  pacienteNombre?: string;
  pacienteRut?: string;
  medicamentoPrincipal?: string;
  posologia?: string;
  cuerpoIndicaciones: string;
  banderasRojas?: string;
  recomendacionesAdicionales?: string;
}

export const VademecumClinico: React.FC<VademecumClinicoProps> = ({
  onShowToast = () => {},
  onOpenTranscribeModal,
  onOpenLiveVoiceModal,
}) => {
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [familyFilter, setFamilyFilter] = useState<string>("all");
  const [selectedDrug, setSelectedDrug] = useState<DrugItem>(DRUGS_DATABASE[0]);

  // Modal Tools State
  const [activeTab, setActiveTab] = useState<"switch" | "bzd" | "titulacion" | "search" | "scales" | "ai">("switch");
  const [isExportingPdf, setIsExportingPdf] = useState<boolean>(false);

  // Print Document State
  const [printDoc, setPrintDoc] = useState<PrintDocumentData>({
    tipo: "monografia",
    titulo: "COSAM RINCONADA - INDICACIONES MÉDICAS FARMACOLÓGICAS",
    subtitulo: "Programa de Tratamiento en Adicciones y Salud Mental",
    medicamentoPrincipal: DRUGS_DATABASE[0].name,
    posologia: DRUGS_DATABASE[0].dosing,
    cuerpoIndicaciones: DRUGS_DATABASE[0].patientInstructions,
    banderasRojas: DRUGS_DATABASE[0].redFlags,
  });

  // Switch Calculator State
  const [switchPatientName, setSwitchPatientName] = useState<string>("");
  const [switchPatientRut, setSwitchPatientRut] = useState<string>("");
  const [switchFrom, setSwitchFrom] = useState<string>("sertralina");
  const [switchAction, setSwitchAction] = useState<"cambiar" | "suspender">("cambiar");
  const [switchTo, setSwitchTo] = useState<string>("escitalopram");
  const [switchResult, setSwitchResult] = useState<string>("");
  const [switchPatientLeaflet, setSwitchPatientLeaflet] = useState<string>("");

  // BZD Ashton Calculator State
  const [bzdPatientName, setBzdPatientName] = useState<string>("");
  const [bzdPatientRut, setBzdPatientRut] = useState<string>("");
  const [bzdSubstance, setBzdSubstance] = useState<string>("alprazolam");
  const [bzdDose, setBzdDose] = useState<string>("2");
  const [bzdResultText, setBzdResultText] = useState<string>("");
  const [bzdPatientLeaflet, setBzdPatientLeaflet] = useState<string>("");

  // Custom Titration (Aumento / Disminución) State
  const [titulacionPaciente, setTitulacionPaciente] = useState<string>("");
  const [titulacionRut, setTitulacionRut] = useState<string>("");
  const [titulacionTipo, setTitulacionTipo] = useState<"aumento" | "disminucion" | "inicio">("disminucion");
  const [titulacionFarmaco, setTitulacionFarmaco] = useState<string>("quetiapina");
  const [titulacionDosisActual, setTitulacionDosisActual] = useState<string>("100 mg/noche");
  const [titulacionDosisObjetivo, setTitulacionDosisObjetivo] = useState<string>("0 mg (suspensión total)");
  const [titulacionEsquema, setTitulacionEsquema] = useState<string>(
    "• SEMANA 1: Tomar 50 mg (1/2 comprimido) por la noche.\n• SEMANA 2: Tomar 25 mg (1/4 comprimido) por la noche.\n• SEMANA 3: Tomar 25 mg noche por medio si hay insomnio.\n• SEMANA 4 EN ADELANTE: Suspender totalmente. Mantener higiene de sueño."
  );
  const [titulacionCuidados, setTitulacionCuidados] = useState<string>(
    "No consumir alcohol. Si presenta insomnio de rebote, no aumentar la dosis por su cuenta; consulte en su próximo control con el Dr. Ruiz."
  );

  // AI Chat Consultant State
  const [chatInput, setChatInput] = useState<string>("");
  const [chatMessages, setChatMessages] = useState<Array<{ role: "user" | "model"; text: string }>>([
    {
      role: "model",
      text: "Hola, Dr. Ruiz. Soy su consultor farmacológico para COSAM Rinconada. Pregúnteme sobre interacciones complejas, pautas de titulación o toxicología en adicciones.",
    },
  ]);
  const [isAiConsulting, setIsAiConsulting] = useState<boolean>(false);

  const filteredDrugs = DRUGS_DATABASE.filter((d) => {
    const matchSearch =
      d.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      d.brands.toLowerCase().includes(searchTerm.toLowerCase());
    const matchFamily = familyFilter === "all" || d.family === familyFilter;
    return matchSearch && matchFamily;
  });

  const handlePrintDrugInstructions = (drug: DrugItem) => {
    setPrintDoc({
      tipo: "monografia",
      titulo: "COSAM RINCONADA - INDICACIONES MÉDICAS FARMACOLÓGICAS",
      subtitulo: "Servicio de Salud Metropolitano Sur - Programa Tratamiento en Adicciones",
      medicamentoPrincipal: `${drug.name.toUpperCase()} (${drug.brands})`,
      posologia: drug.dosing,
      cuerpoIndicaciones: drug.patientInstructions,
      banderasRojas: drug.redFlags,
      recomendacionesAdicionales: drug.addictions,
    });

    setTimeout(() => {
      window.print();
    }, 100);
  };

  const handleExportPdfDrugInstructions = async (drug: DrugItem) => {
    setPrintDoc({
      tipo: "monografia",
      titulo: "COSAM RINCONADA - INDICACIONES MÉDICAS FARMACOLÓGICAS",
      subtitulo: "Servicio de Salud Metropolitano Sur - Programa Tratamiento en Adicciones",
      medicamentoPrincipal: `${drug.name.toUpperCase()} (${drug.brands})`,
      posologia: drug.dosing,
      cuerpoIndicaciones: drug.patientInstructions,
      banderasRojas: drug.redFlags,
      recomendacionesAdicionales: drug.addictions,
    });

    setIsExportingPdf(true);
    try {
      await new Promise((resolve) => setTimeout(resolve, 150));
      const filename = `Indicaciones_${drug.id.toUpperCase()}_COSAM.pdf`;
      await exportElementToPdf("vademecum-print-document", { filename });
      onShowToast(`PDF descargado: ${filename}`, "success");
    } catch (err: any) {
      console.error(err);
      onShowToast("Error al exportar PDF de indicaciones", "error");
    } finally {
      setIsExportingPdf(false);
    }
  };

  const handlePrintSwitchLeaflet = () => {
    const fromDrug = DRUGS_DATABASE.find((d) => d.id === switchFrom);
    const toDrug = DRUGS_DATABASE.find((d) => d.id === switchTo);
    const actionTitle =
      switchAction === "suspender"
        ? `PAUTA DE RETIRO / DISMINUCIÓN GRADUAL DE ${fromDrug?.name.toUpperCase() || "MEDICAMENTO"}`
        : `PAUTA DE CAMBIO DE ${fromDrug?.name.toUpperCase() || "ORIGEN"} A ${toDrug?.name.toUpperCase() || "DESTINO"}`;

    setPrintDoc({
      tipo: "switch",
      titulo: "COSAM RINCONADA - PAUTA DE DISMINUCIÓN Y CAMBIO FARMACOLÓGICO",
      subtitulo: "Servicio de Salud Metropolitano Sur - Programa Tratamiento en Adicciones",
      pacienteNombre: switchPatientName.trim() || undefined,
      pacienteRut: switchPatientRut.trim() || undefined,
      medicamentoPrincipal: actionTitle,
      posologia: switchResult,
      cuerpoIndicaciones: switchPatientLeaflet || "Consulte el esquema con su médico tratante.",
      banderasRojas: "Ante síntomas severos de abstinencia, náuseas extremas, temblor o palpitaciones, no suspenda bruscamente y acuda al centro o llame al 131 / *4141.",
    });

    setTimeout(() => {
      window.print();
    }, 100);
  };

  const handleExportPdfSwitchLeaflet = async () => {
    const fromDrug = DRUGS_DATABASE.find((d) => d.id === switchFrom);
    const toDrug = DRUGS_DATABASE.find((d) => d.id === switchTo);
    const actionTitle =
      switchAction === "suspender"
        ? `PAUTA DE RETIRO / DISMINUCIÓN GRADUAL DE ${fromDrug?.name.toUpperCase() || "MEDICAMENTO"}`
        : `PAUTA DE CAMBIO DE ${fromDrug?.name.toUpperCase() || "ORIGEN"} A ${toDrug?.name.toUpperCase() || "DESTINO"}`;

    setPrintDoc({
      tipo: "switch",
      titulo: "COSAM RINCONADA - PAUTA DE DISMINUCIÓN Y CAMBIO FARMACOLÓGICO",
      subtitulo: "Servicio de Salud Metropolitano Sur - Programa Tratamiento en Adicciones",
      pacienteNombre: switchPatientName.trim() || undefined,
      pacienteRut: switchPatientRut.trim() || undefined,
      medicamentoPrincipal: actionTitle,
      posologia: switchResult,
      cuerpoIndicaciones: switchPatientLeaflet || "Consulte el esquema con su médico tratante.",
      banderasRojas: "Ante síntomas severos de abstinencia, náuseas extremas, temblor o palpitaciones, no suspenda bruscamente y acuda al centro o llame al 131 / *4141.",
    });

    setIsExportingPdf(true);
    try {
      await new Promise((resolve) => setTimeout(resolve, 150));
      const paciente = switchPatientName.trim() ? switchPatientName.replace(/\s+/g, "_") : "Paciente";
      const filename = `Pauta_Cambio_${fromDrug?.id || "farmaco"}_${paciente}.pdf`;
      await exportElementToPdf("vademecum-print-document", { filename });
      onShowToast(`PDF de cambio descargado: ${filename}`, "success");
    } catch (err: any) {
      console.error(err);
      onShowToast("Error al exportar PDF de cambio", "error");
    } finally {
      setIsExportingPdf(false);
    }
  };

  const handlePrintBzdLeaflet = () => {
    const eqItem = ASHTON_EQUIVALENCE.find((x) => x.substance === bzdSubstance);
    setPrintDoc({
      tipo: "bzd",
      titulo: "COSAM RINCONADA - PROTOCOLO ASHTON DE DESESTABILIZACIÓN Y RETIRO BZD",
      subtitulo: "Servicio de Salud Metropolitano Sur - Programa Tratamiento en Adicciones",
      pacienteNombre: bzdPatientName.trim() || undefined,
      pacienteRut: bzdPatientRut.trim() || undefined,
      medicamentoPrincipal: `Sustitución y Desescalada: ${eqItem?.name || "Benzodiacepina"} (${bzdDose} mg/día)`,
      posologia: bzdResultText,
      cuerpoIndicaciones: bzdPatientLeaflet || "Consulte el cronograma con su médico tratante.",
      banderasRojas: "NUNCA suspenda las benzodiacepinas de un día para otro por riesgo de convulsiones e insomnio severo de rebote. Siga el cronograma de destete con Diazepam.",
    });

    setTimeout(() => {
      window.print();
    }, 100);
  };

  const handleExportPdfBzdLeaflet = async () => {
    const eqItem = ASHTON_EQUIVALENCE.find((x) => x.substance === bzdSubstance);
    setPrintDoc({
      tipo: "bzd",
      titulo: "COSAM RINCONADA - PROTOCOLO ASHTON DE DESESTABILIZACIÓN Y RETIRO BZD",
      subtitulo: "Servicio de Salud Metropolitano Sur - Programa Tratamiento en Adicciones",
      pacienteNombre: bzdPatientName.trim() || undefined,
      pacienteRut: bzdPatientRut.trim() || undefined,
      medicamentoPrincipal: `Sustitución y Desescalada: ${eqItem?.name || "Benzodiacepina"} (${bzdDose} mg/día)`,
      posologia: bzdResultText,
      cuerpoIndicaciones: bzdPatientLeaflet || "Consulte el cronograma con su médico tratante.",
      banderasRojas: "NUNCA suspenda las benzodiacepinas de un día para otro por riesgo de convulsiones e insomnio severo de rebote. Siga el cronograma de destete con Diazepam.",
    });

    setIsExportingPdf(true);
    try {
      await new Promise((resolve) => setTimeout(resolve, 150));
      const paciente = bzdPatientName.trim() ? bzdPatientName.replace(/\s+/g, "_") : "Paciente";
      const filename = `Protocolo_Ashton_BZD_${paciente}.pdf`;
      await exportElementToPdf("vademecum-print-document", { filename });
      onShowToast(`PDF Protocolo Ashton descargado: ${filename}`, "success");
    } catch (err: any) {
      console.error(err);
      onShowToast("Error al exportar PDF Ashton", "error");
    } finally {
      setIsExportingPdf(false);
    }
  };

  const handlePrintTitulacion = () => {
    const farmacoObj = DRUGS_DATABASE.find((d) => d.id === titulacionFarmaco);
    const nombreFarmaco = farmacoObj ? farmacoObj.name.toUpperCase() : titulacionFarmaco.toUpperCase();
    const tituloDoc =
      titulacionTipo === "aumento"
        ? `PAUTA DE TITULACIÓN / AUMENTO PROGRESIVO DE ${nombreFarmaco}`
        : titulacionTipo === "disminucion"
        ? `PAUTA DE DISMINUCIÓN / DESTETE GRADUAL DE ${nombreFarmaco}`
        : `PAUTA DE INICIO Y ADAPTACIÓN DE ${nombreFarmaco}`;

    setPrintDoc({
      tipo: "titulacion",
      titulo: "COSAM RINCONADA - INDICACIONES MÉDICAS DE AJUSTE FARMACOLÓGICO",
      subtitulo: "Servicio de Salud Metropolitano Sur - Programa Tratamiento en Adicciones",
      pacienteNombre: titulacionPaciente.trim() || undefined,
      pacienteRut: titulacionRut.trim() || undefined,
      medicamentoPrincipal: `${tituloDoc} (Dosis actual: ${titulacionDosisActual} ➔ Objetivo: ${titulacionDosisObjetivo})`,
      posologia: `Esquema de transición: ${titulacionDosisActual} a ${titulacionDosisObjetivo}`,
      cuerpoIndicaciones: titulacionEsquema,
      banderasRojas: titulacionCuidados,
    });

    setTimeout(() => {
      window.print();
    }, 100);
  };

  const handleExportPdfTitulacion = async () => {
    const farmacoObj = DRUGS_DATABASE.find((d) => d.id === titulacionFarmaco);
    const nombreFarmaco = farmacoObj ? farmacoObj.name.toUpperCase() : titulacionFarmaco.toUpperCase();
    const tituloDoc =
      titulacionTipo === "aumento"
        ? `PAUTA DE TITULACIÓN / AUMENTO PROGRESIVO DE ${nombreFarmaco}`
        : titulacionTipo === "disminucion"
        ? `PAUTA DE DISMINUCIÓN / DESTETE GRADUAL DE ${nombreFarmaco}`
        : `PAUTA DE INICIO Y ADAPTACIÓN DE ${nombreFarmaco}`;

    setPrintDoc({
      tipo: "titulacion",
      titulo: "COSAM RINCONADA - INDICACIONES MÉDICAS DE AJUSTE FARMACOLÓGICO",
      subtitulo: "Servicio de Salud Metropolitano Sur - Programa Tratamiento en Adicciones",
      pacienteNombre: titulacionPaciente.trim() || undefined,
      pacienteRut: titulacionRut.trim() || undefined,
      medicamentoPrincipal: `${tituloDoc} (Dosis actual: ${titulacionDosisActual} ➔ Objetivo: ${titulacionDosisObjetivo})`,
      posologia: `Esquema de transición: ${titulacionDosisActual} a ${titulacionDosisObjetivo}`,
      cuerpoIndicaciones: titulacionEsquema,
      banderasRojas: titulacionCuidados,
    });

    setIsExportingPdf(true);
    try {
      await new Promise((resolve) => setTimeout(resolve, 150));
      const paciente = titulacionPaciente.trim() ? titulacionPaciente.replace(/\s+/g, "_") : "Paciente";
      const tipo = titulacionTipo === "aumento" ? "Aumento" : titulacionTipo === "disminucion" ? "Disminucion" : "Inicio";
      const filename = `Pauta_${tipo}_${farmacoObj?.id || "farmaco"}_${paciente}.pdf`;
      await exportElementToPdf("vademecum-print-document", { filename });
      onShowToast(`PDF de ajuste descargado: ${filename}`, "success");
    } catch (err: any) {
      console.error(err);
      onShowToast("Error al exportar PDF de pauta", "error");
    } finally {
      setIsExportingPdf(false);
    }
  };

  const handleCalculateSwitch = () => {
    const fromDrug = DRUGS_DATABASE.find((d) => d.id === switchFrom);
    const toDrug = DRUGS_DATABASE.find((d) => d.id === switchTo);
    if (!fromDrug) return;

    const fromName = fromDrug.name;
    const toName = toDrug ? toDrug.name : "";

    let strategy = "";
    let leaflet = "";

    if (switchAction === "suspender") {
      if (fromDrug.family === "benzodiacepina") {
        strategy = `DESTETE GRADUAL OBLIGATORIO ASHTON (Alto Riesgo Convulsivo):\nReducir la dosis un 20-25% cada 1 a 2 semanas. En dependencias severas, realizar conversión previa a Diazepam.`;
        leaflet = `PLAN DE RETIRO GRADUAL DE ${fromName.toUpperCase()}\n\n- SEMANA 1: Tome 3/4 de su dosis habitual.\n- SEMANA 2 y 3: Tome la MITAD (1/2) de su dosis.\n- SEMANA 4: Tome UN CUARTO (1/4) de dosis por las noches.\n- SEMANA 5: Suspenda por completo. Asista a control médico.`;
      } else if (fromDrug.id === "fluoxetina") {
        strategy = `RETIRO DIRECTO O RÁPIDO (Auto-destete biológico):\nDebido a la vida media muy prolongada de Norfluoxetina (hasta 14 días), el fármaco se retira sin generar síndrome de discontinuación agudo.`;
        leaflet = `PLAN DE SUSPENSIÓN DE ${fromName.toUpperCase()}\n\n- Desde mañana suspenda la toma diaria.\n- Su cuerpo irá eliminando el medicamento de forma gradual y natural durante los próximos 10 a 14 días sin molestias abruptas.`;
      } else if (["venlafaxina", "desvenlafaxina", "paroxetina"].includes(fromDrug.id)) {
        strategy = `RETIRO HIPER-LENTO (Riesgo severo de Síndrome de Discontinuación - 'Brain Zaps'):\nReducir en pasos del 25% quincenal o utilizar presentaciones líquidas/fraccionadas.`;
        leaflet = `PLAN DE RETIRO LENTO DE ${fromName.toUpperCase()} (Para evitar mareos y descargas)\n\n- SEMANA 1: Tome la MITAD de su dosis habitual.\n- SEMANA 2: Tome la MITAD de su dosis día por medio.\n- SEMANA 3: Suspenda por completo.`;
      } else {
        strategy = `RETIRO GRADUAL ESTÁNDAR:\nReduzca la dosis al 50% durante 7 a 10 días, luego suspenda.`;
        leaflet = `PLAN DE RETIRO DE ${fromName.toUpperCase()}\n\n- PRIMEROS 7 DÍAS: Tome solo la MITAD de su pastilla habitual.\n- DÍA 8 EN ADELANTE: Suspenda por completo el medicamento.`;
      }
    } else {
      // Cambiar a otro
      if (fromDrug.id === toDrug?.id) {
        strategy = "Ha seleccionado el mismo fármaco de origen y destino.";
        leaflet = "Continúe con su esquema habitual.";
      } else if (fromDrug.id === "fluoxetina") {
        strategy = `LAVADO CORTO (Washout):\nSuspenda Fluoxetina, espere un período de lavado de 3 a 5 días y comience ${toName} a dosis inicial baja.`;
        leaflet = `PLAN DE CAMBIO DE ${fromName.toUpperCase()} A ${toName.toUpperCase()}\n\n1. Suspenda ${fromName}.\n2. Espere 3 días completos sin medicación.\n3. Al cuarto día, inicie ${toName} en la dosis recetada.`;
      } else if (["venlafaxina", "paroxetina"].includes(fromDrug.id)) {
        strategy = `CRUCE GRADUAL LENTO (Cross-tapering):\nReduzca ${fromName} al 50% durante 1 semana mientras introduce ${toName} a dosis mínima. En la semana 2 suspenda ${fromName} y titule ${toName}.`;
        leaflet = `PLAN DE CAMBIO CRUZADO\n\n- SEMANA 1: Tome la mitad de ${fromName} y agregue dosis baja de ${toName}.\n- SEMANA 2: Elimine por completo ${fromName} y continúe solo con ${toName}.`;
      } else {
        strategy = `CRUCE GRADUAL ESTÁNDAR DIRECTO:\nDisminución progresiva de ${fromName} en 1 semana con introducción paralela de ${toName}.`;
        leaflet = `PLAN DE CAMBIO MÉDICO\n\n- SEMANA 1: Baje ${fromName} a la mitad e inicie ${toName} en dosis inicial.\n- SEMANA 2: Suspenda ${fromName} y tome la dosis plena de ${toName}.`;
      }
    }

    setSwitchResult(strategy);
    setSwitchPatientLeaflet(leaflet);
    onShowToast("Pauta de cambio calculada", "success");
  };

  const handleCalculateBZD = () => {
    const doseNum = parseFloat(bzdDose);
    if (isNaN(doseNum) || doseNum <= 0) {
      onShowToast("Ingrese una dosis válida mayor a 0", "error");
      return;
    }

    const eqItem = ASHTON_EQUIVALENCE.find((x) => x.substance === bzdSubstance);
    if (!eqItem) return;

    const diazepamEq = (doseNum / eqItem.ratioToDiazepam10mg) * 10;
    const clonazepamEq = diazepamEq / 20;

    const result = `Equivalencia Ashton Calculada:\n${doseNum} mg de ${eqItem.name} = ${diazepamEq.toFixed(
      1
    )} mg de Diazepam al día (o aprox. ${clonazepamEq.toFixed(2)} mg de Clonazepam).`;

    const leaflet = `PLAN DE ESTABILIZACIÓN Y DESTETE DE BENZODIACEPINAS (Protocolo Ashton)\n\nSustancia de abuso/dependencia actual: ${eqItem.name} (${doseNum} mg/día)\n\nNUEVO ESQUEMA DE ESTABILIZACIÓN:\n- Se sustituye por ${diazepamEq.toFixed(
      1
    )} mg de DIAZEPAM al día.\n\nINDICACIONES AL PACIENTE:\n- El Diazepam tiene una duración prolongada en el cuerpo que evita los temblores, la ansiedad y el insomnio de rebote.\n- Siga la dosis exacta indicada. El médico irá reduciendo semanalmente hasta retirar el fármaco sin riesgo de convulsiones.`;

    setBzdResultText(result);
    setBzdPatientLeaflet(leaflet);
    onShowToast("Equivalencia calculada exitosamente", "success");
  };

  const handleSendAiMessage = async () => {
    if (!chatInput.trim()) return;

    const userText = chatInput.trim();
    setChatInput("");
    const newMessages = [...chatMessages, { role: "user" as const, text: userText }];
    setChatMessages(newMessages);
    setIsAiConsulting(true);

    try {
      const response = await chatClinicalAI({
        messages: newMessages,
        systemInstruction:
          "Eres un toxicólogo clínico y psiquiatra especialista en patología dual y adicciones en el COSAM Rinconada. Responde de forma técnica, precisa, concisa y basada en guías clínicas.",
        temperature: 0.2,
      });

      setChatMessages([...newMessages, { role: "model" as const, text: response }]);
    } catch (err: any) {
      console.error(err);
      onShowToast(err.message || "Error al consultar con el asistente IA", "error");
    } finally {
      setIsAiConsulting(false);
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto" id="vademecum-clinico-container">
      {/* Header Bar con Glassmorphism */}
      <div className="clinical-card overflow-hidden">
        <div className="clinical-glass-header px-5 py-3.5 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-sky-500/10 border border-sky-500/20 text-[#075985] dark:text-sky-400 flex items-center justify-center shrink-0">
              <Pill size={18} strokeWidth={1.75} />
            </div>
            <div>
              <div className="flex items-center gap-2 mb-0.5">
                <span className="text-[10px] font-bold uppercase tracking-wider text-[#075985] dark:text-sky-400">
                  Farmacopea Psiquiátrica
                </span>
                <span className="text-slate-300 dark:text-slate-700">·</span>
                <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">COSAM Rinconada · San Ramón</span>
              </div>
              <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white tracking-tight">
                Vademécum Clínico en Adicciones y Salud Mental
              </h2>
            </div>
          </div>

          <button
            onClick={() => {
              const modal = document.getElementById("toolsModalVademecum");
              if (modal) modal.classList.remove("hidden");
            }}
            className="bg-[#075985] hover:bg-[#0c4a6e] text-white font-semibold px-4 py-2 rounded-xl text-xs transition-all shadow-xs flex items-center gap-2 cursor-pointer active:scale-95 shrink-0"
          >
            <Sparkles className="w-3.5 h-3.5 text-sky-200" />
            <span>Calculadoras &amp; Asistente IA</span>
          </button>
        </div>
      </div>

      {/* Main Content: Left Drug List vs Right Drug Details */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Search & Drug Catalog with Sticky Glassmorphism Header */}
        <div className="lg:col-span-4 clinical-card flex flex-col h-[750px] relative overflow-hidden">
          <div className="clinical-glass-header shrink-0 px-5 py-3.5 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-800 dark:text-slate-200">
                Catálogo Farmacológico
              </span>
              <span className="text-[10px] font-mono font-semibold text-slate-500">
                {filteredDrugs.length} fármacos
              </span>
            </div>
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Buscar fármaco o marca comercial..."
                className="w-full bg-white/90 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:border-[#075985] rounded-xl pl-9 pr-3 py-2 text-xs text-slate-900 dark:text-white outline-none font-medium placeholder:text-slate-400"
              />
            </div>

            <select
              value={familyFilter}
              onChange={(e) => setFamilyFilter(e.target.value)}
              className="w-full bg-white/90 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 rounded-xl px-3 py-1.5 text-xs font-semibold focus:border-[#075985] outline-none cursor-pointer"
            >
              <option value="all">Todas las familias</option>
              <option value="antidepresivo">Antidepresivos (ISRS, IRSN, IRND, SARI)</option>
              <option value="benzodiacepina">Benzodiacepinas y Fármacos Z</option>
              <option value="estabilizador">Estabilizadores del Ánimo y Anticonvulsivantes</option>
              <option value="antipsicotico">Antipsicóticos Atípicos y Típicos</option>
              <option value="estimulante">Estimulantes del SNC</option>
              <option value="adicciones">Fármacos Específicos para Adicciones</option>
            </select>
          </div>

          {/* Drug items list */}
          <div className="flex-1 overflow-y-auto space-y-1.5 p-4">
            {filteredDrugs.map((drug) => {
              const isSelected = selectedDrug.id === drug.id;
              let badgeColor = "bg-black/[0.04] dark:bg-white/[0.08] text-slate-700 dark:text-slate-300";
              if (drug.family === "adicciones")
                badgeColor = "bg-teal-500/10 text-teal-700 dark:text-teal-400";
              if (drug.family === "benzodiacepina")
                badgeColor = "bg-amber-500/10 text-amber-700 dark:text-amber-400";
              if (drug.family === "estimulante")
                badgeColor = "bg-rose-500/10 text-rose-700 dark:text-rose-400";

              return (
                <div
                  key={drug.id}
                  onClick={() => setSelectedDrug(drug)}
                  className={`p-3 rounded-2xl cursor-pointer transition-all border ${
                    isSelected
                      ? "bg-slate-900 text-white dark:bg-white dark:text-slate-900 border-slate-900 dark:border-white shadow-xs"
                      : "ios-card hover:bg-black/[0.02] dark:hover:bg-white/[0.04] border-black/[0.04] dark:border-white/[0.06]"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold flex items-center gap-1.5">
                      <span>{drug.name}</span>
                      {drug.recipe === "cheque" && (
                        <span className="w-2 h-2 rounded-full bg-rose-500 shrink-0" title="Receta Cheque" />
                      )}
                      {drug.recipe === "retenida" && (
                        <span className="w-2 h-2 rounded-full bg-amber-500 shrink-0" title="Receta Retenida" />
                      )}
                    </h4>
                    <span className={`text-[9px] font-semibold px-2 py-0.5 rounded-full uppercase ${
                      isSelected ? "bg-white/20 dark:bg-slate-900/15 text-white dark:text-slate-900" : badgeColor
                    }`}>
                      {drug.family}
                    </span>
                  </div>
                  <p className={`text-[10px] mt-1 line-clamp-1 ${
                    isSelected ? "text-slate-300 dark:text-slate-600" : "text-slate-500 dark:text-slate-400"
                  }`}>
                    Marcas: {drug.brands}
                  </p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Complete Drug Monograph with Sticky Glassmorphism Header */}
        <div className="lg:col-span-8 clinical-card h-[750px] overflow-y-auto">
          {/* Sticky Glassmorphism Monograph Header */}
          <div className="clinical-glass-header px-6 py-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <div className="flex items-center gap-3">
                <h3 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white tracking-tight">
                  {selectedDrug.name}
                </h3>
                <span
                  className={`text-[10px] font-bold px-2.5 py-0.5 rounded-md uppercase tracking-wider border ${
                    selectedDrug.recipe === "cheque"
                      ? "bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border-rose-200 dark:border-rose-800/50"
                      : selectedDrug.recipe === "retenida"
                      ? "bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800/50"
                      : "bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800/50"
                  }`}
                >
                  Receta {selectedDrug.recipe}
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 font-medium">
                Marcas comerciales habituales: {selectedDrug.brands}
              </p>
            </div>

            <div className="flex items-center gap-2 sm:gap-3 flex-wrap">
              <div className="text-center bg-slate-950 border border-slate-800 px-3 py-2 rounded-2xl">
                <div
                  className={`text-lg font-black ${
                    selectedDrug.fda === "X" || selectedDrug.fda === "D"
                      ? "text-red-400"
                      : "text-amber-400"
                  }`}
                >
                  {selectedDrug.fda}
                </div>
                <span className="text-[8px] font-bold text-slate-500 uppercase tracking-widest">
                  FDA Embarazo
                </span>
              </div>

              <button
                onClick={() => handleExportPdfDrugInstructions(selectedDrug)}
                disabled={isExportingPdf}
                className="bg-rose-950/80 hover:bg-rose-900 border border-rose-500/40 text-rose-200 p-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-sm disabled:opacity-40 cursor-pointer"
                title="Descargar Ficha en PDF"
              >
                {isExportingPdf ? (
                  <Sparkles className="w-4 h-4 text-rose-400 animate-spin" />
                ) : (
                  <FileDown className="w-4 h-4 text-rose-400" />
                )}
                <span className="hidden sm:inline">Exportar PDF</span>
              </button>

              <button
                onClick={() => handlePrintDrugInstructions(selectedDrug)}
                className="bg-slate-800 hover:bg-slate-700 text-slate-200 p-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
                title="Imprimir hoja de educación"
              >
                <Printer className="w-4 h-4" />
                <span className="hidden sm:inline">Imprimir Ficha</span>
              </button>
            </div>
          </div>

          {/* Clinical Profile Card */}
          <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-4 space-y-2">
            <h4 className="text-xs font-bold text-purple-400 uppercase tracking-wider flex items-center gap-1.5">
              <Activity className="w-3.5 h-3.5" />
              <span>Mecanismo de Acción y Dosificación</span>
            </h4>
            <p className="text-xs text-slate-300 leading-relaxed">
              <strong className="text-white">Mecanismo:</strong> {selectedDrug.mechanism}
            </p>
            <p className="text-xs text-slate-300 leading-relaxed">
              <strong className="text-white">Indicaciones Clínicas:</strong> {selectedDrug.indications}
            </p>
            <div className="bg-purple-950/30 border border-purple-500/20 rounded-xl p-3 mt-2">
              <p className="text-[10px] font-bold uppercase tracking-wider text-purple-300 mb-1">
                Pauta de Dosificación en Adultos
              </p>
              <p className="text-xs font-mono text-purple-200">{selectedDrug.dosing}</p>
            </div>
          </div>

          {/* Adicciones y Patología Dual */}
          <div className="bg-cyan-950/20 border border-cyan-500/30 rounded-2xl p-4 relative overflow-hidden">
            <div className="absolute top-0 left-0 w-1 h-full bg-cyan-500" />
            <h4 className="text-xs font-bold text-cyan-300 uppercase tracking-wider flex items-center gap-1.5 mb-1.5">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              <span>Consideraciones en Adicciones y Patología Dual</span>
            </h4>
            <p className="text-xs text-slate-200 leading-relaxed font-medium">
              {selectedDrug.addictions}
            </p>
          </div>

          {/* Red Flags / Banderas Rojas */}
          <div className="bg-red-950/20 border border-red-500/30 rounded-2xl p-4 relative overflow-hidden">
            <div className="absolute top-0 left-0 w-1 h-full bg-red-500" />
            <h4 className="text-xs font-bold text-red-400 uppercase tracking-wider flex items-center gap-1.5 mb-1.5">
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>Banderas Rojas de Seguridad y Alertas Clínicas</span>
            </h4>
            <p className="text-xs text-red-200 leading-relaxed font-semibold">
              {selectedDrug.redFlags}
            </p>
          </div>

          {/* Safety & Monitoring Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-3.5 space-y-1.5">
              <h5 className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                Monitoreo y Exámenes
              </h5>
              <p className="text-xs text-slate-200">{selectedDrug.labs}</p>
            </div>
            <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-3.5 space-y-1.5">
              <h5 className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                Efectos Adversos Comunes
              </h5>
              <p className="text-xs text-slate-200">{selectedDrug.adverse}</p>
            </div>
            <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-3.5 space-y-1.5">
              <h5 className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                Toxicidad y Sobredosis
              </h5>
              <p className="text-xs text-slate-200">{selectedDrug.toxicity}</p>
            </div>
            <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-3.5 space-y-1.5">
              <h5 className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                Contraindicaciones Absolutas
              </h5>
              <p className="text-xs text-slate-200">{selectedDrug.contraindications}</p>
            </div>
          </div>

          {/* Patient Education Section */}
          <div className="bg-gradient-to-r from-purple-950/30 via-slate-900 to-indigo-950/30 border border-purple-500/30 rounded-2xl p-4 space-y-2">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-purple-300 uppercase tracking-wider flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5" />
                <span>Pauta de Educación y Lenguaje para el Paciente</span>
              </h4>
            </div>
            <p className="text-xs text-slate-200 italic leading-relaxed bg-slate-950/60 p-3 rounded-xl border border-slate-800">
              "{selectedDrug.patientInstructions}"
            </p>
          </div>
        </div>
      </div>

      {/* MODAL: Central de Herramientas Clínicas */}
      <div
        id="toolsModalVademecum"
        className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4 hidden"
      >
        <div className="bg-slate-900 border border-purple-500/30 rounded-3xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
          {/* Modal Header */}
          <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-slate-950/80">
            <div className="flex items-center gap-2.5">
              <Sparkles className="w-5 h-5 text-purple-400" />
              <h3 className="text-base font-bold text-white">
                Central de Herramientas Farmacológicas
              </h3>
            </div>
            <button
              onClick={() => {
                const modal = document.getElementById("toolsModalVademecum");
                if (modal) modal.classList.add("hidden");
              }}
              className="text-slate-400 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
            >
              ✕
            </button>
          </div>

          {/* Tabs */}
          <div className="flex border-b border-slate-800 bg-slate-950/50 px-4 text-xs font-bold overflow-x-auto">
            <button
              onClick={() => setActiveTab("switch")}
              className={`px-4 py-3 border-b-2 whitespace-nowrap transition-all cursor-pointer ${
                activeTab === "switch"
                  ? "border-purple-500 text-purple-300"
                  : "border-transparent text-slate-400 hover:text-slate-200"
              }`}
            >
              🔄 Cambio / Retiro Fármacos
            </button>
            <button
              onClick={() => setActiveTab("bzd")}
              className={`px-4 py-3 border-b-2 whitespace-nowrap transition-all cursor-pointer ${
                activeTab === "bzd"
                  ? "border-amber-500 text-amber-300"
                  : "border-transparent text-slate-400 hover:text-slate-200"
              }`}
            >
              ⚖️ Equivalencias BZD (Ashton)
            </button>
            <button
              onClick={() => setActiveTab("titulacion")}
              className={`px-4 py-3 border-b-2 whitespace-nowrap transition-all cursor-pointer ${
                activeTab === "titulacion"
                  ? "border-emerald-500 text-emerald-300"
                  : "border-transparent text-slate-400 hover:text-slate-200"
              }`}
            >
              📈 Pauta Aumento / Destete
            </button>
            <button
              onClick={() => setActiveTab("search")}
              className={`px-4 py-3 border-b-2 whitespace-nowrap transition-all cursor-pointer ${
                activeTab === "search"
                  ? "border-indigo-500 text-indigo-300"
                  : "border-transparent text-slate-400 hover:text-slate-200"
              }`}
            >
              🌐 Evidencia Web (Google Search Grounding)
            </button>
            <button
              onClick={() => setActiveTab("scales")}
              className={`px-4 py-3 border-b-2 whitespace-nowrap transition-all cursor-pointer ${
                activeTab === "scales"
                  ? "border-cyan-500 text-cyan-300"
                  : "border-transparent text-slate-400 hover:text-slate-200"
              }`}
            >
              📊 Escalas Clínicas (MDCalc)
            </button>
            <button
              onClick={() => setActiveTab("ai")}
              className={`px-4 py-3 border-b-2 whitespace-nowrap transition-all cursor-pointer ${
                activeTab === "ai"
                  ? "border-pink-500 text-pink-300"
                  : "border-transparent text-slate-400 hover:text-slate-200"
              }`}
            >
              🤖 Consultor IA Clínico
            </button>
          </div>

          {/* Tab Content Body */}
          <div className="p-6 overflow-y-auto flex-1 space-y-4 text-xs">
            {/* Tab 1: Switch Calculator */}
            {activeTab === "switch" && (
              <div className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-slate-950/60 p-3.5 rounded-2xl border border-slate-800">
                  <div>
                    <label className="block font-bold text-slate-400 mb-1">Nombre del Paciente (Opcional para Membrete)</label>
                    <input
                      type="text"
                      value={switchPatientName}
                      onChange={(e) => setSwitchPatientName(e.target.value)}
                      placeholder="Ej: Juan Pérez"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-slate-200 outline-none focus:border-purple-500/60"
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-slate-400 mb-1">RUT del Paciente</label>
                    <input
                      type="text"
                      value={switchPatientRut}
                      onChange={(e) => setSwitchPatientRut(e.target.value)}
                      placeholder="Ej: 12.345.678-9"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-slate-200 outline-none focus:border-purple-500/60"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block font-bold text-slate-400 mb-1">1. Fármaco Actual</label>
                    <select
                      value={switchFrom}
                      onChange={(e) => setSwitchFrom(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-slate-200 outline-none"
                    >
                      {DRUGS_DATABASE.map((d) => (
                        <option key={d.id} value={d.id}>
                          {d.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block font-bold text-slate-400 mb-1">2. Acción</label>
                    <select
                      value={switchAction}
                      onChange={(e) => setSwitchAction(e.target.value as any)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-purple-300 font-bold outline-none"
                    >
                      <option value="cambiar">🔄 Cambiar a otro fármaco</option>
                      <option value="suspender">🛑 Suspender (Destete)</option>
                    </select>
                  </div>
                  {switchAction === "cambiar" && (
                    <div>
                      <label className="block font-bold text-slate-400 mb-1">3. Nuevo Fármaco</label>
                      <select
                        value={switchTo}
                        onChange={(e) => setSwitchTo(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-slate-200 outline-none"
                      >
                        {DRUGS_DATABASE.map((d) => (
                          <option key={d.id} value={d.id}>
                            {d.name}
                          </option>
                        ))}
                      </select>
                    </div>
                  )}
                </div>

                <button
                  onClick={handleCalculateSwitch}
                  className="w-full py-3 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-xl shadow-lg transition-all cursor-pointer"
                >
                  Calcular Estrategia y Pauta para Paciente
                </button>

                {switchResult && (
                  <div className="space-y-3 mt-3">
                    <div className="bg-purple-950/30 border border-purple-500/30 rounded-2xl p-4 text-purple-200 font-medium">
                      <p className="font-bold text-purple-400 mb-1">Conducta Médica:</p>
                      <p className="whitespace-pre-line">{switchResult}</p>
                    </div>
                    <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 text-slate-300 font-mono">
                      <div className="flex items-center justify-between mb-2">
                        <p className="font-bold text-emerald-400">Entregable para el Paciente:</p>
                        <div className="flex gap-2 flex-wrap">
                          <button
                            onClick={() => {
                              navigator.clipboard.writeText(switchPatientLeaflet);
                              onShowToast("Pauta copiada al portapapeles", "success");
                            }}
                            className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-[10px] font-bold cursor-pointer"
                          >
                            Copiar
                          </button>
                          <button
                            onClick={handleExportPdfSwitchLeaflet}
                            disabled={isExportingPdf}
                            className="px-3 py-1 bg-rose-950/80 hover:bg-rose-900 border border-rose-500/40 text-rose-200 rounded-lg text-[10px] font-bold flex items-center gap-1.5 shadow cursor-pointer"
                          >
                            <FileDown className="w-3.5 h-3.5 text-rose-400" />
                            <span>Exportar PDF</span>
                          </button>
                          <button
                            onClick={handlePrintSwitchLeaflet}
                            className="px-3 py-1 bg-purple-600 hover:bg-purple-500 text-white rounded-lg text-[10px] font-bold flex items-center gap-1.5 shadow cursor-pointer"
                          >
                            <Printer className="w-3.5 h-3.5" />
                            <span>Imprimir Membrete COSAM</span>
                          </button>
                        </div>
                      </div>
                      <p className="whitespace-pre-line text-[11px] leading-relaxed">{switchPatientLeaflet}</p>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Tab 2: Ashton BZD Calculator */}
            {activeTab === "bzd" && (
              <div className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-slate-950/60 p-3.5 rounded-2xl border border-slate-800">
                  <div>
                    <label className="block font-bold text-slate-400 mb-1">Nombre del Paciente (Opcional)</label>
                    <input
                      type="text"
                      value={bzdPatientName}
                      onChange={(e) => setBzdPatientName(e.target.value)}
                      placeholder="Ej: María González"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-slate-200 outline-none focus:border-amber-500/60"
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-slate-400 mb-1">RUT del Paciente</label>
                    <input
                      type="text"
                      value={bzdPatientRut}
                      onChange={(e) => setBzdPatientRut(e.target.value)}
                      placeholder="Ej: 14.567.890-K"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-slate-200 outline-none focus:border-amber-500/60"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block font-bold text-slate-400 mb-1">Sustancia BZD Actual</label>
                    <select
                      value={bzdSubstance}
                      onChange={(e) => setBzdSubstance(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-slate-200 outline-none"
                    >
                      {ASHTON_EQUIVALENCE.map((item) => (
                        <option key={item.substance} value={item.substance}>
                          {item.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block font-bold text-slate-400 mb-1">Dosis Diaria Total (mg)</label>
                    <input
                      type="number"
                      step="0.5"
                      value={bzdDose}
                      onChange={(e) => setBzdDose(e.target.value)}
                      placeholder="Ej: 2"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-slate-200 outline-none"
                    />
                  </div>
                </div>

                <button
                  onClick={handleCalculateBZD}
                  className="w-full py-3 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-xl shadow-lg transition-all cursor-pointer"
                >
                  Calcular Dosis Equivalente Diazepam
                </button>

                {bzdResultText && (
                  <div className="space-y-3 mt-3">
                    <div className="bg-amber-950/30 border border-amber-500/30 rounded-2xl p-4 text-amber-200">
                      <p className="font-bold text-amber-400 mb-1">Cálculo Ashton:</p>
                      <p className="whitespace-pre-line font-mono">{bzdResultText}</p>
                    </div>
                    <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 text-slate-300 font-mono">
                      <div className="flex items-center justify-between mb-2">
                        <p className="font-bold text-emerald-400">Pauta Paciente Ashton:</p>
                        <div className="flex gap-2 flex-wrap">
                          <button
                            onClick={() => {
                              navigator.clipboard.writeText(bzdPatientLeaflet);
                              onShowToast("Pauta Ashton copiada", "success");
                            }}
                            className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-[10px] font-bold cursor-pointer"
                          >
                            Copiar
                          </button>
                          <button
                            onClick={handleExportPdfBzdLeaflet}
                            disabled={isExportingPdf}
                            className="px-3 py-1 bg-rose-950/80 hover:bg-rose-900 border border-rose-500/40 text-rose-200 rounded-lg text-[10px] font-bold flex items-center gap-1.5 shadow cursor-pointer"
                          >
                            <FileDown className="w-3.5 h-3.5 text-rose-400" />
                            <span>Exportar PDF</span>
                          </button>
                          <button
                            onClick={handlePrintBzdLeaflet}
                            className="px-3 py-1 bg-amber-600 hover:bg-amber-500 text-white rounded-lg text-[10px] font-bold flex items-center gap-1.5 shadow cursor-pointer"
                          >
                            <Printer className="w-3.5 h-3.5" />
                            <span>Imprimir con Membrete COSAM</span>
                          </button>
                        </div>
                      </div>
                      <p className="whitespace-pre-line text-[11px] leading-relaxed">{bzdPatientLeaflet}</p>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Tab 3: Custom Titration / Increase / Decrease Leaflet */}
            {activeTab === "titulacion" && (
              <div className="space-y-4">
                <div className="bg-emerald-950/20 border border-emerald-500/30 rounded-2xl p-4">
                  <h4 className="font-bold text-emerald-300 text-sm mb-1 flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-emerald-400" />
                    <span>Generador de Indicaciones de Aumento / Disminución de Dosis</span>
                  </h4>
                  <p className="text-slate-400 text-[11px]">
                    Configure esquemas de titulación ascendente o destete progresivo para entregar impreso al paciente con membrete oficial del COSAM.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-slate-400 mb-1">Nombre del Paciente</label>
                    <input
                      type="text"
                      value={titulacionPaciente}
                      onChange={(e) => setTitulacionPaciente(e.target.value)}
                      placeholder="Nombre y Apellidos"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-slate-200 outline-none focus:border-emerald-500/60"
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-slate-400 mb-1">RUT</label>
                    <input
                      type="text"
                      value={titulacionRut}
                      onChange={(e) => setTitulacionRut(e.target.value)}
                      placeholder="Ej: 16.789.012-3"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-slate-200 outline-none focus:border-emerald-500/60"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block font-bold text-slate-400 mb-1">Tipo de Pauta</label>
                    <select
                      value={titulacionTipo}
                      onChange={(e) => setTitulacionTipo(e.target.value as any)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-emerald-300 font-bold outline-none"
                    >
                      <option value="disminucion">📉 Disminución / Destete Gradual</option>
                      <option value="aumento">📈 Aumento / Titulación Progresiva</option>
                      <option value="inicio">🚀 Inicio / Adaptación Inicial</option>
                    </select>
                  </div>
                  <div>
                    <label className="block font-bold text-slate-400 mb-1">Fármaco a Ajustar</label>
                    <select
                      value={titulacionFarmaco}
                      onChange={(e) => setTitulacionFarmaco(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-slate-200 outline-none"
                    >
                      {DRUGS_DATABASE.map((d) => (
                        <option key={d.id} value={d.id}>
                          {d.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block font-bold text-slate-400 mb-1">Dosis Actual ➔ Objetivo</label>
                    <div className="flex gap-1.5">
                      <input
                        type="text"
                        value={titulacionDosisActual}
                        onChange={(e) => setTitulacionDosisActual(e.target.value)}
                        placeholder="Actual"
                        className="w-1/2 bg-slate-950 border border-slate-800 rounded-xl p-2 text-[11px] text-slate-200 outline-none"
                      />
                      <input
                        type="text"
                        value={titulacionDosisObjetivo}
                        onChange={(e) => setTitulacionDosisObjetivo(e.target.value)}
                        placeholder="Objetivo"
                        className="w-1/2 bg-slate-950 border border-slate-800 rounded-xl p-2 text-[11px] text-slate-200 outline-none"
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-slate-400 mb-1">
                    Esquema Detallado Semana a Semana (Pauta para el Paciente)
                  </label>
                  <textarea
                    value={titulacionEsquema}
                    onChange={(e) => setTitulacionEsquema(e.target.value)}
                    rows={4}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs font-mono text-emerald-200 outline-none focus:border-emerald-500/60 leading-relaxed"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-400 mb-1">
                    Cuidados Especiales, Banderas Rojas y Advertencias
                  </label>
                  <textarea
                    value={titulacionCuidados}
                    onChange={(e) => setTitulacionCuidados(e.target.value)}
                    rows={2}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-rose-200 outline-none focus:border-rose-500/60"
                  />
                </div>

                <div className="flex gap-3 pt-2 flex-wrap">
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(`${titulacionEsquema}\n\nCuidados: ${titulacionCuidados}`);
                      onShowToast("Pauta copiada al portapapeles", "success");
                    }}
                    className="px-4 py-3 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-xl transition-all text-xs cursor-pointer"
                  >
                    Copiar Pauta
                  </button>
                  <button
                    onClick={handleExportPdfTitulacion}
                    disabled={isExportingPdf}
                    className="flex-1 py-3 bg-rose-950/80 hover:bg-rose-900 border border-rose-500/40 text-rose-200 font-bold rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 text-xs cursor-pointer"
                  >
                    <FileDown className="w-4 h-4 text-rose-400" />
                    <span>Exportar PDF Pauta</span>
                  </button>
                  <button
                    onClick={handlePrintTitulacion}
                    className="flex-1 py-3 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 text-xs cursor-pointer"
                  >
                    <Printer className="w-4 h-4" />
                    <span>Imprimir con Membrete</span>
                  </button>
                </div>
              </div>
            )}

            {/* Tab 4: Search Grounding (gemini-3.5-flash with googleSearch) */}
            {activeTab === "search" && (
              <SearchGroundingPanel
                defaultQuery={`Alertas farmacológicas e interacciones sobre ${selectedDrug.name}`}
                onShowToast={onShowToast}
              />
            )}

            {/* Tab 5: Clinical Scales */}
            {activeTab === "scales" && (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                <a
                  href="https://www.mdcalc.com/calc/1731/ciwaar-alcohol-withdrawal"
                  target="_blank"
                  rel="noreferrer"
                  className="bg-slate-950 hover:bg-slate-900 border border-slate-800 hover:border-cyan-500/50 p-4 rounded-2xl transition-all flex items-center justify-between"
                >
                  <div>
                    <h5 className="font-bold text-white">CIWA-Ar</h5>
                    <p className="text-[10px] text-slate-400">Abstinencia de Alcohol</p>
                  </div>
                  <ExternalLink className="w-4 h-4 text-cyan-400" />
                </a>

                <a
                  href="https://www.mdcalc.com/calc/10189/audit-c-alcohol-use"
                  target="_blank"
                  rel="noreferrer"
                  className="bg-slate-950 hover:bg-slate-900 border border-slate-800 hover:border-amber-500/50 p-4 rounded-2xl transition-all flex items-center justify-between"
                >
                  <div>
                    <h5 className="font-bold text-white">AUDIT-C</h5>
                    <p className="text-[10px] text-slate-400">Screening Consumo de Alcohol</p>
                  </div>
                  <ExternalLink className="w-4 h-4 text-amber-400" />
                </a>

                <a
                  href="https://www.mdcalc.com/calc/1725/phq9-patient-health-questionnaire-9"
                  target="_blank"
                  rel="noreferrer"
                  className="bg-slate-950 hover:bg-slate-900 border border-slate-800 hover:border-purple-500/50 p-4 rounded-2xl transition-all flex items-center justify-between"
                >
                  <div>
                    <h5 className="font-bold text-white">PHQ-9</h5>
                    <p className="text-[10px] text-slate-400">Depresión e Ideación Suicida</p>
                  </div>
                  <ExternalLink className="w-4 h-4 text-purple-400" />
                </a>

                <a
                  href="https://www.mdcalc.com/calc/1727/gad7-general-anxiety-disorder7"
                  target="_blank"
                  rel="noreferrer"
                  className="bg-slate-950 hover:bg-slate-900 border border-slate-800 hover:border-teal-500/50 p-4 rounded-2xl transition-all flex items-center justify-between"
                >
                  <div>
                    <h5 className="font-bold text-white">GAD-7</h5>
                    <p className="text-[10px] text-slate-400">Ansiedad Generalizada</p>
                  </div>
                  <ExternalLink className="w-4 h-4 text-teal-400" />
                </a>

                <a
                  href="https://www.mdcalc.com/calc/4059/asrs-v11-adhd"
                  target="_blank"
                  rel="noreferrer"
                  className="bg-slate-950 hover:bg-slate-900 border border-slate-800 hover:border-rose-500/50 p-4 rounded-2xl transition-all flex items-center justify-between"
                >
                  <div>
                    <h5 className="font-bold text-white">ASRS v1.1</h5>
                    <p className="text-[10px] text-slate-400">TDAH en Adultos</p>
                  </div>
                  <ExternalLink className="w-4 h-4 text-rose-400" />
                </a>
              </div>
            )}

            {/* Tab 6: Live AI Pharmacological Consultant */}
            {activeTab === "ai" && (
              <div className="flex flex-col h-[400px]">
                <div className="flex items-center justify-between bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 mb-2">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-3.5 h-3.5 text-pink-400" />
                    <span className="text-[11px] text-slate-300 font-semibold">Consultor Clínico Farmacológico</span>
                  </div>
                  {onOpenLiveVoiceModal && (
                    <button
                      onClick={onOpenLiveVoiceModal}
                      className="flex items-center gap-1 px-2.5 py-1 bg-pink-950/60 hover:bg-pink-900 border border-pink-500/40 text-pink-300 rounded-lg text-[10px] font-bold transition-colors cursor-pointer"
                    >
                      <Radio className="w-3 h-3 text-pink-400 animate-pulse" />
                      <span>Hablar por Voz en Vivo</span>
                    </button>
                  )}
                </div>

                <div className="flex-1 bg-slate-950 border border-slate-800 rounded-2xl p-4 overflow-y-auto space-y-3 mb-3">
                  {chatMessages.map((m, idx) => (
                    <div
                      key={idx}
                      className={`flex gap-2.5 ${m.role === "user" ? "justify-end" : "justify-start"}`}
                    >
                      {m.role === "model" && (
                        <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
                          <Bot className="w-4 h-4" />
                        </div>
                      )}
                      <div
                        className={`p-3 rounded-2xl max-w-[85%] text-xs leading-relaxed ${
                          m.role === "user"
                            ? "bg-purple-600 text-white rounded-tr-sm"
                            : "bg-slate-900 text-slate-200 border border-slate-800 rounded-tl-sm"
                        }`}
                      >
                        {m.text}
                      </div>
                      {m.role === "user" && (
                        <div className="w-7 h-7 rounded-lg bg-purple-500/20 text-purple-300 flex items-center justify-center shrink-0">
                          <User className="w-4 h-4" />
                        </div>
                      )}
                    </div>
                  ))}
                  {isAiConsulting && (
                    <div className="flex items-center gap-2 text-slate-500 italic text-[10px]">
                      <Sparkles className="w-3.5 h-3.5 animate-spin text-purple-400" />
                      <span>Consultando base de conocimiento médico...</span>
                    </div>
                  )}
                </div>

                <div className="flex gap-2">
                  <input
                    type="text"
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handleSendAiMessage()}
                    placeholder="Ej: ¿Interacción de riesgo entre Disulfiram y Sertralina?"
                    className="flex-1 bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-slate-200 outline-none focus:border-pink-500/60"
                  />
                  {onOpenTranscribeModal && (
                    <button
                      type="button"
                      onClick={onOpenTranscribeModal}
                      title="Dictar pregunta con micrófono"
                      className="px-3 bg-purple-950 hover:bg-purple-900 border border-purple-500/40 text-purple-300 rounded-xl transition-colors flex items-center justify-center cursor-pointer"
                    >
                      <Mic className="w-4 h-4" />
                    </button>
                  )}
                  <button
                    onClick={handleSendAiMessage}
                    disabled={isAiConsulting}
                    className="px-4 py-2 bg-pink-600 hover:bg-pink-500 text-white font-bold rounded-xl transition-colors flex items-center justify-center disabled:opacity-50 cursor-pointer"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Hidden Print Area for Patient Leaflet with Official COSEM Letterhead */}
      <div id="vademecum-print-document" className="print-only print-area hidden">
        {/* Official Letterhead */}
        <div style={{ borderBottom: "2px solid #334155", paddingBottom: "12px", marginBottom: "16px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
            <div>
              <h2 style={{ fontSize: "16px", fontWeight: "bold", color: "#0f172a", margin: 0, textTransform: "uppercase", letterSpacing: "0.5px" }}>
                Cosem Rinconada
              </h2>
              <p style={{ fontSize: "11px", color: "#475569", margin: "3px 0 0 0", fontWeight: 600 }}>
                San Ramón, Santiago de Chile
              </p>
              <p style={{ fontSize: "12px", fontWeight: "600", color: "#334155", margin: "4px 0 0 0" }}>
                {printDoc.subtitulo}
              </p>
            </div>
            <div style={{ textAlign: "right", fontSize: "11px", color: "#64748b" }}>
              <p style={{ margin: 0, fontWeight: "bold", color: "#334155" }}>FECHA DE EMISIÓN</p>
              <p style={{ margin: "2px 0 0 0" }}>{new Date().toLocaleDateString("es-CL")}</p>
            </div>
          </div>
        </div>

        {/* Document Title */}
        <div style={{ textAlign: "center", marginBottom: "16px", backgroundColor: "#f1f5f9", padding: "8px 12px", borderRadius: "6px", border: "1px solid #cbd5e1" }}>
          <h3 style={{ fontSize: "14px", fontWeight: "bold", color: "#0f172a", margin: 0, textTransform: "uppercase", letterSpacing: "0.5px" }}>
            {printDoc.titulo}
          </h3>
        </div>

        {/* Patient and Doctor Identification Box */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px", padding: "10px 14px", backgroundColor: "#f8fafc", border: "1px solid #cbd5e1", borderRadius: "6px", fontSize: "12px", marginBottom: "16px" }}>
          <div>
            <p style={{ margin: "2px 0" }}><strong>Paciente:</strong> {printDoc.pacienteNombre || "Indicación General / En Box"}</p>
            <p style={{ margin: "2px 0" }}><strong>RUT:</strong> {printDoc.pacienteRut || "Sin especificar"}</p>
          </div>
          <div>
            <p style={{ margin: "2px 0" }}><strong>Médico Tratante:</strong> Dr. Andrés Ruiz Miranda</p>
            <p style={{ margin: "2px 0" }}><strong>Unidad:</strong> Programa de Tratamiento en Adicciones</p>
          </div>
        </div>

        {/* Medication Header */}
        <div style={{ marginBottom: "14px" }}>
          <p style={{ fontSize: "15px", fontWeight: "bold", color: "#1e293b", margin: "0 0 4px 0" }}>
            📋 {printDoc.medicamentoPrincipal}
          </p>
          {printDoc.posologia && (
            <p style={{ fontSize: "12px", color: "#334155", margin: "0 0 8px 0" }}>
              <strong>Esquema / Resumen Clínico:</strong> {printDoc.posologia}
            </p>
          )}
        </div>

        {/* Main Body Instructions / Step-by-Step Schedule */}
        <div style={{ padding: "14px 16px", backgroundColor: "#ffffff", border: "1.5px solid #94a3b8", borderRadius: "8px", fontSize: "12px", lineHeight: "1.6", whiteSpace: "pre-line", marginBottom: "16px" }}>
          <p style={{ fontWeight: "bold", fontSize: "12.5px", color: "#0f172a", margin: "0 0 8px 0", textTransform: "uppercase" }}>
            📅 Instrucciones Detalladas y Cronograma para el Paciente:
          </p>
          <div style={{ color: "#1e293b" }}>{printDoc.cuerpoIndicaciones}</div>
        </div>

        {/* Warnings / Red Flags */}
        {printDoc.banderasRojas && (
          <div style={{ padding: "10px 14px", backgroundColor: "#fef2f2", border: "1.5px solid #f87171", borderRadius: "6px", fontSize: "11.5px", lineHeight: "1.5", marginBottom: "20px" }}>
            <p style={{ color: "#991b1b", fontWeight: "bold", margin: "0 0 4px 0" }}>
              ⚠️ ADVERTENCIAS DE SEGURIDAD Y SIGNOS DE ALERTA:
            </p>
            <p style={{ color: "#7f1d1d", margin: 0 }}>{printDoc.banderasRojas}</p>
          </div>
        )}

        {/* Emergency Network Notice */}
        <div style={{ fontSize: "10px", color: "#64748b", borderTop: "1px dashed #cbd5e1", paddingTop: "8px", marginBottom: "40px", display: "flex", justifyContent: "space-between" }}>
          <span>En caso de urgencia vital o crisis descompensada: SAMU 131 • Fono Prevención Suicidio: *4141</span>
          <span>Salud Responde: 600 360 7777</span>
        </div>

        {/* Doctor Signature Block */}
        <div style={{ textAlign: "center", width: "260px", marginLeft: "auto", marginRight: "auto" }}>
          <div style={{ borderTop: "1.5px solid #000000", paddingTop: "6px", fontWeight: "bold", fontSize: "13px", color: "#0f172a" }}>
            Dr. Andrés Ruiz Miranda
          </div>
          <div style={{ fontSize: "11px", color: "#334155" }}>Médico Programa de Tratamiento en Adicciones</div>
          <div style={{ fontSize: "10px", color: "#64748b" }}>Cosem Rinconada, San Ramón</div>
        </div>
      </div>
    </div>
  );
};
