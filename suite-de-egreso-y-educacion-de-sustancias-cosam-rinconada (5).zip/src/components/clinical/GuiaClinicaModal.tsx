import { X, ShieldAlert, Award, Layers } from "lucide-react";

interface GuiaClinicaModalProps {
  onClose: () => void;
}

export function GuiaClinicaModal({ onClose }: GuiaClinicaModalProps) {
  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fadeIn" id="guia-clinica-modal">
      <div className="bg-white rounded-2xl shadow-xl border border-slate-100 max-w-2xl w-full max-h-[85vh] overflow-y-auto">
        <div className="p-5 border-b border-slate-100 flex items-center justify-between sticky top-0 bg-white z-10">
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-indigo-600" />
            <h3 className="font-bold text-slate-800 text-sm md:text-base">Guía Clínica: Estándares Diagnósticos en COSAM</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-50 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-100 flex items-start gap-3">
            <Layers className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <p className="text-xs font-bold text-emerald-900">Lineamiento Técnico MINSAL Chile</p>
              <p className="text-[11px] text-emerald-700 mt-0.5">
                Esta guía resume los criterios clínicos oficiales vigentes para el diagnóstico y derivación de pacientes con consumo problemático de alcohol y otras drogas en el sistema de salud pública de Chile, adaptada para COSAM Rinconada.
              </p>
            </div>
          </div>

          <div className="space-y-3">
            <h4 className="font-bold text-slate-800 text-sm flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-amber-500" /> Criterios Diagnósticos DSM-5 / CIE-11 (Trastorno por Uso de Sustancias)
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs text-slate-600">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 space-y-1.5">
                <p className="font-semibold text-slate-800 text-xs">Pérdida de Control sobre el Consumo:</p>
                <ul className="list-disc pl-4 space-y-1 text-[11px]">
                  <li>Consumo en mayores cantidades o más tiempo del planeado.</li>
                  <li>Deseo persistente o esfuerzos inútiles por disminuir o controlar.</li>
                  <li>Inversión de mucho tiempo en conseguir la sustancia o recuperarse.</li>
                  <li>Ansia o fuerte deseo de consumir (Craving).</li>
                </ul>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 space-y-1.5">
                <p className="font-semibold text-slate-800 text-xs">Deterioro Social y Riesgo Físico:</p>
                <ul className="list-disc pl-4 space-y-1 text-[11px]">
                  <li>Incumplimiento de deberes fundamentales (trabajo, escuela, hogar).</li>
                  <li>Problemas interpersonales o sociales continuos causados.</li>
                  <li>Reducción de actividades sociales, ocupacionales o recreativas.</li>
                  <li>Consumo en situaciones en las que provoca peligro físico.</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <h4 className="font-bold text-slate-800 text-xs uppercase tracking-wide text-slate-500">Esquema de Severidad:</h4>
            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
                <p className="text-xs font-bold text-emerald-600">Leve</p>
                <p className="text-[10px] text-slate-500 mt-1">Presencia de 2 a 3 síntomas de la lista.</p>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
                <p className="text-xs font-bold text-amber-600">Moderado</p>
                <p className="text-[10px] text-slate-500 mt-1">Presencia de 4 a 5 síntomas de la lista.</p>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
                <p className="text-xs font-bold text-rose-600">Severo</p>
                <p className="text-[10px] text-slate-500 mt-1">Presencia de 6 o más síntomas clínicos.</p>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <h4 className="font-bold text-slate-800 text-sm">Objetivos Generales de Intervención (PAI)</h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              El Plan de Tratamiento Individual (PAI) debe orientarse no solo a la abstinencia o reducción de daños, sino también a la reconstrucción familiar, inserción laboral o educacional y al desarrollo de habilidades cognitivo-conductuales para la prevención de recaídas.
            </p>
          </div>
        </div>

        <div className="p-4 bg-slate-50 border-t border-slate-100 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-lg transition-colors"
          >
            Cerrar Guía
          </button>
        </div>
      </div>
    </div>
  );
}
