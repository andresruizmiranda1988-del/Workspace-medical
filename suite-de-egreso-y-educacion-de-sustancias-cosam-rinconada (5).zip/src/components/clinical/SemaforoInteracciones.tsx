import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ShieldCheck, AlertTriangle, ShieldAlert, CheckCircle2, Info, ChevronDown, Pill, HeartPulse } from "lucide-react";

export type RiskLevel = "verde" | "ambar" | "rojo";

interface SemaforoInteraccionesProps {
  currentLevel?: RiskLevel;
  onLevelChange?: (level: RiskLevel) => void;
}

export function SemaforoInteracciones({
  currentLevel = "verde",
  onLevelChange,
}: SemaforoInteraccionesProps) {
  const [level, setLevel] = useState<RiskLevel>(currentLevel);
  const [isOpen, setIsOpen] = useState(false);

  const handleSelect = (newLevel: RiskLevel) => {
    setLevel(newLevel);
    if (onLevelChange) onLevelChange(newLevel);
  };

  const statusConfig = {
    verde: {
      label: "Seguro • Sin Interacción Crítica",
      shortLabel: "Seguro",
      color: "bg-emerald-500",
      textColor: "text-emerald-700 dark:text-emerald-300",
      bgClass: "bg-emerald-50 dark:bg-emerald-950/70 border-emerald-200 dark:border-emerald-800",
      icon: ShieldCheck,
      desc: "Prescripciones compatibles según pautas COSAM/Ashton. Sin contraindicaciones metabólicas o QTc identificadas.",
    },
    ambar: {
      label: "Monitoreo Clínico Requerido",
      shortLabel: "Monitoreo",
      color: "bg-amber-500",
      textColor: "text-amber-700 dark:text-amber-300",
      bgClass: "bg-amber-50 dark:bg-amber-950/70 border-amber-200 dark:border-amber-800",
      icon: AlertTriangle,
      desc: "Precaución: verificar niveles de Litemia (rango 0.6-0.8 mEq/L), función hepática o ECG basal con antipsicóticos.",
    },
    rojo: {
      label: "Bandera Roja / Contraindicación",
      shortLabel: "Riesgo Alto",
      color: "bg-rose-500",
      textColor: "text-rose-700 dark:text-rose-300",
      bgClass: "bg-rose-50 dark:bg-rose-950/70 border-rose-200 dark:border-rose-800",
      icon: ShieldAlert,
      desc: "Alerta Crítica: riesgo de síndrome serotoninérgico, prolongación severa de QTc o intoxicación aguda.",
    },
  };

  const current = statusConfig[level];
  const Icon = current.icon;

  return (
    <div className="relative">
      {/* Trigger Pill */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`p-2.5 rounded-2xl border ${current.bgClass} flex items-center gap-2.5 transition-all shadow-2xs hover:shadow-sm cursor-pointer group`}
        title="Semáforo de Seguridad e Interacciones Farmacológicas - Clic para ver pauta"
      >
        {/* 3-light mini visual indicator */}
        <div className="flex items-center gap-1 px-1.5 py-1 rounded-lg bg-slate-900/90 text-white shadow-2xs">
          <span
            className={`w-2.5 h-2.5 rounded-full transition-all ${
              level === "rojo" ? "bg-rose-500 shadow-[0_0_8px_#f43f5e]" : "bg-rose-950 opacity-40"
            }`}
          />
          <span
            className={`w-2.5 h-2.5 rounded-full transition-all ${
              level === "ambar" ? "bg-amber-400 shadow-[0_0_8px_#fbbf24]" : "bg-amber-950 opacity-40"
            }`}
          />
          <span
            className={`w-2.5 h-2.5 rounded-full transition-all ${
              level === "verde" ? "bg-emerald-400 shadow-[0_0_8px_#34d399]" : "bg-emerald-950 opacity-40"
            }`}
          />
        </div>

        <div className="text-left">
          <div className="flex items-center gap-1 text-[9px] font-black uppercase tracking-wider text-slate-500 dark:text-slate-400">
            <span>Semáforo Seguridad</span>
          </div>
          <div className={`text-xs font-black ${current.textColor} flex items-center gap-1 leading-none mt-0.5`}>
            <Icon size={12} />
            <span>{current.shortLabel}</span>
          </div>
        </div>

        <ChevronDown size={12} className={`text-slate-400 transition-transform duration-200 ${isOpen ? "rotate-180" : ""}`} />
      </button>

      {/* Popover / Matrix Info Modal */}
      <AnimatePresence>
        {isOpen && (
          <>
            <div className="fixed inset-0 z-40" onClick={() => setIsOpen(false)} />
            <motion.div
              initial={{ opacity: 0, y: 6, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 6, scale: 0.96 }}
              transition={{ duration: 0.15 }}
              className="absolute right-0 top-full mt-2 w-84 p-4 rounded-2xl bg-white/95 dark:bg-slate-900/95 border border-slate-200 dark:border-slate-750 shadow-2xl backdrop-blur-md z-50 space-y-3.5"
            >
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
                <div className="flex items-center gap-1.5 text-xs font-black text-slate-900 dark:text-white">
                  <Pill size={14} className="text-emerald-600" />
                  <span>Semáforo de Seguridad Farmacológica</span>
                </div>
                <span className="text-[9px] font-bold text-slate-400">Pauta COSAM</span>
              </div>

              {/* Selector Buttons */}
              <div className="space-y-1.5">
                {(["verde", "ambar", "rojo"] as RiskLevel[]).map((lvl) => {
                  const cfg = statusConfig[lvl];
                  const CfgIcon = cfg.icon;
                  const isSel = level === lvl;
                  return (
                    <button
                      key={lvl}
                      onClick={() => handleSelect(lvl)}
                      className={`w-full p-2.5 rounded-xl border text-left transition-all flex items-start gap-2.5 cursor-pointer ${
                        isSel
                          ? `${cfg.bgClass} shadow-2xs scale-[1.01]`
                          : "bg-slate-50 dark:bg-slate-800/40 border-slate-200/50 dark:border-slate-700/50 hover:bg-slate-100"
                      }`}
                    >
                      <div className={`w-3 h-3 rounded-full ${cfg.color} shrink-0 mt-0.5 shadow-2xs`} />
                      <div className="space-y-0.5">
                        <div className={`text-xs font-black ${isSel ? cfg.textColor : "text-slate-800 dark:text-slate-200"}`}>
                          {cfg.label}
                        </div>
                        <p className="text-[10px] text-slate-500 dark:text-slate-400 font-medium leading-tight">
                          {cfg.desc}
                        </p>
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Quick Clinical Pearl */}
              <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200/60 dark:border-slate-700/60 text-[10px] text-slate-600 dark:text-slate-300 flex items-center gap-2">
                <HeartPulse size={14} className="text-purple-600 shrink-0" />
                <span>Interacción clave: Disulfiram + Etanol produce acumulación de acetaldehído a los 10 minutos.</span>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
