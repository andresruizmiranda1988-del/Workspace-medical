import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Activity, Clock, TrendingUp, Users, CheckCircle2, ChevronRight } from "lucide-react";

interface BoxSparklineProps {
  compact?: boolean;
}

export function BoxSparkline({ compact = false }: BoxSparklineProps) {
  const [showDetails, setShowDetails] = useState(false);

  // Weekly data (Consultations per day: Mon-Sun)
  const weeklyData = [
    { day: "Lun", count: 7, avgMin: 26, label: "7 atenciones" },
    { day: "Mar", count: 9, avgMin: 24, label: "9 atenciones" },
    { day: "Mié", count: 6, avgMin: 28, label: "6 atenciones" },
    { day: "Jue", count: 10, avgMin: 22, label: "10 atenciones" },
    { day: "Vie", count: 8, avgMin: 25, label: "8 atenciones" },
    { day: "Sáb", count: 4, avgMin: 20, label: "4 atenciones (Extensión)" },
    { day: "Hoy", count: 8, avgMin: 23, label: "8 programadas" },
  ];

  const maxVal = Math.max(...weeklyData.map((d) => d.count), 12);
  const minVal = 0;
  const height = 28;
  const width = 110;

  // Generate SVG path points
  const points = weeklyData.map((d, i) => {
    const x = (i / (weeklyData.length - 1)) * width;
    const y = height - ((d.count - minVal) / (maxVal - minVal)) * (height - 6) - 3;
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  });

  const pathD = `M ${points.join(" L ")}`;
  const areaD = `M ${points[0]} L ${points.join(" L ")} L ${width},${height} L 0,${height} Z`;

  const totalWeekly = weeklyData.reduce((acc, cur) => acc + cur.count, 0);
  const avgTime = Math.round(weeklyData.reduce((acc, cur) => acc + cur.avgMin, 0) / weeklyData.length);

  return (
    <div className="relative">
      <div
        onClick={() => setShowDetails(!showDetails)}
        className="p-2.5 rounded-2xl bg-white/90 dark:bg-slate-850/90 border border-slate-200/80 dark:border-slate-750 hover:border-emerald-300 dark:hover:border-emerald-700 transition-all cursor-pointer shadow-2xs flex items-center gap-3 group"
        title="Haga clic para ver el pulso y flujo semanal de carga de box"
      >
        {/* Left text metrics */}
        <div className="space-y-0.5 min-w-[70px]">
          <div className="flex items-center gap-1 text-[9px] font-black text-emerald-700 dark:text-emerald-400 uppercase tracking-wider">
            <Activity size={10} className="text-emerald-600 animate-pulse" />
            <span>Carga Box</span>
          </div>
          <div className="text-xs font-black text-slate-900 dark:text-white flex items-baseline gap-1 leading-none">
            <span>52 pac</span>
            <span className="text-[9px] font-bold text-slate-400 dark:text-slate-500">/sem</span>
          </div>
          <div className="text-[9px] font-semibold text-slate-500 dark:text-slate-400 flex items-center gap-0.5">
            <Clock size={8} />
            <span>{avgTime} min prom</span>
          </div>
        </div>

        {/* Mini Sparkline SVG */}
        <div className="w-[110px] h-[30px] flex items-center justify-center shrink-0">
          <svg width={width} height={height} className="overflow-visible">
            <defs>
              <linearGradient id="sparklineGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#10b981" stopOpacity="0.35" />
                <stop offset="100%" stopColor="#10b981" stopOpacity="0.0" />
              </linearGradient>
            </defs>
            <path d={areaD} fill="url(#sparklineGrad)" />
            <path
              d={pathD}
              fill="none"
              stroke="#059669"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            {/* Last Point Glowing Marker */}
            {points.length > 0 && (
              <circle
                cx={points[points.length - 1].split(",")[0]}
                cy={points[points.length - 1].split(",")[1]}
                r="3"
                className="fill-emerald-500 stroke-white dark:stroke-slate-900 stroke-2 animate-ping"
              />
            )}
            {points.length > 0 && (
              <circle
                cx={points[points.length - 1].split(",")[0]}
                cy={points[points.length - 1].split(",")[1]}
                r="3"
                className="fill-emerald-600 stroke-white dark:stroke-slate-900 stroke-2"
              />
            )}
          </svg>
        </div>

        <div className="hidden sm:flex flex-col items-end pl-1 border-l border-slate-150 dark:border-slate-750">
          <span className="text-[8.5px] font-black uppercase text-emerald-800 dark:text-emerald-300 bg-emerald-100 dark:bg-emerald-950 px-1.5 py-0.5 rounded">
            94% FUC
          </span>
        </div>
      </div>

      {/* Floating Modal / Popover with Weekly Details */}
      <AnimatePresence>
        {showDetails && (
          <>
            <div
              className="fixed inset-0 z-40"
              onClick={() => setShowDetails(false)}
            />
            <motion.div
              initial={{ opacity: 0, y: 6, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 6, scale: 0.96 }}
              transition={{ duration: 0.15 }}
              className="absolute right-0 top-full mt-2 w-80 p-4 rounded-2xl bg-white/95 dark:bg-slate-900/95 border border-slate-200 dark:border-slate-750 shadow-xl backdrop-blur-md z-50 space-y-3"
            >
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
                <div className="flex items-center gap-1.5 text-xs font-black text-slate-900 dark:text-white">
                  <TrendingUp size={14} className="text-emerald-600" />
                  <span>Rendimiento Clínico Semanal</span>
                </div>
                <span className="text-[9px] font-bold text-slate-500">Box COSAM</span>
              </div>

              {/* Day by Day Bar chart breakdown */}
              <div className="space-y-1.5">
                <span className="text-[10px] font-black uppercase text-slate-500 dark:text-slate-400 tracking-wider">
                  Atenciones por Día
                </span>
                <div className="grid grid-cols-7 gap-1 text-center pt-1">
                  {weeklyData.map((d, i) => {
                    const isToday = i === weeklyData.length - 1;
                    const pct = Math.round((d.count / maxVal) * 100);
                    return (
                      <div key={i} className="flex flex-col items-center gap-1">
                        <div className="w-full h-16 bg-slate-100 dark:bg-slate-800 rounded-lg relative flex items-end overflow-hidden p-0.5">
                          <div
                            className={`w-full rounded-md transition-all ${
                              isToday
                                ? "bg-gradient-to-t from-emerald-600 to-teal-500"
                                : "bg-slate-300 dark:bg-slate-700"
                            }`}
                            style={{ height: `${pct}%` }}
                          />
                        </div>
                        <span className={`text-[9px] font-black ${isToday ? "text-emerald-600 dark:text-emerald-400" : "text-slate-500"}`}>
                          {d.day}
                        </span>
                        <span className="text-[8.5px] font-bold text-slate-700 dark:text-slate-300">
                          {d.count}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Summary Stats */}
              <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-100 dark:border-slate-800 text-[10.5px]">
                <div className="p-2 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-700/60">
                  <span className="text-slate-500 dark:text-slate-400 text-[9.5px] font-medium block">Total Atenciones</span>
                  <span className="text-xs font-black text-slate-900 dark:text-white">{totalWeekly} pacientes</span>
                </div>
                <div className="p-2 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-700/60">
                  <span className="text-slate-500 dark:text-slate-400 text-[9.5px] font-medium block">Tiempo Promedio</span>
                  <span className="text-xs font-black text-emerald-600 dark:text-emerald-400">{avgTime} min / box</span>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
