import { useState, useEffect, useRef } from "react";
import { X, Mic, MicOff, Volume2, Loader2, Send, Radio, MessageSquare } from "lucide-react";
import { LiveVoiceClient, VoiceTurnMessage } from "../../services/liveVoiceService";

interface LiveVoiceModalProps {
  onClose: () => void;
}

export function LiveVoiceModal({ onClose }: LiveVoiceModalProps) {
  const [status, setStatus] = useState<"disconnected" | "connecting" | "connected" | "error">("connecting");
  const [errorMessage, setErrorMessage] = useState("");
  const [volume, setVolume] = useState(0);
  const [aiSpeaking, setAiSpeaking] = useState(false);
  const [mode, setMode] = useState<"websocket" | "http">("http");
  const [transcripts, setTranscripts] = useState<VoiceTurnMessage[]>([]);
  const [inputText, setInputText] = useState("");
  const [isSendingText, setIsSendingText] = useState(false);
  const clientRef = useRef<LiveVoiceClient | null>(null);
  const transcriptBottomRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const client = new LiveVoiceClient();
    clientRef.current = client;

    client.onStatusChange = (newStatus, err) => {
      setStatus(newStatus);
      if (err) setErrorMessage(err);
    };

    client.onModeChange = (newMode) => {
      setMode(newMode);
    };

    client.onVolumeChange = (vol) => {
      setVolume(vol);
    };

    client.onAiSpeaking = (speaking) => {
      setAiSpeaking(speaking);
    };

    client.onTranscript = (userText, modelText) => {
      setTranscripts((prev) => [
        ...prev,
        { role: "user", text: userText },
        { role: "model", text: modelText },
      ]);
    };

    client.connect().catch((err) => {
      console.warn("Live voice fallback handled:", err);
    });

    return () => {
      if (clientRef.current) {
        clientRef.current.disconnect();
      }
    };
  }, []);

  useEffect(() => {
    transcriptBottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [transcripts]);

  const handleSendText = async () => {
    if (!inputText.trim() || !clientRef.current || isSendingText) return;
    const text = inputText.trim();
    setInputText("");
    setIsSendingText(true);
    try {
      await clientRef.current.sendTextMessage(text);
    } catch (err) {
      console.warn("Error sending text to voice client:", err);
    } finally {
      setIsSendingText(false);
    }
  };

  const handleManualCommit = () => {
    if (clientRef.current) {
      clientRef.current.commitVoiceTurn();
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-fadeIn" id="live-voice-modal">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden text-white flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 md:p-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/90">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
              <Volume2 className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-semibold text-sm md:text-base leading-tight">Consulta Clínica por Voz</h3>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="text-[11px] text-slate-400 flex items-center gap-1">
                  <Radio className={`w-3 h-3 ${status === "connected" ? "text-emerald-400 animate-pulse" : "text-slate-500"}`} />
                  {mode === "websocket" ? "Canal Gemini Live (WebSocket)" : "Canal de Voz IA (Audio PCM & TTS)"}
                </span>
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            title="Cerrar modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Central Audio & Visualizer Display */}
        <div className="p-6 text-center flex flex-col items-center bg-gradient-to-b from-slate-900 to-slate-950">
          {status === "connecting" && (
            <div className="relative w-24 h-24 flex items-center justify-center mb-4">
              <Loader2 className="w-12 h-12 text-indigo-500 animate-spin" />
              <p className="absolute text-[10px] text-indigo-400 font-semibold uppercase tracking-wider animate-pulse">Conectando</p>
            </div>
          )}

          {status === "connected" && (
            <div className="mb-4 relative flex items-center justify-center w-24 h-24">
              {/* Voice Volume Dynamic Ripple */}
              <div
                className="absolute inset-0 rounded-full bg-indigo-500/20 transition-transform duration-75 pointer-events-none"
                style={{ transform: `scale(${1 + volume * 0.7})` }}
              />
              <div
                className={`absolute inset-2 rounded-full transition-all duration-300 pointer-events-none ${
                  aiSpeaking ? "bg-emerald-500/30" : "bg-indigo-500/30"
                }`}
                style={{ transform: `scale(${1 + volume * 0.35})` }}
              />
              <button
                onClick={handleManualCommit}
                className={`w-14 h-14 rounded-full flex items-center justify-center shadow-lg transition-all transform active:scale-95 ${
                  aiSpeaking ? "bg-emerald-600 text-white" : "bg-indigo-600 hover:bg-indigo-500 text-white"
                }`}
                title="Haz clic para forzar envío de lo grabado o hablar"
              >
                {aiSpeaking ? <Volume2 className="w-6 h-6 animate-pulse" /> : <Mic className="w-6 h-6" />}
              </button>
            </div>
          )}

          {status === "disconnected" && (
            <div className="w-14 h-14 mx-auto mb-4 flex items-center justify-center bg-slate-800 text-slate-400 rounded-full border border-slate-700">
              <MicOff className="w-7 h-7" />
            </div>
          )}

          <h4 className="font-medium text-sm md:text-base">
            {status === "connected"
              ? aiSpeaking
                ? "Gemini está respondiendo en voz..."
                : "Escuchando tu voz..."
              : status === "connecting"
              ? "Inicializando Canal Clínico"
              : "Canal de Voz Desconectado"}
          </h4>

          <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto leading-relaxed">
            {status === "connected"
              ? "Habla con normalidad al micrófono de tu equipo. Detecta pausas automáticamente o pulsa 'Enviar Audio'."
              : status === "connecting"
              ? "Configurando entrada de audio 16kHz y sintetizador Zephyr de Google Gemini..."
              : errorMessage || "La sesión de voz ha finalizado."}
          </p>

          {status === "connected" && (
            <div className="mt-3 flex items-center gap-2">
              <span className="flex items-center gap-1.5 px-3 py-1 bg-slate-800/80 rounded-full border border-slate-700/60">
                <span className={`w-2 h-2 rounded-full ${aiSpeaking ? "bg-emerald-400 animate-pulse" : "bg-indigo-400 animate-ping"}`} />
                <span className="text-[10px] text-slate-300 font-medium uppercase tracking-wider">
                  {aiSpeaking ? "IA Hablando (24kHz)" : "Micrófono Abierto"}
                </span>
              </span>

              <button
                onClick={handleManualCommit}
                className="px-2.5 py-1 text-[10px] bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-full border border-slate-700 transition-colors"
                title="Envía el audio inmediatamente sin esperar la pausa de silencio"
              >
                Enviar Audio Ahora
              </button>
            </div>
          )}
        </div>

        {/* Transcript / Dialogue History */}
        <div className="flex-1 overflow-y-auto p-4 border-t border-slate-800 bg-slate-950/60 min-h-[140px] max-h-[220px] space-y-3">
          {transcripts.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center text-slate-500 py-6">
              <MessageSquare className="w-6 h-6 mb-1.5 opacity-40" />
              <p className="text-xs">El diálogo transcrito y las respuestas de voz aparecerán aquí.</p>
              <p className="text-[11px] text-slate-600 mt-0.5">Ejemplo: "¿Cuál es el protocolo de deshabituación de benzodiacepinas?"</p>
            </div>
          ) : (
            transcripts.map((msg, i) => (
              <div
                key={i}
                className={`flex flex-col ${msg.role === "user" ? "items-end" : "items-start"}`}
              >
                <span className="text-[10px] text-slate-400 font-medium mb-1 px-1">
                  {msg.role === "user" ? "Tú (Clínico)" : "Gemini Especialista COSAM"}
                </span>
                <div
                  className={`px-3 py-2 rounded-xl text-xs max-w-[85%] leading-relaxed ${
                    msg.role === "user"
                      ? "bg-indigo-600/90 text-white rounded-tr-none"
                      : "bg-slate-800/90 text-slate-200 border border-slate-700/60 rounded-tl-none"
                  }`}
                >
                  {msg.text}
                </div>
              </div>
            ))
          )}
          <div ref={transcriptBottomRef} />
        </div>

        {/* Text Fallback Input Bar */}
        <div className="p-3 bg-slate-900 border-t border-slate-800 flex items-center gap-2">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                handleSendText();
              }
            }}
            placeholder="O escribe una consulta si estás en box ruidoso..."
            disabled={status !== "connected" || isSendingText}
            className="flex-1 bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors disabled:opacity-50"
          />
          <button
            onClick={handleSendText}
            disabled={!inputText.trim() || status !== "connected" || isSendingText}
            className="p-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white rounded-lg transition-colors flex items-center justify-center"
            title="Enviar mensaje escrito"
          >
            {isSendingText ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
          </button>
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-950 border-t border-slate-850 flex justify-between items-center text-xs">
          <span className="text-[10px] text-slate-500">Audio PCM 16kHz & Sintetizador Zephyr</span>
          <button
            onClick={onClose}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-750 text-slate-200 text-xs font-medium rounded-lg transition-colors"
          >
            Finalizar
          </button>
        </div>
      </div>
    </div>
  );
}
