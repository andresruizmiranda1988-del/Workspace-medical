import React, { useState, useEffect } from "react";
import {
  FilePlus2,
  ExternalLink,
  CheckCircle2,
  Settings2,
  Sparkles,
  LogOut,
  UserCheck,
  AlertCircle,
  X,
} from "lucide-react";
import { GoogleDriveService } from "../../services/googleDriveService";
import {
  GoogleDocsService,
  PersonalDocExportMode,
  PersonalDocExportRecord,
  DEFAULT_PERSONAL_PHYSICIAN_DOC_TITLE,
} from "../../services/googleDocsService";
import { initAuth } from "../../services/firebaseAuthService";
import { GoogleSignInButton } from "./GoogleSignInButton";

interface PersonalDocsAutoExportBarProps {
  reportType: string;
  patientName: string;
  patientRut?: string;
  generatedContent: string;
  lastExportedRecord?: PersonalDocExportRecord | null;
  onExportSuccess?: (record: PersonalDocExportRecord) => void;
  onShowToast?: (msg: string, type?: "success" | "error" | "info") => void;
}

export const PersonalDocsAutoExportBar: React.FC<PersonalDocsAutoExportBarProps> = ({
  reportType,
  patientName,
  patientRut,
  generatedContent,
  lastExportedRecord,
  onExportSuccess,
  onShowToast,
}) => {
  const [isConnected, setIsConnected] = useState(() => GoogleDriveService.isConnected());
  const [userInfo, setUserInfo] = useState(() =>
    GoogleDriveService.getAuthenticatedUserInfo()
  );
  const [isSigningIn, setIsSigningIn] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [autoExport, setAutoExport] = useState(() =>
    GoogleDocsService.isAutoExportEnabled()
  );
  const [exportMode, setExportMode] = useState<PersonalDocExportMode>(() =>
    GoogleDocsService.getExportMode()
  );
  const [masterDocTitle, setMasterDocTitle] = useState(() =>
    GoogleDocsService.getMasterDocTitle()
  );
  const [tempMasterTitle, setTempMasterTitle] = useState(masterDocTitle);
  const [isConfigOpen, setIsConfigOpen] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [localLastRecord, setLocalLastRecord] =
    useState<PersonalDocExportRecord | null>(null);

  // Confirmación obligatoria antes de modificar/anexar a un Google Doc existente
  const [pendingAppendConfirm, setPendingAppendConfirm] = useState(false);

  useEffect(() => {
    const unsubscribe = initAuth(
      () => {
        setIsConnected(GoogleDriveService.isConnected());
        setUserInfo(GoogleDriveService.getAuthenticatedUserInfo());
      },
      () => {
        setIsConnected(false);
        setUserInfo(null);
      }
    );

    const handleAuthChange = () => {
      setIsConnected(GoogleDriveService.isConnected());
      setUserInfo(GoogleDriveService.getAuthenticatedUserInfo());
    };

    const handleSettingsChange = () => {
      setAutoExport(GoogleDocsService.isAutoExportEnabled());
      setExportMode(GoogleDocsService.getExportMode());
      setMasterDocTitle(GoogleDocsService.getMasterDocTitle());
    };

    const handleExportCompleted = (e: Event) => {
      const customEvt = e as CustomEvent<PersonalDocExportRecord>;
      if (customEvt.detail) {
        setLocalLastRecord(customEvt.detail);
      }
    };

    window.addEventListener("cosam:gdrive-auth-changed", handleAuthChange);
    window.addEventListener("cosam:gdocs-settings-changed", handleSettingsChange);
    window.addEventListener("cosam:gdocs-export-completed", handleExportCompleted);

    return () => {
      unsubscribe();
      window.removeEventListener("cosam:gdrive-auth-changed", handleAuthChange);
      window.removeEventListener("cosam:gdocs-settings-changed", handleSettingsChange);
      window.removeEventListener(
        "cosam:gdocs-export-completed",
        handleExportCompleted
      );
    };
  }, []);

  const displayedRecord = lastExportedRecord || localLastRecord;

  const handleFirebaseGoogleSignIn = async () => {
    if (isSigningIn) return;
    setIsSigningIn(true);
    setErrorMsg(null);
    try {
      await GoogleDriveService.requestAuth();
      setIsConnected(true);
      setUserInfo(GoogleDriveService.getAuthenticatedUserInfo());
      if (onShowToast) {
        onShowToast(
          "Autenticado mediante Firebase Auth con acceso a Google Docs",
          "success"
        );
      }
    } catch (err: any) {
      const msg = err?.message || "No se pudo autenticar con Firebase Auth.";
      setErrorMsg(msg);
      if (onShowToast) onShowToast(msg, "error");
    } finally {
      setIsSigningIn(false);
    }
  };

  const handleDisconnect = async () => {
    await GoogleDriveService.disconnect();
    setIsConnected(false);
    setUserInfo(null);
    if (onShowToast) {
      onShowToast("Sesión de Firebase Auth cerrada", "info");
    }
  };

  const handleToggleAutoExport = () => {
    if (!isConnected) {
      handleFirebaseGoogleSignIn();
      return;
    }
    const next = !autoExport;
    setAutoExport(next);
    GoogleDocsService.setAutoExportEnabled(next);
    if (onShowToast) {
      onShowToast(
        next
          ? "Exportación automática a Google Docs personal activada"
          : "Exportación automática a Google Docs desactivada",
        "info"
      );
    }
  };

  const executeExportToPersonalDoc = async (modeToUse: PersonalDocExportMode) => {
    if (!generatedContent.trim()) {
      if (onShowToast) {
        onShowToast("Genere el informe clínico primero antes de exportar", "error");
      }
      return;
    }
    setIsExporting(true);
    setErrorMsg(null);
    try {
      const record = await GoogleDocsService.exportClinicalReportToPersonalDoc({
        reportType,
        patientName,
        patientRut,
        content: generatedContent,
        modeOverride: modeToUse,
      });
      setLocalLastRecord(record);
      if (onExportSuccess) onExportSuccess(record);
      if (onShowToast) {
        onShowToast(
          `Informe exportado a Google Docs: ${record.documentTitle}`,
          "success"
        );
      }
    } catch (err: any) {
      const msg = err?.message || "Error al exportar informe a Google Docs.";
      setErrorMsg(msg);
      if (onShowToast) onShowToast(msg, "error");
    } finally {
      setIsExporting(false);
      setPendingAppendConfirm(false);
    }
  };

  const handleManualExportClick = async () => {
    if (!generatedContent.trim()) {
      if (onShowToast) {
        onShowToast("Genere el informe clínico primero antes de exportar", "error");
      }
      return;
    }
    if (!isConnected) {
      try {
        setIsSigningIn(true);
        await GoogleDriveService.requestAuth();
        setIsConnected(true);
        setUserInfo(GoogleDriveService.getAuthenticatedUserInfo());
      } catch (err: any) {
        setIsSigningIn(false);
        setErrorMsg(err?.message || "Autenticación requerida.");
        return;
      } finally {
        setIsSigningIn(false);
      }
    }

    if (exportMode === "append_master_doc") {
      // Confirmación explícita obligatoria antes de mutar un documento existente del médico
      setPendingAppendConfirm(true);
    } else {
      await executeExportToPersonalDoc("new_doc_per_report");
    }
  };

  const handleSaveMasterTitle = () => {
    const clean = tempMasterTitle.trim() || DEFAULT_PERSONAL_PHYSICIAN_DOC_TITLE;
    setMasterDocTitle(clean);
    GoogleDocsService.setMasterDocTitle(clean);
    setIsConfigOpen(false);
    if (onShowToast) {
      onShowToast(`Documento personal configurado: "${clean}"`, "success");
    }
  };

  return (
    <div className="bg-blue-50/70 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800/70 rounded-xl p-3.5 transition-colors space-y-2.5">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
        {/* Left: Toggle + Status */}
        <div className="flex items-start sm:items-center gap-3">
          <button
            type="button"
            onClick={handleToggleAutoExport}
            disabled={isSigningIn || isExporting}
            className={`relative mt-0.5 sm:mt-0 inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-hidden disabled:opacity-50 ${
              autoExport && isConnected
                ? "bg-blue-600 dark:bg-blue-500"
                : "bg-slate-300 dark:bg-slate-700"
            }`}
            title="Activar/Desactivar exportación automática a Google Docs personal"
          >
            <span
              className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-xs ring-0 transition duration-200 ease-in-out ${
                autoExport && isConnected ? "translate-x-4" : "translate-x-0"
              }`}
            />
          </button>

          <div className="space-y-0.5">
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-semibold text-slate-900 dark:text-white flex items-center gap-1.5 text-xs">
                <FilePlus2
                  className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400"
                  strokeWidth={1.75}
                />
                Exportación Automática a Google Docs Personal
              </span>
              <span
                className={`text-[10px] px-2 py-0.5 rounded-md font-semibold border ${
                  autoExport && isConnected
                    ? "bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800"
                    : isConnected
                    ? "bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700"
                    : "bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800"
                }`}
              >
                {!isConnected
                  ? "Requiere Firebase Auth"
                  : autoExport
                  ? "Auto-Export Activo"
                  : "Modo Manual"}
              </span>
              {isConnected && userInfo && (
                <span className="text-[10px] text-blue-700 dark:text-blue-300 bg-white/80 dark:bg-slate-900/80 px-2 py-0.5 rounded-md border border-blue-200 dark:border-blue-800 flex items-center gap-1">
                  <UserCheck className="w-3 h-3 text-emerald-600" />
                  <span className="truncate max-w-[180px]">
                    {userInfo.email || userInfo.displayName}
                  </span>
                </span>
              )}
            </div>
            <p className="text-[11px] text-slate-600 dark:text-slate-400">
              {!isConnected
                ? "Inicie sesión con su cuenta de Google mediante Firebase Auth para exportar automáticamente cada informe clínico generado a su Google Docs personal."
                : exportMode === "new_doc_per_report"
                ? "Al generar el informe con IA, se crea y formatea automáticamente un Documento Personal en su Google Docs."
                : `Modo Bitácora Personal: los informes se anexan a "${masterDocTitle}" (con confirmación previa).`}
            </p>
          </div>
        </div>

        {/* Right: Actions */}
        <div className="flex flex-wrap items-center gap-2 self-end md:self-center shrink-0">
          {!isConnected ? (
            <GoogleSignInButton
              onClick={handleFirebaseGoogleSignIn}
              isLoading={isSigningIn}
              label="Sign in with Google"
              compact
            />
          ) : (
            <>
              <button
                type="button"
                onClick={handleManualExportClick}
                disabled={!generatedContent.trim() || isExporting}
                className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5 disabled:opacity-40 cursor-pointer shadow-xs"
                title="Exportar el informe clínico actual a su Google Docs personal"
              >
                {isExporting ? (
                  <Sparkles className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <FilePlus2 className="w-3.5 h-3.5" strokeWidth={1.75} />
                )}
                <span>
                  {isExporting ? "Exportando a Docs..." : "Exportar a mi Google Doc"}
                </span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setTempMasterTitle(masterDocTitle);
                  setIsConfigOpen(!isConfigOpen);
                }}
                className="p-1.5 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-750 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 rounded-lg text-xs transition-colors cursor-pointer"
                title="Configurar modo de Documento Personal del Médico en Google Docs"
              >
                <Settings2 className="w-3.5 h-3.5" strokeWidth={1.75} />
              </button>

              <button
                type="button"
                onClick={handleDisconnect}
                className="p-1.5 bg-white dark:bg-slate-800 hover:bg-rose-50 dark:hover:bg-rose-950/40 border border-slate-200 dark:border-slate-700 text-slate-500 hover:text-rose-600 rounded-lg text-xs transition-colors cursor-pointer"
                title="Cerrar sesión de Firebase Auth"
              >
                <LogOut className="w-3.5 h-3.5" strokeWidth={1.75} />
              </button>
            </>
          )}
        </div>
      </div>

      {/* Error message */}
      {errorMsg && (
        <div className="flex items-center justify-between gap-2 text-[11px] text-rose-700 dark:text-rose-300 bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 rounded-lg px-3 py-1.5">
          <div className="flex items-center gap-1.5">
            <AlertCircle className="w-3.5 h-3.5 shrink-0" />
            <span>{errorMsg}</span>
          </div>
          <button
            type="button"
            onClick={() => setErrorMsg(null)}
            className="text-rose-500 hover:text-rose-700 cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Last Exported Google Doc Banner */}
      {displayedRecord && (
        <div className="p-2.5 bg-white dark:bg-slate-900 border border-blue-200 dark:border-blue-800/80 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-2 min-w-0">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <div className="truncate">
              <span className="text-slate-800 dark:text-slate-200 font-medium text-[11px]">
                Exportado a Google Docs:{" "}
                <strong className="text-blue-700 dark:text-blue-300">
                  {displayedRecord.documentTitle}
                </strong>
              </span>
              <span className="text-[10px] text-slate-400 ml-2">
                ({displayedRecord.exportedAt})
              </span>
            </div>
          </div>
          <a
            href={displayedRecord.webViewLink}
            target="_blank"
            rel="noopener noreferrer"
            className="py-1 px-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-md font-medium text-[11px] flex items-center gap-1 shrink-0 transition-colors self-end sm:self-center shadow-2xs"
          >
            <span>Abrir en Google Docs</span>
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>
      )}

      {/* Expandable Configuration Panel */}
      {isConfigOpen && (
        <div className="pt-2.5 border-t border-blue-200/80 dark:border-blue-800/60 space-y-2.5 text-xs">
          <div className="flex items-center justify-between">
            <span className="font-semibold text-slate-800 dark:text-slate-200 text-[11px]">
              Configuración de Destino en Google Docs Personal
            </span>
            <button
              type="button"
              onClick={() => setIsConfigOpen(false)}
              className="text-[11px] text-slate-500 hover:text-slate-700 cursor-pointer"
            >
              ✕ Cerrar
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => {
                setExportMode("new_doc_per_report");
                GoogleDocsService.setExportMode("new_doc_per_report");
              }}
              className={`p-2.5 rounded-lg border text-left transition-colors cursor-pointer ${
                exportMode === "new_doc_per_report"
                  ? "bg-white dark:bg-slate-900 border-blue-500 ring-1 ring-blue-500"
                  : "bg-white/60 dark:bg-slate-900/50 border-slate-200 dark:border-slate-700"
              }`}
            >
              <p className="font-semibold text-slate-900 dark:text-white text-xs">
                1. Documento Individual por Informe (Automático)
              </p>
              <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">
                Crea automáticamente un Google Doc nuevo por cada evolución o informe generado.
              </p>
            </button>

            <button
              type="button"
              onClick={() => {
                setExportMode("append_master_doc");
                GoogleDocsService.setExportMode("append_master_doc");
              }}
              className={`p-2.5 rounded-lg border text-left transition-colors cursor-pointer ${
                exportMode === "append_master_doc"
                  ? "bg-white dark:bg-slate-900 border-blue-500 ring-1 ring-blue-500"
                  : "bg-white/60 dark:bg-slate-900/50 border-slate-200 dark:border-slate-700"
              }`}
            >
              <p className="font-semibold text-slate-900 dark:text-white text-xs">
                2. Anexar en Bitácora Personal Única del Médico
              </p>
              <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">
                Agrega los informes al final del documento maestro del médico (solicita confirmación).
              </p>
            </button>
          </div>

          {exportMode === "append_master_doc" && (
            <div className="flex flex-col sm:flex-row gap-2 pt-1">
              <input
                type="text"
                value={tempMasterTitle}
                onChange={(e) => setTempMasterTitle(e.target.value)}
                placeholder="Título de la Bitácora Personal en Google Docs..."
                className="flex-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 dark:text-slate-200"
              />
              <button
                type="button"
                onClick={handleSaveMasterTitle}
                className="px-3 py-1.5 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-lg text-xs font-medium cursor-pointer"
              >
                Guardar Título
              </button>
            </div>
          )}
        </div>
      )}

      {/* Mandatory Confirmation Modal when mutating existing Master Personal Doc */}
      {pendingAppendConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800 flex items-center justify-center text-blue-600 dark:text-blue-400">
                  <FilePlus2 className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                    Confirmar Actualización en Google Docs
                  </h4>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    Bitácora Personal del Médico
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setPendingAppendConfirm(false)}
                className="text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="text-xs text-slate-600 dark:text-slate-300 space-y-2 bg-slate-50 dark:bg-slate-800/60 p-3 rounded-xl border border-slate-200 dark:border-slate-700">
              <p>
                ¿Desea anexar el informe <strong>{reportType}</strong> del paciente{" "}
                <strong>{patientName || "Paciente en Control"}</strong> al final de su
                documento personal en Google Docs?
              </p>
              <p className="text-[11px] text-slate-500">
                Documento destino: <strong>{masterDocTitle}</strong>
              </p>
            </div>

            <div className="flex items-center justify-end gap-2 pt-1">
              <button
                type="button"
                onClick={() => setPendingAppendConfirm(false)}
                disabled={isExporting}
                className="px-3.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => executeExportToPersonalDoc("append_master_doc")}
                disabled={isExporting}
                className="px-4 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-xs"
              >
                {isExporting ? (
                  <Sparkles className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <FilePlus2 className="w-3.5 h-3.5" />
                )}
                <span>Confirmar y Anexar</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PersonalDocsAutoExportBar;
