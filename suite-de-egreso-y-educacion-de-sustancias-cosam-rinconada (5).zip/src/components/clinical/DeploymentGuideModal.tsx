import { X, BookOpen, Key, Cloud, Check } from "lucide-react";

interface DeploymentGuideModalProps {
  onClose: () => void;
}

export function DeploymentGuideModal({ onClose }: DeploymentGuideModalProps) {
  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fadeIn" id="deployment-guide-modal">
      <div className="bg-white rounded-2xl shadow-xl border border-slate-100 max-w-2xl w-full max-h-[85vh] overflow-y-auto">
        <div className="p-5 border-b border-slate-100 flex items-center justify-between sticky top-0 bg-white z-10">
          <div className="flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-indigo-600" />
            <h3 className="font-bold text-slate-800 text-sm md:text-base">Guía de Producción y Configuración</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-50 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          <div className="space-y-2">
            <h4 className="font-bold text-slate-800 text-sm">1. Arquitectura Full-Stack Integrada</h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              La plataforma ha sido configurada bajo una estructura <strong>Express + Vite (SPA)</strong>. Todos los secretos (incluyendo la clave de la API de Gemini) se manejan en el servidor backend seguro para prevenir fugas de credenciales en el navegador del usuario final.
            </p>
          </div>

          <div className="space-y-3">
            <h4 className="font-bold text-slate-800 text-sm flex items-center gap-1.5">
              <Key className="w-4 h-4 text-amber-500" /> 2. Configuración de API Keys
            </h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Para habilitar la IA en producción, declare la siguiente variable de entorno en su servidor o archivo de configuración local:
            </p>
            <div className="bg-slate-900 text-slate-200 p-3 rounded-lg text-[11px] font-mono select-all">
              GEMINI_API_KEY=AIzaSy...
            </div>
            <p className="text-[10px] text-slate-500">
              * Nota: La clave se inicializa de forma tardía en el backend para prevenir que falle la carga inicial del contenedor si la clave está vacía.
            </p>
          </div>

          <div className="space-y-3">
            <h4 className="font-bold text-slate-800 text-sm flex items-center gap-1.5">
              <Cloud className="w-4 h-4 text-indigo-500" /> 3. Configuración de Google Drive (OAuth 2.0)
            </h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              El respaldo seguro en Google Drive funciona en el navegador del profesional mediante <strong>Google Identity Services (GSI)</strong> con alcances restringidos de tipo <code>drive.file</code> (solo accede a archivos creados por esta aplicación).
            </p>
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-150 space-y-2">
              <p className="text-xs font-semibold text-slate-800">Pasos de Integración en Consola GCP:</p>
              <ul className="list-disc pl-4 space-y-1.5 text-[11px] text-slate-600">
                <li>Cree un cliente OAuth de tipo Aplicación Web en su proyecto Google Cloud.</li>
                <li>Agregue la URI de producción de este contenedor a la lista de "Orígenes autorizados de JavaScript".</li>
                <li>Habilite la API de Google Drive en la Consola de APIs de Google.</li>
                <li>La aplicación buscará automáticamente la ID de cliente. Puede personalizarla en el código de <code>GoogleDriveService</code> si es requerido.</li>
              </ul>
            </div>
          </div>

          <div className="p-4 bg-indigo-50 rounded-xl border border-indigo-100 flex items-start gap-3">
            <Check className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
            <div>
              <p className="text-xs font-bold text-indigo-900">Cumplimiento Estricto de Seguridad de Datos</p>
              <p className="text-[11px] text-indigo-700 mt-0.5">
                La aplicación cumple con los estándares de privacidad clínica al no almacenar datos del paciente en bases de datos externas de terceros. Toda la información médica estructurada se almacena localmente en la sesión activa del profesional o en su propio almacenamiento institucional de Google Drive.
              </p>
            </div>
          </div>
        </div>

        <div className="p-4 bg-slate-50 border-t border-slate-100 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-lg transition-colors"
          >
            Entendido
          </button>
        </div>
      </div>
    </div>
  );
}
