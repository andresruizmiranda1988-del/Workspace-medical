import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Brain,
  Zap,
  Sparkles,
  Waves,
  Apple,
  ChevronLeft,
  ChevronRight,
  RotateCcw,
  Play,
  Pause,
  HelpCircle,
  Building2,
  Tv,
  Type,
  Sun,
  Moon,
  Crosshair,
  LogOut,
  Maximize2,
  Minimize2,
  CheckCircle2,
  Sparkle,
  ArrowLeft,
  ShieldCheck,
  Columns,
  Search,
  Pill,
  HeartHandshake,
  Activity,
  ShieldAlert,
  Stethoscope,
  ChevronDown,
  ChevronUp,
  Lightbulb,
  Compass,
  MessageSquareQuote,
  Flame,
  Info,
  Projector,
  MonitorUp,
  ExternalLink,
  Eye,
  Copy,
  Check,
  Radio,
  FileText,
  AlertTriangle,
  ScreenShare,
  X
} from "lucide-react";
import SimuladorCircuitoRecompensa from "./SimuladorCircuitoRecompensa";
import VistaPacienteDualProyeccion from "./VistaPacienteDualProyeccion";

interface ModoPsicoeducacionBoxProps {
  isSidebarCollapsed?: boolean;
  onToggleSidebar?: (collapsed: boolean) => void;
  onExitToStandard?: () => void;
}

export default function ModoPsicoeducacionBox({
  isSidebarCollapsed = false,
  onToggleSidebar,
  onExitToStandard
}: ModoPsicoeducacionBoxProps) {
  const [currentSlide, setCurrentSlide] = useState<number>(0);
  const [activeTab, setActiveTab] = useState<"diapositivas" | "vista_partida" | "surf_timer" | "faq_paciente">("vista_partida");
  const [selectedFaq, setSelectedFaq] = useState<number | null>(0);

  // ESTADO VISTA PARTIDA: FAQ TRATAMIENTO
  const [treatmentFaqCategory, setTreatmentFaqCategory] = useState<string>("todas");
  const [treatmentFaqSearch, setTreatmentFaqSearch] = useState<string>("");
  const [expandedTreatmentFaqId, setExpandedTreatmentFaqId] = useState<string | null>("farmacos_antabuse");

  // CONFIGURACIÓN VISUAL PROYECTOR
  const [projectorTheme, setProjectorTheme] = useState<"dark" | "light">("dark"); // Por defecto Dark Alto Contraste
  const [fontSizeLevel, setFontSizeLevel] = useState<"normal" | "large" | "huge">("large");
  const [isLaserPointer, setIsLaserPointer] = useState<boolean>(false);
  const [laserPos, setLaserPos] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [isProjectorClean, setIsProjectorClean] = useState<boolean>(false);

  // Temporizador "Surfear la Ola (Urge Surfing 15 min)"
  const [timerSeconds, setTimerSeconds] = useState<number>(15 * 60);
  const [isTimerRunning, setIsTimerRunning] = useState<boolean>(false);
  const [timerPhase, setTimerPhase] = useState<"inicio" | "pico" | "descenso" | "calma">("inicio");

  // VISTA DUAL (POP-UP / PROYECCIÓN EXCLUSIVA PACIENTE)
  const [isDualWindowActive, setIsDualWindowActive] = useState<boolean>(false);
  const [isDualModalOpen, setIsDualModalOpen] = useState<boolean>(false);
  const [popupBlockedNotice, setPopupBlockedNotice] = useState<boolean>(false);
  const [isDoctorNotesOpen, setIsDoctorNotesOpen] = useState<boolean>(true);
  const [copiedRayenNote, setCopiedRayenNote] = useState<boolean>(false);
  const broadcastChannelRef = useRef<BroadcastChannel | null>(null);

  const containerRef = useRef<HTMLDivElement>(null);

  // SINCRONIZACIÓN EN TIEMPO REAL CON LA VENTANA DEL PACIENTE (BROADCASTCHANNEL & LOCALSTORAGE)
  useEffect(() => {
    try {
      if (typeof window !== "undefined" && "BroadcastChannel" in window) {
        const channel = new BroadcastChannel("cosam_dual_sync");
        broadcastChannelRef.current = channel;

        channel.onmessage = (event) => {
          const data = event.data;
          if (data && data.type === "PONG_PATIENT") {
            setIsDualWindowActive(true);
          }
        };

        // Enviar ping inicial para verificar si la ventana del paciente ya está abierta
        channel.postMessage({ type: "PING_DOCTOR", timestamp: Date.now() });
      }
    } catch {
      // Ignorar en entornos sin BroadcastChannel
    }

    return () => {
      if (broadcastChannelRef.current) {
        broadcastChannelRef.current.close();
      }
    };
  }, []);

  // Función emisora de sincronización dual
  const broadcastSync = (payload: any) => {
    try {
      if (broadcastChannelRef.current) {
        broadcastChannelRef.current.postMessage(payload);
      }
      localStorage.setItem("cosam_dual_sync_payload", JSON.stringify({ ...payload, timestamp: Date.now() }));
    } catch {
      // fallback
    }
  };

  // Función para abrir la ventana emergente limpia del paciente
  const handleOpenDualPatientWindow = () => {
    const dualUrl = `${window.location.origin}${window.location.pathname}?view=paciente_dual#paciente_dual`;
    try {
      const dualWin = window.open(
        dualUrl,
        "CosamPacienteDualWindow",
        "width=1280,height=800,menubar=no,toolbar=no,location=no,status=no,resizable=yes"
      );

      if (!dualWin || dualWin.closed || typeof dualWin.closed === "undefined") {
        setPopupBlockedNotice(true);
      } else {
        setIsDualWindowActive(true);
        setPopupBlockedNotice(false);
        // Sincronizar estado actual con la nueva ventana tras un instante
        setTimeout(() => {
          broadcastSync({
            type: "SET_TAB",
            tab: activeTab === "vista_partida" ? "circuito" : activeTab,
            slideIndex: currentSlide,
            theme: projectorTheme,
            scale: fontSizeLevel
          });
        }, 500);
      }
    } catch {
      setPopupBlockedNotice(true);
    }
  };

  // Copiar registro de evolución a Rayen APS
  const handleCopyRayenNote = () => {
    const text = `[COSAM RINCONADA - PSICOEDUCACIÓN EN CONSULTA MÉDICA]
Fecha: ${new Date().toLocaleDateString("es-CL")}
Modalidad: Psicoeducación Médica con Proyección Dual en Box.
Contenidos Abordados:
- Diapositiva / Tema: ${slides[currentSlide]?.title || "Neurobiología y Freno Frontal"}
- Comprensión de la Neurobiología: Acelerador dopaminérgico (Accumbens) vs. Freno prefrontal consciente. Desestigmatización de la adicción como condición médica tratable.
- Manejo de Craving: Técnica Urge Surfing (Regla de 15 minutos, respiración vagal diafragmática 4-2-6).
- Farmacología & Neuroplasticidad: Recuperación de receptores D2, estímulo de BDNF mediante caminatas/ejercicio y adherencia a fármacos acordados.
Compromiso del Paciente: Buena receptividad en box, formula preguntas aclaradas satisfactoriamente, comprende el fundamento biológico del tratamiento y se compromete con la pauta acordada.
Plan: Mantener esquema farmacológico, seguimiento en consulta médica y citación a control.`;
    navigator.clipboard.writeText(text);
    setCopiedRayenNote(true);
    setTimeout(() => setCopiedRayenNote(false), 2500);
  };

  // LIMPIEZA AUTOMÁTICA EN EL MONTAJE: OCULTAR CUALQUIER TEXTO/BANNER "Proyección Terapéutica"
  useEffect(() => {
    const hideProyeccionElements = () => {
      const allElements = document.querySelectorAll("h1, h2, h3, h4, span, p, div, header");
      allElements.forEach((el) => {
        const text = el.textContent || "";
        if (text.includes("Proyección Terapéutica") || text.includes("proyección terapéutica") || text.includes("PROYECCIÓN TERAPÉUTICA")) {
          // Si el elemento es un encabezado/banner específico o un contenedor de dicho texto
          if (el.children.length === 0 || (el.tagName.toLowerCase().startsWith("h") && text.length < 80)) {
            (el as HTMLElement).style.display = "none";
          }
        }
      });
    };

    hideProyeccionElements();
    // Ejecutar también un frame después por si hay animaciones de entrada
    const timeout = setTimeout(hideProyeccionElements, 100);
    return () => clearTimeout(timeout);
  }, []);

  // TICK DEL TEMPORIZADOR
  useEffect(() => {
    let interval: any = null;
    if (isTimerRunning && timerSeconds > 0) {
      interval = setInterval(() => {
        setTimerSeconds((prev) => {
          const next = prev - 1;
          if (next > 12 * 60) setTimerPhase("inicio");
          else if (next > 7 * 60) setTimerPhase("pico");
          else if (next > 2 * 60) setTimerPhase("descenso");
          else setTimerPhase("calma");
          return next;
        });
      }, 1000);
    } else if (timerSeconds === 0) {
      setIsTimerRunning(false);
      setTimerPhase("calma");
    }
    return () => clearInterval(interval);
  }, [isTimerRunning, timerSeconds]);

  // TOGGLE PANTALLA COMPLETA
  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      if (containerRef.current?.requestFullscreen) {
        containerRef.current.requestFullscreen().catch(() => {});
        setIsFullscreen(true);
      }
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen().catch(() => {});
        setIsFullscreen(false);
      }
    }
  };

  // BOTÓN SALIR Y RETORNAR AL MODO CONSULTA ESTÁNDAR
  const handleExit = () => {
    if (document.fullscreenElement) {
      document.exitFullscreen().catch(() => {});
    }
    if (onToggleSidebar) {
      onToggleSidebar(false);
    }
    if (onExitToStandard) {
      onExitToStandard();
    }
  };

  // NAVEGACIÓN POR TECLADO PARA EL PROYECTOR / CONTROL REMOTO
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight" || e.key === "PageDown") {
        if (activeTab === "diapositivas") {
          setCurrentSlide((prev) => Math.min(slides.length - 1, prev + 1));
        }
      } else if (e.key === "ArrowLeft" || e.key === "PageUp") {
        if (activeTab === "diapositivas") {
          setCurrentSlide((prev) => Math.max(0, prev - 1));
        }
      } else if (e.key === "Escape") {
        if (isProjectorClean) {
          setIsProjectorClean(false);
          e.preventDefault();
          e.stopPropagation();
        } else {
          handleExit();
        }
      } else if (e.key === " " && activeTab === "surf_timer") {
        e.preventDefault();
        setIsTimerRunning((prev) => !prev);
      } else if (e.key === "f" || e.key === "F") {
        if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
        toggleFullscreen();
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [activeTab, currentSlide, isProjectorClean]);

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isLaserPointer) {
      setLaserPos({ x: e.clientX, y: e.clientY });
    }
  };

  const formatTimer = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
  };

  const resetTimer = () => {
    setIsTimerRunning(false);
    setTimerSeconds(15 * 60);
    setTimerPhase("inicio");
  };

  // DIAPOSITIVAS CLÍNICAS DE ALTO IMPACTO PSICOEDUCATIVO
  const slides = [
    {
      title: "1. ¿Qué es una Adicción? No es falta de voluntad",
      badge: "Concepto Fundamental",
      subtitle: "Una condición médica real en los circuitos del cerebro",
      icon: Brain,
      color: "purple",
      leadText: "La adicción es una enfermedad médica del cerebro, igual que la diabetes lo es del páncreas o el asma de los pulmones.",
      takeaway: "Nadie elige enfermarse. Las sustancias químicas alteran los circuitos de supervivencia y autocontrol. La culpa no ayuda a sanar; el tratamiento médico y psicosocial sí.",
      simplifiedPoints: [
        {
          label: "El Mito Antiguo",
          text: "«Si tuviera fuerza de voluntad, pararía cuando quisiera. Es un vicio o falta de carácter».",
          status: "FALSO / ESTIGMA",
          color: "rose"
        },
        {
          label: "La Evidencia Médica",
          text: "El freno biológico frontal está temporalmente apagado por el tóxico. Con tratamiento se recupera.",
          status: "CIENCIA COSAM",
          color: "emerald"
        }
      ]
    },
    {
      title: "2. El Acelerador y el Freno del Cerebro",
      badge: "Neurobiología Simple",
      subtitle: "Por qué la mente quiere parar pero el cuerpo siente un impulso incontrolable",
      icon: Zap,
      color: "amber",
      leadText: "El cerebro tiene dos partes en conflicto: un Acelerador primitivo de supervivencia y un Freno consciente de decisiones.",
      takeaway: "La sustancia pisa el acelerador con 10 veces más dopamina que la comida, desgastando el freno. El objetivo en COSAM es reparar ese freno biológico.",
      simplifiedPoints: [
        {
          label: "El Acelerador (Núcleo Accumbens)",
          text: "Centro del impulso urgente. Cree falsamente que consumir es tan vital como respirar o comer.",
          status: "DOPAMINA ALTA",
          color: "amber"
        },
        {
          label: "El Freno (Corteza Prefrontal)",
          text: "Piensa en el futuro, hijos, salud y trabajo. Se desgasta con el consumo crónico pero vuelve a formarse.",
          status: "AUTOCONTROL",
          color: "blue"
        }
      ]
    },
    {
      title: "3. Surfear la Ola del Craving (15 Minutos)",
      badge: "Herramienta Práctica",
      subtitle: "El deseo intenso no dura para siempre: sube, alcanza un pico y baja por sí solo",
      icon: Waves,
      color: "teal",
      leadText: "El craving no es una pared fija infinita: tiene forma de ola en el mar y su pico fisiológico dura entre 15 y 20 minutos.",
      takeaway: "Si no alimentas el pensamiento y te concentras en respirar y mover el cuerpo, la dopamina baja espontáneamente sin necesidad de consumir.",
      simplifiedPoints: [
        {
          label: "1. Reconocer la Ola",
          text: "«Esto es solo un impulso químico temporal, no es una orden real de mi cuerpo».",
          status: "MIN 1 - 5",
          color: "teal"
        },
        {
          label: "2. Pausa & Respiración",
          text: "Inhalar en 4s, retener en 2s, exhalar en 6s. Beber un vaso de agua fría.",
          status: "MIN 5 - 10",
          color: "indigo"
        },
        {
          label: "3. Cambio de Entorno",
          text: "Caminar, llamar a una persona de confianza o salir del sitio gatillante.",
          status: "MIN 10 - 15",
          color: "emerald"
        }
      ]
    },
    {
      title: "4. El Cronograma de la Esperanza: Regeneración Cerebral",
      badge: "Neuroplasticidad Real",
      subtitle: "Cómo el cerebro reconstruye sus receptores D2 mes a mes al mantener la sobriedad",
      icon: Sparkles,
      color: "indigo",
      leadText: "La neurociencia demostró con escáneres cerebrales (PET) que el cerebro recupera sus receptores de placer natural al dejar el tóxico.",
      takeaway: "A los 14 meses de sobriedad, la densidad neuronal del autocontrol vuelve a niveles casi normales. La recuperación es visible y biológica.",
      simplifiedPoints: [
        {
          label: "Días 1 a 14: Desintoxicación",
          text: "El cuerpo elimina el tóxico. Desaparecen los temblores, sudoración y taquicardia.",
          status: "FASE 1",
          color: "purple"
        },
        {
          label: "Meses 1 a 3: Siembra D2",
          text: "Regresa el sueño reparador y el apetito. Disminuye la irritabilidad matinal.",
          status: "FASE 2",
          color: "blue"
        },
        {
          label: "Meses 3 a 6: Consolidación",
          text: "Se fortalecen las conexiones frontales, la memoria de trabajo y la estabilidad.",
          status: "FASE 3",
          color: "teal"
        },
        {
          label: "Meses 6 a 14+: Placer Natural",
          text: "Capacidad de disfrutar a los hijos, la comida, los proyectos y la vida cotidiana.",
          status: "RECUPERACIÓN",
          color: "emerald"
        }
      ]
    },
    {
      title: "5. Alimentación, Hidratación y Sueño como Medicina",
      badge: "Nutrición & Neurogénesis",
      subtitle: "El cerebro necesita materia prima biológica para sintetizar bienestar y BDNF",
      icon: Apple,
      color: "emerald",
      leadText: "No se puede reparar una casa sin ladrillos: el cerebro necesita agua, proteínas y vitaminas para fabricar dopamina natural.",
      takeaway: "Estar deshidratado, en ayuno prolongado o sin dormir duplica el riesgo de craving. Comer cada 3-4 horas es una estrategia médica directa.",
      simplifiedPoints: [
        {
          label: "Agua (2 a 3 Litros / día)",
          text: "Elimina metabolitos tóxicos, alivia dolores de cabeza y reduce la fatiga.",
          status: "HIDRATACIÓN",
          color: "blue"
        },
        {
          label: "Proteínas (Huevos, Pollo, Legumbres)",
          text: "Aportan tirosina y triptófano, bloques directos para dopamina y serotonina.",
          status: "NEUROQUÍMICA",
          color: "amber"
        },
        {
          label: "Complejo B & Bisglicinato Magnesio",
          text: "Protegen las neuronas, favorecen el sueño profundo y reparan el sistema nervioso.",
          status: "MICRONUTRIENTES",
          color: "purple"
        },
        {
          label: "Ejercicio Aeróbico (150 min/sem)",
          text: "Libera BDNF, el abono natural que hace crecer nuevas ramas neuronales.",
          status: "BDNF FERTILIZANTE",
          color: "emerald"
        }
      ]
    },
    {
      title: "6. Gatillantes del Deseo: Modelo H.A.L.T. & Disparadores",
      badge: "Identificación Temprana",
      subtitle: "Reconocer las trampas biológicas y del entorno antes de que se active el impulso ciego",
      icon: Flame,
      color: "amber",
      leadText: "El deseo de consumo casi nunca nace de la nada; es disparado por estados de vulnerabilidad interna (H.A.L.T.) o por señales externas aprendidas.",
      takeaway: "Un gatillante es solo una chispa; no es una orden de consumo. Si aprendes a detectar la chispa a tiempo (hambre, cansancio, dinero en mano), puedes apagarla antes de que toque la pólvora del hábito.",
      simplifiedPoints: [
        {
          label: "Triggers Internos (H.A.L.T.)",
          text: "Hambre (Hungry), Enojo/Rabia (Angry), Soledad/Tristeza (Lonely), Cansancio (Tired). El cerebro confunde estas necesidades con ganas de consumir.",
          status: "VULNERABILIDAD",
          color: "amber"
        },
        {
          label: "Triggers Externos (Señales)",
          text: "Personas de consumo, rutas habituales, viernes por la tarde, portar efectivo o música y olores asociados.",
          status: "MEMORIA ASOCIADA",
          color: "rose"
        },
        {
          label: "Trampa Mental: «Solo una vez»",
          text: "Pensamiento saboteador del circuito de recompensa para bajar la guardia. Reconócelo como un síntoma, no como una verdad.",
          status: "DISTORSIÓN",
          color: "purple"
        },
        {
          label: "Estrategia: Bloqueo de Acceso",
          text: "Evitar portar efectivo innecesario, cambiar rutas hacia el hogar y bloquear contactos de riesgo en el teléfono.",
          status: "PROTECCIÓN",
          color: "emerald"
        }
      ]
    },
    {
      title: "7. Técnicas de Afrontamiento: Protocolo SOS de 5 Pasos",
      badge: "Herramienta Práctica",
      subtitle: "Estrategias de rescate conductual y cognitivo cuando la urgencia de consumir se dispara",
      icon: ShieldCheck,
      color: "teal",
      leadText: "Cuando el craving aparece, no debes pelear con él. Aplica de inmediato el protocolo conductual de frenado antes de tomar cualquier decisión.",
      takeaway: "La «Regla de los 15 Minutos» y la técnica de la «Película Completa» desactivan el secuestro emocional del Núcleo Accumbens y reconectan el lóbulo prefrontal.",
      simplifiedPoints: [
        {
          label: "1. Pausa & Reflejo Vagal",
          text: "Detente. Bebe un vaso grande de agua helada o lávate la cara con agua fría. Activa el nervio vago y desacelera el pulso.",
          status: "FRENO VAGAL",
          color: "blue"
        },
        {
          label: "2. Respiración Diafragmática (4-2-6)",
          text: "Inhala por la nariz en 4s, retén 2s, exhala por la boca en 6s durante 3 minutos. Reduce el cortisol y la angustia.",
          status: "CALMA FÍSICA",
          color: "teal"
        },
        {
          label: "3. Mirar la «Película Completa»",
          text: "No te quedes en la fantasía de los primeros 10 min. Adelanta la cinta mentalmente hasta la culpa, el gasto y la resaca del día siguiente.",
          status: "REESTRUCTURACIÓN",
          color: "amber"
        },
        {
          label: "4. Movimiento & Red de Apoyo",
          text: "Sal del lugar físico, camina a paso firme y llama a tu persona de confianza o comunícate con el equipo de COSAM Rinconada.",
          status: "ACCIÓN RESCATE",
          color: "emerald"
        }
      ]
    }
  ];

  const faqs = [
    {
      q: "¿Por qué siento que nada me alegra ni me da placer (anhedonia)?",
      a: "Es absolutamente normal en las primeras semanas. Al dejar la sustancia, los receptores de dopamina quedaron temporalmente dormidos por el exceso previo. No es que tu vida sea triste, es que tus sensores biológicos están en mantención. Con las semanas volverás a sentir alegría natural."
    },
    {
      q: "¿El Disulfiram me va a hacer daño a la salud?",
      a: "No. El Disulfiram es un medicamento muy seguro si no tomas alcohol. Lo que hace es bloquear temporalmente la enzima que degrada el alcohol, actuando como un escudo protector para que no consumas por impulso. Mientras no bebas alcohol ni comas alimentos con vinagre o licor, no sentirás molestias."
    },
    {
      q: "¿Qué diferencia hay entre una 'caída' (lapse) y una 'recaída' (relapse)?",
      a: "Una caída es un consumo puntual de un día o una noche. Si te detienes inmediatamente y vienes al COSAM, no se pierde todo el camino avanzado; se analiza qué gatilló el consumo y se ajusta el plan. Una recaída es volver al patrón antiguo durante semanas abandonando el tratamiento. ¡No dejes de venir si tuviste una caída!"
    },
    {
      q: "¿Por qué el ejercicio físico me ayuda tanto contra las ganas de consumir?",
      a: "El ejercicio aeróbico (caminar rápido, trotar, andar en bicicleta) libera una sustancia mágica llamada BDNF (Factor Neurotrófico Derivado del Cerebro) y endorfinas naturales, que actúan como abono fertilizante para que las neuronas creen nuevas ramas y reparen el freno frontal."
    }
  ];

  // PREGUNTAS FRECUENTES ESPECIALIZADAS SOBRE EL TRATAMIENTO (PARA VISTA PARTIDA)
  const treatmentFaqs = [
    {
      id: "farmacos_antabuse",
      categoria: "farmacos",
      categoriaLabel: "Fármacos & Tratamiento",
      badge: "Protección Biológica",
      color: "purple",
      pregunta: "¿Cómo funciona el Disulfiram (Antabuse) y qué precauciones debo tener?",
      respuestaDirecta:
        "El Disulfiram es un escudo farmacológico. Bloquea temporalmente la enzima que procesa el alcohol en el hígado. Si bebes, se acumula acetaldehído y provoca malestar intenso e inmediato. No daña tu cuerpo si no consumes alcohol.",
      fundamentoNeurobiologico:
        "Inhibe irreversiblemente la Aldehído Deshidrogenasa (ALDH). Al saber que el consumo produce malestar fisiológico seguro, el circuito de recompensa desactiva el impulso compulsivo (desvincula la promesa de placer inmediato).",
      vinculoSimulador:
        "En el simulador izquierdo, observa cómo el alcohol bloquea a los 'vigilantes' GABA y desborda la dopamina. El Disulfiram frena la decisión antes de que el motor se descontrole.",
      consejoBox:
        "Tómalo por la mañana, preferentemente supervisado por un familiar de confianza, y evita alimentos con vinagre, enjuagues bucales con alcohol y licores de repostería."
    },
    {
      id: "farmacos_anticraving",
      categoria: "farmacos",
      categoriaLabel: "Fármacos & Tratamiento",
      badge: "Estabilizadores Sinápticos",
      color: "indigo",
      pregunta: "¿Los medicamentos como Bupropión, Topiramato o Naltrexona causan adicción?",
      respuestaDirecta:
        "No. Ninguno de estos medicamentos genera dependencia ni adicción. Su función médica es nivelar los neurotransmisores, suavizar las ganas intensas de consumir (craving) y proteger al cerebro de la irritabilidad.",
      fundamentoNeurobiologico:
        "El Bupropión modula suavemente los transportadores DAT y NET sin disparos fásicos violentos; el Topiramato frena la hiperexcitabilidad glutamatérgica; la Naltrexona bloquea los receptores opioides que alimentan el refuerzo placentero.",
      vinculoSimulador:
        "Observa en la fase 5 'Downregulation' cómo la dopamina basal se desploma: estos medicamentos estabilizan el piso químico para que no caigas en el abismo de la anhedonia.",
      consejoBox:
        "Tómalos de forma continua según la pauta médica. No los suspendas de golpe ni los uses solo cuando tengas ganas de consumir."
    },
    {
      id: "neurobiologia_tiempo",
      categoria: "neurobiologia",
      categoriaLabel: "Recuperación D2",
      badge: "Neuroplasticidad Real",
      color: "teal",
      pregunta: "¿Cuánto tiempo necesita mi cerebro para recuperar los receptores D2 y el freno frontal?",
      respuestaDirecta:
        "La siembra y recuperación de receptores comienza desde las primeras 2 semanas de abstinencia, consolidándose entre los 3 y 14 meses de tratamiento continuo.",
      fundamentoNeurobiologico:
        "Los escáneres cerebrales (PET) demuestran que tras 90-120 días sin tóxicos, la membrana neuronal re-expresa receptores D2/D3 y la corteza prefrontal recupera su capacidad de inhibir impulsos.",
      vinculoSimulador:
        "Selecciona el estado 6 'Regeneración & Soporte COSAM' en el simulador para ver cómo la densidad de receptores D2 sube del 30% al 85%.",
      consejoBox:
        "Los primeros 90 días son la etapa de mayor reconstrucción biológica. Cada día de sobriedad es una nueva capa de receptores sanos en tu cerebro."
    },
    {
      id: "neurobiologia_anhedonia",
      categoria: "neurobiologia",
      categoriaLabel: "Recuperación D2",
      badge: "Fase de Transición",
      color: "blue",
      pregunta: "¿Por qué siento que nada me alegra ni me motiva al principio (anhedonia)?",
      respuestaDirecta:
        "Porque tus sensores neuronales quedaron 'adormecidos' por las inundaciones químicas pasadas. No es que tu vida sea triste, es que tus sensores están en mantención y necesitan tiempo para volver a captar alegrías naturales.",
      fundamentoNeurobiologico:
        "Down-regulation compensatoria: ante estímulos masivos del 800% de dopamina, el cerebro esconde sus receptores. Al retirar la sustancia, los estímulos naturales de la vida (100%) se perciben planos temporalmente.",
      vinculoSimulador:
        "Corresponde a la fase 4 y 5 del simulador. La anhedonia no es permanente: se revierte a medida que el sistema sináptico se desintoxica.",
      consejoBox:
        "Realiza actividades placenteras simples aunque al principio no sientas entusiasmo. La acción despierta a las neuronas antes que las ganas."
    },
    {
      id: "craving_urgencias",
      categoria: "craving",
      categoriaLabel: "Craving & SOS",
      badge: "Manejo en Crisis",
      color: "rose",
      pregunta: "¿Qué hago cuando siento una urgencia intensa por consumir (ola de craving)?",
      respuestaDirecta:
        "Aplica los 4 pasos SOS: 1) Reconoce que es una ola química de 15 minutos; 2) Respira diafragmáticamente (4s inhala, 2s retén, 6s exhala); 3) Toma un vaso grande de agua fría; 4) Sal inmediatamente del entorno gatillante.",
      fundamentoNeurobiologico:
        "El craving es un pico fásico de dopamina inducido por memorias del Núcleo Accumbens. Al no consumir y oxigenar la corteza prefrontal, el pico se agota por sí solo en 15 a 20 minutos.",
      vinculoSimulador:
        "En el simulador, el freno frontal compite contra el impulso del Accumbens. Respirar lento le devuelve energía a la corteza frontal.",
      consejoBox:
        "Puedes usar la pestaña 'Surfeo Craving' con el cronómetro de 15 minutos proyectado en la pantalla de consulta para entrenarlo aquí mismo."
    },
    {
      id: "habitos_nutricion",
      categoria: "habitos",
      categoriaLabel: "Hábitos Biológicos",
      badge: "Materia Prima",
      color: "emerald",
      pregunta: "¿Por qué la nutrición, el agua y el sueño se consideran medicina para la adicción?",
      respuestaDirecta:
        "El cerebro no puede fabricar bienestar de la nada. Las proteínas aportan los ladrillos (tirosina) para crear dopamina, y el ejercicio aeróbico produce BDNF, el abono que hace crecer nuevas conexiones neuronales.",
      fundamentoNeurobiologico:
        "La síntesis de dopamina requiere L-Tirosina -> L-DOPA -> Dopamina con cofactores B6, folato, hierro y magnesio. El ejercicio eleva el Factor Neurotrófico Derivado del Cerebro (BDNF) acelerando la neurogénesis.",
      vinculoSimulador:
        "Es el combustible biológico que permite transicionar de la fase 5 'Agotado' a la fase 6 'Regeneración COSAM'.",
      consejoBox:
        "Desayuna con huevos, legumbres o lácteos, bebe 2.5 litros de agua al día y camina 30 minutos a paso rápido."
    },
    {
      id: "vinculos_caida",
      categoria: "vinculos",
      categoriaLabel: "Vínculos & COSAM",
      badge: "Continuidad del Cuidado",
      color: "amber",
      pregunta: "¿Si tuve un consumo puntual (caída), perdí todo el camino recorrido?",
      respuestaDirecta:
        "¡No! Una caída es un tropezón en el camino, no el fin del viaje. Si vienes de inmediato al COSAM, no se pierde lo aprendido; analizamos juntos qué gatilló el consumo y reforzamos el plan de protección.",
      fundamentoNeurobiologico:
        "El 'Efecto de Violación de la Abstinencia' genera culpa tóxica que induce cortisol y bloquea el freno frontal. Al consultar a tiempo, se desactiva la culpa y se restablece el control ejecutivo.",
      vinculoSimulador:
        "La red neuronal reconstruida durante semanas de sobriedad no desaparece en una sola noche. Mantener el tratamiento consolida la red sináptica.",
      consejoBox:
        "Nunca dejes de asistir por vergüenza o temor. El equipo de salud mental está aquí para acompañarte sin juzgar."
    },
    {
      id: "vinculos_familia",
      categoria: "vinculos",
      categoriaLabel: "Vínculos & COSAM",
      badge: "Apoyo Cercano",
      color: "sky",
      pregunta: "¿Cómo puede apoyar la familia sin convertirse en vigilantes ni generar discusiones?",
      respuestaDirecta:
        "Apoyando con cariño y límites saludables: supervisar la medicación con afecto, planear paseos o comidas familiares libres de alcohol, y celebrar cada semana de progreso en lugar de recordar errores del pasado.",
      fundamentoNeurobiologico:
        "El soporte familiar cálido estimula la liberación de oxitocina y serotonina, disminuyendo la reactividad de la amígdala cerebral y reduciendo el estrés que desencadena el deseo de consumo.",
      vinculoSimulador:
        "Un entorno seguro fortalece el freno frontal del paciente al mantener bajos los niveles de cortisol.",
      consejoBox:
        "La familia puede integrarse a las sesiones de psicoeducación del COSAM para coordinar un plan de apoyo mutuo."
    }
  ];

  const filteredTreatmentFaqs = treatmentFaqs.filter((faq) => {
    const matchesCategory =
      treatmentFaqCategory === "todas" || faq.categoria === treatmentFaqCategory;
    const matchesSearch =
      faq.pregunta.toLowerCase().includes(treatmentFaqSearch.toLowerCase()) ||
      faq.respuestaDirecta.toLowerCase().includes(treatmentFaqSearch.toLowerCase()) ||
      faq.fundamentoNeurobiologico.toLowerCase().includes(treatmentFaqSearch.toLowerCase()) ||
      faq.categoriaLabel.toLowerCase().includes(treatmentFaqSearch.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  // CLASES DE TEMA DE ALTO CONTRASTE
  const isDark = projectorTheme === "dark";
  const bgMain = isDark ? "bg-[#060814] text-white" : "bg-slate-50 text-slate-950";
  const cardBg = isDark ? "bg-slate-900/90 border-slate-800 text-white" : "bg-white border-slate-300 text-slate-900";
  const innerCardBg = isDark ? "bg-slate-950/80 border-slate-800" : "bg-slate-100 border-slate-200";

  const getFontSizeClasses = () => {
    if (fontSizeLevel === "huge") return "text-2xl md:text-3xl leading-relaxed";
    if (fontSizeLevel === "large") return "text-lg md:text-xl leading-relaxed";
    return "text-base md:text-lg leading-normal";
  };

  return (
    <div
      ref={containerRef}
      onMouseMove={handleMouseMove}
      className={`w-full min-h-[calc(100vh-5rem)] rounded-3xl p-4 md:p-8 transition-colors duration-300 ${bgMain} space-y-6 relative overflow-hidden ${isProjectorClean ? "projector-clean-active" : ""}`}
    >
      {/* FLOATING BUTTON TO EXIT PROJECTION CLEAN MODE */}
      {isProjectorClean && (
        <button
          onClick={() => setIsProjectorClean(false)}
          className="fixed top-4 right-4 z-50 px-3.5 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-black text-xs uppercase tracking-wider transition-all flex items-center gap-1.5 shadow-lg opacity-40 hover:opacity-100 cursor-pointer border border-rose-500"
          title="Salir de la Proyección Limpia (Esc)"
        >
          <LogOut size={13} />
          <span>Salir de Proyección (Esc)</span>
        </button>
      )}

      {/* PUNTERO LÁSER VIRTUAL OPCIONAL */}
      {isLaserPointer && (
        <div
          className="fixed pointer-events-none z-50 w-6 h-6 rounded-full bg-rose-500/80 blur-xs border-2 border-white shadow-[0_0_20px_#f43f5e] transform -translate-x-1/2 -translate-y-1/2 transition-transform duration-75"
          style={{ left: `${laserPos.x}px`, top: `${laserPos.y}px` }}
        />
      )}

      {/* =========================================================================
          BARRA DE CONTROL COMPACTA (SIN BANNER DISTRACTOR PARA PROYECCIÓN LIMPIA)
         ========================================================================= */}
      <header
        className={`rounded-2xl p-3 md:p-3.5 border transition-all ${cardBg} flex flex-wrap items-center justify-between gap-3 shadow-xs`}
      >
        {/* LADO IZQUIERDO: BOTÓN SALIR DIRECTO Y MODO BOX */}
        <div className="flex items-center gap-2.5">
          <button
            onClick={handleExit}
            title="Salir del Modo Proyector y volver al portal (Esc)"
            className="px-3 py-1.5 rounded-lg bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 active:scale-95 text-slate-800 dark:text-slate-200 font-medium text-xs transition-colors flex items-center gap-1.5 cursor-pointer border border-slate-300 dark:border-slate-700"
          >
            <LogOut size={13} strokeWidth={1.75} />
            <span>Salir</span>
          </button>

          <div className="hidden sm:flex items-center gap-1.5 text-xs font-medium text-slate-500 dark:text-slate-400 pl-1">
            <Tv size={14} strokeWidth={1.75} />
            <span>Modo Box</span>
          </div>

          {/* BOTÓN VISTA DUAL (POP-UP PACIENTE) */}
          <button
            onClick={handleOpenDualPatientWindow}
            title="Abrir ventana emergente exclusivamente para el paciente (proyector o 2da pantalla en box)"
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5 cursor-pointer border ${
              isDualWindowActive
                ? "bg-emerald-600 text-white border-emerald-500 shadow-xs"
                : "bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-300 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-750"
            }`}
          >
            <MonitorUp size={14} strokeWidth={1.75} />
            <span>{isDualWindowActive ? "Vista Dual Activa" : "Vista Dual"}</span>
            {isDualWindowActive && (
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-200 inline-block ml-0.5" />
            )}
          </button>
        </div>

        {/* CENTRO: SELECTOR DE SUB-MÓDULOS */}
        <div className="flex p-0.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-950/60 gap-1 shrink-0 flex-wrap">
          <button
            onClick={() => {
              setActiveTab("vista_partida");
              broadcastSync({ type: "SET_TAB", tab: "circuito" });
            }}
            title="Vista partida: Simulador de circuito a la izquierda y FAQ de tratamiento a la derecha"
            className={`px-3 py-1 rounded-md text-xs font-medium transition-colors flex items-center gap-1.5 cursor-pointer ${
              activeTab === "vista_partida"
                ? "bg-white dark:bg-slate-850 text-slate-900 dark:text-white shadow-xs"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
            }`}
          >
            <Columns size={13} strokeWidth={1.75} />
            <span>Vista Partida</span>
          </button>

          <button
            onClick={() => {
              setActiveTab("diapositivas");
              broadcastSync({ type: "SET_TAB", tab: "diapositivas" });
            }}
            className={`px-3 py-1 rounded-md text-xs font-medium transition-colors flex items-center gap-1.5 cursor-pointer ${
              activeTab === "diapositivas"
                ? "bg-white dark:bg-slate-850 text-slate-900 dark:text-white shadow-xs"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
            }`}
          >
            <Brain size={13} strokeWidth={1.75} />
            <span>Diapositivas</span>
          </button>

          <button
            onClick={() => {
              setActiveTab("surf_timer");
              broadcastSync({ type: "SET_TAB", tab: "surf_timer" });
            }}
            className={`px-3 py-1 rounded-md text-xs font-medium transition-colors flex items-center gap-1.5 cursor-pointer ${
              activeTab === "surf_timer"
                ? "bg-white dark:bg-slate-850 text-slate-900 dark:text-white shadow-xs"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
            }`}
          >
            <Waves size={13} strokeWidth={1.75} />
            <span>Surfeo Craving</span>
          </button>

          <button
            onClick={() => {
              setActiveTab("faq_paciente");
              broadcastSync({ type: "SET_TAB", tab: "faq_paciente" });
            }}
            className={`px-3 py-1 rounded-md text-xs font-medium transition-colors flex items-center gap-1.5 cursor-pointer ${
              activeTab === "faq_paciente"
                ? "bg-white dark:bg-slate-850 text-slate-900 dark:text-white shadow-xs"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
            }`}
          >
            <HelpCircle size={13} strokeWidth={1.75} />
            <span>Preguntas Box</span>
          </button>
        </div>

        {/* LADO DERECHO: HERRAMIENTAS DE VISUALIZACIÓN */}
        <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-950/60 p-0.5 rounded-lg border border-slate-200 dark:border-slate-800 shrink-0">
          {/* Alternar Notas Clínicas Privadas del Médico */}
          <button
            onClick={() => setIsDoctorNotesOpen(!isDoctorNotesOpen)}
            title={isDoctorNotesOpen ? "Ocultar guía médico" : "Mostrar guía clínico confidencial"}
            className={`px-2 py-1 rounded-md transition-colors text-xs flex items-center gap-1 cursor-pointer ${
              isDoctorNotesOpen
                ? "bg-white dark:bg-slate-850 text-slate-900 dark:text-white shadow-xs font-medium"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
            }`}
          >
            <FileText size={13} strokeWidth={1.75} />
            <span className="hidden xl:inline text-[11px]">Guía Médico</span>
          </button>

          {/* Alternar Tema Oscuro / Claro */}
          <button
            onClick={() => {
              const nextTheme = projectorTheme === "dark" ? "light" : "dark";
              setProjectorTheme(nextTheme);
              broadcastSync({ type: "SET_THEME", theme: nextTheme });
            }}
            title={isDark ? "Cambiar a modo claro" : "Cambiar a fondo oscuro proyector"}
            className="p-1.5 rounded-md text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer"
          >
            {isDark ? <Sun size={13} strokeWidth={1.75} /> : <Moon size={13} strokeWidth={1.75} />}
          </button>

          {/* Tamaño de Fuente para Pared */}
          <button
            onClick={() => {
              let nextLevel: "normal" | "large" | "huge" = "normal";
              if (fontSizeLevel === "normal") nextLevel = "large";
              else if (fontSizeLevel === "large") nextLevel = "huge";
              else nextLevel = "normal";
              setFontSizeLevel(nextLevel);
              broadcastSync({ type: "SET_TEXT_SCALE", scale: nextLevel });
            }}
            title="Ajustar tamaño de letra para legibilidad a distancia"
            className="px-1.5 py-1 rounded-md text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white transition-colors text-xs flex items-center gap-1 cursor-pointer font-medium"
          >
            <Type size={13} strokeWidth={1.75} />
            <span className="text-[10px]">
              {fontSizeLevel === "huge" ? "XL" : fontSizeLevel === "large" ? "L" : "M"}
            </span>
          </button>

          {/* Puntero Láser */}
          <button
            onClick={() => {
              const nextLaser = !isLaserPointer;
              setIsLaserPointer(nextLaser);
              if (!nextLaser) {
                broadcastSync({ type: "LASER_MOVE", x: 0, y: 0, active: false });
              }
            }}
            title={isLaserPointer ? "Desactivar Puntero Láser" : "Activar Puntero Láser Virtual"}
            className={`p-1.5 rounded-md transition-colors cursor-pointer ${
              isLaserPointer ? "bg-slate-900 dark:bg-white text-white dark:text-slate-900 shadow-xs" : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
            }`}
          >
            <Crosshair size={13} strokeWidth={1.75} />
          </button>

          {/* Proyección Limpia para Proyector de Pared */}
          <button
            onClick={() => setIsProjectorClean(!isProjectorClean)}
            title={isProjectorClean ? "Mostrar barras de herramientas" : "Ocultar barras para proyección limpia"}
            className={`px-2 py-1 rounded-md transition-colors text-xs flex items-center gap-1 cursor-pointer ${
              isProjectorClean 
                ? "bg-slate-900 dark:bg-white text-white dark:text-slate-900 shadow-xs font-medium" 
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
            }`}
          >
            <Projector size={13} strokeWidth={1.75} />
            <span className="hidden md:inline text-[11px]">Proyectar</span>
          </button>

          {/* Pantalla Completa */}
          <button
            onClick={toggleFullscreen}
            title={isFullscreen ? "Salir de Pantalla Completa (F)" : "Pantalla Completa (F)"}
            className="p-1.5 rounded-md text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer"
          >
            {isFullscreen ? <Minimize2 size={13} strokeWidth={1.75} /> : <Maximize2 size={13} strokeWidth={1.75} />}
          </button>
        </div>
      </header>

      {/* AVISO SI EL NAVEGADOR BLOQUEÓ EL POP-UP */}
      {popupBlockedNotice && (
        <div className="p-4 rounded-2xl bg-amber-500/15 border border-amber-500/40 text-amber-200 flex flex-col md:flex-row items-start md:items-center justify-between gap-3 shadow-lg">
          <div className="flex items-center gap-3">
            <AlertTriangle size={20} className="text-amber-400 shrink-0" />
            <div className="text-xs">
              <strong className="block text-amber-300 font-black">
                Ventana emergente bloqueada por el navegador:
              </strong>
              El navegador impidió abrir automáticamente el pop-up de la segunda pantalla. Puedes abrir la pantalla del paciente en una pestaña nueva o ver la proyección flotante aquí.
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <a
              href={`${window.location.origin}${window.location.pathname}?view=paciente_dual#paciente_dual`}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => setPopupBlockedNotice(false)}
              className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs transition-all flex items-center gap-1.5 cursor-pointer shadow-sm"
            >
              <ExternalLink size={13} />
              <span>Abrir en Nueva Pestaña</span>
            </a>
            <button
              onClick={() => {
                setIsDualModalOpen(true);
                setPopupBlockedNotice(false);
              }}
              className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-black text-xs transition-all flex items-center gap-1.5 cursor-pointer border border-slate-600"
            >
              <Eye size={13} />
              <span>Proyección Flotante</span>
            </button>
            <button
              onClick={() => setPopupBlockedNotice(false)}
              className="p-1.5 rounded-lg hover:bg-white/10 text-slate-400 hover:text-white"
            >
              <X size={14} />
            </button>
          </div>
        </div>
      )}

      {/* =========================================================================
          PANEL CONFIDENCIAL DEL MÉDICO EN BOX (INFORMACIÓN SENSIBLE & NOTAS PRIVADAS)
          Nota: Esta sección SOLO se muestra en la pantalla del médico. La ventana
          emergente o proyector del paciente NO la muestra para mantener su privacidad
          y evitar alarmarlo con detalles de anamnesis o advertencias técnicas.
         ========================================================================= */}
      {isDoctorNotesOpen && (
        <section
          aria-label="Panel Confidencial del Médico"
          className={`rounded-2xl p-4 md:p-5 border shadow-xl transition-all ${
            isDark
              ? "bg-slate-900/95 border-amber-500/30 text-slate-100"
              : "bg-amber-50/90 border-amber-300 text-slate-900"
          }`}
        >
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b pb-3 border-amber-500/20">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
                <Stethoscope size={18} />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-sm font-black uppercase tracking-wider text-amber-400">
                    Panel Clínico Confidencial • Box COSAM Rinconada
                  </h2>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-amber-500/20 text-amber-300 border border-amber-500/30">
                    Solo Pantalla Médico
                  </span>
                </div>
                <p className="text-xs text-slate-400">
                  {isDualWindowActive
                    ? "🟢 Sincronizado con Pantalla Paciente: Tu paciente ve únicamente el material visual limpio sin notas clínicas."
                    : "Guía socrática para la entrevista médica en box y atajo para registro en ficha Rayen APS."}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={handleCopyRayenNote}
                title="Copiar texto médico estructurado para pegar directamente en la consulta de Rayen APS"
                className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-slate-950 font-black text-xs transition-all flex items-center gap-1.5 shadow-sm active:scale-95 cursor-pointer"
              >
                {copiedRayenNote ? <Check size={14} className="text-emerald-950" /> : <Copy size={14} />}
                <span>{copiedRayenNote ? "¡Copiado a Rayen!" : "Copiar Registro Rayen"}</span>
              </button>

              <button
                onClick={() => setIsDoctorNotesOpen(false)}
                className="p-1.5 rounded-lg hover:bg-white/10 text-slate-400 hover:text-white text-xs"
                title="Ocultar notas clínicas"
              >
                <X size={14} />
              </button>
            </div>
          </div>

          {/* CONTENIDO PRIVADO DEL MÉDICO */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-3 text-xs">
            {/* COLUMNA 1: PREGUNTAS SOCRÁTICAS RECOMENDADAS */}
            <div className="p-3 rounded-xl bg-black/20 border border-white/5 space-y-1.5">
              <span className="font-black text-amber-400 flex items-center gap-1 text-[11px] uppercase tracking-wider">
                <MessageSquareQuote size={13} />
                Pregunta Socrática para el Paciente:
              </span>
              <p className="text-slate-300 leading-relaxed italic">
                {activeTab === "diapositivas" && currentSlide === 0 && '«¿Has sentido alguna vez que una parte de ti quiere frenar y otra parte pareciera acelerar sola? Eso es exactamente lo que vemos aquí: no es falta de voluntad, es biología desincronizada.»'}
                {activeTab === "diapositivas" && currentSlide === 1 && '«Imagina el pedal del acelerador pegado a fondo en bajada. Tu freno frontal se cansó. ¿Qué apoyos crees que necesita hoy tu freno para volver a responder?»'}
                {activeTab === "diapositivas" && currentSlide === 2 && '«Cuando te baja la urgencia intensa, ¿cuánto tiempo calculas que dura antes de que se pase o busques distraerte? Vamos a ver que dura solo 15 a 20 minutos.»'}
                {activeTab === "diapositivas" && currentSlide === 3 && '«Mira esta curva: cada día sin consumo no es un día perdido de sufrimiento, es un día donde tu cerebro está sembrando nuevos receptores de bienestar natural.»'}
                {activeTab === "surf_timer" && '«Vamos a practicar ahora mismo la respiración: inhala conmigo en 4 segundos, sostén 2 y bota en 6. Siente cómo tu ritmo cardíaco le avisa a tu cerebro que estás a salvo.»'}
                {activeTab === "vista_partida" && '«En la pantalla a tu izquierda vemos tus circuitos; en la derecha tenemos respuestas concretas sobre los fármacos que tomamos en COSAM.»'}
                {activeTab === "faq_paciente" && '«Cualquiera de estas dudas es 100% normal en este proceso. Pregúntame con confianza lo que más te preocupe de tus medicamentos o síntomas.»'}
              </p>
            </div>

            {/* COLUMNA 2: BANDERAS ROJAS & PRECAUCIONES CLÍNICAS */}
            <div className="p-3 rounded-xl bg-black/20 border border-white/5 space-y-1.5">
              <span className="font-black text-rose-400 flex items-center gap-1 text-[11px] uppercase tracking-wider">
                <ShieldAlert size={13} />
                Banderas Rojas en Box (Sensible):
              </span>
              <ul className="text-slate-300 space-y-1 list-disc list-inside leading-snug">
                <li><strong>Consumo reciente de OH:</strong> Si toma Disulfiram, prohibido iniciar hasta 12-24h de abstinencia estricta.</li>
                <li><strong>Riesgo de Síndrome de Abstinencia:</strong> Evaluar temblor fino de manos, sudoración y signos vitales (CIWA-Ar).</li>
                <li><strong>Craving desbordante:</strong> Si el craving supera 8/10 persistente, considerar ajuste farmacológico y apoyo por dupla psicosocial COSAM.</li>
              </ul>
            </div>

            {/* COLUMNA 3: RESUMEN DE LA NOTA QUE SE EXPORTA */}
            <div className="p-3 rounded-xl bg-black/20 border border-white/5 space-y-1.5">
              <span className="font-black text-emerald-400 flex items-center gap-1 text-[11px] uppercase tracking-wider">
                <Activity size={13} />
                Pauta Rayen APS Lista:
              </span>
              <div className="p-2 rounded-lg bg-black/40 border border-white/5 text-[11px] text-slate-300 font-mono leading-tight space-y-1 overflow-hidden">
                <div className="truncate text-slate-400">• Diapositiva: {slides[currentSlide]?.title}</div>
                <div className="truncate text-slate-400">• Modalidad: Proyección Dual en Box</div>
                <div className="text-emerald-400 font-bold">✓ Listo para portapapeles (Alt+5 o botón superior)</div>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* MODAL DE PROYECCIÓN FLOTANTE / SIMULACIÓN DE 2DA PANTALLA */}
      {isDualModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm p-3 md:p-6 flex flex-col">
          <div className="flex items-center justify-between pb-3 text-white">
            <div className="flex items-center gap-2">
              <MonitorUp size={18} className="text-emerald-400" />
              <span className="text-sm font-black uppercase tracking-wider">
                Vista Proyección Paciente (Previsualización Limpia)
              </span>
            </div>
            <button
              onClick={() => setIsDualModalOpen(false)}
              className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-black text-xs transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <LogOut size={14} />
              <span>Cerrar Previsualización</span>
            </button>
          </div>
          <div className="flex-1 rounded-2xl overflow-hidden border border-white/20 shadow-2xl relative">
            <VistaPacienteDualProyeccion isEmbedded={true} onClose={() => setIsDualModalOpen(false)} />
          </div>
        </div>
      )}

      {/* =========================================================================
          CONTENIDO 0: VISTA PARTIDA (SIMULADOR DE CIRCUITO + FAQ DE TRATAMIENTO)
         ========================================================================= */}
      {activeTab === "vista_partida" && (
        <div className="space-y-6">
          {/* BARRA SUPERIOR DE CONTEXTO DE VISTA PARTIDA */}
          <div
            className={`p-4 rounded-3xl border transition-all flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-lg ${cardBg}`}
          >
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-2xl bg-gradient-to-br from-purple-600 to-indigo-600 text-white shadow-md">
                <Columns size={20} />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-black uppercase tracking-wider text-purple-400 bg-purple-950/60 border border-purple-800 px-2.5 py-0.5 rounded-md">
                    Interacción Dual en Box
                  </span>
                  <span className="text-xs font-bold opacity-75 hidden sm:inline">
                    • Dinámica Neurobiología &amp; Tratamiento
                  </span>
                </div>
                <h2 className="text-lg md:text-xl font-black tracking-tight text-white">
                  Circuito de Recompensa &amp; Preguntas del Tratamiento
                </h2>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2 text-xs font-bold opacity-80">
              <span className="px-3 py-1.5 rounded-xl bg-purple-500/20 text-purple-300 border border-purple-500/30 flex items-center gap-1.5">
                <Brain size={14} className="text-purple-400" />
                <span>Panel Izq: Neurobiología</span>
              </span>
              <span className="px-3 py-1.5 rounded-xl bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 flex items-center gap-1.5">
                <MessageSquareQuote size={14} className="text-indigo-400" />
                <span>Panel Der: Preguntas Tratamiento</span>
              </span>
            </div>
          </div>

          {/* GRID DE VISTA PARTIDA (2 COLUMNAS) */}
          <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
            {/* COLUMNA IZQUIERDA: SIMULADOR DE CIRCUITO DE RECOMPENSA */}
            <div className="xl:col-span-7 space-y-4">
              <div className={`rounded-3xl border p-1 shadow-2xl ${cardBg}`}>
                <div className="p-4 border-b border-white/10 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
                    <span className="text-xs font-black uppercase tracking-wider text-emerald-400">
                      Simulador Interactivo de Recompensa
                    </span>
                  </div>
                  <span className="text-[11px] font-bold opacity-60">
                    ATV • Accumbens • Freno Prefrontal
                  </span>
                </div>

                <div className="p-2 sm:p-4">
                  <SimuladorCircuitoRecompensa />
                </div>
              </div>
            </div>

            {/* COLUMNA DERECHA: PANEL DE PREGUNTAS FRECUENTES SOBRE EL TRATAMIENTO */}
            <div className="xl:col-span-5 space-y-4">
              <div className={`rounded-3xl border p-5 md:p-6 shadow-2xl space-y-5 ${cardBg}`}>
                {/* ENCABEZADO Y BÚSQUEDA */}
                <div className="space-y-3 border-b border-white/10 pb-4">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <div className="p-2 rounded-xl bg-indigo-600/30 text-indigo-400 border border-indigo-500/30">
                        <MessageSquareQuote size={18} />
                      </div>
                      <div>
                        <h3 className="text-base md:text-lg font-black tracking-tight text-white">
                          Preguntas sobre el Tratamiento
                        </h3>
                        <p className="text-xs font-medium opacity-70">
                          Respuestas médicas claras para el paciente y familia
                        </p>
                      </div>
                    </div>
                    <span className="text-xs font-black px-2.5 py-1 rounded-full bg-indigo-900/60 text-indigo-300 border border-indigo-700/60 shrink-0">
                      {filteredTreatmentFaqs.length} temas
                    </span>
                  </div>

                  {/* BUSCADOR */}
                  <div className="relative">
                    <Search
                      size={15}
                      className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400"
                    />
                    <input
                      type="text"
                      placeholder="Buscar por fármaco, síntoma o duda..."
                      value={treatmentFaqSearch}
                      onChange={(e) => setTreatmentFaqSearch(e.target.value)}
                      className={`w-full pl-9 pr-4 py-2 rounded-xl border text-xs font-semibold placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all ${
                        isDark ? "bg-slate-950 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                      }`}
                    />
                  </div>

                  {/* FILTROS POR CATEGORÍA */}
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {[
                      { id: "todas", label: "Todas", icon: Sparkles },
                      { id: "farmacos", label: "Fármacos", icon: Pill },
                      { id: "neurobiologia", label: "Recuperación D2", icon: Brain },
                      { id: "craving", label: "Craving", icon: Flame },
                      { id: "habitos", label: "Nutrición & BDNF", icon: Apple },
                      { id: "vinculos", label: "Familia & Vínculos", icon: HeartHandshake }
                    ].map((cat) => {
                      const Icon = cat.icon;
                      const isSelected = treatmentFaqCategory === cat.id;
                      return (
                        <button
                          key={cat.id}
                          onClick={() => setTreatmentFaqCategory(cat.id)}
                          className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all flex items-center gap-1 ${
                            isSelected
                              ? "bg-indigo-600 text-white shadow-sm"
                              : isDark
                              ? "bg-slate-800/80 text-slate-300 hover:bg-slate-700"
                              : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                          }`}
                        >
                          <Icon size={12} />
                          <span>{cat.label}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* LISTA DE PREGUNTAS EXPANDIBLES (ACCORDION) */}
                <div className="space-y-3 max-h-[850px] overflow-y-auto pr-1">
                  {filteredTreatmentFaqs.length === 0 ? (
                    <div className="text-center py-8 opacity-60 text-xs font-bold">
                      No se encontraron preguntas con ese criterio de búsqueda.
                    </div>
                  ) : (
                    filteredTreatmentFaqs.map((faq) => {
                      const isExpanded = expandedTreatmentFaqId === faq.id;
                      return (
                        <div
                          key={faq.id}
                          className={`rounded-2xl border transition-all overflow-hidden ${
                            isExpanded
                              ? isDark
                                ? "bg-slate-950/90 border-indigo-500/70 shadow-lg ring-1 ring-indigo-500/30"
                                : "bg-indigo-50/50 border-indigo-300 shadow-md"
                              : isDark
                              ? "bg-slate-900/60 border-slate-800 hover:border-slate-700"
                              : "bg-white border-slate-200 hover:border-slate-300"
                          }`}
                        >
                          {/* BOTÓN PREGUNTA */}
                          <button
                            onClick={() =>
                              setExpandedTreatmentFaqId(isExpanded ? null : faq.id)
                            }
                            className="w-full p-4 text-left flex items-start justify-between gap-3"
                          >
                            <div className="space-y-1.5">
                              <div className="flex items-center gap-2 flex-wrap">
                                <span
                                  className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-md ${
                                    faq.color === "purple"
                                      ? "bg-purple-900/60 text-purple-300 border border-purple-700"
                                      : faq.color === "indigo"
                                      ? "bg-indigo-900/60 text-indigo-300 border border-indigo-700"
                                      : faq.color === "teal"
                                      ? "bg-teal-900/60 text-teal-300 border border-teal-700"
                                      : faq.color === "blue"
                                      ? "bg-blue-900/60 text-blue-300 border border-blue-700"
                                      : faq.color === "rose"
                                      ? "bg-rose-900/60 text-rose-300 border border-rose-700"
                                      : faq.color === "emerald"
                                      ? "bg-emerald-900/60 text-emerald-300 border border-emerald-700"
                                      : "bg-amber-900/60 text-amber-300 border border-amber-700"
                                  }`}
                                >
                                  {faq.badge}
                                </span>
                                <span className="text-[10px] font-bold opacity-60">
                                  {faq.categoriaLabel}
                                </span>
                              </div>
                              <h4 className="text-xs md:text-sm font-black text-white leading-snug">
                                {faq.pregunta}
                              </h4>
                            </div>
                            <div className="p-1 rounded-lg bg-white/10 text-slate-300 shrink-0 mt-1">
                              {isExpanded ? <ChevronUp size={15} /> : <ChevronDown size={15} />}
                            </div>
                          </button>

                          {/* CONTENIDO EXPANDIDO */}
                          <AnimatePresence>
                            {isExpanded && (
                              <motion.div
                                initial={{ opacity: 0, height: 0 }}
                                animate={{ opacity: 1, height: "auto" }}
                                exit={{ opacity: 0, height: 0 }}
                                transition={{ duration: 0.2 }}
                                className="px-4 pb-4 space-y-3.5 border-t border-white/10 pt-3"
                              >
                                {/* RESPUESTA DIRECTA / EMPÁTICA */}
                                <div
                                  className={`p-3.5 rounded-xl border ${
                                    isDark
                                      ? "bg-indigo-950/40 border-indigo-700/60 text-indigo-100"
                                      : "bg-indigo-50 border-indigo-200 text-indigo-950"
                                  }`}
                                >
                                  <div className="flex items-center gap-1.5 mb-1.5">
                                    <Sparkle size={13} className="text-indigo-400" />
                                    <span className="text-[10px] font-black uppercase tracking-wider text-indigo-300">
                                      Respuesta para el Paciente
                                    </span>
                                  </div>
                                  <p className="text-xs md:text-sm font-semibold leading-relaxed">
                                    {faq.respuestaDirecta}
                                  </p>
                                </div>

                                {/* FUNDAMENTO NEUROBIOLÓGICO */}
                                <div className="space-y-1 text-xs">
                                  <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 flex items-center gap-1">
                                    <Brain size={12} className="text-purple-400" />
                                    Fundamento Neurobiológico:
                                  </span>
                                  <p className="text-slate-300 font-medium leading-relaxed bg-black/30 p-2.5 rounded-xl border border-white/5">
                                    {faq.fundamentoNeurobiologico}
                                  </p>
                                </div>

                                {/* VÍNCULO CON EL SIMULADOR IZQUIERDO */}
                                <div className="p-2.5 rounded-xl bg-purple-950/30 border border-purple-800/50 flex items-start gap-2 text-xs text-purple-200">
                                  <Info size={14} className="text-purple-400 shrink-0 mt-0.5" />
                                  <div>
                                    <strong className="text-[10px] font-black uppercase tracking-wider block text-purple-300">
                                      Vínculo con el Simulador:
                                    </strong>
                                    <span className="text-[11px] font-medium leading-snug">
                                      {faq.vinculoSimulador}
                                    </span>
                                  </div>
                                </div>

                                {/* CONSEJO PRÁCTICO EN BOX */}
                                <div className="p-2.5 rounded-xl bg-emerald-950/30 border border-emerald-800/50 flex items-start gap-2 text-xs text-emerald-200">
                                  <CheckCircle2 size={14} className="text-emerald-400 shrink-0 mt-0.5" />
                                  <div>
                                    <strong className="text-[10px] font-black uppercase tracking-wider block text-emerald-300">
                                      Pauta Práctica en Box:
                                    </strong>
                                    <span className="text-[11px] font-medium leading-snug">
                                      {faq.consejoBox}
                                    </span>
                                  </div>
                                </div>
                              </motion.div>
                            )}
                          </AnimatePresence>
                        </div>
                      );
                    })
                  )}
                </div>

                {/* PIE DEL PANEL DERECHO */}
                <div className="pt-3 border-t border-white/10 flex items-center justify-between text-[11px] font-bold opacity-70">
                  <span className="flex items-center gap-1.5">
                    <Stethoscope size={13} className="text-indigo-400" />
                    COSAM Rinconada de San Ramón
                  </span>
                  <span>Diálogo Médico Guiado</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          CONTENIDO 1: DIAPOSITIVAS CLÍNICAS EN ALTO CONTRASTE
         ========================================================================= */}
      {activeTab === "diapositivas" && (
        <div className="space-y-6">
          {/* BARRA DE NAVEGACIÓN DE DIAPOSITIVAS */}
          <div
            className={`flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 p-4 rounded-3xl border transition-all ${cardBg}`}
          >
            <div className="flex items-center gap-2">
              <span className="text-xs font-black uppercase tracking-wider opacity-80">
                Diapositiva {currentSlide + 1} de {slides.length}:
              </span>
              <span className="text-xs font-black px-3.5 py-1 rounded-xl bg-purple-600 text-white">
                {slides[currentSlide].badge}
              </span>
            </div>

            <div className="flex items-center gap-3 w-full sm:w-auto justify-between sm:justify-end">
              <button
                onClick={() => {
                  const prev = Math.max(0, currentSlide - 1);
                  setCurrentSlide(prev);
                  broadcastSync({ type: "SET_SLIDE", slideIndex: prev });
                }}
                disabled={currentSlide === 0}
                className={`px-5 py-2.5 rounded-2xl border text-xs font-black uppercase tracking-wider flex items-center gap-1.5 transition-all disabled:opacity-30 disabled:cursor-not-allowed ${
                  isDark ? "border-slate-700 bg-slate-800 text-white hover:bg-slate-700" : "border-slate-300 bg-white text-slate-900 hover:bg-slate-100"
                }`}
              >
                <ChevronLeft size={18} /> Anterior
              </button>

              <div className="flex gap-2">
                {slides.map((s, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setCurrentSlide(idx);
                      broadcastSync({ type: "SET_SLIDE", slideIndex: idx });
                    }}
                    title={s.title}
                    className={`h-3 rounded-full transition-all ${
                      currentSlide === idx ? "w-12 bg-purple-500 shadow-md" : "w-3 bg-slate-700 hover:bg-purple-400"
                    }`}
                  />
                ))}
              </div>

              <button
                onClick={() => {
                  const next = Math.min(slides.length - 1, currentSlide + 1);
                  setCurrentSlide(next);
                  broadcastSync({ type: "SET_SLIDE", slideIndex: next });
                }}
                disabled={currentSlide === slides.length - 1}
                className="px-6 py-2.5 rounded-2xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-black uppercase tracking-wider flex items-center gap-1.5 shadow-lg disabled:opacity-30 disabled:cursor-not-allowed transition-all"
              >
                Siguiente <ChevronRight size={18} />
              </button>
            </div>
          </div>

          {/* LIENZO DE DIAPOSITIVA MAXIMIZADA */}
          <AnimatePresence mode="wait">
            <motion.div
              key={currentSlide}
              initial={{ opacity: 0, scale: 0.99, y: 12 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.99, y: -12 }}
              transition={{ duration: 0.2 }}
              className={`rounded-3xl p-6 md:p-12 border shadow-2xl flex flex-col justify-between min-h-[560px] ${cardBg}`}
            >
              <div className="space-y-8">
                {/* TÍTULO Y SUBTÍTULO */}
                <div className="space-y-2.5 border-b pb-5 border-slate-800">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-black uppercase tracking-widest px-3 py-1 rounded-full bg-purple-600 text-white">
                      {slides[currentSlide].badge}
                    </span>
                    <span className="text-xs font-bold opacity-60">
                      • Diálogo Médico en Box
                    </span>
                  </div>

                  <h2 className="text-2xl md:text-4xl font-black tracking-tight leading-tight">
                    {slides[currentSlide].title}
                  </h2>

                  <p className="text-base md:text-xl font-semibold opacity-80">
                    {slides[currentSlide].subtitle}
                  </p>
                </div>

                {/* MENSAJE PRINCIPAL EN ALTO CONTRASTE */}
                <div
                  className={`p-6 md:p-10 rounded-3xl border shadow-md space-y-4 ${
                    isDark
                      ? "bg-purple-950/40 border-purple-700/80 text-purple-100"
                      : "bg-purple-50 border-purple-300 text-purple-950"
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className="w-3.5 h-3.5 rounded-full bg-purple-400 animate-ping"></span>
                    <span className="text-xs font-black uppercase tracking-widest text-purple-300">
                      Conclusión Médica Fundamental
                    </span>
                  </div>
                  <h3 className={`font-black ${getFontSizeClasses()}`}>
                    {slides[currentSlide].leadText}
                  </h3>
                  <p className="text-base md:text-lg font-medium opacity-90 leading-relaxed">
                    {slides[currentSlide].takeaway}
                  </p>
                </div>

                {/* PUNTOS CLAVE Y COMPARATIVAS */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5 pt-2">
                  {slides[currentSlide].simplifiedPoints.map((pt, pIdx) => (
                    <div
                      key={pIdx}
                      className={`p-6 rounded-2xl border space-y-3 shadow-md ${innerCardBg}`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs font-black uppercase tracking-wider text-purple-300">
                          {pt.label}
                        </span>
                        <span
                          className={`text-[11px] font-black uppercase px-3 py-1 rounded-lg ${
                            pt.color === "emerald"
                              ? "bg-emerald-600 text-white"
                              : pt.color === "rose"
                              ? "bg-rose-600 text-white"
                              : pt.color === "amber"
                              ? "bg-amber-600 text-white"
                              : "bg-indigo-600 text-white"
                          }`}
                        >
                          {pt.status}
                        </span>
                      </div>
                      <p className={`font-bold ${getFontSizeClasses()}`}>
                        {pt.text}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              {/* PIE DE DIAPOSITIVA */}
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 pt-6 mt-8 border-t border-slate-800 text-xs font-bold opacity-70">
                <span>Dr. Andrés Felipe Ruiz Miranda • COSAM Rinconada de San Ramón</span>
                <span className="hidden sm:inline">Usa las flechas [←] [→] del teclado para avanzar o retroceder</span>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
      )}

      {/* =========================================================================
          CONTENIDO 2: TEMPORIZADOR INTERACTIVO "SURFEAR LA OLA"
         ========================================================================= */}
      {activeTab === "surf_timer" && (
        <div className={`rounded-3xl p-6 md:p-12 border shadow-2xl space-y-8 ${cardBg}`}>
          <div className="text-center max-w-3xl mx-auto space-y-3">
            <span className="text-xs font-black uppercase tracking-widest bg-teal-600 text-white px-4 py-1.5 rounded-full shadow-md">
              Herramienta Terapéutica en Vivo
            </span>
            <h2 className="text-3xl md:text-5xl font-black">
              Temporizador: Surfear la Ola (Urge Surfing)
            </h2>
            <p className="text-base md:text-lg font-medium opacity-80">
              Acompaña al paciente en box durante una crisis de craving. El pico fisiológico declina espontáneamente en 15 a 20 minutos.
            </p>
          </div>

          <div
            className={`flex flex-col items-center justify-center p-8 md:p-16 rounded-3xl border space-y-8 ${
              isDark ? "bg-slate-950 border-slate-800" : "bg-teal-50/70 border-teal-200"
            }`}
          >
            {/* CÍRCULO CRONÓMETRO GIGANTE */}
            <div
              className={`relative w-72 h-72 md:w-96 md:h-96 rounded-full flex flex-col items-center justify-center space-y-3 shadow-2xl border-8 ${
                timerPhase === "pico"
                  ? "border-rose-500 animate-pulse bg-rose-950/20"
                  : timerPhase === "descenso"
                  ? "border-teal-400 bg-teal-950/20"
                  : timerPhase === "calma"
                  ? "border-emerald-500 bg-emerald-950/20"
                  : "border-purple-500 bg-purple-950/20"
              } ${isDark ? "bg-black" : "bg-white"}`}
            >
              <span className="text-6xl md:text-8xl font-black font-mono tracking-tight text-white">
                {formatTimer(timerSeconds)}
              </span>

              <span
                className={`text-xs md:text-sm font-black uppercase tracking-widest px-5 py-1.5 rounded-full ${
                  timerPhase === "inicio"
                    ? "bg-amber-500 text-white"
                    : timerPhase === "pico"
                    ? "bg-rose-600 text-white animate-pulse"
                    : timerPhase === "descenso"
                    ? "bg-teal-600 text-white"
                    : "bg-emerald-600 text-white"
                }`}
              >
                Fase: {timerPhase}
              </span>
            </div>

            {/* MENSAJE GUÍA */}
            <div className="text-center max-w-2xl space-y-3">
              <h3 className="text-xl md:text-3xl font-black">
                {timerPhase === "inicio" && "Inhalando y pausando: Observa la sensación en el cuerpo sin juzgarla ni pelear con ella."}
                {timerPhase === "pico" && "Estamos en el pico máximo de la ola. Respira lento. Esta angustia química va a ceder."}
                {timerPhase === "descenso" && "La ola ya comenzó a bajar. Toma un vaso de agua fría y siente tus pies en el suelo."}
                {timerPhase === "calma" && "¡Impulso superado con éxito! El cerebro demostró que puede frenar sin consumir."}
              </h3>
              <p className="text-sm md:text-base font-semibold opacity-75">
                Respiración diafragmática: Inhala por la nariz (4s) • Retén (2s) • Exhala lento por la boca (6s).
              </p>
            </div>

            {/* BOTONES DE CONTROL */}
            <div className="flex items-center gap-4">
              <button
                onClick={() => {
                  const nextRunning = !isTimerRunning;
                  setIsTimerRunning(nextRunning);
                  broadcastSync({ type: "TIMER_ACTION", action: nextRunning ? "start" : "pause" });
                }}
                className={`px-10 py-4 rounded-2xl text-sm font-black uppercase tracking-wider transition-all flex items-center gap-2.5 shadow-xl cursor-pointer ${
                  isTimerRunning ? "bg-amber-600 hover:bg-amber-700 text-white" : "bg-teal-600 hover:bg-teal-700 text-white"
                }`}
              >
                {isTimerRunning ? <Pause size={20} /> : <Play size={20} />}
                <span>{isTimerRunning ? "Pausar" : "Comenzar Surfeo (15 Min)"}</span>
              </button>

              <button
                onClick={() => {
                  resetTimer();
                  broadcastSync({ type: "TIMER_ACTION", action: "reset" });
                }}
                className="px-6 py-4 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white text-sm font-black uppercase tracking-wider transition-all flex items-center gap-2 cursor-pointer"
              >
                <RotateCcw size={18} />
                <span>Reiniciar</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          CONTENIDO 3: PREGUNTAS FRECUENTES DEL PACIENTE EN BOX
         ========================================================================= */}
      {activeTab === "faq_paciente" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-5 space-y-3">
            <span className="text-xs font-black uppercase tracking-wider block mb-2 opacity-80">
              Preguntas Habituales en la Consulta:
            </span>
            {faqs.map((f, idx) => (
              <button
                key={idx}
                onClick={() => setSelectedFaq(idx)}
                className={`w-full text-left p-5 rounded-2xl transition-all border text-sm font-bold flex items-start gap-3.5 shadow-md ${
                  selectedFaq === idx
                    ? "bg-indigo-600 text-white border-indigo-400 shadow-indigo-900/50"
                    : isDark
                    ? "bg-slate-900 text-slate-200 border-slate-800 hover:bg-slate-800"
                    : "bg-white text-slate-800 border-slate-200 hover:bg-slate-100"
                }`}
              >
                <span className="shrink-0 w-7 h-7 rounded-full bg-white/20 flex items-center justify-center text-xs font-black">
                  {idx + 1}
                </span>
                <span className="leading-snug">{f.q}</span>
              </button>
            ))}
          </div>

          <div className="lg:col-span-7">
            {selectedFaq !== null && (
              <motion.div
                key={selectedFaq}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`rounded-3xl p-8 md:p-12 border shadow-2xl space-y-8 h-full flex flex-col justify-between ${cardBg}`}
              >
                <div className="space-y-5">
                  <span className="text-xs font-black uppercase tracking-widest text-indigo-400 bg-indigo-950/60 border border-indigo-700 px-3.5 py-1.5 rounded-lg inline-block">
                    Respuesta Médica Empática para el Paciente
                  </span>
                  <h3 className="text-2xl md:text-3xl font-black leading-snug">
                    {faqs[selectedFaq].q}
                  </h3>
                  <p className={`font-medium opacity-90 ${getFontSizeClasses()}`}>
                    {faqs[selectedFaq].a}
                  </p>
                </div>

                <div
                  className={`p-5 rounded-2xl border flex items-center gap-3.5 text-xs md:text-sm font-bold ${
                    isDark ? "bg-slate-950 border-slate-800 text-indigo-300" : "bg-indigo-50 border-indigo-200 text-indigo-950"
                  }`}
                >
                  <ShieldCheck size={22} className="text-indigo-400 shrink-0" />
                  <span>Enfoque basado en el Modelo Transteórico de Cambio y Neurobiología COSAM Rinconada.</span>
                </div>
              </motion.div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
