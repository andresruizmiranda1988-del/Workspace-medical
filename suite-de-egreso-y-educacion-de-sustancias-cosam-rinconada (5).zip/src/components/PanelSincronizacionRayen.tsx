import { useState, useId, useEffect, useCallback } from "react";
import { Check, Copy, EyeOff, Eye, Keyboard, ShieldAlert } from "lucide-react";

interface PanelSincronizacionRayenProps {
  isAnonymizedGlobal?: boolean;
  onToggleAnonymized?: () => void;
}

export default function PanelSincronizacionRayen({
  isAnonymizedGlobal,
  onToggleAnonymized
}: PanelSincronizacionRayenProps) {
  const patientNameId = useId();
  const rutId = useId();
  const ageId = useId();
  const fucDateId = useId();
  const substanceId = useId();
  const disulfiramDoseId = useId();

  // Active view tab inside synchronization panel
  const [activeTab, setActiveTab] = useState<"atajos_rapidos" | "constructor_nota" | "guia_rayen">("atajos_rapidos");

  // Local anonymization state if not passed from parent
  const [localAnonymized, setLocalAnonymized] = useState<boolean>(false);
  const isAnonymized = isAnonymizedGlobal !== undefined ? isAnonymizedGlobal : localAnonymized;

  const toggleAnonymized = () => {
    if (onToggleAnonymized) {
      onToggleAnonymized();
    } else {
      setLocalAnonymized(prev => !prev);
    }
  };

  // Helper functions for anonymization (Ley de Derechos y Deberes del Paciente)
  const getDisplayPatientName = (name: string) => {
    if (!isAnonymized) return name;
    const parts = name.split(" ").filter(Boolean);
    if (parts.length === 0) return "Paciente Anonimizado";
    return parts.map(p => p[0].toUpperCase() + ".").join(" ") + " (Anonimizado)";
  };

  const getDisplayRut = (rutStr: string) => {
    if (!isAnonymized) return rutStr;
    const parts = rutStr.split("-");
    if (parts.length === 2) {
      const numPart = parts[0].replace(/\./g, "");
      const prefix = numPart.slice(0, 2);
      return `${prefix}.XXX.XXX-${parts[1]}`;
    }
    return "XX.XXX.XXX-X";
  };

  // Patient & Clinical Data
  const [patientName, setPatientName] = useState("Juan Carlos M. V.");
  const [rut, setRut] = useState("16.894.312-3");
  const [age, setAge] = useState("38");
  const [primarySubstance, setPrimarySubstance] = useState("Pasta Base de Cocaína (PBC)");
  const [secondarySubstance, setSecondarySubstance] = useState("Alcohol / Tabaco");
  const [fucDate, setFucDate] = useState(() => {
    // Default to 28 days ago for realistic clinical representation
    const d = new Date();
    d.setDate(d.getDate() - 28);
    return d.toISOString().split("T")[0];
  });
  const [consumptionPattern, setConsumptionPattern] = useState("Abstinente en programa ambulatorio");
  const [stageOfChange, setStageOfChange] = useState("Acción (Comprometido en tratamiento)");
  const [cravingLevel, setCravingLevel] = useState<number>(3);

  // Mental Exam & Biology
  const [mood, setMood] = useState("Eutímico con leve ansiedad anticipatoria");
  const [sleep, setSleep] = useState("Conservado (7-8 hrs continuas)");
  const [appetite, setAppetite] = useState("Normorexia");
  const [suicideRisk, setSuicideRisk] = useState("Descartado (Sin ideación suicida)");
  const [psychoticSymptoms, setPsychoticSymptoms] = useState("Negativo (Sin sensopercepciones anómalas)");

  // Disulfiram Monitoring
  const [takingDisulfiram, setTakingDisulfiram] = useState<boolean>(true);
  const [disulfiramDose, setDisulfiramDose] = useState("250 mg/día (1 comprimido v.o. matinal)");
  const [disulfiramSupervisor, setDisulfiramSupervisor] = useState("Supervisada por familiar responsable / red de apoyo");
  const [liverFunctionChecked, setLiverFunctionChecked] = useState<boolean>(true);
  const [disulfiramContraindications, setDisulfiramContraindications] = useState("Descartadas (Sin cardiopatía, hepatopatía severa ni embarazo)");
  const [disulfiramAdverseEffects, setDisulfiramAdverseEffects] = useState("Buena tolerancia clínica, sin RAMs");

  // Micronutrition & Pharmacotherapy
  const [nutritionalPlan, setNutritionalPlan] = useState("Tiamina 300 mg/d + Magnesio Bisglicinato 400 mg noche + Complejo B");
  const [psychopharmacology, setPsychopharmacology] = useState("Sertralina 50 mg/d + Quetiapina 25 mg noche (SOS insomnio)");
  const [nextAppointment, setNextAppointment] = useState("14 días (Control Médico + Taller Grupal COSAM)");

  // Feedback states for copy buttons
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const copyToClipboard = useCallback((text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => {
      setCopiedKey(null);
    }, 2500);
  }, []);

  // Calculate Days of Abstinence from FUC
  const calculateDaysAbstinence = () => {
    if (!fucDate) return null;
    const fuc = new Date(fucDate);
    const today = new Date();
    const diffTime = today.getTime() - fuc.getTime();
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    return diffDays >= 0 ? diffDays : 0;
  };

  const daysAbstinent = calculateDaysAbstinence();

  const getAbstinenceCategory = (days: number | null) => {
    if (days === null) return "Sin registro";
    if (days < 14) return "Desintoxicación Aguda (0-14 días)";
    if (days <= 90) return "Abstinencia Temprana (1-3 meses)";
    if (days <= 180) return "Consolidación (3-6 meses)";
    return "Mantenimiento Sostenido (>6 meses)";
  };

  // Preset quick templates
  const loadPresetPBC = () => {
    setPatientName("Juan Carlos M. V.");
    setRut("16.894.312-3");
    setAge("38");
    setPrimarySubstance("Pasta Base de Cocaína (PBC)");
    setSecondarySubstance("Alcohol / Tabaco");
    const d = new Date();
    d.setDate(d.getDate() - 28);
    setFucDate(d.toISOString().split("T")[0]);
    setConsumptionPattern("Abstinente en programa ambulatorio");
    setStageOfChange("Acción (Comprometido en tratamiento)");
    setCravingLevel(3);
    setMood("Eutímico con leve ansiedad anticipatoria");
    setTakingDisulfiram(false);
    setNutritionalPlan("Tiamina 300 mg/d + Magnesio 400 mg/d + N-Acetilcisteína (NAC) 1200 mg/d");
    setPsychopharmacology("Topiramato 50 mg c/12h + Quetiapina 50 mg noche");
    setNextAppointment("7 días (Control Médico Prioritario COSAM)");
  };

  const loadPresetAlcoholDisulfiram = () => {
    setPatientName("María Elena S. R.");
    setRut("14.205.811-9");
    setAge("45");
    setPrimarySubstance("Alcohol (Trastorno por dependencia F10.2)");
    setSecondarySubstance("Tabaco");
    const d = new Date();
    d.setDate(d.getDate() - 60);
    setFucDate(d.toISOString().split("T")[0]);
    setConsumptionPattern("Abstinencia completa sostenida");
    setStageOfChange("Mantenimiento (Sosteniendo logros)");
    setCravingLevel(1);
    setMood("Eutímica, orientada, tranquila");
    setTakingDisulfiram(true);
    setDisulfiramDose("250 mg/día (1 comprimido v.o. matinal en ayunas)");
    setDisulfiramSupervisor("Supervisada por cónyuge todas las mañanas");
    setLiverFunctionChecked(true);
    setDisulfiramAdverseEffects("Excelente tolerancia, sin sabor metálico ni prurito");
    setNutritionalPlan("Tiamina 300 mg/d + Complejo B + Magnesio Bisglicinato");
    setPsychopharmacology("Disulfiram 250 mg/d + Sertralina 50 mg/d");
    setNextAppointment("14 días (Control de Seguimiento)");
  };

  const loadPresetPoliconsumo = () => {
    setPatientName("Rodrigo A. T.");
    setRut("17.921.405-8");
    setAge("31");
    setPrimarySubstance("Policonsumo Complejo (Cannabis + Alcohol + PBC)");
    setSecondarySubstance("Benzodiacepinas no prescritas");
    const d = new Date();
    d.setDate(d.getDate() - 14);
    setFucDate(d.toISOString().split("T")[0]);
    setConsumptionPattern("Abstinente reciente en fase inicial");
    setStageOfChange("Contemplación / Preparación");
    setCravingLevel(5);
    setMood("Ansioso, insomnio de conciliación moderado");
    setTakingDisulfiram(false);
    setNutritionalPlan("Tiamina 300 mg/d + Complejo B + Ácido Fólico 5 mg/d + Omega 3");
    setPsychopharmacology("Trazodona 50 mg noche + Pregabalina 75 mg c/12h");
    setNextAppointment("7 días (Control Médico Estrecho)");
  };

  const loadPresetDesintoxicacion = () => {
    setPatientName("Carlos E. G.");
    setRut("15.109.843-2");
    setAge("42");
    setPrimarySubstance("Alcohol (Desintoxicación Aguda)");
    setSecondarySubstance("Tabaco 20 cig/día");
    const d = new Date();
    d.setDate(d.getDate() - 4);
    setFucDate(d.toISOString().split("T")[0]);
    setConsumptionPattern("Abstinencia en box médico (Día 4)");
    setStageOfChange("Acción (Inicio PAI)");
    setCravingLevel(7);
    setMood("Inquieto, temblor fino distal, sudoración leve");
    setTakingDisulfiram(false);
    setNutritionalPlan("Tiamina 300 mg/d i.m./v.o. + Complejo B + Hidratación oral guiada");
    setPsychopharmacology("Diazepam 10 mg c/8h decreciente (Pauta CIWA-Ar) + Tiamina 300 mg");
    setNextAppointment("48 horas (Evaluación de Retirada & Seguridad)");
  };

  // Structured Texts for 1-Click Copy
  const getFucStructuredText = useCallback(() => {
    const todayStr = new Date().toLocaleDateString("es-CL");
    const dispName = getDisplayPatientName(patientName);
    const dispRut = getDisplayRut(rut);
    return `[FUC & CONSUMO - COSAM RINCONADA SAN RAMÓN (NIVEL SECUNDARIO)]
- Paciente: ${dispName} | RUT: ${dispRut}
- Fecha Último Consumo (FUC): ${fucDate || "No registrada"}
- Días de Abstinencia Continua: ${daysAbstinent !== null ? `${daysAbstinent} días` : "En evaluación"} (${getAbstinenceCategory(daysAbstinent)})
- Sustancia Principal: ${primarySubstance}
- Sustancia Secundaria: ${secondarySubstance}
- Patrón Actual: ${consumptionPattern}
- Etapa de Cambio (Prochaska): ${stageOfChange}
- Termómetro de Craving: ${cravingLevel}/10 (${cravingLevel > 6 ? "Alto / Alerta reactivación" : cravingLevel > 3 ? "Moderado" : "Bajo / Controlado"})
- Registro realizado por Dr. Andrés Felipe Ruiz Miranda el ${todayStr}`;
  }, [patientName, rut, fucDate, daysAbstinent, primarySubstance, secondarySubstance, consumptionPattern, stageOfChange, cravingLevel, isAnonymized]);

  const getDisulfiramStructuredText = useCallback(() => {
    const todayStr = new Date().toLocaleDateString("es-CL");
    const dispName = getDisplayPatientName(patientName);
    const dispRut = getDisplayRut(rut);
    return `[PROTOCOLO TERAPIA AVERSIVA DISULFIRAM - COSAM RINCONADA]
- Paciente: ${dispName} | RUT: ${dispRut}
- Tratamiento Activo: SÍ (Disulfiram ${disulfiramDose})
- Modalidad de Administración: ${disulfiramSupervisor}
- Consentimiento Informado: Aceptado y firmado por paciente y red de apoyo familiar.
- Perfil Hepático Basal: ${liverFunctionChecked ? "Verificado dentro de límites de seguridad (GOT/GPT <3x LN)" : "Pendiente de control"}
- Descarte de Contraindicaciones: ${disulfiramContraindications}
- Tolerancia y RAMs: ${disulfiramAdverseEffects}
- Pauta de Seguridad Reforzada: Paciente y tutor educados en prohibición estricta de alcohol en bebidas, alimentos, vinagres, salsas, enjuagues bucales y lociones. Advertencia clara de reacción acetaldehídica grave.
- Indicación médica suscrita por Dr. Andrés Felipe Ruiz Miranda (${todayStr})`;
  }, [patientName, rut, disulfiramDose, disulfiramSupervisor, liverFunctionChecked, disulfiramContraindications, disulfiramAdverseEffects, isAnonymized]);

  const getMentalExamStructuredText = useCallback(() => {
    const dispName = getDisplayPatientName(patientName);
    return `[EXAMEN MENTAL Y RITMOS BIOLÓGICOS - COSAM RINCONADA]
- Paciente: ${dispName}
- Aspecto / Psicomotricidad: Adecuado aseo y aliño personal, normoquinético, colaborador en la entrevista.
- Conciencia y Orientación: Lúcido, orientado témporo-espacialmente.
- Afectividad: ${mood}.
- Pensamiento: Curso lineal y coherente, ideas centradas en recuperación y metas de sobriedad.
- Sensopercepción: ${psychoticSymptoms}.
- Riesgo Suicida / Vital: ${suicideRisk}.
- Ritmo Sueño-Vigilia: ${sleep}.
- Apetito y Estado Nutricional: ${appetite}.`;
  }, [patientName, mood, psychoticSymptoms, suicideRisk, sleep, appetite, isAnonymized]);

  const getNutritionalStructuredText = useCallback(() => {
    return `[MICRORREHABILITACIÓN Y NUTRICIÓN NEUROMETABÓLICA]
- Pauta Nutricional Indicada: ${nutritionalPlan}
- Fundamento: Reposición de cofactores para síntesis de dopamina/GABA, neutralización del daño oxidativo mitocondrial y reactivación de neurogénesis vía BDNF.
- Pauta Física: Ejercicio aeróbico moderado 150 min/semana.`;
  }, [nutritionalPlan]);

  const getFullEvolutionNote = useCallback(() => {
    const todayStr = new Date().toLocaleDateString("es-CL");
    const dispName = getDisplayPatientName(patientName);
    const dispRut = getDisplayRut(rut);
    return `=== EVOLUCIÓN CLÍNICA MÉDICA - COSAM RINCONADA DE SAN RAMÓN ===
NIVEL DE ATENCIÓN: Especialidad Secundaria en Salud Mental & Adicciones (SSM Sur Oriente)
FECHA: ${todayStr} | BOX MÉDICO SALUD MENTAL / PAI
MÉDICO: Dr. Andrés Felipe Ruiz Miranda (Médico Cirujano • Reg. SIS N° 492014)

1. IDENTIFICACIÓN & PATRÓN DE CONSUMO:
- Paciente: ${dispName} | RUT: ${dispRut} | Edad: ${age} años.
- Sustancia(s): ${primarySubstance} / ${secondarySubstance}.
- FUC: ${fucDate} (${daysAbstinent !== null ? `${daysAbstinent} días de abstinencia` : "No registrada"} - ${getAbstinenceCategory(daysAbstinent)}).
- Patrón: ${consumptionPattern} | Etapa: ${stageOfChange}.
- Craving: ${cravingLevel}/10.

2. EXAMEN MENTAL & BIOLOGÍA:
- Estado Afectivo: ${mood}.
- Ritmo Circadiano (Sueño): ${sleep}.
- Apetito / Alimentación: ${appetite}.
- Riesgo Suicida: ${suicideRisk}.
- Sensopercepción: ${psychoticSymptoms}.

3. MONITOREO DISULFIRAM (TERAPIA AVERSIVA):
${
  takingDisulfiram
    ? `- Tratamiento activo: ${disulfiramDose}.
- Supervisión: ${disulfiramSupervisor}.
- Perfil Hepático: ${liverFunctionChecked ? "Verificado normal" : "Pendiente"}.
- Tolerancia / RAMs: ${disulfiramAdverseEffects}.
- Educación en seguridad y reacción antabús entregada a paciente y red.`
    : `- Disulfiram no indicado en esta sesión.`
}

4. MICRORREHABILITACIÓN & FARMACOTERAPIA:
- Nutrición: ${nutritionalPlan}.
- Esquema Farmacológico: ${psychopharmacology}.

5. INDICACIONES Y PRÓXIMO CONTROL:
- Mantener abstinencia completa y asistencia a psicoterapia y grupo COSAM.
- Próximo Control: ${nextAppointment}.

Dr. Andrés Felipe Ruiz Miranda | COSAM Rinconada de San Ramón`;
  }, [patientName, rut, age, primarySubstance, secondarySubstance, fucDate, daysAbstinent, consumptionPattern, stageOfChange, cravingLevel, mood, sleep, appetite, suicideRisk, psychoticSymptoms, takingDisulfiram, disulfiramDose, disulfiramSupervisor, liverFunctionChecked, disulfiramAdverseEffects, nutritionalPlan, psychopharmacology, nextAppointment, isAnonymized]);

  // Global Keyboard hotkeys listener for 1-Click copies inside this component
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.altKey) {
        if (e.key === "1") {
          e.preventDefault();
          copyToClipboard(getFucStructuredText(), "fuc");
        } else if (e.key === "2") {
          e.preventDefault();
          copyToClipboard(getDisulfiramStructuredText(), "disulfiram");
        } else if (e.key === "3") {
          e.preventDefault();
          copyToClipboard(getMentalExamStructuredText(), "examen_mental");
        } else if (e.key === "4") {
          e.preventDefault();
          copyToClipboard(getNutritionalStructuredText(), "nutricion");
        } else if (e.key === "5") {
          e.preventDefault();
          copyToClipboard(getFullEvolutionNote(), "completa");
        } else if (e.key === "a" || e.key === "A") {
          e.preventDefault();
          toggleAnonymized();
        }
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [getFucStructuredText, getDisulfiramStructuredText, getMentalExamStructuredText, getNutritionalStructuredText, getFullEvolutionNote, copyToClipboard]);

  return (
    <div className="space-y-6 animate-fadeIn pb-12 max-w-7xl mx-auto">
      {/* HEADER LIMPIO & CONTEXTO CLÍNICO */}
      <section className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-xs">
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
          <div className="space-y-1.5 max-w-3xl">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-purple-700 dark:text-purple-300 bg-purple-50 dark:bg-purple-950/80 border border-purple-200 dark:border-purple-800 px-2 py-0.5 rounded text-[11px] font-bold uppercase tracking-wider">
                COSAM Rinconada — San Ramón
              </span>
              <span className="text-slate-400 dark:text-slate-600">•</span>
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                Atención Secundaria de Especialidad en Salud Mental &amp; Adicciones (SSM Sur Oriente)
              </span>
            </div>

            <h2 className="text-2xl font-bold text-slate-900 dark:text-white tracking-tight">
              Sincronización Rayen APS
            </h2>

            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              Atajos estructurados de 1-clic para transferir FUC, Protocolo Disulfiram, Examen Mental y Microrrehabilitación directamente a la ficha Rayen APS sin fricción.
            </p>
          </div>

          {/* SELECTOR DE MODO / VISTA & BOTÓN DE ANONIMIZACIÓN */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={toggleAnonymized}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all border shadow-xs cursor-pointer ${
                isAnonymized
                  ? "bg-amber-500 text-slate-950 border-amber-400 hover:bg-amber-400"
                  : "bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-300 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-750"
              }`}
              title={isAnonymized ? "Modo Docencia Activo (RUT y Nombre anonimizados con Alt+A)" : "Activar Modo Docencia / Anonimización (Alt+A)"}
            >
              {isAnonymized ? <EyeOff size={14} className="shrink-0" /> : <Eye size={14} className="shrink-0" />}
              <span>{isAnonymized ? "Docencia: Anonimizado" : "Anonimizar Datos"}</span>
            </button>

            <div className="flex bg-slate-100 dark:bg-slate-800/80 p-1 rounded-xl border border-slate-200 dark:border-slate-700 shrink-0 w-full sm:w-auto">
              <button
                onClick={() => setActiveTab("atajos_rapidos")}
                className={`flex-1 sm:flex-initial px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                  activeTab === "atajos_rapidos"
                    ? "bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs"
                    : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
                }`}
              >
                Atajos 1-Clic
              </button>

              <button
                onClick={() => setActiveTab("constructor_nota")}
                className={`flex-1 sm:flex-initial px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                  activeTab === "constructor_nota"
                    ? "bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs"
                    : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
                }`}
              >
                Constructor de Ficha
              </button>

              <button
                onClick={() => setActiveTab("guia_rayen")}
                className={`flex-1 sm:flex-initial px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                  activeTab === "guia_rayen"
                    ? "bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs"
                    : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
                }`}
              >
                Guía Box
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* BARRA STICKY / PINNED DE CASOS FRECUENTES */}
      <section className="sticky top-2 z-20 bg-slate-900 text-slate-100 p-3 rounded-xl border border-slate-800 shadow-md flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-xs font-semibold text-slate-300">
          <span>Plantillas Rápidas:</span>
          {isAnonymized && (
            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
              Modo Docencia Activo
            </span>
          )}
        </div>
        <div className="flex flex-wrap gap-2 w-full sm:w-auto">
          <button
            onClick={loadPresetPBC}
            className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-medium transition-colors cursor-pointer"
          >
            Caso PBC (FUC 28d)
          </button>
          <button
            onClick={loadPresetAlcoholDisulfiram}
            className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-medium transition-colors cursor-pointer"
          >
            Caso Alcohol + Disulfiram
          </button>
          <button
            onClick={loadPresetPoliconsumo}
            className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-medium transition-colors cursor-pointer"
          >
            Caso Policonsumo
          </button>
          <button
            onClick={loadPresetDesintoxicacion}
            className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-medium transition-colors cursor-pointer"
          >
            Desintoxicación Aguda
          </button>
        </div>
      </section>

      {/* =========================================================================
          TAB 1: ATAJOS RÁPIDOS DE 1-CLIC (FUC, DISULFIRAM, EXAMEN MENTAL, NUTRICIÓN)
         ========================================================================= */}
      {activeTab === "atajos_rapidos" && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* CARD 1: ATAJO FUC (FECHA ÚLTIMO CONSUMO) */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4 flex flex-col justify-between">
              <div className="space-y-3">
                <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                        Atajo 1: Registro FUC &amp; Abstinencia
                      </h3>
                      <kbd className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-300 dark:border-slate-700">
                        Alt + 1
                      </kbd>
                    </div>
                    <span className="text-xs text-slate-500 dark:text-slate-400">
                      Cálculo de días continuos y estadio de cambio
                    </span>
                  </div>
                  <span className="text-xs font-semibold px-2.5 py-1 rounded-md border border-emerald-300 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/40">
                    {daysAbstinent !== null ? `${daysAbstinent} Días` : "0 Días"}
                  </span>
                </div>

                <div className="bg-slate-50 dark:bg-slate-800/60 p-3 rounded-xl border border-slate-200 dark:border-slate-700/60 space-y-1.5 text-xs text-slate-700 dark:text-slate-300">
                  <div className="flex justify-between">
                    <span className="text-slate-500 dark:text-slate-400">Paciente:</span>
                    <strong className="text-slate-900 dark:text-slate-100">{getDisplayPatientName(patientName)}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500 dark:text-slate-400">Fecha FUC:</span>
                    <strong className="text-slate-900 dark:text-slate-100">{fucDate || "No registrada"}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500 dark:text-slate-400">Fase Biológica:</span>
                    <strong className="text-slate-900 dark:text-slate-100">{getAbstinenceCategory(daysAbstinent)}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500 dark:text-slate-400">Craving:</span>
                    <strong className="text-slate-900 dark:text-slate-100">{cravingLevel}/10 ({cravingLevel > 6 ? "Alto" : cravingLevel > 3 ? "Moderado" : "Bajo"})</strong>
                  </div>
                </div>

                <pre className="bg-slate-950 text-slate-200 p-3 rounded-xl font-mono text-[11px] leading-relaxed overflow-x-auto max-h-36 whitespace-pre-wrap select-all border border-slate-800">
                  {getFucStructuredText()}
                </pre>
              </div>

              <button
                onClick={() => copyToClipboard(getFucStructuredText(), "fuc")}
                className={`w-full py-2.5 px-4 rounded-xl text-xs font-semibold transition-colors flex items-center justify-between min-h-[42px] cursor-pointer ${
                  copiedKey === "fuc"
                    ? "bg-emerald-600 text-white"
                    : "bg-indigo-600 hover:bg-indigo-500 text-white shadow-xs"
                }`}
              >
                <span>{copiedKey === "fuc" ? "✓ Copiado al portapapeles de Rayen" : "Copiar Atajo FUC"}</span>
                <kbd className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-white/20 text-white">Alt + 1</kbd>
              </button>
            </div>

            {/* CARD 2: ATAJO DISULFIRAM (PROTOCOLO & SEGURIDAD) */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4 flex flex-col justify-between">
              <div className="space-y-3">
                <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                        Atajo 2: Protocolo de Disulfiram
                      </h3>
                      <kbd className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-300 dark:border-slate-700">
                        Alt + 2
                      </kbd>
                    </div>
                    <span className="text-xs text-slate-500 dark:text-slate-400">
                      Consentimiento, supervisión y control hepático
                    </span>
                  </div>
                  <span className={`text-xs font-semibold px-2.5 py-1 rounded-md border ${
                    takingDisulfiram
                      ? "border-emerald-300 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/40"
                      : "border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 bg-slate-100 dark:bg-slate-800"
                  }`}>
                    {takingDisulfiram ? "Activo" : "Inactivo"}
                  </span>
                </div>

                <div className="bg-slate-50 dark:bg-slate-800/60 p-3 rounded-xl border border-slate-200 dark:border-slate-700/60 space-y-1.5 text-xs text-slate-700 dark:text-slate-300">
                  <div className="flex justify-between">
                    <span className="text-slate-500 dark:text-slate-400">Dosis Prescrita:</span>
                    <strong className="text-slate-900 dark:text-slate-100">{disulfiramDose}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500 dark:text-slate-400">Perfil Hepático:</span>
                    <strong className="text-slate-900 dark:text-slate-100">{liverFunctionChecked ? "Verificado Normal" : "Pendiente"}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500 dark:text-slate-400">Supervisión:</span>
                    <span className="text-slate-900 dark:text-slate-100 truncate max-w-[200px]">{disulfiramSupervisor}</span>
                  </div>
                </div>

                <pre className="bg-slate-950 text-slate-200 p-3 rounded-xl font-mono text-[11px] leading-relaxed overflow-x-auto max-h-36 whitespace-pre-wrap select-all border border-slate-800">
                  {getDisulfiramStructuredText()}
                </pre>
              </div>

              <button
                onClick={() => copyToClipboard(getDisulfiramStructuredText(), "disulfiram")}
                className={`w-full py-2.5 px-4 rounded-xl text-xs font-semibold transition-colors flex items-center justify-between min-h-[42px] cursor-pointer ${
                  copiedKey === "disulfiram"
                    ? "bg-emerald-600 text-white"
                    : "bg-indigo-600 hover:bg-indigo-500 text-white shadow-xs"
                }`}
              >
                <span>{copiedKey === "disulfiram" ? "✓ Copiado al portapapeles de Rayen" : "Copiar Atajo Disulfiram"}</span>
                <kbd className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-white/20 text-white">Alt + 2</kbd>
              </button>
            </div>

            {/* CARD 3: ATAJO EXAMEN MENTAL */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4 flex flex-col justify-between">
              <div className="space-y-3">
                <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                        Atajo 3: Examen Mental &amp; Ritmos
                      </h3>
                      <kbd className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-300 dark:border-slate-700">
                        Alt + 3
                      </kbd>
                    </div>
                    <span className="text-xs text-slate-500 dark:text-slate-400">
                      Psicopatología, sueño, afecto y descarte suicida
                    </span>
                  </div>
                  <span className="text-xs font-semibold text-slate-600 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 px-2.5 py-1 rounded-md border border-slate-200 dark:border-slate-700">
                    Box Psiquiatría
                  </span>
                </div>

                <div className="bg-slate-50 dark:bg-slate-800/60 p-3 rounded-xl border border-slate-200 dark:border-slate-700/60 space-y-1.5 text-xs text-slate-700 dark:text-slate-300">
                  <div className="flex justify-between">
                    <span className="text-slate-500 dark:text-slate-400">Ánimo / Afecto:</span>
                    <strong className="text-slate-900 dark:text-slate-100">{mood}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500 dark:text-slate-400">Sueño Circadiano:</span>
                    <strong className="text-slate-900 dark:text-slate-100">{sleep}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500 dark:text-slate-400">Riesgo Suicida:</span>
                    <strong className="text-emerald-600 dark:text-emerald-400 font-semibold">{suicideRisk}</strong>
                  </div>
                </div>

                <pre className="bg-slate-950 text-slate-200 p-3 rounded-xl font-mono text-[11px] leading-relaxed overflow-x-auto max-h-36 whitespace-pre-wrap select-all border border-slate-800">
                  {getMentalExamStructuredText()}
                </pre>
              </div>

              <button
                onClick={() => copyToClipboard(getMentalExamStructuredText(), "examen_mental")}
                className={`w-full py-2.5 px-4 rounded-xl text-xs font-semibold transition-colors flex items-center justify-between min-h-[42px] cursor-pointer ${
                  copiedKey === "examen_mental"
                    ? "bg-emerald-600 text-white"
                    : "bg-indigo-600 hover:bg-indigo-500 text-white shadow-xs"
                }`}
              >
                <span>{copiedKey === "examen_mental" ? "✓ Copiado al portapapeles de Rayen" : "Copiar Atajo Examen Mental"}</span>
                <kbd className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-white/20 text-white">Alt + 3</kbd>
              </button>
            </div>

            {/* CARD 4: ATAJO MICRORREHABILITACIÓN & NUTRICIÓN */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4 flex flex-col justify-between">
              <div className="space-y-3">
                <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                        Atajo 4: Pauta Microrrehabilitación
                      </h3>
                      <kbd className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-300 dark:border-slate-700">
                        Alt + 4
                      </kbd>
                    </div>
                    <span className="text-xs text-slate-500 dark:text-slate-400">
                      Tiamina B1, Magnesio, Antioxidantes &amp; BDNF
                    </span>
                  </div>
                  <span className="text-xs font-semibold text-slate-600 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 px-2.5 py-1 rounded-md border border-slate-200 dark:border-slate-700">
                    Metabólico
                  </span>
                </div>

                <div className="bg-slate-50 dark:bg-slate-800/60 p-3 rounded-xl border border-slate-200 dark:border-slate-700/60 space-y-1.5 text-xs text-slate-700 dark:text-slate-300">
                  <div className="flex justify-between">
                    <span className="text-slate-500 dark:text-slate-400">Esquema B1 / Mg:</span>
                    <strong className="text-slate-900 dark:text-slate-100 truncate max-w-[200px]">{nutritionalPlan}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500 dark:text-slate-400">Actividad Física:</span>
                    <strong className="text-slate-900 dark:text-slate-100">150 min/semana (BDNF)</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500 dark:text-slate-400">Próximo Control:</span>
                    <strong className="text-slate-900 dark:text-slate-100 font-semibold">{nextAppointment}</strong>
                  </div>
                </div>

                <pre className="bg-slate-950 text-slate-200 p-3 rounded-xl font-mono text-[11px] leading-relaxed overflow-x-auto max-h-36 whitespace-pre-wrap select-all border border-slate-800">
                  {getNutritionalStructuredText()}
                </pre>
              </div>

              <button
                onClick={() => copyToClipboard(getNutritionalStructuredText(), "nutricion")}
                className={`w-full py-2.5 px-4 rounded-xl text-xs font-semibold transition-colors flex items-center justify-between min-h-[42px] cursor-pointer ${
                  copiedKey === "nutricion"
                    ? "bg-emerald-600 text-white"
                    : "bg-indigo-600 hover:bg-indigo-500 text-white shadow-xs"
                }`}
              >
                <span>{copiedKey === "nutricion" ? "✓ Copiado al portapapeles de Rayen" : "Copiar Atajo Nutrición"}</span>
                <kbd className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-white/20 text-white">Alt + 4</kbd>
              </button>
            </div>
          </div>

          {/* BANNER NOTA COMPLETA INTEGRAL DE EVOLUCIÓN */}
          <div className="bg-slate-900 text-slate-100 p-6 rounded-2xl border border-slate-800 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <h4 className="text-sm font-bold text-white">
                  Evolución Médica Completa para Rayen APS
                </h4>
                <kbd className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-slate-800 text-purple-300 border border-slate-700">
                  Alt + 5
                </kbd>
              </div>
              <p className="text-xs text-slate-400">
                Compila todos los bloques clínicos en una sola nota formal estructurada lista para pegar.
              </p>
            </div>

            <button
              onClick={() => copyToClipboard(getFullEvolutionNote(), "completa")}
              className={`py-2.5 px-5 rounded-xl text-xs font-semibold transition-colors flex items-center justify-between gap-3 shrink-0 w-full md:w-auto min-h-[42px] cursor-pointer ${
                copiedKey === "completa"
                  ? "bg-emerald-600 text-white"
                  : "bg-indigo-600 hover:bg-indigo-500 text-white shadow-xs"
              }`}
            >
              <span>{copiedKey === "completa" ? "✓ Evolución Completa Copiada" : "Copiar Evolución Completa Rayen"}</span>
              <kbd className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-white/20 text-white">Alt + 5</kbd>
            </button>
          </div>
        </div>
      )}

      {/* =========================================================================
          TAB 2: CONSTRUCTOR Y EDITOR DE NOTA DE EVOLUCIÓN
         ========================================================================= */}
      {activeTab === "constructor_nota" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* COLUMNA IZQUIERDA: FORMULARIO DINÁMICO */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* 1. Identificación y FUC */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
              <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider border-b border-slate-100 dark:border-slate-800 pb-3">
                1. Datos del Paciente &amp; FUC
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                <div>
                  <label htmlFor={patientNameId} className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">Nombre Paciente</label>
                  <input
                    id={patientNameId}
                    type="text"
                    value={patientName}
                    onChange={(e) => setPatientName(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-medium"
                  />
                </div>

                <div>
                  <label htmlFor={rutId} className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">RUT</label>
                  <input
                    id={rutId}
                    type="text"
                    value={rut}
                    onChange={(e) => setRut(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-medium"
                  />
                </div>

                <div>
                  <label htmlFor={ageId} className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">Edad</label>
                  <input
                    id={ageId}
                    type="text"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-medium"
                  />
                </div>

                <div>
                  <label htmlFor={substanceId} className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">Sustancia Principal</label>
                  <select
                    id={substanceId}
                    value={primarySubstance}
                    onChange={(e) => setPrimarySubstance(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-medium"
                  >
                    <option value="Pasta Base de Cocaína (PBC)">Pasta Base de Cocaína (PBC)</option>
                    <option value="Alcohol (Dependencia F10.2)">Alcohol (Dependencia F10.2)</option>
                    <option value="Clorhidrato de Cocaína">Clorhidrato de Cocaína</option>
                    <option value="Cannabis">Cannabis</option>
                    <option value="Benzodiacepinas">Benzodiacepinas</option>
                    <option value="Policonsumo Complejo">Policonsumo Complejo</option>
                  </select>
                </div>

                <div>
                  <label htmlFor={fucDateId} className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">FUC (Fecha Último Consumo)</label>
                  <input
                    id={fucDateId}
                    type="date"
                    value={fucDate}
                    onChange={(e) => setFucDate(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-medium"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">Patrón de Consumo</label>
                  <select
                    value={consumptionPattern}
                    onChange={(e) => setConsumptionPattern(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-medium"
                  >
                    <option value="Abstinente en programa">Abstinente en programa</option>
                    <option value="Consumo episódico (Lapse)">Consumo episódico / Lapse</option>
                    <option value="Recaída activa (Relapse)">Recaída activa (Relapse)</option>
                    <option value="Reducción de daños">Reducción de daños</option>
                  </select>
                </div>
              </div>

              {/* Termómetro de Craving */}
              <div className="pt-2 bg-slate-50 dark:bg-slate-800/60 p-3 rounded-xl border border-slate-200 dark:border-slate-700/60">
                <div className="flex justify-between items-center mb-1 text-xs">
                  <span className="font-semibold text-slate-700 dark:text-slate-300">Intensidad del Craving Actual:</span>
                  <span className="font-bold text-slate-900 dark:text-slate-100 bg-slate-200 dark:bg-slate-700 px-2 py-0.5 rounded text-[11px]">
                    {cravingLevel} / 10
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="10"
                  value={cravingLevel}
                  onChange={(e) => setCravingLevel(Number(e.target.value))}
                  className="w-full h-2 bg-slate-200 dark:bg-slate-700 rounded-lg accent-indigo-600 cursor-pointer"
                />
              </div>
            </div>

            {/* 2. Disulfiram Protocol Settings */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                  2. Parámetros de Disulfiram (Terapia Aversiva)
                </h3>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={takingDisulfiram}
                    onChange={(e) => setTakingDisulfiram(e.target.checked)}
                    className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 accent-indigo-600 cursor-pointer"
                  />
                  <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">¿Prescribir / Monitorear Disulfiram?</span>
                </label>
              </div>

              {takingDisulfiram && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div>
                    <label htmlFor={disulfiramDoseId} className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">Dosis Prescrita</label>
                    <input
                      id={disulfiramDoseId}
                      type="text"
                      value={disulfiramDose}
                      onChange={(e) => setDisulfiramDose(e.target.value)}
                      className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-medium"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">Supervisión de Toma</label>
                    <input
                      type="text"
                      value={disulfiramSupervisor}
                      onChange={(e) => setDisulfiramSupervisor(e.target.value)}
                      className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-medium"
                    />
                  </div>

                  <div className="sm:col-span-2 flex items-center gap-2 bg-slate-50 dark:bg-slate-800/60 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700/60">
                    <input
                      type="checkbox"
                      id="chk-perfil-hepatico"
                      checked={liverFunctionChecked}
                      onChange={(e) => setLiverFunctionChecked(e.target.checked)}
                      className="w-4 h-4 rounded text-indigo-600 accent-indigo-600 cursor-pointer"
                    />
                    <label htmlFor="chk-perfil-hepatico" className="text-xs font-semibold text-slate-700 dark:text-slate-300 cursor-pointer">
                      Perfil Hepático Basal verificado (&lt;3x GOT/GPT normal)
                    </label>
                  </div>
                </div>
              )}
            </div>

            {/* 3. Indicaciones y Farmacoterapia */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
              <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider border-b border-slate-100 dark:border-slate-800 pb-3">
                3. Microrrehabilitación, Psicofármacos &amp; Control
              </h3>

              <div className="space-y-3 text-xs">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">Pauta de Microrrehabilitación</label>
                  <input
                    type="text"
                    value={nutritionalPlan}
                    onChange={(e) => setNutritionalPlan(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-medium"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">Esquema Psicofarmacológico</label>
                  <input
                    type="text"
                    value={psychopharmacology}
                    onChange={(e) => setPsychopharmacology(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-medium"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">Próximo Control en COSAM</label>
                  <input
                    type="text"
                    value={nextAppointment}
                    onChange={(e) => setNextAppointment(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-medium"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* COLUMNA DERECHA: VISTA PREVIA FORMATO RAYEN */}
          <div className="lg:col-span-5 space-y-4">
            <div className="bg-slate-900 text-slate-100 p-6 rounded-2xl shadow-sm border border-slate-800 flex flex-col justify-between h-full space-y-4">
              <div className="flex justify-between items-center border-b border-slate-800 pb-3">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                  Evolución Rayen Generada
                </span>
                <button
                  onClick={() => copyToClipboard(getFullEvolutionNote(), "completa_sidebar")}
                  className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold transition-colors shadow-xs"
                >
                  {copiedKey === "completa_sidebar" ? "¡Copiado!" : "Copiar"}
                </button>
              </div>

              <div className="flex-1 bg-slate-950 p-4 rounded-xl border border-slate-800 font-mono text-[11px] text-slate-300 overflow-y-auto max-h-[580px] leading-relaxed whitespace-pre-wrap select-all">
                {getFullEvolutionNote()}
              </div>

              <div className="text-[11px] text-slate-400 bg-slate-800/60 p-3 rounded-xl border border-slate-700/60">
                Haz clic en <strong>Copiar</strong> y pega con <strong>Ctrl + V</strong> en el campo de Evolución de Rayen APS.
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          TAB 3: GUÍA PASO A PASO PARA EL BOX EN RAYEN APS
         ========================================================================= */}
      {activeTab === "guia_rayen" && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
            <div className="w-8 h-8 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white flex items-center justify-center font-bold text-xs">
              1
            </div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Paso 1: Anamnesis &amp; FUC
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              Usa el atajo <strong>FUC</strong> para registrar la fecha del último consumo y los días de abstinencia calculados. Pégalo directamente en la anamnesis actual o motivo de consulta.
            </p>
          </div>

          <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
            <div className="w-8 h-8 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white flex items-center justify-center font-bold text-xs">
              2
            </div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Paso 2: Disulfiram &amp; Farmacoterapia
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              Copia el atajo de <strong>Disulfiram</strong> para documentar el consentimiento informado, la supervisión de la toma y la verificación del perfil hepático en el apartado de indicaciones.
            </p>
          </div>

          <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
            <div className="w-8 h-8 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white flex items-center justify-center font-bold text-xs">
              3
            </div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Paso 3: Plan Integral COSAM
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              Copia la pauta de <strong>Microrrehabilitación</strong> para que quede constancia del soporte metabólico con complejo B y citación a taller grupal del programa de adicciones.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
