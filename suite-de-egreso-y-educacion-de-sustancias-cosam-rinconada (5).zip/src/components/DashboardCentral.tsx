import { useState, useEffect, useMemo } from "react";
import {
  Brain,
  Stethoscope,
  Layers,
  Flame,
  AlertCircle,
  Apple,
  FileSpreadsheet,
  ShieldCheck,
  FileText,
  Tv2,
  TrendingUp,
  Printer,
  ChevronRight,
  Zap,
  Building2,
  SlidersHorizontal,
  CheckSquare,
  ListTodo,
  Plus,
  RefreshCw,
  CheckCircle2,
  Calendar,
  Trash2,
  FolderPlus,
  CloudUpload,
  UserCheck,
  Clock,
  ExternalLink,
  X,
  Edit3
} from "lucide-react";
import {
  GoogleTasksKeepService,
  GoogleTaskList,
  GoogleTaskItem,
  StagedClinicalTask
} from "../services/googleTasksKeepService";
import { GoogleDriveService } from "../services/googleDriveService";
import { getCurrentAuthUser, initAuth } from "../services/firebaseAuthService";
import { GoogleSignInButton } from "./clinical/GoogleSignInButton";
import { PRESET_PATIENTS, PatientProfile } from "./clinical/PatientSelectorBar";

interface DashboardCentralProps {
  onNavigate: (tabId: string) => void;
}

interface TaskConfirmModalState {
  title: string;
  description: string;
  details: string[];
  confirmLabel: string;
  variant: "primary" | "danger";
  onConfirm: () => Promise<void>;
}

const COSAM_PROTOCOL_TASK_PRESETS: {
  id: string;
  label: string;
  protocolTag: StagedClinicalTask["protocolTag"];
  priority: StagedClinicalTask["priority"];
  dueDaysOffset: number;
  title: string;
  notes: string;
}[] = [
  {
    id: "triaje_p1",
    label: "Triaje SIC Prioridad P1 (<72h)",
    protocolTag: "Triaje PAI SSMSO",
    priority: "P1 Urgente (<72h)",
    dueDaysOffset: 1,
    title: "Triaje SIC Prioridad P1 (<72h) — Validar Ley 21.331 y DSM-5",
    notes:
      "Protocolo PAI COSAM Rinconada (SSMSO): Revisar Solicitud de Interconsulta en SIDRA (gestante / orden judicial TTD / riesgo descompensación), certificar ≥6 criterios DSM-5 para PAI, consentimiento voluntario (Ley 21.331) y estabilidad médica basal."
  },
  {
    id: "bateria_ecg",
    label: "Batería Basal (<3m) + ECG",
    protocolTag: "Laboratorio & ECG",
    priority: "P1 Urgente (<72h)",
    dueDaysOffset: 2,
    title: "Verificar Batería Laboratorio (<3m) y ECG 12 derivaciones",
    notes:
      "Requisitos obligatorios Comité de Triaje COSAM: Hemograma completo, Perfil Bioquímico, Pruebas Hepáticas (GOT, GPT, GGT, Bilirrubina total/fraccionada), Orina completa y ECG basal (obligatorio en uso crónico de cocaína/pasta base o >45 años)."
  },
  {
    id: "top_sistrat",
    label: "Monitoreo TOP & SISTRAT",
    protocolTag: "TOP / SISTRAT",
    priority: "P2 Alta (<15d)",
    dueDaysOffset: 3,
    title: "Aplicar Instrumento TOP (30 días) y Registro Mensual SISTRAT",
    notes:
      "Convenio SENDA-MINSAL: Administrar cuestionario Treatment Outcome Profile (consumo últimos 30 días, riesgo biológico inyectable, funcionamiento psicosocial y salud global) en hito basal / 3m / 6m y digitalizar prestaciones en plataforma SISTRAT."
  },
  {
    id: "patologia_dual",
    label: "Conciliación Patología Dual",
    protocolTag: "Farmacovigilancia",
    priority: "P2 Alta (<15d)",
    dueDaysOffset: 2,
    title: "Conciliación Psicofarmacológica en Patología Dual (Grupos A/B/C)",
    notes:
      "Protocolo Patología Dual COSAM Rinconada: Evaluar riesgo autolítico, interacciones entre esquema psicofarmacológico (Litio/Valproico/Antipsicóticos/Anticraving) y consumo activo; coordinar enlace con UHCE Hospital Padre Hurtado si existe descompensación aguda."
  },
  {
    id: "taller_habituacion",
    label: "Taller Habituación & Deshabituación",
    protocolTag: "Taller Habituación",
    priority: "P3 Estándar",
    dueDaysOffset: 4,
    title: "Integrar a Taller 'Reconstruyendo el Camino: Hábito y Deshabituación'",
    notes:
      "Equipo COSAM (Dr. Andrés Ruiz / Tec. Rehab. Katherine Astudillo / T.O. Felipe Campos): Psicoeducación sobre automatización en Ganglios Basales, Ciclo del Hábito (Señal/Gatillo → Anhelo → Rutina → Recompensa), mapeo de gatillos (emocionales, sociales, ambientales) y neuroplasticidad."
  },
  {
    id: "contrarreferencia_aps",
    label: "Epicrisis Contrarreferencia APS (<5d)",
    protocolTag: "Contrarreferencia APS",
    priority: "P3 Estándar",
    dueDaysOffset: 5,
    title: "Emitir Epicrisis de Contrarreferencia en SIDRA hacia CESFAM (<5 días hábiles)",
    notes:
      "Criterios de Alta PAI (≥6 meses estabilidad clínica, esquema farmacológico simplificado en arsenal APS y restitución de red comunitaria): Consignar diagnóstico CIE-10/DSM-5, posología de mantención y señales de alerta de recaída para CESFAM Salvador Allende / La Bandera / Gabriela Mistral."
  }
];

export default function DashboardCentral({ onNavigate }: DashboardCentralProps) {
  const [activePanelFilter, setActivePanelFilter] = useState<
    "todos" | "operativo" | "tareas" | "medico" | "psicoeducacion"
  >("todos");

  // =========================================================================
  // ESTADO DE AUTENTICACIÓN Y SINCRONIZACIÓN CON GOOGLE TASKS API
  // =========================================================================
  const [isGoogleConnected, setIsGoogleConnected] = useState<boolean>(() =>
    GoogleDriveService.isConnected()
  );
  const [authUser, setAuthUser] = useState(() => getCurrentAuthUser());
  const [isConnectingGoogle, setIsConnectingGoogle] = useState(false);

  // Paciente activo para contextualizar las tareas clínicas desde el Dashboard
  const [selectedPatientId, setSelectedPatientId] = useState<string>(PRESET_PATIENTS[0].id);
  const selectedPatient: PatientProfile = useMemo(
    () => PRESET_PATIENTS.find((p) => p.id === selectedPatientId) || PRESET_PATIENTS[0],
    [selectedPatientId]
  );

  // Estado de Google Tasks API (Listas y Tareas en la nube)
  const [taskLists, setTaskLists] = useState<GoogleTaskList[]>([]);
  const [selectedListId, setSelectedListId] = useState<string>("@default");
  const [googleTasks, setGoogleTasks] = useState<GoogleTaskItem[]>([]);
  const [isLoadingGoogleTasks, setIsLoadingGoogleTasks] = useState(false);

  // Cola Clínica Local de Box (Staged Tasks sincronizables con 1 clic a Google Tasks)
  const [stagedTasks, setStagedTasks] = useState<StagedClinicalTask[]>(() =>
    GoogleTasksKeepService.getStagedClinicalTasks()
  );

  // Vista activa dentro del módulo de Tareas del Dashboard
  const [tasksViewMode, setTasksViewMode] = useState<"google_cloud" | "box_queue">(
    GoogleDriveService.isConnected() ? "google_cloud" : "box_queue"
  );
  const [statusFilter, setStatusFilter] = useState<"all" | "needsAction" | "completed">("needsAction");

  // Formulario de creación / edición rápida de tarea clínica
  const [editingGoogleTaskId, setEditingGoogleTaskId] = useState<string | null>(null);
  const [taskTitle, setTaskTitle] = useState("");
  const [taskNotes, setTaskNotes] = useState("");
  const [taskDueDate, setTaskDueDate] = useState(() => {
    const tomorrow = new Date(Date.now() + 86400000);
    return tomorrow.toISOString().split("T")[0];
  });
  const [taskPriority, setTaskPriority] = useState<StagedClinicalTask["priority"]>("P1 Urgente (<72h)");
  const [taskProtocolTag, setTaskProtocolTag] =
    useState<StagedClinicalTask["protocolTag"]>("Triaje PAI SSMSO");

  // Nueva lista de Google Tasks
  const [showNewListForm, setShowNewListForm] = useState(false);
  const [newListName, setNewListName] = useState("");

  // Modal de Confirmación Obligatoria (Seguridad Google Workspace API) y Feedback
  const [confirmModal, setConfirmModal] = useState<TaskConfirmModalState | null>(null);
  const [isExecutingAction, setIsExecutingAction] = useState(false);
  const [syncFeedback, setSyncFeedback] = useState<{
    type: "success" | "error" | "info";
    text: string;
  } | null>(null);

  useEffect(() => {
    const unsubscribe = initAuth(
      (user) => {
        setIsGoogleConnected(true);
        setAuthUser(user);
        setTasksViewMode("google_cloud");
      },
      () => {
        const connected = GoogleDriveService.isConnected();
        setIsGoogleConnected(connected);
        setAuthUser(getCurrentAuthUser());
      }
    );

    const handleAuthChange = () => {
      const connected = GoogleDriveService.isConnected();
      setIsGoogleConnected(connected);
      setAuthUser(getCurrentAuthUser());
      if (connected) {
        setTasksViewMode("google_cloud");
        fetchGoogleTasksData(selectedListId);
      }
    };

    window.addEventListener("cosam:gdrive-auth-changed", handleAuthChange);
    if (GoogleDriveService.isConnected()) {
      fetchGoogleTasksData("@default");
    }

    return () => {
      unsubscribe();
      window.removeEventListener("cosam:gdrive-auth-changed", handleAuthChange);
    };
  }, []);

  const fetchGoogleTasksData = async (listId = selectedListId) => {
    if (!GoogleDriveService.isConnected()) return;
    setIsLoadingGoogleTasks(true);
    try {
      const [lists, items] = await Promise.all([
        GoogleTasksKeepService.listTaskLists(),
        GoogleTasksKeepService.listTasks(listId, true)
      ]);
      setTaskLists(lists);
      setGoogleTasks(items);
      if (listId === "@default" && lists.length > 0) {
        setSelectedListId(lists[0].id);
      }
    } catch (err: any) {
      setSyncFeedback({
        type: "error",
        text: err.message || "Error al sincronizar listas desde Google Tasks API."
      });
    } finally {
      setIsLoadingGoogleTasks(false);
    }
  };

  const handleConnectGoogleTasks = async () => {
    setIsConnectingGoogle(true);
    setSyncFeedback(null);
    try {
      await GoogleDriveService.requestAuth();
      setIsGoogleConnected(true);
      setAuthUser(getCurrentAuthUser());
      setTasksViewMode("google_cloud");
      await fetchGoogleTasksData("@default");
      setSyncFeedback({
        type: "success",
        text: "Conectado a Google Tasks API mediante Firebase Auth. Listas clínicas sincronizadas."
      });
    } catch (err: any) {
      setSyncFeedback({
        type: "error",
        text: err.message || "No se completó la autenticación con Google Tasks."
      });
    } finally {
      setIsConnectingGoogle(false);
    }
  };

  const handleApplyProtocolPreset = (preset: (typeof COSAM_PROTOCOL_TASK_PRESETS)[number]) => {
    const due = new Date(Date.now() + preset.dueDaysOffset * 86400000)
      .toISOString()
      .split("T")[0];
    setEditingGoogleTaskId(null);
    setTaskTitle(`${preset.title} — ${selectedPatient.name} (${selectedPatient.rut})`);
    setTaskNotes(
      `Paciente: ${selectedPatient.name} | RUT: ${selectedPatient.rut} | Previsión: ${selectedPatient.prevision}\nDiagnóstico: ${selectedPatient.diagnostic}\n\n${preset.notes}`
    );
    setTaskDueDate(due);
    setTaskPriority(preset.priority);
    setTaskProtocolTag(preset.protocolTag);
  };

  // =========================================================================
  // OPERACIONES DE ESCRITURA CON CONFIRMACIÓN EXPLÍCITA DEL MÉDICO
  // =========================================================================

  const handleRequestCreateOrUpdateTask = () => {
    if (!taskTitle.trim()) {
      setSyncFeedback({
        type: "error",
        text: "Ingrese un título descriptivo para la tarea clínica pendiente."
      });
      return;
    }

    // Si no está conectado a Google Tasks y está en modo Cola de Box, permite guardar en la cola local o conectar
    if (!isGoogleConnected) {
      const updated = GoogleTasksKeepService.addStagedClinicalTask({
        title: taskTitle.trim(),
        notes: taskNotes.trim(),
        dueDate: taskDueDate,
        priority: taskPriority,
        protocolTag: taskProtocolTag,
        patientName: selectedPatient.name,
        patientRut: selectedPatient.rut
      });
      setStagedTasks(updated);
      setTaskTitle("");
      setTaskNotes("");
      setTasksViewMode("box_queue");
      setSyncFeedback({
        type: "info",
        text: "Tarea agregada a la Cola Clínica de Box. Inicie sesión con Google para sincronizarla con Google Tasks API."
      });
      return;
    }

    const activeListTitle =
      taskLists.find((l) => l.id === selectedListId)?.title || "Lista Principal (@default)";

    if (editingGoogleTaskId) {
      setConfirmModal({
        title: "Confirmar actualización de tarea en Google Tasks",
        description:
          "Se modificarán los datos de la tarea clínica seleccionada directamente en su cuenta de Google Tasks.",
        details: [
          `Lista Google Tasks: ${activeListTitle}`,
          `Tarea: ${taskTitle.trim()}`,
          `Fecha límite: ${taskDueDate || "Sin fecha"}`,
          `Paciente asociado: ${selectedPatient.name} (${selectedPatient.rut})`
        ],
        confirmLabel: "Confirmar y Actualizar en Google Tasks",
        variant: "primary",
        onConfirm: async () => {
          setIsExecutingAction(true);
          try {
            await GoogleTasksKeepService.updateTask(selectedListId, editingGoogleTaskId, {
              title: taskTitle.trim(),
              notes: taskNotes.trim(),
              dueDate: taskDueDate || null
            });
            setEditingGoogleTaskId(null);
            setTaskTitle("");
            setTaskNotes("");
            await fetchGoogleTasksData(selectedListId);
            setSyncFeedback({
              type: "success",
              text: "Tarea clínica actualizada correctamente en Google Tasks."
            });
          } catch (err: any) {
            setSyncFeedback({
              type: "error",
              text: err.message || "Error al actualizar la tarea en Google Tasks."
            });
          } finally {
            setIsExecutingAction(false);
          }
        }
      });
      return;
    }

    setConfirmModal({
      title: "Confirmar creación de tarea clínica en Google Tasks",
      description:
        "Se registrará una nueva tarea clínica pendiente en su cuenta personal de Google Tasks y se vinculará al seguimiento de box.",
      details: [
        `Lista destino: ${activeListTitle}`,
        `Título: ${taskTitle.trim()}`,
        `Protocolo: ${taskProtocolTag} · Prioridad: ${taskPriority}`,
        `Fecha límite: ${taskDueDate || "Sin fecha"}`,
        ...(taskNotes.trim() ? [`Notas clínicas: ${taskNotes.trim().slice(0, 110)}...`] : [])
      ],
      confirmLabel: "Confirmar y Crear en Google Tasks",
      variant: "primary",
      onConfirm: async () => {
        setIsExecutingAction(true);
        try {
          const formattedNotes = `[${taskProtocolTag} · ${taskPriority} · Paciente: ${selectedPatient.name} (${selectedPatient.rut})]\n${taskNotes.trim()}`.trim();
          const created = await GoogleTasksKeepService.createTask(selectedListId, {
            title: taskTitle.trim(),
            notes: formattedNotes,
            dueDate: taskDueDate || undefined
          });
          // También registramos trazabilidad en la cola clínica como sincronizada
          const stagedWithSync = GoogleTasksKeepService.addStagedClinicalTask({
            title: taskTitle.trim(),
            notes: taskNotes.trim(),
            dueDate: taskDueDate,
            priority: taskPriority,
            protocolTag: taskProtocolTag,
            patientName: selectedPatient.name,
            patientRut: selectedPatient.rut,
            syncedGoogleTaskId: created.id
          });
          setStagedTasks(stagedWithSync);
          setTaskTitle("");
          setTaskNotes("");
          setTasksViewMode("google_cloud");
          await fetchGoogleTasksData(selectedListId);
          setSyncFeedback({
            type: "success",
            text: `Tarea "${created.title}" creada y sincronizada en Google Tasks.`
          });
        } catch (err: any) {
          setSyncFeedback({
            type: "error",
            text: err.message || "Error al crear la tarea en Google Tasks API."
          });
        } finally {
          setIsExecutingAction(false);
        }
      }
    });
  };

  const handleRequestCreateTaskList = () => {
    if (!newListName.trim()) return;
    const cleanName = newListName.trim();
    setConfirmModal({
      title: "Confirmar nueva lista en Google Tasks",
      description:
        "Se creará una nueva lista de tareas clínicas en su cuenta de Google Tasks.",
      details: [`Nombre de la lista: ${cleanName}`],
      confirmLabel: "Crear Lista en Google Tasks",
      variant: "primary",
      onConfirm: async () => {
        setIsExecutingAction(true);
        try {
          const createdList = await GoogleTasksKeepService.createTaskList(cleanName);
          setNewListName("");
          setShowNewListForm(false);
          setSelectedListId(createdList.id);
          await fetchGoogleTasksData(createdList.id);
          setSyncFeedback({
            type: "success",
            text: `Lista "${createdList.title}" creada exitosamente en Google Tasks.`
          });
        } catch (err: any) {
          setSyncFeedback({
            type: "error",
            text: err.message || "No se pudo crear la lista en Google Tasks."
          });
        } finally {
          setIsExecutingAction(false);
        }
      }
    });
  };

  const handleRequestToggleGoogleTask = (task: GoogleTaskItem) => {
    const nextStatus = task.status === "completed" ? "needsAction" : "completed";
    setConfirmModal({
      title:
        nextStatus === "completed"
          ? "Confirmar cierre de tarea en Google Tasks"
          : "Confirmar reapertura de tarea en Google Tasks",
      description: `¿Confirma cambiar el estado de la tarea clínica a "${
        nextStatus === "completed" ? "Completada" : "Pendiente de acción"
      }" en Google Tasks?`,
      details: [
        `Tarea: ${task.title}`,
        `Nuevo estado: ${nextStatus === "completed" ? "Completada" : "Pendiente"}`
      ],
      confirmLabel: nextStatus === "completed" ? "Marcar Completada" : "Reabrir Tarea",
      variant: "primary",
      onConfirm: async () => {
        setIsExecutingAction(true);
        try {
          await GoogleTasksKeepService.updateTask(selectedListId, task.id, {
            status: nextStatus
          });
          await fetchGoogleTasksData(selectedListId);
          setSyncFeedback({
            type: "success",
            text: `Estado de "${task.title}" sincronizado en Google Tasks.`
          });
        } catch (err: any) {
          setSyncFeedback({
            type: "error",
            text: err.message || "No se pudo actualizar el estado de la tarea."
          });
        } finally {
          setIsExecutingAction(false);
        }
      }
    });
  };

  const handleRequestDeleteGoogleTask = (task: GoogleTaskItem) => {
    setConfirmModal({
      title: "Confirmar eliminación en Google Tasks",
      description:
        "Esta acción eliminará de forma permanente la tarea seleccionada de su lista de Google Tasks.",
      details: [`Tarea a eliminar: ${task.title}`],
      confirmLabel: "Eliminar de Google Tasks",
      variant: "danger",
      onConfirm: async () => {
        setIsExecutingAction(true);
        try {
          await GoogleTasksKeepService.deleteTask(selectedListId, task.id);
          await fetchGoogleTasksData(selectedListId);
          setSyncFeedback({
            type: "info",
            text: `Tarea "${task.title}" eliminada de Google Tasks.`
          });
        } catch (err: any) {
          setSyncFeedback({
            type: "error",
            text: err.message || "Error al eliminar la tarea de Google Tasks."
          });
        } finally {
          setIsExecutingAction(false);
        }
      }
    });
  };

  const handleRequestSyncSingleStagedTask = (staged: StagedClinicalTask) => {
    if (!isGoogleConnected) {
      handleConnectGoogleTasks();
      return;
    }
    const activeListTitle =
      taskLists.find((l) => l.id === selectedListId)?.title || "Lista Principal (@default)";

    setConfirmModal({
      title: "Sincronizar tarea de Box hacia Google Tasks",
      description:
        "Se enviará esta tarea clínica pendiente desde la Cola de Box del COSAM Rinconada hacia su lista activa de Google Tasks.",
      details: [
        `Lista destino: ${activeListTitle}`,
        `Tarea: ${staged.title}`,
        `Protocolo: ${staged.protocolTag} (${staged.priority})`,
        `Paciente: ${staged.patientName || "General COSAM"}`
      ],
      confirmLabel: "Sincronizar con Google Tasks",
      variant: "primary",
      onConfirm: async () => {
        setIsExecutingAction(true);
        try {
          const { updatedStaged } = await GoogleTasksKeepService.syncStagedTaskToGoogle(
            selectedListId,
            staged
          );
          setStagedTasks(updatedStaged);
          await fetchGoogleTasksData(selectedListId);
          setSyncFeedback({
            type: "success",
            text: `Tarea "${staged.title}" sincronizada con Google Tasks.`
          });
        } catch (err: any) {
          setSyncFeedback({
            type: "error",
            text: err.message || "No se pudo sincronizar la tarea con Google Tasks."
          });
        } finally {
          setIsExecutingAction(false);
        }
      }
    });
  };

  const handleRequestSyncAllStagedTasks = () => {
    const unsynced = stagedTasks.filter(
      (t) => t.status === "needsAction" && !t.syncedGoogleTaskId
    );
    if (unsynced.length === 0) {
      setSyncFeedback({
        type: "info",
        text: "Todas las tareas pendientes de la Cola de Box ya están sincronizadas con Google Tasks."
      });
      return;
    }
    if (!isGoogleConnected) {
      handleConnectGoogleTasks();
      return;
    }
    const activeListTitle =
      taskLists.find((l) => l.id === selectedListId)?.title || "Lista Principal (@default)";

    setConfirmModal({
      title: "Confirmar sincronización masiva a Google Tasks",
      description: `Se exportarán ${unsynced.length} tareas clínicas pendientes del Protocolo PAI / COSAM Rinconada a su lista activa de Google Tasks.`,
      details: [
        `Lista destino: ${activeListTitle}`,
        ...unsynced.map((u) => `• [${u.priority}] ${u.title}`)
      ],
      confirmLabel: `Sincronizar ${unsynced.length} Tareas Ahora`,
      variant: "primary",
      onConfirm: async () => {
        setIsExecutingAction(true);
        try {
          const { syncedCount, updatedStaged } =
            await GoogleTasksKeepService.syncAllPendingStagedTasksToGoogle(selectedListId);
          setStagedTasks(updatedStaged);
          setTasksViewMode("google_cloud");
          await fetchGoogleTasksData(selectedListId);
          setSyncFeedback({
            type: "success",
            text: `Se sincronizaron ${syncedCount} tareas clínicas con Google Tasks exitosamente.`
          });
        } catch (err: any) {
          setSyncFeedback({
            type: "error",
            text: err.message || "Error durante la sincronización masiva con Google Tasks."
          });
        } finally {
          setIsExecutingAction(false);
        }
      }
    });
  };

  // Filtrado de tareas en la nube y en cola local
  const filteredGoogleTasks = useMemo(() => {
    return googleTasks.filter((t) =>
      statusFilter === "all" ? true : t.status === statusFilter
    );
  }, [googleTasks, statusFilter]);

  const filteredStagedTasks = useMemo(() => {
    return stagedTasks.filter((t) =>
      statusFilter === "all" ? true : t.status === statusFilter
    );
  }, [stagedTasks, statusFilter]);

  const pendingCloudCount = googleTasks.filter((t) => t.status === "needsAction").length;
  const unsyncedBoxCount = stagedTasks.filter(
    (t) => t.status === "needsAction" && !t.syncedGoogleTaskId
  ).length;

  // PANEL 1: ACCIONES INMEDIATAS DE BOX (4 HERRAMIENTAS OPERATIVAS CON PALETA UNIFICADA)
  const boxTools = [
    {
      id: "workspace",
      title: "Ficha Rayen APS",
      subtitle: "Registro rápido & FUC",
      icon: FileText,
      color: "text-[#075985] dark:text-sky-400",
      bg: "bg-sky-500/10 dark:bg-sky-400/15 border-sky-500/20"
    },
    {
      id: "resumen_pdf",
      title: "Informe Clínico PDF",
      subtitle: "Pauta formal paciente",
      icon: Printer,
      color: "text-[#075985] dark:text-sky-400",
      bg: "bg-sky-500/10 dark:bg-sky-400/15 border-sky-500/20"
    },
    {
      id: "gatillantes_afrontamiento",
      title: "Gatillantes & SOS",
      subtitle: "Craving 15m & respiración",
      icon: ShieldCheck,
      color: "text-emerald-700 dark:text-emerald-400",
      bg: "bg-emerald-500/10 dark:bg-emerald-400/15 border-emerald-500/20"
    },
    {
      id: "proyector",
      title: "Psicoeducación Box",
      subtitle: "Proyección dual interactiva",
      icon: Tv2,
      color: "text-[#075985] dark:text-sky-400",
      bg: "bg-sky-500/10 dark:bg-sky-400/15 border-sky-500/20"
    }
  ];

  // PANEL 2: EVALUACIÓN MÉDICA & FARMACOLOGÍA (6 MÓDULOS)
  const medicalModules = [
    {
      id: "atlas",
      title: "Atlas Fisiopatológico",
      desc: "Daño multiorgánico, neuroinflamación y pautas de box.",
      icon: Stethoscope,
      category: "Fisiopatología"
    },
    {
      id: "neurometabolix",
      title: "Toxicología & NeuroMetabolix",
      desc: "Estrés biológico por sustancia y ventanas de recuperación.",
      icon: Flame,
      category: "Toxicología"
    },
    {
      id: "sistemas",
      title: "Impacto Multisistémico",
      desc: "Visualizador comparativo de daño en 8 sistemas corporales.",
      icon: Layers,
      category: "Sistemas"
    },
    {
      id: "sustancias",
      title: "Vademécum de Sustancias",
      desc: "Farmacocinética, metabolitos y perlas toxicológicas clínicas.",
      icon: FileSpreadsheet,
      category: "Farmacología"
    },
    {
      id: "sintomas",
      title: "Signos & Banderas Rojas",
      desc: "Semiología de alarma urgente y estabilización en COSAM.",
      icon: AlertCircle,
      category: "Urgencia"
    },
    {
      id: "nutricion",
      title: "Microrrehabilitación Nutricional",
      desc: "Protocolo de reposición con Tiamina, Magnesio y pauta oral.",
      icon: Apple,
      category: "Terapéutica"
    }
  ];

  // PANEL 3: PSICOEDUCACIÓN & NEUROBIOLOGÍA (4 MÓDULOS)
  const psychoModules = [
    {
      id: "neurobiologia",
      title: "Bases Neurobiológicas",
      desc: "Circuito mesolímbico VTA y las 5 estaciones sinápticas.",
      icon: Brain,
      category: "Neuroanatomía"
    },
    {
      id: "simulador",
      title: "Simulador de Recompensa",
      desc: "Dinámica interactiva de liberación de dopamina y receptores D2.",
      icon: SlidersHorizontal,
      category: "Dinámica Sináptica"
    },
    {
      id: "neuroplasticidad",
      title: "Neuroplasticidad & BDNF",
      desc: "Curvas biológicas de recuperación y tiempos de abstinencia.",
      icon: TrendingUp,
      category: "Recuperación D2"
    },
    {
      id: "ecosistemas_civico",
      title: "Trabajo Médico & IA",
      desc: "Evolución SOAP, PAI, Protocolo COSAM y derivación asistida.",
      icon: Building2,
      category: "Gestión Clínica"
    }
  ];

  return (
    <div className="space-y-6 animate-fadeIn pb-12 max-w-7xl mx-auto">
      {/* =========================================================================
          BARRA SUPERIOR CON GLASSMORPHISM EN SCROLL Y JERARQUÍA CLARA
         ========================================================================= */}
      <section className="sticky top-[53px] z-20 clinical-glass-bar p-4 sm:p-5 rounded-2xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="space-y-0.5">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block" />
            <span className="text-[10px] font-mono font-bold uppercase tracking-widest text-[#075985] dark:text-sky-400">
              ESTACIÓN CLÍNICA DE BOX • COSAM RINCONADA
            </span>
          </div>
          <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white tracking-tight">
            Panel de Control y Navegación Asistencial
          </h2>
        </div>

        {/* Selector de Paneles y Acciones Principales Agrupadas */}
        <div className="flex flex-wrap items-center gap-2.5 self-stretch md:self-auto justify-between md:justify-end">
          <div className="ios-segmented flex flex-wrap items-center p-1 rounded-xl text-xs">
            {[
              { id: "todos", label: "Todos" },
              { id: "operativo", label: "Operación Box" },
              { id: "tareas", label: "Google Tasks Clínico" },
              { id: "medico", label: "Evaluación Médica" },
              { id: "psicoeducacion", label: "Psicoeducación" }
            ].map((f) => (
              <button
                key={f.id}
                onClick={() => setActivePanelFilter(f.id as any)}
                className={`px-2.5 py-1 rounded-lg font-semibold transition-all cursor-pointer ${
                  activePanelFilter === f.id
                    ? "bg-[#075985] text-white shadow-xs"
                    : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>

          <button
            onClick={() => onNavigate("ecosistemas_civico")}
            className="px-3.5 py-2 bg-[#075985] hover:bg-[#0c4a6e] text-white rounded-xl text-xs font-semibold transition-all shadow-xs flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <Zap size={13} className="text-sky-200" />
            <span>Trabajo Médico</span>
          </button>

          <button
            onClick={() => onNavigate("proyector")}
            className="px-3.5 py-2 bg-white/80 dark:bg-slate-800/80 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200 rounded-xl text-xs font-semibold transition-all border border-slate-200/90 dark:border-slate-700 flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <Tv2 size={13} className="text-[#075985] dark:text-sky-400" />
            <span>Proyector Box</span>
          </button>
        </div>
      </section>

      {/* =========================================================================
          PANEL 1: CONSOLA DE ACCIONES OPERATIVAS DE BOX CON HEADER GLASSMORPHISM
         ========================================================================= */}
      {(activePanelFilter === "todos" || activePanelFilter === "operativo") && (
        <section className="clinical-card overflow-hidden">
          <div className="clinical-glass-header px-5 py-3 flex items-center justify-between">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800 dark:text-slate-200 flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-[#075985] dark:bg-sky-400 inline-block" />
              Acciones Inmediatas de Box
            </h3>
            <span className="text-[10px] font-mono font-semibold text-slate-500">
              Atajos operativos
            </span>
          </div>

          <div className="p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {boxTools.map((tool) => {
              const Icon = tool.icon;
              return (
                <button
                  key={tool.id}
                  onClick={() => onNavigate(tool.id)}
                  className="p-3.5 rounded-xl bg-slate-50/70 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-700/80 hover:border-[#075985]/40 text-left transition-all hover:-translate-y-0.5 group flex items-center gap-3 cursor-pointer"
                >
                  <div
                    className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 border ${tool.bg} ${tool.color}`}
                  >
                    <Icon size={17} strokeWidth={2} />
                  </div>
                  <div className="min-w-0 leading-tight">
                    <span className="text-xs font-bold text-slate-900 dark:text-white block truncate group-hover:text-[#075985] dark:group-hover:text-sky-400 transition-colors">
                      {tool.title}
                    </span>
                    <span className="text-[11px] text-slate-500 dark:text-slate-400 block truncate mt-0.5">
                      {tool.subtitle}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </section>
      )}

      {/* =========================================================================
          PANEL CENTRAL DE SINCRONIZACIÓN CLÍNICA CON GOOGLE TASKS API
          Permite crear, gestionar y sincronizar tareas clínicas pendientes del
          Protocolo PAI SSMSO y Taller de Habituación directamente desde DashboardCentral
         ========================================================================= */}
      {(activePanelFilter === "todos" ||
        activePanelFilter === "operativo" ||
        activePanelFilter === "tareas") && (
        <section className="clinical-card overflow-hidden">
          {/* Header Sticky con Glassmorphism */}
          <div className="clinical-glass-header px-5 py-3.5 flex flex-col lg:flex-row lg:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-sky-500/10 dark:bg-sky-400/15 border border-sky-500/20 flex items-center justify-center text-[#075985] dark:text-sky-400 shrink-0">
                <CheckSquare size={16} strokeWidth={2} />
              </div>
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900 dark:text-white flex items-center gap-2">
                  <span>Tareas Clínicas Pendientes &amp; Sincronización Google Tasks API</span>
                  <span className="text-[10px] font-mono font-normal text-slate-500 dark:text-slate-400">
                    {isGoogleConnected
                      ? `· ${pendingCloudCount} pendientes en Google Tasks`
                      : `· ${unsyncedBoxCount} en cola de box por sincronizar`}
                  </span>
                </h3>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  Protocolo Derivación PAI SSMSO (P1/P2/P3), Exámenes Basales, Monitoreo TOP/SISTRAT y Taller de Habituación
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {/* Selector de Paciente en Box para etiquetar la tarea */}
              <div className="flex items-center gap-1.5 bg-slate-100/90 dark:bg-slate-800/80 border border-slate-200/80 dark:border-slate-700 rounded-xl px-2.5 py-1.5">
                <UserCheck size={13} className="text-[#075985] dark:text-sky-400 shrink-0" />
                <select
                  value={selectedPatientId}
                  onChange={(e) => setSelectedPatientId(e.target.value)}
                  aria-label="Seleccionar paciente activo para tareas"
                  className="bg-transparent text-xs font-semibold text-slate-800 dark:text-slate-200 outline-none cursor-pointer"
                >
                  {PRESET_PATIENTS.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} ({p.rut})
                    </option>
                  ))}
                </select>
              </div>

              {isGoogleConnected ? (
                <>
                  <select
                    value={selectedListId}
                    onChange={(e) => {
                      setSelectedListId(e.target.value);
                      fetchGoogleTasksData(e.target.value);
                    }}
                    aria-label="Lista de Google Tasks"
                    className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-2.5 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 outline-none cursor-pointer"
                  >
                    {taskLists.length === 0 && <option value="@default">Mis Tareas</option>}
                    {taskLists.map((list) => (
                      <option key={list.id} value={list.id}>
                        {list.title}
                      </option>
                    ))}
                  </select>

                  <button
                    type="button"
                    onClick={() => setShowNewListForm((prev) => !prev)}
                    title="Crear nueva lista en Google Tasks"
                    className="p-1.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 cursor-pointer"
                  >
                    <FolderPlus size={14} />
                  </button>

                  <button
                    type="button"
                    onClick={() => fetchGoogleTasksData(selectedListId)}
                    disabled={isLoadingGoogleTasks}
                    className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <RefreshCw
                      size={13}
                      className={isLoadingGoogleTasks ? "animate-spin text-[#075985]" : ""}
                    />
                    <span>Sincronizar</span>
                  </button>
                </>
              ) : (
                <GoogleSignInButton
                  onClick={handleConnectGoogleTasks}
                  isLoading={isConnectingGoogle}
                  label="Sign in with Google"
                  compact
                />
              )}
            </div>
          </div>

          {/* Feedback de Sincronización */}
          {syncFeedback && (
            <div
              className={`mx-5 mt-4 px-4 py-2.5 rounded-xl border flex items-center justify-between gap-3 text-xs font-medium ${
                syncFeedback.type === "success"
                  ? "bg-emerald-50/90 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-800/60 text-emerald-800 dark:text-emerald-200"
                  : syncFeedback.type === "error"
                  ? "bg-rose-50/90 dark:bg-rose-950/30 border-rose-200 dark:border-rose-800/60 text-rose-800 dark:text-rose-200"
                  : "bg-sky-50/90 dark:bg-sky-950/30 border-sky-200 dark:border-sky-800/60 text-sky-900 dark:text-sky-200"
              }`}
            >
              <div className="flex items-center gap-2">
                {syncFeedback.type === "success" ? (
                  <CheckCircle2 size={15} className="shrink-0" />
                ) : (
                  <AlertCircle size={15} className="shrink-0" />
                )}
                <span>{syncFeedback.text}</span>
              </div>
              <button
                type="button"
                onClick={() => setSyncFeedback(null)}
                className="text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X size={14} />
              </button>
            </div>
          )}

          {/* Formulario rápido para crear nueva lista en Google Tasks */}
          {isGoogleConnected && showNewListForm && (
            <div className="mx-5 mt-4 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 flex flex-wrap items-center gap-2">
              <input
                type="text"
                value={newListName}
                onChange={(e) => setNewListName(e.target.value)}
                placeholder="Nombre de lista (ej. COSAM Rinconada — Ingresos PAI SSMSO)"
                className="flex-1 min-w-[220px] bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-900 dark:text-slate-100 outline-none"
              />
              <button
                type="button"
                onClick={handleRequestCreateTaskList}
                className="px-3 py-1.5 rounded-lg bg-[#075985] hover:bg-[#0c4a6e] text-white text-xs font-semibold cursor-pointer"
              >
                Crear Lista
              </button>
              <button
                type="button"
                onClick={() => setShowNewListForm(false)}
                className="px-2.5 py-1.5 rounded-lg text-xs text-slate-500 hover:text-slate-700 cursor-pointer"
              >
                Cancelar
              </button>
            </div>
          )}

          {/* Cuerpo Principal en 2 Columnas: Creación Protocolizada + Lista Sincronizada */}
          <div className="p-5 grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
            {/* COLUMNA IZQUIERDA (5 cols): CREACIÓN RÁPIDA Y PLANTILLAS NORMATIVAS COSAM */}
            <div className="lg:col-span-5 space-y-3.5 bg-slate-50/70 dark:bg-slate-800/40 p-4 rounded-xl border border-slate-200/80 dark:border-slate-800">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-900 dark:text-white">
                  {editingGoogleTaskId
                    ? "Editar Tarea de Google Tasks"
                    : "Nueva Tarea Clínica Pendiente"}
                </span>
                {editingGoogleTaskId && (
                  <button
                    type="button"
                    onClick={() => {
                      setEditingGoogleTaskId(null);
                      setTaskTitle("");
                      setTaskNotes("");
                    }}
                    className="text-[11px] font-semibold text-slate-500 hover:text-slate-800 cursor-pointer"
                  >
                    Cancelar edición
                  </button>
                )}
              </div>

              {/* Plantillas Rápidas del Protocolo PAI SSMSO y Taller Habituación */}
              <div className="space-y-1.5">
                <span className="text-[10px] font-mono font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 block">
                  Plantillas Normativas COSAM Rinconada (1 clic):
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                  {COSAM_PROTOCOL_TASK_PRESETS.map((preset) => (
                    <button
                      key={preset.id}
                      type="button"
                      onClick={() => handleApplyProtocolPreset(preset)}
                      className="px-2.5 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-700 hover:border-[#075985] text-left text-[11px] font-medium text-slate-700 dark:text-slate-200 transition-all truncate cursor-pointer"
                      title={preset.title}
                    >
                      + {preset.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-2.5 pt-1">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                    Título de la Tarea Clínica
                  </label>
                  <input
                    type="text"
                    value={taskTitle}
                    onChange={(e) => setTaskTitle(e.target.value)}
                    placeholder={`Ej: Revisar Litemia y ECG basal — ${selectedPatient.name}`}
                    className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-900 dark:text-slate-100 focus:border-[#075985] outline-none"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                      Vencimiento
                    </label>
                    <input
                      type="date"
                      value={taskDueDate}
                      onChange={(e) => setTaskDueDate(e.target.value)}
                      className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg px-2.5 py-1.5 text-xs font-mono text-slate-900 dark:text-slate-100 focus:border-[#075985] outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                      Prioridad SSMSO
                    </label>
                    <select
                      value={taskPriority}
                      onChange={(e) => setTaskPriority(e.target.value as any)}
                      className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg px-2 py-1.5 text-xs text-slate-900 dark:text-slate-100 outline-none"
                    >
                      <option value="P1 Urgente (<72h)">P1 (&lt;72h)</option>
                      <option value="P2 Alta (<15d)">P2 (&lt;15d)</option>
                      <option value="P3 Estándar">P3 (&lt;30d)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                      Eje Clínico
                    </label>
                    <select
                      value={taskProtocolTag}
                      onChange={(e) => setTaskProtocolTag(e.target.value as any)}
                      className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg px-2 py-1.5 text-xs text-slate-900 dark:text-slate-100 outline-none"
                    >
                      <option value="Triaje PAI SSMSO">Triaje PAI SSMSO</option>
                      <option value="Laboratorio & ECG">Laboratorio &amp; ECG</option>
                      <option value="TOP / SISTRAT">TOP / SISTRAT</option>
                      <option value="Taller Habituación">Taller Habituación</option>
                      <option value="Farmacovigilancia">Farmacovigilancia</option>
                      <option value="Contrarreferencia APS">Contrarreferencia APS</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                    Notas Clínicas / Indicaciones de Seguimiento
                  </label>
                  <textarea
                    rows={3}
                    value={taskNotes}
                    onChange={(e) => setTaskNotes(e.target.value)}
                    placeholder="Detalle criterios DSM-5, exámenes pendientes, coordinación con CESFAM o pauta farmacológica..."
                    className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg p-2.5 text-xs text-slate-800 dark:text-slate-200 focus:border-[#075985] outline-none resize-none"
                  />
                </div>

                <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                  <span className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                    Paciente: <strong className="text-slate-700 dark:text-slate-200">{selectedPatient.name}</strong>
                  </span>

                  <button
                    type="button"
                    onClick={handleRequestCreateOrUpdateTask}
                    disabled={isExecutingAction}
                    className="px-4 py-2 rounded-xl bg-[#075985] hover:bg-[#0c4a6e] text-white text-xs font-semibold flex items-center gap-1.5 transition-all shadow-xs cursor-pointer disabled:opacity-50"
                  >
                    <Plus size={14} />
                    <span>
                      {editingGoogleTaskId
                        ? "Actualizar en Google Tasks"
                        : isGoogleConnected
                        ? "Crear en Google Tasks"
                        : "Agregar a Cola de Box"}
                    </span>
                  </button>
                </div>
              </div>
            </div>

            {/* COLUMNA DERECHA (7 cols): LISTA DE TAREAS SINCRONIZADAS & COLA DE BOX */}
            <div className="lg:col-span-7 flex flex-col space-y-3">
              {/* Barra de conmutación entre Nube Google Tasks y Cola de Box COSAM */}
              <div className="flex flex-wrap items-center justify-between gap-2 pb-1 border-b border-slate-200/80 dark:border-slate-800">
                <div className="ios-segmented flex items-center p-1 rounded-xl text-xs">
                  <button
                    type="button"
                    onClick={() => setTasksViewMode("google_cloud")}
                    className={`px-3 py-1 rounded-lg font-semibold transition-all cursor-pointer ${
                      tasksViewMode === "google_cloud"
                        ? "bg-[#075985] text-white shadow-2xs"
                        : "text-slate-600 dark:text-slate-400 hover:text-slate-900"
                    }`}
                  >
                    Google Tasks API ({googleTasks.length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setTasksViewMode("box_queue")}
                    className={`px-3 py-1 rounded-lg font-semibold transition-all cursor-pointer ${
                      tasksViewMode === "box_queue"
                        ? "bg-[#075985] text-white shadow-2xs"
                        : "text-slate-600 dark:text-slate-400 hover:text-slate-900"
                    }`}
                  >
                    Cola Protocolo PAI ({stagedTasks.length})
                  </button>
                </div>

                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg text-[11px]">
                    {[
                      { id: "needsAction", label: "Pendientes" },
                      { id: "completed", label: "Completadas" },
                      { id: "all", label: "Todas" }
                    ].map((st) => (
                      <button
                        key={st.id}
                        type="button"
                        onClick={() => setStatusFilter(st.id as any)}
                        className={`px-2 py-0.5 rounded-md font-semibold transition-colors cursor-pointer ${
                          statusFilter === st.id
                            ? "bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-2xs"
                            : "text-slate-500 dark:text-slate-400"
                        }`}
                      >
                        {st.label}
                      </button>
                    ))}
                  </div>

                  {unsyncedBoxCount > 0 && (
                    <button
                      type="button"
                      onClick={handleRequestSyncAllStagedTasks}
                      className="px-2.5 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-[11px] font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                      title="Exportar tareas pendientes de la Cola de Box a Google Tasks"
                    >
                      <CloudUpload size={13} />
                      <span>Sincronizar Cola ({unsyncedBoxCount})</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Contenedor Scrolleable de Tareas */}
              <div className="max-h-[370px] overflow-y-auto space-y-2 pr-1">
                {tasksViewMode === "google_cloud" ? (
                  !isGoogleConnected ? (
                    <div className="rounded-xl border border-slate-200/90 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-900/40 p-6 text-center space-y-3">
                      <ListTodo size={28} className="text-[#075985] dark:text-sky-400 mx-auto" />
                      <div className="space-y-1 max-w-md mx-auto">
                        <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900 dark:text-white">
                          Sincronización Directa con Google Tasks API
                        </h4>
                        <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                          Inicie sesión con su cuenta de Google mediante Firebase Auth para ver y gestionar sus listas reales de Google Tasks, o utilice la pestaña{" "}
                          <button
                            type="button"
                            onClick={() => setTasksViewMode("box_queue")}
                            className="text-[#075985] dark:text-sky-400 font-semibold underline cursor-pointer"
                          >
                            Cola Protocolo PAI ({stagedTasks.length})
                          </button>{" "}
                          para preparar tareas en box y sincronizarlas en 1 clic.
                        </p>
                      </div>
                      <div className="flex justify-center pt-1">
                        <GoogleSignInButton
                          onClick={handleConnectGoogleTasks}
                          isLoading={isConnectingGoogle}
                          label="Sign in with Google"
                        />
                      </div>
                    </div>
                  ) : isLoadingGoogleTasks ? (
                    <div className="py-12 text-center text-xs text-slate-500 flex items-center justify-center gap-2">
                      <RefreshCw size={15} className="animate-spin text-[#075985]" />
                      <span>Consultando tareas clínicas en Google Tasks API...</span>
                    </div>
                  ) : filteredGoogleTasks.length === 0 ? (
                    <div className="rounded-xl border border-slate-200/80 dark:border-slate-800 p-6 text-center space-y-2">
                      <p className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                        No hay tareas {statusFilter === "needsAction" ? "pendientes" : ""} en esta lista de Google Tasks.
                      </p>
                      <p className="text-[11px] text-slate-500">
                        Seleccione una plantilla normativa a la izquierda o sincronice las tareas pendientes de la Cola Protocolo PAI.
                      </p>
                      {unsyncedBoxCount > 0 && (
                        <button
                          type="button"
                          onClick={handleRequestSyncAllStagedTasks}
                          className="mt-1 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#075985] text-white text-xs font-semibold cursor-pointer"
                        >
                          <CloudUpload size={13} />
                          <span>Exportar {unsyncedBoxCount} tareas del Protocolo PAI a Google Tasks</span>
                        </button>
                      )}
                    </div>
                  ) : (
                    filteredGoogleTasks.map((task) => {
                      const isDone = task.status === "completed";
                      return (
                        <div
                          key={task.id}
                          className={`p-3.5 rounded-xl border transition-all flex items-start justify-between gap-3 ${
                            isDone
                              ? "bg-slate-50/50 dark:bg-slate-900/30 border-slate-200/60 dark:border-slate-800/60 opacity-75"
                              : "bg-white dark:bg-slate-900/90 border-slate-200/90 dark:border-slate-800 hover:border-[#075985]/40"
                          }`}
                        >
                          <div className="flex items-start gap-3 min-w-0 flex-1">
                            <button
                              type="button"
                              onClick={() => handleRequestToggleGoogleTask(task)}
                              title={
                                isDone
                                  ? "Reabrir tarea en Google Tasks"
                                  : "Marcar como completada en Google Tasks"
                              }
                              className={`mt-0.5 w-4 h-4 rounded flex items-center justify-center border shrink-0 cursor-pointer transition-colors ${
                                isDone
                                  ? "bg-emerald-600 border-emerald-600 text-white"
                                  : "border-slate-400 dark:border-slate-500 hover:border-[#075985]"
                              }`}
                            >
                              {isDone && <CheckCircle2 size={12} />}
                            </button>

                            <div className="min-w-0 flex-1 space-y-1">
                              <span
                                className={`text-xs font-bold block leading-snug ${
                                  isDone
                                    ? "line-through text-slate-400 dark:text-slate-500"
                                    : "text-slate-900 dark:text-white"
                                }`}
                              >
                                {task.title}
                              </span>

                              {task.notes && (
                                <p className="text-[11px] text-slate-600 dark:text-slate-400 whitespace-pre-line line-clamp-2 leading-relaxed">
                                  {task.notes}
                                </p>
                              )}

                              <div className="flex flex-wrap items-center gap-3 pt-0.5 text-[10px] font-mono text-slate-500">
                                {task.due && (
                                  <span className="inline-flex items-center gap-1">
                                    <Calendar size={11} className="text-[#075985] dark:text-sky-400" />
                                    Vence: {task.due.split("T")[0]}
                                  </span>
                                )}
                                <span>Google Tasks API</span>
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center gap-1 shrink-0">
                            <button
                              type="button"
                              onClick={() => {
                                setEditingGoogleTaskId(task.id);
                                setTaskTitle(task.title);
                                setTaskNotes(task.notes || "");
                                if (task.due) {
                                  setTaskDueDate(task.due.split("T")[0]);
                                }
                              }}
                              title="Editar tarea"
                              className="p-1.5 rounded-lg text-slate-400 hover:text-[#075985] hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                            >
                              <Edit3 size={13} />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleRequestDeleteGoogleTask(task)}
                              title="Eliminar tarea de Google Tasks"
                              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 cursor-pointer"
                            >
                              <Trash2 size={13} />
                            </button>
                          </div>
                        </div>
                      );
                    })
                  )
                ) : (
                  /* VISTA COLA DE BOX (TAREAS NORMATIVAS DEL PROTOCOLO PAI & TALLER HABITUACIÓN) */
                  filteredStagedTasks.map((staged) => {
                    const isDone = staged.status === "completed";
                    return (
                      <div
                        key={staged.id}
                        className={`p-3.5 rounded-xl border transition-all flex items-start justify-between gap-3 ${
                          isDone
                            ? "bg-slate-50/50 dark:bg-slate-900/30 border-slate-200/60 dark:border-slate-800/60 opacity-75"
                            : "bg-white dark:bg-slate-900/90 border-slate-200/90 dark:border-slate-800 hover:border-[#075985]/40"
                        }`}
                      >
                        <div className="flex items-start gap-3 min-w-0 flex-1">
                          <button
                            type="button"
                            onClick={() => {
                              const updated = GoogleTasksKeepService.toggleStagedClinicalTask(
                                staged.id
                              );
                              setStagedTasks(updated);
                            }}
                            className={`mt-0.5 w-4 h-4 rounded flex items-center justify-center border shrink-0 cursor-pointer ${
                              isDone
                                ? "bg-emerald-600 border-emerald-600 text-white"
                                : "border-slate-400 dark:border-slate-500 hover:border-[#075985]"
                            }`}
                          >
                            {isDone && <CheckCircle2 size={12} />}
                          </button>

                          <div className="min-w-0 flex-1 space-y-1">
                            <div className="flex flex-wrap items-center gap-2">
                              <span
                                className={`text-xs font-bold leading-snug ${
                                  isDone
                                    ? "line-through text-slate-400 dark:text-slate-500"
                                    : "text-slate-900 dark:text-white"
                                }`}
                              >
                                {staged.title}
                              </span>
                            </div>

                            <p className="text-[11px] text-slate-600 dark:text-slate-400 line-clamp-2 leading-relaxed">
                              {staged.notes}
                            </p>

                            <div className="flex flex-wrap items-center gap-3 pt-0.5 text-[10px] font-mono text-slate-500">
                              <span className="text-[#075985] dark:text-sky-400 font-semibold">
                                {staged.protocolTag}
                              </span>
                              <span>·</span>
                              <span
                                className={
                                  staged.priority.startsWith("P1")
                                    ? "text-rose-600 dark:text-rose-400 font-semibold"
                                    : "text-slate-500"
                                }
                              >
                                {staged.priority}
                              </span>
                              {staged.patientName && (
                                <>
                                  <span>·</span>
                                  <span>{staged.patientName}</span>
                                </>
                              )}
                              <span>·</span>
                              <span className="inline-flex items-center gap-1">
                                <Clock size={10} />
                                {staged.dueDate}
                              </span>
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-1.5 shrink-0">
                          {staged.syncedGoogleTaskId ? (
                            <span className="text-[10px] font-mono font-semibold text-emerald-700 dark:text-emerald-400 px-2 py-1 rounded-md bg-emerald-500/10">
                              Sincronizada
                            </span>
                          ) : (
                            <button
                              type="button"
                              onClick={() => handleRequestSyncSingleStagedTask(staged)}
                              className="px-2.5 py-1 rounded-lg bg-[#075985]/10 hover:bg-[#075985] text-[#075985] hover:text-white dark:text-sky-400 text-[11px] font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                              title="Enviar esta tarea a Google Tasks API"
                            >
                              <CloudUpload size={12} />
                              <span>Enviar a Tasks</span>
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => {
                              const updated = GoogleTasksKeepService.deleteStagedClinicalTask(
                                staged.id
                              );
                              setStagedTasks(updated);
                            }}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 cursor-pointer"
                            title="Quitar de la cola"
                          >
                            <Trash2 size={13} />
                          </button>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>

              {/* Pie del Panel con enlace directo a la vista expandida de Tareas & Keep */}
              <div className="pt-2 border-t border-slate-200/70 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-500">
                <span>
                  {authUser
                    ? `Sesión activa: ${authUser.displayName || authUser.email}`
                    : "OAuth 2.0 Client-Side · Scopes: tasks & tasks.readonly"}
                </span>
                <button
                  type="button"
                  onClick={() => onNavigate("ecosistemas_civico")}
                  className="text-[#075985] dark:text-sky-400 font-semibold hover:underline inline-flex items-center gap-1 cursor-pointer"
                >
                  <span>Abrir Espacio Completo Tasks &amp; Keep en Trabajo Médico</span>
                  <ExternalLink size={12} />
                </button>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* =========================================================================
          PANEL 2 & 3: EVALUACIÓN MÉDICA & PSICOEDUCACIÓN CON HEADERS GLASSMORPHISM
         ========================================================================= */}
      {(activePanelFilter === "todos" ||
        activePanelFilter === "medico" ||
        activePanelFilter === "psicoeducacion") && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
          {/* PANEL DE EVALUACIÓN MÉDICA & FARMACOLOGÍA */}
          {(activePanelFilter === "todos" || activePanelFilter === "medico") && (
            <section className="clinical-card max-h-[520px] overflow-y-auto">
              <div className="clinical-glass-header px-5 py-3.5 flex items-center justify-between">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800 dark:text-slate-200 flex items-center gap-2">
                  <Stethoscope size={14} className="text-[#075985] dark:text-sky-400" />
                  Evaluación Médica &amp; Farmacología
                </h3>
                <span className="text-[10px] font-mono font-semibold text-slate-500">
                  6 Módulos
                </span>
              </div>

              <div className="divide-y divide-slate-200/70 dark:divide-slate-800/80">
                {medicalModules.map((item) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.id}
                      onClick={() => onNavigate(item.id)}
                      className="w-full p-4 text-left flex items-center gap-3.5 hover:bg-slate-50/90 dark:hover:bg-slate-800/50 transition-all cursor-pointer group"
                    >
                      <div className="w-9 h-9 rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700 text-[#075985] dark:text-sky-400 flex items-center justify-center shrink-0 group-hover:bg-[#075985] group-hover:text-white transition-all">
                        <Icon size={16} strokeWidth={1.85} />
                      </div>

                      <div className="flex-1 min-w-0 leading-tight">
                        <div className="flex items-center justify-between gap-2 mb-0.5">
                          <span className="text-xs font-bold text-slate-900 dark:text-white truncate group-hover:text-[#075985] dark:group-hover:text-sky-400 transition-colors">
                            {item.title}
                          </span>
                          <span className="text-[10px] font-mono font-medium text-slate-400 dark:text-slate-500 shrink-0">
                            {item.category}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                          {item.desc}
                        </p>
                      </div>

                      <ChevronRight
                        size={14}
                        className="text-slate-400 group-hover:translate-x-0.5 group-hover:text-[#075985] transition-all shrink-0"
                      />
                    </button>
                  );
                })}
              </div>
            </section>
          )}

          {/* PANEL DE PSICOEDUCACIÓN & NEUROBIOLOGÍA */}
          {(activePanelFilter === "todos" || activePanelFilter === "psicoeducacion") && (
            <div className="space-y-4">
              <section className="clinical-card max-h-[420px] overflow-y-auto">
                <div className="clinical-glass-header px-5 py-3.5 flex items-center justify-between">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800 dark:text-slate-200 flex items-center gap-2">
                    <Brain size={14} className="text-[#075985] dark:text-sky-400" />
                    Psicoeducación &amp; Neurobiología
                  </h3>
                  <span className="text-[10px] font-mono font-semibold text-slate-500">
                    4 Módulos
                  </span>
                </div>

                <div className="divide-y divide-slate-200/70 dark:divide-slate-800/80">
                  {psychoModules.map((item) => {
                    const Icon = item.icon;
                    return (
                      <button
                        key={item.id}
                        onClick={() => onNavigate(item.id)}
                        className="w-full p-4 text-left flex items-center gap-3.5 hover:bg-slate-50/90 dark:hover:bg-slate-800/50 transition-all cursor-pointer group"
                      >
                        <div className="w-9 h-9 rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700 text-[#075985] dark:text-sky-400 flex items-center justify-center shrink-0 group-hover:bg-[#075985] group-hover:text-white transition-all">
                          <Icon size={16} strokeWidth={1.85} />
                        </div>

                        <div className="flex-1 min-w-0 leading-tight">
                          <div className="flex items-center justify-between gap-2 mb-0.5">
                            <span className="text-xs font-bold text-slate-900 dark:text-white truncate group-hover:text-[#075985] dark:group-hover:text-sky-400 transition-colors">
                              {item.title}
                            </span>
                            <span className="text-[10px] font-mono font-medium text-slate-400 dark:text-slate-500 shrink-0">
                              {item.category}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                            {item.desc}
                          </p>
                        </div>

                        <ChevronRight
                          size={14}
                          className="text-slate-400 group-hover:translate-x-0.5 group-hover:text-[#075985] transition-all shrink-0"
                        />
                      </button>
                    );
                  })}
                </div>
              </section>

              {/* DIRECTRIZ CLÍNICA RÁPIDA */}
              <div className="clinical-card p-4 flex items-center gap-3 text-xs text-slate-600 dark:text-slate-400">
                <span className="w-2 h-2 rounded-full bg-[#075985] dark:bg-sky-400 shrink-0" />
                <p className="leading-snug">
                  Priorice en box el manejo de craving (15 min), el tamizaje de criterios DSM-5 (PAI ≥6 criterios) y la profilaxis con Tiamina 100-300 mg antes del cierre de evolución en Rayen.
                </p>
              </div>
            </div>
          )}
        </div>
      )}

      {/* =========================================================================
          MODAL DE CONFIRMACIÓN EXPLÍCITA PARA OPERACIONES EN GOOGLE TASKS API
         ========================================================================= */}
      {confirmModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="clinical-card max-w-md w-full overflow-hidden shadow-xl animate-fadeIn">
            <div className="clinical-glass-header px-5 py-3.5 flex items-center justify-between">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900 dark:text-white">
                {confirmModal.title}
              </h4>
              <button
                type="button"
                onClick={() => setConfirmModal(null)}
                disabled={isExecutingAction}
                className="text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X size={15} />
              </button>
            </div>

            <div className="p-5 space-y-4">
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                {confirmModal.description}
              </p>

              <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200/80 dark:border-slate-700 space-y-1.5">
                {confirmModal.details.map((detail, idx) => (
                  <div
                    key={idx}
                    className="text-xs text-slate-700 dark:text-slate-200 font-medium leading-snug"
                  >
                    {detail}
                  </div>
                ))}
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => setConfirmModal(null)}
                  disabled={isExecutingAction}
                  className="px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={async () => {
                    await confirmModal.onConfirm();
                    setConfirmModal(null);
                  }}
                  disabled={isExecutingAction}
                  className={`px-4 py-2 rounded-xl text-xs font-semibold text-white flex items-center gap-1.5 cursor-pointer disabled:opacity-50 ${
                    confirmModal.variant === "danger"
                      ? "bg-rose-600 hover:bg-rose-700"
                      : "bg-[#075985] hover:bg-[#0c4a6e]"
                  }`}
                >
                  {isExecutingAction && <RefreshCw size={13} className="animate-spin" />}
                  <span>{confirmModal.confirmLabel}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
