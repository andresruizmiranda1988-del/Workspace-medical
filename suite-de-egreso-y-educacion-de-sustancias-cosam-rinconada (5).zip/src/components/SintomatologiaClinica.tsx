import { useState } from "react";
import { SINTOMAS_CLINICOS_DATA } from "../data/symptomsData";
import { SintomaClinicoCard } from "../types";
import { motion, AnimatePresence } from "motion/react";
import {
  TrendingDown,
  Droplets,
  CalendarX,
  Shield,
  Sparkles,
  Smile,
  UtensilsCrossed,
  Brain,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Search,
  Stethoscope,
  ChevronRight
} from "lucide-react";

export default function SintomatologiaClinica() {
  const [selectedCard, setSelectedCard] = useState<SintomaClinicoCard>(SINTOMAS_CLINICOS_DATA[0]);
  const [selectedCategory, setSelectedCategory] = useState<string>("Todas");
  const [searchFilter, setSearchFilter] = useState<string>("" );

  const getIcon = (name: string) => {
    switch (name) {
      case "TrendingDown": return <TrendingDown size={18} />;
      case "Droplets": return <Droplets size={18} />;
      case "CalendarX": return <CalendarX size={18} />;
      case "Shield": return <Shield size={18} />;
      case "Sparkles": return <Sparkles size={18} />;
      case "Smile": return <Smile size={18} />;
      case "UtensilsCrossed": return <UtensilsCrossed size={18} />;
      default: return <Brain size={18} />;
    }
  };

  const categories = ["Todas", "Fisico", "Metabolico", "Psiquico", "Dermatologico", "Reproductivo", "Bucodental"];

  const filteredCards = SINTOMAS_CLINICOS_DATA.filter((c) => {
    const matchesCat = selectedCategory === "Todas" || c.categoria === selectedCategory;
    const matchesSearch =
      !searchFilter.trim() ||
      c.titulo.toLowerCase().includes(searchFilter.toLowerCase()) ||
      c.subtitulo.toLowerCase().includes(searchFilter.toLowerCase()) ||
      c.descripcion.toLowerCase().includes(searchFilter.toLowerCase());
    return matchesCat && matchesSearch;
  });

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* BANNER PRINCIPAL */}
      <section className="liquid-glass rounded-3xl p-6 md:p-8 shadow-sm border border-purple-200/70 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-2.5 h-full bg-gradient-to-b from-purple-700 via-indigo-600 to-slate-900"></div>
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="bg-purple-100 text-purple-900 border border-purple-200 text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-lg">
                Semiología y Banderas Rojas
              </span>
              <span className="text-slate-500 text-xs font-semibold">• Monitoreo por Cuadros Clínicos</span>
            </div>
            <h2 className="text-xl md:text-2xl font-black text-slate-900 tracking-tight">
              Tablero de Sintomatologías Clínicas Comunes en Adicciones
            </h2>
            <p className="text-xs md:text-sm text-slate-700 font-medium max-w-3xl mt-1 leading-relaxed">
              Explore los principales cuadros de deterioro físico, metabólico, psíquico y reproductivo asociados al consumo. Cada tarjeta incluye fisiopatología, signos de alarma urgentes, tiempos de reversibilidad y pautas de manejo en box.
            </p>
          </div>
        </div>
      </section>

      {/* FILTROS Y BÚSQUEDA */}
      <div className="flex flex-col md:flex-row gap-3">
        <div className="flex-1 relative">
          <Search className="absolute left-4 top-3.5 text-slate-400" size={16} />
          <input
            type="text"
            value={searchFilter}
            onChange={(e) => setSearchFilter(e.target.value)}
            placeholder="Filtrar síntoma (ej. 'amenorrea', 'pérdida de peso', 'anemia', 'dientes', 'paranoia')..."
            className="w-full pl-11 pr-4 py-3 bg-white/90 border border-purple-200/80 rounded-2xl text-xs font-semibold text-slate-800 focus:ring-2 focus:ring-purple-600 focus:border-purple-600 outline-none shadow-2xs placeholder:text-slate-400"
          />
        </div>

        <div className="flex flex-wrap gap-1.5 liquid-glass p-1.5 rounded-2xl border border-purple-200/70 shadow-2xs overflow-x-auto">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
                selectedCategory === cat
                  ? "bg-gradient-to-r from-purple-700 to-slate-900 text-white shadow-sm led-glow-purple font-black"
                  : "text-slate-700 hover:text-slate-950 hover:bg-white/80"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* CONTENIDO EN 2 COLUMNAS: TARJETAS A LA IZQUIERDA Y DETALLE A LA DERECHA */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* LISTA DE TARJETAS */}
        <div className="lg:col-span-5 space-y-3">
          {filteredCards.map((card) => {
            const isSelected = selectedCard.id === card.id;
            return (
              <button
                key={card.id}
                onClick={() => setSelectedCard(card)}
                className={`w-full text-left p-4 rounded-3xl border transition-all flex items-start justify-between gap-3 ${
                  isSelected
                    ? "bg-white border-purple-600 shadow-md ring-2 ring-purple-200/60 led-glow-purple"
                    : "liquid-glass hover:bg-white border-purple-200/60 hover:border-purple-300"
                }`}
              >
                <div className="flex items-start gap-3">
                  <div className={`w-9 h-9 rounded-2xl ${isSelected ? "bg-gradient-to-br from-purple-700 to-slate-900 text-white led-glow-purple" : "bg-purple-100/90 text-purple-800 border border-purple-200/60"} flex items-center justify-center shrink-0 shadow-sm mt-0.5`}>
                    {getIcon(card.icono)}
                  </div>
                  <div>
                    <span className="text-[9px] font-black uppercase tracking-widest text-purple-700 block">
                      {card.categoria}
                    </span>
                    <h4 className="text-xs font-black text-slate-900 leading-snug">
                      {card.titulo}
                    </h4>
                    <p className="text-[11px] text-slate-600 line-clamp-1 mt-0.5 font-medium">
                      {card.subtitulo}
                    </p>
                  </div>
                </div>
                <ChevronRight
                  size={16}
                  className={`shrink-0 mt-2 transition-transform ${
                    isSelected ? "text-purple-700 translate-x-0.5" : "text-slate-400"
                  }`}
                />
              </button>
            );
          })}
        </div>

        {/* DETALLE COMPLETO DEL SÍNTOMA SELECCIONADO */}
        <div className="lg:col-span-7">
          <AnimatePresence mode="wait">
            <motion.div
              key={selectedCard.id}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.2 }}
              className="bg-white/95 backdrop-blur-md rounded-3xl p-6 md:p-8 shadow-sm border border-purple-200/80 space-y-6"
            >
              {/* Header */}
              <div className="flex items-start justify-between border-b border-purple-100 pb-5">
                <div className="flex items-center gap-3.5">
                  <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-purple-700 to-slate-900 text-white flex items-center justify-center shadow-md shrink-0 led-glow-purple border border-purple-300/30">
                    {getIcon(selectedCard.icono)}
                  </div>
                  <div>
                    <span className="text-[10px] font-black uppercase tracking-widest bg-purple-100 text-purple-900 border border-purple-200 px-2.5 py-0.5 rounded-md">
                      {selectedCard.categoria}
                    </span>
                    <h3 className="text-lg md:text-xl font-black text-slate-900 mt-1">
                      {selectedCard.titulo}
                    </h3>
                    <p className="text-xs text-slate-600 font-medium">
                      {selectedCard.subtitulo}
                    </p>
                  </div>
                </div>
              </div>

              {/* Descripción & Fisiopatología */}
              <div className="space-y-3">
                <div className="p-4 bg-slate-50/90 rounded-2xl border border-slate-200 text-xs text-slate-800 font-medium leading-relaxed">
                  <span className="text-[10px] font-black text-slate-500 uppercase tracking-wider block mb-1">
                    Descripción del Cuadro:
                  </span>
                  {selectedCard.descripcion}
                </div>

                <div className="p-4 liquid-glass-purple rounded-2xl border border-purple-300/80 text-xs text-purple-950 font-medium leading-relaxed led-glow-purple">
                  <span className="text-[10px] font-black text-purple-900 uppercase tracking-wider block mb-1">
                    Mecanismo Fisiopatológico Clínico:
                  </span>
                  {selectedCard.fisiopatologiaExplicada}
                </div>
              </div>

              {/* Signos de Alarma */}
              <div className="space-y-2">
                <span className="text-[10px] font-black text-rose-800 uppercase tracking-wider flex items-center gap-1.5">
                  <AlertTriangle size={14} className="text-rose-600" /> Banderas Rojas / Signos de Alarma Inmediata:
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {selectedCard.signosDeAlarma.map((s, idx) => (
                    <div
                      key={idx}
                      className="p-3 bg-rose-50/80 border border-rose-200 rounded-xl text-xs font-semibold text-rose-950 flex items-start gap-2"
                    >
                      <span className="w-1.5 h-1.5 rounded-full bg-rose-600 shrink-0 mt-1.5"></span>
                      <span className="leading-tight">{s}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Cómo se revierte y tiempo */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 bg-emerald-50/80 border border-emerald-200 rounded-2xl space-y-1.5">
                  <span className="text-[10px] font-black text-emerald-900 uppercase tracking-wider flex items-center gap-1.5">
                    <CheckCircle2 size={13} className="text-emerald-700" /> ¿Cómo se Revierte este Cuadro?
                  </span>
                  <p className="text-xs text-emerald-950 font-medium leading-relaxed">
                    {selectedCard.comoSeRevierte}
                  </p>
                </div>

                <div className="p-4 bg-slate-50/90 border border-slate-200 rounded-2xl space-y-1.5 flex flex-col justify-between">
                  <div>
                    <span className="text-[10px] font-black text-slate-600 uppercase tracking-wider flex items-center gap-1.5">
                      <Clock size={13} className="text-purple-700" /> Tiempo Estimado de Recuperación:
                    </span>
                    <p className="text-xs font-bold text-slate-800 mt-1">
                      {selectedCard.tiempoEstimado}
                    </p>
                  </div>

                  <div>
                    <span className="text-[9px] font-black text-slate-500 uppercase tracking-wider block mb-1">
                      Nutrientes Clave:
                    </span>
                    <div className="flex flex-wrap gap-1">
                      {selectedCard.nutrientesClave.map((n, idx) => (
                        <span
                          key={idx}
                          className="px-2 py-0.5 bg-purple-100 text-purple-900 border border-purple-200 text-[10px] font-bold rounded-md"
                        >
                          {n}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Intervención en Box */}
              <div className="p-4 bg-slate-900/95 backdrop-blur-md text-white rounded-2xl border border-slate-700/80 space-y-1.5 led-glow-purple">
                <span className="text-[10px] font-black text-purple-300 uppercase tracking-widest flex items-center gap-1.5">
                  <Stethoscope size={13} className="text-purple-400" /> Intervención Psiquiátrica &amp; Médica en Box (COSAM):
                </span>
                <p className="text-xs text-slate-200 font-medium leading-relaxed">
                  {selectedCard.intervencionEnBox}
                </p>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
