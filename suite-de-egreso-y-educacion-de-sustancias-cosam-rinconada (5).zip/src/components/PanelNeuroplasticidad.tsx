import { useState } from "react";
import { motion } from "motion/react";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid,
  Cell,
  ReferenceLine
} from "recharts";
import {
  Brain,
  Activity,
  Heart,
  Users,
  Moon,
  Apple,
  Sparkles,
  Flame,
  Shield,
  Stethoscope,
  Lightbulb,
  CheckCircle2,
  Printer,
  ChevronRight,
  Sliders,
  TrendingUp,
  RefreshCw,
  Info,
  Dna,
  Zap,
  BarChart2
} from "lucide-react";

interface FactoresSimulacion {
  mesesAbstinencia: number; // 0 a 24 meses
  ejercicioFisico: number; // 0 (sedentario), 1 (1-2x/sem), 2 (150 min/sem OMS), 3 (intenso)
  apoyoSocial: number; // 0 (aislado), 1 (familiar básico), 2 (taller grupal COSAM), 3 (red integral)
  nutricionYSueño: number; // 0 (insomnio/dieta proinflamatoria), 1 (regular), 2 (pauta microrrehabilitación)
}

export default function PanelNeuroplasticidad() {
  const [activeView, setActiveView] = useState<"cronologia" | "simulador_factores" | "pet_volkow">("simulador_factores");

  // Factores interactivos del simulador
  const [factores, setFactores] = useState<FactoresSimulacion>({
    mesesAbstinencia: 6,
    ejercicioFisico: 2,
    apoyoSocial: 2,
    nutricionYSueño: 2
  });

  // Datos cronológicos de recuperación estándar (Evidencia Volkow / Koob)
  const cronologiaData = [
    {
      etapa: "Consumo Activo",
      tiempo: "Día 0",
      densidadD2: 25,
      bdnf: 20,
      frenoPrefrontal: 15,
      resistenciaCraving: 10,
      color: "#e11d48"
    },
    {
      etapa: "Desintox. Aguda",
      tiempo: "1-2 Semanas",
      densidadD2: 32,
      bdnf: 30,
      frenoPrefrontal: 22,
      resistenciaCraving: 20,
      color: "#f97316"
    },
    {
      etapa: "Ventana Crítica",
      tiempo: "1-2 Meses",
      densidadD2: 48,
      bdnf: 45,
      frenoPrefrontal: 40,
      resistenciaCraving: 38,
      color: "#eab308"
    },
    {
      etapa: "Neurogénesis",
      tiempo: "3-6 Meses",
      densidadD2: 68,
      bdnf: 72,
      frenoPrefrontal: 62,
      resistenciaCraving: 60,
      color: "#8b5cf6"
    },
    {
      etapa: "Remodelación",
      tiempo: "12-14 Meses",
      densidadD2: 85,
      bdnf: 88,
      frenoPrefrontal: 80,
      resistenciaCraving: 82,
      color: "#06b6d4"
    },
    {
      etapa: "Sostén COSAM",
      tiempo: "24+ Meses",
      densidadD2: 95,
      bdnf: 96,
      frenoPrefrontal: 92,
      resistenciaCraving: 94,
      color: "#10b981"
    }
  ];

  // Cálculo de recuperación multivariable en tiempo real basado en neurobiología
  // Abstinencia base: aporta hasta 55%
  // Ejercicio físico (BDNF): aporta hasta +20%
  // Apoyo social (Tampón de estrés / Oxitocina): aporta hasta +15%
  // Nutrición & Sueño (Cofactores dopaminérgicos y depuración glinfática): aporta hasta +10%
  const baseAbstinenciaScore = Math.min(
    65,
    20 + (Math.log(factores.mesesAbstinencia + 1) / Math.log(25)) * 45
  );

  const bonusEjercicio = factores.ejercicioFisico * 6.5; // max 19.5%
  const bonusApoyo = factores.apoyoSocial * 5.0; // max 15%
  const bonusNutricion = factores.nutricionYSueño * 5.0; // max 10%

  const totalD2 = Math.min(100, Math.round(baseAbstinenciaScore + bonusEjercicio * 0.7 + bonusApoyo * 0.6 + bonusNutricion * 0.7));
  const totalBDNF = Math.min(100, Math.round(18 + (factores.mesesAbstinencia * 1.5) + bonusEjercicio * 1.6 + bonusApoyo * 0.4 + bonusNutricion * 0.6));
  const totalFreno = Math.min(100, Math.round(15 + (factores.mesesAbstinencia * 2.0) + bonusEjercicio * 0.8 + bonusApoyo * 1.4 + bonusNutricion * 0.5));
  const totalResistencia = Math.min(100, Math.round(12 + (factores.mesesAbstinencia * 2.2) + bonusEjercicio * 0.7 + bonusApoyo * 1.3 + bonusNutricion * 0.8));

  // Datos comparativos para el gráfico de barras del simulador
  const comparativaFactoresData = [
    {
      indicador: "Densidad Receptores D2 (Estriado)",
      soloAbstinencia: Math.round(baseAbstinenciaScore),
      conMultimodalCOSAM: totalD2,
      diferencia: totalD2 - Math.round(baseAbstinenciaScore),
      meta: "100% Control Sano"
    },
    {
      indicador: "Factor BDNF (Fertilizante Cerebral)",
      soloAbstinencia: Math.round(20 + factores.mesesAbstinencia * 1.8),
      conMultimodalCOSAM: totalBDNF,
      diferencia: totalBDNF - Math.round(20 + factores.mesesAbstinencia * 1.8),
      meta: "100% Control Sano"
    },
    {
      indicador: "Control Ejecutivo Prefrontal (Freno)",
      soloAbstinencia: Math.round(18 + factores.mesesAbstinencia * 2.1),
      conMultimodalCOSAM: totalFreno,
      diferencia: totalFreno - Math.round(18 + factores.mesesAbstinencia * 2.1),
      meta: "100% Control Sano"
    },
    {
      indicador: "Resistencia al Craving & Autocontrol",
      soloAbstinencia: Math.round(15 + factores.mesesAbstinencia * 2.2),
      conMultimodalCOSAM: totalResistencia,
      diferencia: totalResistencia - Math.round(15 + factores.mesesAbstinencia * 2.2),
      meta: "100% Control Sano"
    }
  ];

  // Aportes individuales de cada pilar en el gráfico de composición
  const pilaresData = [
    {
      pilar: "Abstinencia Sostenida",
      porcentaje: Math.round(baseAbstinenciaScore * 0.5),
      descripcion: "Permite la desensibilización y el repliegue del daño tóxico.",
      color: "#8b5cf6"
    },
    {
      pilar: "Ejercicio Aeróbico",
      porcentaje: Math.round(bonusEjercicio * 1.2),
      descripcion: "Secreta BDNF, estimula la neurogénesis en el hipocampo y oxigena la microvasculatura.",
      color: "#06b6d4"
    },
    {
      pilar: "Apoyo Social & Grupo COSAM",
      porcentaje: Math.round(bonusApoyo * 1.3),
      descripcion: "Reduce el cortisol (estrés alostático), libera oxitocina y refuerza la identidad protectora.",
      color: "#10b981"
    },
    {
      pilar: "Nutrición & Sueño Profundo",
      porcentaje: Math.round(bonusNutricion * 1.4),
      descripcion: "Aporta L-Tirosina, antioxidantes (NAC) y activa el sistema glinfático nocturno.",
      color: "#f59e0b"
    }
  ];

  const handlePrintPlan = () => {
    window.print();
  };

  return (
    <div className="space-y-8 animate-fadeIn pb-10">
      {/* HEADER BANNER CON IDENTIDAD INSTITUCIONAL */}
      <section className="liquid-glass rounded-3xl p-6 md:p-8 border border-purple-200/80 shadow-md relative overflow-hidden">
        <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-teal-500 via-purple-600 to-indigo-600 led-glow-purple"></div>

        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
          <div className="space-y-2 max-w-3xl">
            <div className="flex flex-wrap items-center gap-2">
              <span className="bg-teal-100 text-teal-900 border border-teal-200 text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-lg">
                Neuroplasticidad &amp; Regeneración Sináptica
              </span>
              <span className="text-slate-500 text-xs font-semibold flex items-center gap-1">
                <Stethoscope size={13} className="text-purple-600" /> Dr. Andrés Felipe Ruiz Miranda • COSAM Rinconada de San Ramón
              </span>
              <span className="bg-purple-100 text-purple-900 text-[10px] font-extrabold px-2.5 py-0.5 rounded-md border border-purple-200">
                Evidencia Nora Volkow &amp; George Koob
              </span>
            </div>

            <h2 className="text-2xl md:text-3xl font-black text-slate-900 tracking-tight">
              Panel de <span className="bg-gradient-to-r from-purple-700 via-indigo-600 to-teal-700 bg-clip-text text-transparent">Neuroplasticidad &amp; Recuperación</span> de Receptores D2
            </h2>

            <p className="text-xs md:text-sm text-slate-700 font-medium leading-relaxed">
              Herramienta visual para demostrar al paciente la maleabilidad del cerebro: cómo la suma de <strong>abstinencia</strong>, <strong>actividad física aeróbica</strong>, <strong>vínculo grupal en COSAM</strong> y <strong>microrrehabilitación</strong> acelera exponencialmente la densidad de receptores dopaminérgicos y el control prefrontal.
            </p>
          </div>

          {/* VISTAS SELECTOR */}
          <div className="liquid-glass-dark p-2 rounded-2xl border border-slate-700/80 shrink-0 flex flex-wrap gap-1.5 shadow-lg w-full sm:w-auto">
            <button
              onClick={() => setActiveView("simulador_factores")}
              className={`px-3.5 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center gap-1.5 ${
                activeView === "simulador_factores"
                  ? "bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-md led-pulse-purple"
                  : "bg-slate-800/80 text-slate-300 hover:bg-slate-700"
              }`}
            >
              <BarChart2 size={14} />
              <span>Simulador Multimodal</span>
            </button>

            <button
              onClick={() => setActiveView("cronologia")}
              className={`px-3.5 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center gap-1.5 ${
                activeView === "cronologia"
                  ? "bg-gradient-to-r from-teal-600 to-indigo-600 text-white shadow-md led-pulse-teal"
                  : "bg-slate-800/80 text-slate-300 hover:bg-slate-700"
              }`}
            >
              <TrendingUp size={14} />
              <span>Cronología de D2</span>
            </button>

            <button
              onClick={() => setActiveView("pet_volkow")}
              className={`px-3.5 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center gap-1.5 ${
                activeView === "pet_volkow"
                  ? "bg-gradient-to-r from-indigo-600 to-slate-900 text-white shadow-md border border-indigo-400/40"
                  : "bg-slate-800/80 text-slate-300 hover:bg-slate-700"
              }`}
            >
              <Brain size={14} />
              <span>PET Scan Cerebral</span>
            </button>
          </div>
        </div>
      </section>

      {/* VISTA 1: SIMULADOR MULTIMODAL CON GRÁFICO DE BARRAS COMPARATIVO */}
      {activeView === "simulador_factores" && (
        <div className="space-y-6">
          {/* SLIDERS Y SELECTORES DE FACTORES TERAPÉUTICOS */}
          <div className="liquid-glass rounded-3xl p-6 border border-purple-200/80 shadow-md">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-purple-100 pb-4 mb-6">
              <div className="flex items-center gap-2">
                <Sliders size={18} className="text-purple-700" />
                <h3 className="text-sm font-black uppercase tracking-wider text-slate-900">
                  Moduladores del Tratamiento en COSAM (Ajuste los parámetros para ver el impacto):
                </h3>
              </div>
              <span className="text-[11px] font-bold text-slate-500">
                Puntaje Estimado de Neuroplasticidad: <strong className="text-purple-800 text-sm font-black">{totalBDNF}%</strong>
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
              {/* FACTOR 1: TIEMPO DE ABSTINENCIA */}
              <div className="p-4 bg-purple-50/70 rounded-2xl border border-purple-200/70 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-purple-950 uppercase flex items-center gap-1.5">
                    <Shield size={14} className="text-purple-700" /> Abstinencia
                  </span>
                  <span className="text-xs font-black bg-purple-200 text-purple-900 px-2 py-0.5 rounded-md">
                    {factores.mesesAbstinencia} {factores.mesesAbstinencia === 1 ? "mes" : "meses"}
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="24"
                  step="1"
                  value={factores.mesesAbstinencia}
                  onChange={(e) =>
                    setFactores({ ...factores, mesesAbstinencia: Number(e.target.value) })
                  }
                  className="w-full h-2 bg-purple-200 rounded-lg appearance-none cursor-pointer accent-purple-700"
                />
                <p className="text-[10px] text-slate-600 font-medium">
                  {factores.mesesAbstinencia < 3
                    ? "Fase de desintoxicación y alto riesgo de rebote."
                    : factores.mesesAbstinencia < 12
                    ? "Ventana activa de regeneración dendrítica."
                    : "Consolidación de nuevos circuitos y plasticidad sólida."}
                </p>
              </div>

              {/* FACTOR 2: ACTIVIDAD FÍSICA AERÓBICA */}
              <div className="p-4 bg-teal-50/70 rounded-2xl border border-teal-200/70 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-teal-950 uppercase flex items-center gap-1.5">
                    <Activity size={14} className="text-teal-700" /> Ejercicio (BDNF)
                  </span>
                  <span className="text-xs font-black bg-teal-200 text-teal-900 px-2 py-0.5 rounded-md">
                    {factores.ejercicioFisico === 0
                      ? "Sedentario"
                      : factores.ejercicioFisico === 1
                      ? "Ligero (1-2x/sem)"
                      : factores.ejercicioFisico === 2
                      ? "Regular (150m OMS)"
                      : "Intenso (>200m)"}
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="3"
                  step="1"
                  value={factores.ejercicioFisico}
                  onChange={(e) =>
                    setFactores({ ...factores, ejercicioFisico: Number(e.target.value) })
                  }
                  className="w-full h-2 bg-teal-200 rounded-lg appearance-none cursor-pointer accent-teal-700"
                />
                <p className="text-[10px] text-slate-600 font-medium">
                  El cardio eleva el BDNF sérico en un 200-300%, actuando como fertilizante para crear nuevas espinas dendríticas.
                </p>
              </div>

              {/* FACTOR 3: APOYO SOCIAL & GRUPO COSAM */}
              <div className="p-4 bg-indigo-50/70 rounded-2xl border border-indigo-200/70 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-indigo-950 uppercase flex items-center gap-1.5">
                    <Users size={14} className="text-indigo-700" /> Vínculo &amp; Grupo
                  </span>
                  <span className="text-xs font-black bg-indigo-200 text-indigo-900 px-2 py-0.5 rounded-md">
                    {factores.apoyoSocial === 0
                      ? "Aislamiento"
                      : factores.apoyoSocial === 1
                      ? "Familiar Básico"
                      : factores.apoyoSocial === 2
                      ? "Taller COSAM"
                      : "Red Sólida"}
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="3"
                  step="1"
                  value={factores.apoyoSocial}
                  onChange={(e) =>
                    setFactores({ ...factores, apoyoSocial: Number(e.target.value) })
                  }
                  className="w-full h-2 bg-indigo-200 rounded-lg appearance-none cursor-pointer accent-indigo-700"
                />
                <p className="text-[10px] text-slate-600 font-medium">
                  La contención grupal y la oxitocina mitigan el CRF (factor liberador de corticotropina) en la amígdala extendida.
                </p>
              </div>

              {/* FACTOR 4: NUTRICIÓN & SUEÑO PROFUNDO */}
              <div className="p-4 bg-amber-50/70 rounded-2xl border border-amber-200/70 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-amber-950 uppercase flex items-center gap-1.5">
                    <Apple size={14} className="text-amber-700" /> Nutrición &amp; Sueño
                  </span>
                  <span className="text-xs font-black bg-amber-200 text-amber-900 px-2 py-0.5 rounded-md">
                    {factores.nutricionYSueño === 0
                      ? "Deficiente"
                      : factores.nutricionYSueño === 1
                      ? "Estándar"
                      : "Microrreh. Full"}
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="2"
                  step="1"
                  value={factores.nutricionYSueño}
                  onChange={(e) =>
                    setFactores({ ...factores, nutricionYSueño: Number(e.target.value) })
                  }
                  className="w-full h-2 bg-amber-200 rounded-lg appearance-none cursor-pointer accent-amber-700"
                />
                <p className="text-[10px] text-slate-600 font-medium">
                  Aporte de L-Tirosina, Magnesio, Complejo B y depuración glinfática durante el sueño delta profundo.
                </p>
              </div>
            </div>
          </div>

          {/* GRÁFICO PRINCIPAL DE BARRAS: ABSTINENCIA SOLA VS INTERVENCIÓN MULTIMODAL COSAM */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-8 liquid-glass rounded-3xl p-6 md:p-8 border border-purple-200/80 shadow-md space-y-6">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-purple-100 pb-4">
                <div>
                  <h3 className="text-base font-black text-slate-900">
                    Impacto Comparativo: Abstinencia Pasiva vs. Tratamiento Multimodal COSAM
                  </h3>
                  <p className="text-xs text-slate-600 font-medium">
                    Porcentaje de recuperación biológica alcanzado a los <strong>{factores.mesesAbstinencia} meses</strong>
                  </p>
                </div>

                <div className="flex items-center gap-4 text-xs font-bold">
                  <div className="flex items-center gap-1.5">
                    <div className="w-3 h-3 rounded bg-slate-400"></div>
                    <span className="text-slate-600">Abstinencia Sola</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <div className="w-3 h-3 rounded bg-gradient-to-r from-purple-600 to-teal-500"></div>
                    <span className="text-purple-900 font-black">Plan Integral COSAM</span>
                  </div>
                </div>
              </div>

              {/* BAR CHART RECHARTS */}
              <div className="h-80 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={comparativaFactoresData}
                    margin={{ top: 20, right: 20, left: -10, bottom: 25 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" opacity={0.7} />
                    <XAxis
                      dataKey="indicador"
                      tick={{ fill: "#475569", fontSize: 11, fontWeight: 700 }}
                      interval={0}
                      tickFormatter={(val) => val.split("(")[0]}
                    />
                    <YAxis
                      domain={[0, 100]}
                      tick={{ fill: "#475569", fontSize: 11, fontWeight: 600 }}
                      unit="%"
                    />
                    <Tooltip
                      content={({ active, payload, label }) => {
                        if (active && payload && payload.length) {
                          return (
                            <div className="bg-slate-900 text-white p-3.5 rounded-2xl shadow-xl border border-purple-500/40 text-xs space-y-1.5">
                              <p className="font-black text-purple-300">{label}</p>
                              <div className="flex justify-between gap-4 text-slate-300">
                                <span>Abstinencia Sola:</span>
                                <strong className="text-slate-100">{payload[0]?.value}%</strong>
                              </div>
                              <div className="flex justify-between gap-4 text-teal-300">
                                <span>Plan Integral COSAM:</span>
                                <strong className="text-teal-200 font-black">{payload[1]?.value}%</strong>
                              </div>
                              <div className="pt-1.5 border-t border-slate-700 text-[11px] text-amber-300 font-bold">
                                Ganancia por Multimodalidad: +{Number(payload[1]?.value) - Number(payload[0]?.value)}%
                              </div>
                            </div>
                          );
                        }
                        return null;
                      }}
                    />
                    <ReferenceLine y={100} stroke="#10b981" strokeDasharray="3 3" label={{ value: "Nivel Sano (100%)", fill: "#10b981", fontSize: 10, position: "top" }} />
                    <Bar
                      dataKey="soloAbstinencia"
                      name="Abstinencia Pasiva"
                      fill="#94a3b8"
                      radius={[8, 8, 0, 0]}
                    />
                    <Bar
                      dataKey="conMultimodalCOSAM"
                      name="Plan Multimodal COSAM"
                      fill="url(#colorMultimodal)"
                      radius={[8, 8, 0, 0]}
                    />
                    <defs>
                      <linearGradient id="colorMultimodal" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#7c3aed" stopOpacity={0.95} />
                        <stop offset="100%" stopColor="#0d9488" stopOpacity={0.85} />
                      </linearGradient>
                    </defs>
                  </BarChart>
                </ResponsiveContainer>
              </div>

              {/* DIÁLOGO EN BOX DEL DR. RUIZ MIRANDA */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-purple-50 via-teal-50/50 to-indigo-50 border border-purple-200 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-purple-900 uppercase flex items-center gap-1.5">
                    <Lightbulb size={15} className="text-amber-600" /> Perla de Explicación en Box (Dr. Andrés Felipe Ruiz Miranda):
                  </span>
                  <span className="text-[10px] font-bold text-slate-500">COSAM Rinconada de San Ramón</span>
                </div>
                <p className="text-xs text-slate-800 font-medium leading-relaxed">
                  &quot;El tiempo limpia las sustancias del cuerpo, pero <strong>el ejercicio, la terapia grupal y la buena alimentación son los albañiles que reconstruyen los receptores D2</strong>. Sin estos pilares, la recuperación tarda el doble. Con ellos, el cerebro vuelve a sentir placer con la vida cotidiana en la mitad del tiempo.&quot;
                </p>
              </div>
            </div>

            {/* PANEL DERECHO: DESGLOSE DE PILARES & ACCIONES RECOMENDADAS */}
            <div className="lg:col-span-4 space-y-5">
              {/* TARJETA DE PILARES */}
              <div className="liquid-glass rounded-3xl p-5 md:p-6 border border-purple-200/80 shadow-sm space-y-4">
                <div className="flex items-center gap-2 border-b border-purple-100 pb-3">
                  <Dna size={16} className="text-purple-700" />
                  <h4 className="text-xs font-black uppercase tracking-wider text-slate-900">
                    Aporte a la Neuroplasticidad Total
                  </h4>
                </div>

                <div className="space-y-3">
                  {pilaresData.map((item, idx) => (
                    <div key={idx} className="p-3 bg-white/90 rounded-2xl border border-purple-100 space-y-1.5 shadow-2xs">
                      <div className="flex justify-between items-center text-xs">
                        <span className="font-black text-slate-800">{item.pilar}</span>
                        <span className="font-black text-purple-700">+{item.porcentaje}%</span>
                      </div>
                      <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                        <div
                          className="h-full rounded-full transition-all duration-500"
                          style={{
                            width: `${Math.min(100, item.porcentaje * 2.5)}%`,
                            backgroundColor: item.color
                          }}
                        ></div>
                      </div>
                      <p className="text-[10px] text-slate-500 font-medium leading-tight">
                        {item.descripcion}
                      </p>
                    </div>
                  ))}
                </div>

                <button
                  onClick={handlePrintPlan}
                  className="w-full py-2.5 px-4 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center justify-center gap-2 shadow-md"
                >
                  <Printer size={14} /> Imprimir Plan de Neuroplasticidad
                </button>
              </div>

              {/* RECOMENDACIONES CLÍNICAS COSAM */}
              <div className="p-4 bg-emerald-50/90 rounded-3xl border border-emerald-200 space-y-2">
                <h5 className="text-xs font-black text-emerald-950 uppercase flex items-center gap-1.5">
                  <CheckCircle2 size={14} className="text-emerald-700" /> Prescripción Neurobiológica Activa:
                </h5>
                <ul className="text-[11px] text-emerald-900 space-y-1.5 font-medium">
                  <li>• Caminata rápida o trote 30 min 4 veces por semana.</li>
                  <li>• Asistencia semanal al taller de psicoterapia en COSAM.</li>
                  <li>• Tomar suplementación de Tirosina / NAC según pauta médica.</li>
                  <li>• Rutina de higiene del sueño para maximizar hormona de crecimiento y BDNF.</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* VISTA 2: CRONOLOGÍA DETALLADA DE RECEPTORES D2 (VOLKOW DATA) */}
      {activeView === "cronologia" && (
        <div className="space-y-6">
          <div className="liquid-glass rounded-3xl p-6 md:p-8 border border-purple-200/80 shadow-md space-y-6">
            <div className="border-b border-purple-100 pb-4">
              <h3 className="text-base font-black text-slate-900">
                Línea de Tiempo de la Densidad de Receptores Dopaminérgicos D2 en el Estriado
              </h3>
              <p className="text-xs text-slate-600 font-medium">
                Evolución documentada en estudios de tomografía por emisión de positrones (PET Scan) a lo largo de 24 meses de abstinencia y tratamiento.
              </p>
            </div>

            {/* GRÁFICO DE BARRAS DE CRONOLOGÍA */}
            <div className="h-80 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={cronologiaData} margin={{ top: 20, right: 20, left: -10, bottom: 25 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" opacity={0.7} />
                  <XAxis dataKey="etapa" tick={{ fill: "#475569", fontSize: 11, fontWeight: 700 }} />
                  <YAxis domain={[0, 100]} tick={{ fill: "#475569", fontSize: 11, fontWeight: 600 }} unit="%" />
                  <Tooltip
                    content={({ active, payload, label }) => {
                      if (active && payload && payload.length) {
                        const data = payload[0]?.payload;
                        return (
                          <div className="bg-slate-900 text-white p-3.5 rounded-2xl shadow-xl border border-purple-500/40 text-xs space-y-1.5">
                            <p className="font-black text-purple-300">{label} ({data?.tiempo})</p>
                            <div className="text-emerald-300 font-bold">
                              Densidad D2: {data?.densidadD2}% del valor basal
                            </div>
                            <div className="text-teal-300 font-bold">
                              Nivel BDNF: {data?.bdnf}%
                            </div>
                            <div className="text-indigo-300 font-bold">
                              Freno Prefrontal: {data?.frenoPrefrontal}%
                            </div>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Bar dataKey="densidadD2" radius={[8, 8, 0, 0]}>
                    {cronologiaData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* TARJETAS DE HITOS CRONOLÓGICOS */}
            <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-3 pt-2">
              {cronologiaData.map((etapa, idx) => (
                <div
                  key={idx}
                  className="p-3.5 rounded-2xl border text-left space-y-1.5 transition-all bg-white shadow-2xs"
                  style={{ borderColor: `${etapa.color}40` }}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black text-slate-500">{etapa.tiempo}</span>
                    <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: etapa.color }}></span>
                  </div>
                  <h5 className="text-xs font-black text-slate-900 leading-tight">{etapa.etapa}</h5>
                  <div className="text-xs font-black" style={{ color: etapa.color }}>
                    D2: {etapa.densidadD2}%
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* VISTA 3: MODELO PET SCAN CEREBRAL (NORA VOLKOW) */}
      {activeView === "pet_volkow" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 liquid-glass rounded-3xl p-6 md:p-8 border border-purple-200/80 shadow-md space-y-6">
            <div className="border-b border-purple-100 pb-4">
              <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                <Brain className="text-purple-700" size={20} />
                Visualización PET Scan: Fijación del Radioligando [11C]Raclopride
              </h3>
              <p className="text-xs text-slate-600 font-medium">
                Modelo basado en los hallazgos de Nora Volkow, MD (NIDA / NIH) sobre la recuperación de receptores D2 en el estriado.
              </p>
            </div>

            {/* REPRESENTACIÓN GRÁFICA DEL CORTE TRANSVERSAL PET */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {/* CORTE 1: CONTROL SANO */}
              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 text-center space-y-3">
                <span className="text-[10px] font-black uppercase tracking-wider text-emerald-400 block">
                  Cerebro Sano Control
                </span>
                <div className="w-24 h-24 mx-auto rounded-full bg-slate-900 border border-slate-700 flex items-center justify-center relative overflow-hidden">
                  <div className="w-14 h-14 rounded-full bg-gradient-to-r from-red-500 via-orange-500 to-yellow-400 blur-xs shadow-lg shadow-red-500/50"></div>
                </div>
                <div className="text-[11px] font-black text-emerald-300">
                  Alta Densidad D2 (100%)
                </div>
                <p className="text-[9.5px] text-slate-400 leading-tight">
                  Señal intensa en cuerpo estriado bilateral (rojo y amarillo brillante).
                </p>
              </div>

              {/* CORTE 2: CONSUMO ACTIVO */}
              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 text-center space-y-3">
                <span className="text-[10px] font-black uppercase tracking-wider text-rose-400 block">
                  1 Mes Abstinencia (Agudo)
                </span>
                <div className="w-24 h-24 mx-auto rounded-full bg-slate-900 border border-slate-700 flex items-center justify-center relative overflow-hidden">
                  <div className="w-8 h-8 rounded-full bg-purple-900/60 blur-xs"></div>
                </div>
                <div className="text-[11px] font-black text-rose-300">
                  Down-Regulation Severa (25%)
                </div>
                <p className="text-[9.5px] text-slate-400 leading-tight">
                  Ausencia casi total de señal. El cerebro no responde al placer natural.
                </p>
              </div>

              {/* CORTE 3: 14 MESES DE ABSTINENCIA Y COSAM */}
              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 text-center space-y-3">
                <span className="text-[10px] font-black uppercase tracking-wider text-teal-400 block">
                  14 Meses + Terapia COSAM
                </span>
                <div className="w-24 h-24 mx-auto rounded-full bg-slate-900 border border-slate-700 flex items-center justify-center relative overflow-hidden">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-r from-orange-600 via-amber-500 to-yellow-400 blur-xs shadow-md shadow-orange-500/40"></div>
                </div>
                <div className="text-[11px] font-black text-teal-300">
                  Regeneración Significativa (85%)
                </div>
                <p className="text-[9.5px] text-slate-400 leading-tight">
                  Re-expresión masiva de receptores D2. Retorno de la capacidad de goce cotidiano.
                </p>
              </div>
            </div>

            <div className="p-4 bg-purple-50 rounded-2xl border border-purple-200 text-xs text-purple-950 font-medium">
              <strong>Mensaje Terapéutico Clave:</strong> El daño no es permanente. El cerebro humano conserva plasticidad para remodelar sus sinapsis independientemente de la severidad del consumo previo.
            </div>
          </div>

          <div className="lg:col-span-5 space-y-5">
            <div className="liquid-glass rounded-3xl p-6 border border-purple-200/80 shadow-md space-y-4">
              <h4 className="text-xs font-black uppercase tracking-wider text-slate-900 flex items-center gap-1.5">
                <Sparkles size={16} className="text-purple-700" />
                Mecanismos de Regeneración Sináptica:
              </h4>

              <div className="space-y-3 text-xs text-slate-700">
                <div className="p-3 bg-white rounded-xl border border-purple-100">
                  <strong className="text-purple-900 block mb-0.5">1. Neurogénesis Hipocampal:</strong>
                  Estimulada directamente por el ejercicio aeróbico regular, aumentando el volumen de la circunvolución dentada.
                </div>

                <div className="p-3 bg-white rounded-xl border border-purple-100">
                  <strong className="text-indigo-900 block mb-0.5">2. Depuración de $\Delta$FosB:</strong>
                  El factor de transcripción patológico que perpetúa el craving se degrada gradualmente durante los primeros 6 a 12 meses de abstinencia.
                </div>

                <div className="p-3 bg-white rounded-xl border border-purple-100">
                  <strong className="text-teal-900 block mb-0.5">3. Re-sintonización del Freno Frontal:</strong>
                  La psicoterapia cognitiva y el entrenamiento en contención de crisis (App Pausa y Control) fortalecen los axones córtico-estriatales.
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
