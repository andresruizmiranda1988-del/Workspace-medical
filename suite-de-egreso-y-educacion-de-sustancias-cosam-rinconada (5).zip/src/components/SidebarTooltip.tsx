import React from "react";
import { motion, AnimatePresence } from "motion/react";
import { LucideIcon } from "lucide-react";

export interface TooltipItemInfo {
  id: string;
  label: string;
  sub: string;
  quickDesc: string;
  badge?: string;
  icon?: LucideIcon | any;
  orderNumber?: string;
  groupName?: string;
  isSpecial?: boolean;
}

export interface SidebarTooltipProps {
  item: TooltipItemInfo | null;
  position: { top: number; left: number } | null;
}

export const SidebarTooltip: React.FC<SidebarTooltipProps> = ({ item, position }) => {
  return (
    <AnimatePresence>
      {item && position && (
        <motion.div
          key={item.id}
          initial={{ opacity: 0, x: -6, scale: 0.98 }}
          animate={{ opacity: 1, x: 0, scale: 1 }}
          exit={{ opacity: 0, x: -4, scale: 0.98 }}
          transition={{ duration: 0.15, ease: "easeOut" }}
          style={{
            top: `${position.top}px`,
            left: `${position.left}px`,
            transform: "translateY(-50%)",
          }}
          className="fixed z-50 pointer-events-none hidden lg:block w-72 max-w-xs"
        >
          <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-lg text-slate-800 dark:text-slate-100">
            {/* Encabezado */}
            <div className="flex items-start justify-between gap-2 pb-2 mb-2 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2 min-w-0">
                {item.icon && (
                  <div className="w-6 h-6 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 flex items-center justify-center shrink-0">
                    <item.icon size={13} strokeWidth={1.75} />
                  </div>
                )}
                <div className="min-w-0 leading-tight">
                  <div className="text-xs font-semibold text-slate-900 dark:text-white truncate">
                    {item.label}
                  </div>
                  <div className="text-[10px] text-slate-500 dark:text-slate-400 truncate">
                    {item.sub}
                  </div>
                </div>
              </div>

              {item.badge && (
                <span className="shrink-0 text-[9px] font-medium px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                  {item.badge}
                </span>
              )}
            </div>

            {/* Descripción breve */}
            <p className="text-[11px] leading-relaxed text-slate-600 dark:text-slate-300">
              {item.quickDesc}
            </p>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
