import { motion, AnimatePresence } from "motion/react";
import {
  Keyboard,
  X,
  Copy,
  Lock,
  EyeOff,
  Tv2,
  Battery,
  Moon,
  Maximize2,
  CheckCircle2,
  Sparkles
} from "lucide-react";

interface ModalAtajosTecladoProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function ModalAtajosTeclado({ isOpen, onClose }: ModalAtajosTecladoProps) {
  if (!isOpen) return null;

  const hotkeyGroups = [
    {
      title: "Atajos de 1-Clic para Rayen APS",
      items: [
        {
          keys: ["Alt", "1"],
          desc: "Copiar Registro de FUC & Abstinencia continua",
          tag: "FUC Rayen",
          icon: Copy
        },
        {
          keys: ["Alt", "2"],
          desc: "Copiar Protocolo Terapia Aversiva Disulfiram",
          tag: "Disulfiram",
          icon: Copy
        },
        {
          keys: ["Alt", "3"],
          desc: "Copiar Examen Mental & Ritmos Biológicos",
          tag: "Ex. Mental",
          icon: Copy
        },
        {
          keys: ["Alt", "4"],
          desc: "Copiar Microrrehabilitación & Nutrición Metabólica",
          tag: "Nutrición",
          icon: Copy
        },
        {
          keys: ["Alt", "5"],
          desc: "Copiar Evolución SOAP Integral de Box Médico",
          tag: "SOAP Completo",
          icon: Copy
        }
      ]
    },
    {
      title: "Control del Box & Privacidad del Paciente",
      items: [
        {
          keys: ["Alt", "A"],
          desc: "Modo Docencia / Anonimización rápida (Oculta RUT y Nombres en pantalla)",
          tag: "Privacidad",
          icon: EyeOff
        },
        {
          keys: ["Alt", "P"],
          desc: "Alternar a Vista Paciente / Modo Psicoeducación Box",
          tag: "Psicoeducación",
          icon: Tv2
        },
        {
          keys: ["Ctrl", "L"],
          desc: "Bloquear pantalla del box con PIN (Privacidad al salir del box)",
          tag: "Seguridad",
          icon: Lock
        },
        {
          keys: ["Alt", "B"],
          desc: "Modo Ahorro de Batería (Desactiva animaciones y blurs en Tablet)",
          tag: "Autonomía",
          icon: Battery
        },
        {
          keys: ["Alt", "N"],
          desc: "Alternar Modo Noche Clínico (Alto contraste y descanso visual)",
          tag: "Ergonomía",
          icon: Moon
        },
        {
          keys: ["Alt", "F"],
          desc: "Alternar Pantalla Completa (Maximiza área visible en tablet)",
          tag: "Visual",
          icon: Maximize2
        }
      ]
    }
  ];

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 10 }}
          className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto overflow-x-hidden text-slate-900 dark:text-slate-100"
        >
          {/* Encabezado */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-850">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-purple-600 dark:bg-purple-500 text-white flex items-center justify-center shadow-xs">
                <Keyboard size={18} />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white leading-tight">
                  Atajos Rápidos de Teclado (Power User)
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Acelere la atención en box sin alternar constantemente entre ratón y teclado
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white hover:bg-slate-200/60 dark:hover:bg-slate-800 transition-colors"
              title="Cerrar (Esc)"
            >
              <X size={18} />
            </button>
          </div>

          {/* Contenido de los atajos */}
          <div className="p-6 space-y-6">
            {hotkeyGroups.map((group, gIdx) => (
              <div key={gIdx} className="space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-purple-700 dark:text-purple-300 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-purple-600 dark:bg-purple-400" />
                  {group.title}
                </h4>

                <div className="grid grid-cols-1 gap-2.5">
                  {group.items.map((item, iIdx) => {
                    const Icon = item.icon;
                    return (
                      <div
                        key={iIdx}
                        className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-750 hover:border-purple-300 dark:hover:border-purple-700 transition-colors"
                      >
                        <div className="flex items-center gap-3">
                          <Icon size={16} className="text-purple-600 dark:text-purple-400 shrink-0" />
                          <div>
                            <p className="text-xs font-semibold text-slate-900 dark:text-slate-100">
                              {item.desc}
                            </p>
                            <span className="text-[10px] text-slate-500 dark:text-slate-400">
                              {item.tag}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-1 shrink-0 ml-3">
                          {item.keys.map((k, kIdx) => (
                            <kbd
                              key={kIdx}
                              className="px-2.5 py-1 text-[11px] font-mono font-bold text-slate-800 dark:text-slate-200 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-2xs"
                            >
                              {k}
                            </kbd>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}

            <div className="p-3.5 rounded-xl bg-purple-50 dark:bg-purple-950/40 border border-purple-200/80 dark:border-purple-900/60 flex items-center gap-3">
              <CheckCircle2 size={18} className="text-purple-600 dark:text-purple-400 shrink-0" />
              <p className="text-xs text-purple-900 dark:text-purple-200">
                <strong>Consejo clínico:</strong> Todos los atajos de 1-Clic copian el texto directamente al portapapeles y muestran una confirmación sonora/visual instantánea para pegar en Rayen APS con <kbd className="px-1.5 py-0.5 text-[10px] font-mono bg-white dark:bg-slate-800 border rounded">Ctrl + V</kbd>.
              </p>
            </div>
          </div>

          {/* Pie de modal */}
          <div className="flex justify-end px-6 py-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-850">
            <button
              onClick={onClose}
              className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold rounded-xl transition-colors shadow-xs"
            >
              Entendido
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
