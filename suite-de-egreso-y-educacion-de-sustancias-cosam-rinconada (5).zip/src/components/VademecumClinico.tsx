export { VademecumClinico, type PrintDocumentData } from "./clinical/VademecumClinico";
