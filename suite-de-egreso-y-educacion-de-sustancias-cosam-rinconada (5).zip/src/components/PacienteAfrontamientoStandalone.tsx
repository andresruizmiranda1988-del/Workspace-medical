import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  ShieldCheck,
  PhoneCall,
  Moon,
  Sun,
  Volume2,
  VolumeX,
  Sparkles,
  Share2,
  Copy,
  CheckCircle2,
  Compass,
  Wind,
  Waves,
  HeartHandshake,
  ArrowLeft,
  Smartphone,
  ExternalLink,
  Info,
  Building2,
  QrCode,
  Check
} from "lucide-react";
import GatillantesYAfrontamiento from "./GatillantesYAfrontamiento";
import { unlockAudioEngine, playTherapeuticTone, speakTherapeuticVoice } from "../utils/audioGuide";

interface PacienteAfrontamientoStandaloneProps {
  onExitPatientMode?: () => void;
  isNightMode: boolean;
  onToggleNightMode: () => void;
}

export default function PacienteAfrontamientoStandalone({
  onExitPatientMode,
  isNightMode,
  onToggleNightMode
}: PacienteAfrontamientoStandaloneProps) {
  const [isAudioReady, setIsAudioReady] = useState<boolean>(false);
  const [copiedLink, setCopiedLink] = useState<boolean>(false);
  const [isSosModalOpen, setIsSosModalOpen] = useState<boolean>(false);
  const [isQrModalOpen, setIsQrModalOpen] = useState<boolean>(false);

  // Desbloqueo pasivo de audio al primer tap/click en dispositivo móvil
  useEffect(() => {
    const handleTap = () => {
      unlockAudioEngine();
      setIsAudioReady(true);
    };
    window.addEventListener("touchstart", handleTap, { once: true });
    window.addEventListener("click", handleTap, { once: true });
    return () => {
      window.removeEventListener("touchstart", handleTap);
      window.removeEventListener("click", handleTap);
    };
  }, []);

  const handleManualUnlockAudio = () => {
    unlockAudioEngine();
    setIsAudioReady(true);
    playTherapeuticTone("ding");
    speakTherapeuticVoice(
      "Guía de audio activada. Respira suave y acompáñate en este momento de calma."
    );
  };

  const patientUrl =
    typeof window !== "undefined"
      ? `${window.location.origin}/paciente?modulo=afrontamiento`
      : "https://cosam-rinconada.cl/paciente?modulo=afrontamiento";

  const handleCopyPatientLink = () => {
    if (typeof navigator !== "undefined" && navigator.clipboard) {
      navigator.clipboard.writeText(patientUrl);
      setCopiedLink(true);
      playTherapeuticTone("ding");
      setTimeout(() => setCopiedLink(false), 2500);
    }
  };

  const handleShareWhatsApp = () => {
    const message = encodeURIComponent(
      `Guardo mi Guía Móvil de Calma y Afrontamiento SOS de COSAM Rinconada:\n${patientUrl}`
    );
    window.open(`https://api.whatsapp.com/send?text=${message}`, "_blank");
  };

  return (
    <div className="min-h-screen bg-ambient-light text-slate-900 dark:text-slate-100 flex flex-col font-sans select-none antialiased relative overflow-x-hidden">
      {/* Glow Ambient Lights Relajantes de Fondo */}
      <div className="fixed top-0 left-1/4 w-96 h-96 bg-purple-500/10 dark:bg-purple-600/15 rounded-full blur-3xl pointer-events-none -z-10" />
      <div className="fixed top-1/3 right-10 w-80 h-80 bg-indigo-500/10 dark:bg-indigo-600/15 rounded-full blur-3xl pointer-events-none -z-10" />
      <div className="fixed bottom-10 left-10 w-96 h-96 bg-cyan-500/10 dark:bg-cyan-600/15 rounded-full blur-3xl pointer-events-none -z-10" />

      {/* =========================================================================
          TOP HEADER EXCLUSIVO PARA EL PACIENTE: LIMPIO, SERENO Y PREMIUM
         ========================================================================= */}
      <header className="sticky top-0 z-30 liquid-glass border-b border-purple-200/80 dark:border-purple-900/50 shadow-xs px-3 sm:px-6 py-2.5 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto w-full flex items-center justify-between gap-2 sm:gap-4">
          {/* Logo e Identificación Institucional */}
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-2xl bg-gradient-to-br from-purple-700 via-indigo-600 to-purple-900 text-white flex items-center justify-center shadow-md border border-white/20 shrink-0">
              <ShieldCheck size={20} />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-[9px] font-black uppercase tracking-wider text-purple-900 dark:text-purple-300 bg-purple-100 dark:bg-purple-950/80 border border-purple-200 dark:border-purple-800 px-2 py-0.2 rounded-full">
                  COSAM Rinconada
                </span>
                <span className="text-[9px] font-bold px-1.5 py-0.2 rounded-full bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
                  Guía Móvil
                </span>
              </div>
              <h1 className="text-xs sm:text-sm font-black text-slate-900 dark:text-white leading-tight">
                Gatillantes &amp; Afrontamiento SOS
              </h1>
            </div>
          </div>

          {/* Acciones Rápidas del Paciente */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            {/* BOTÓN SOS URGENCIA */}
            <button
              onClick={() => setIsSosModalOpen(true)}
              className="px-2.5 sm:px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 active:scale-95 text-white font-black text-xs shadow-md shadow-rose-600/30 flex items-center gap-1.5 transition-all"
              title="Líneas de ayuda gratuitas 24/7"
            >
              <PhoneCall size={14} className="animate-pulse" />
              <span className="text-[11px] font-black">SOS 1412</span>
            </button>

            {/* BOTÓN PROBAR/ACTIVAR AUDIO */}
            <button
              onClick={handleManualUnlockAudio}
              className={`p-2 sm:px-3 sm:py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 border shadow-xs ${
                isAudioReady
                  ? "bg-purple-100 dark:bg-purple-950/80 text-purple-900 dark:text-purple-200 border-purple-300 dark:border-purple-800"
                  : "bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700 hover:bg-purple-50"
              }`}
              title={isAudioReady ? "Audio Terapéutico Activado" : "Activar Voz y Sonido"}
            >
              <Volume2 size={15} className={isAudioReady ? "text-purple-600 dark:text-purple-400" : ""} />
              <span className="hidden md:inline">{isAudioReady ? "Audio Activo" : "Activar Audio"}</span>
            </button>

            {/* TOGGLE MODO DÍA / NOCHE */}
            <button
              onClick={onToggleNightMode}
              className="p-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors shadow-xs"
              title={isNightMode ? "Cambiar a Modo Día" : "Activar Modo Noche"}
            >
              {isNightMode ? <Sun size={15} className="text-amber-400" /> : <Moon size={15} className="text-purple-700" />}
            </button>

            {/* COMPARTIR O GUARDAR */}
            <button
              onClick={() => setIsQrModalOpen(true)}
              className="p-2 sm:px-3 sm:py-1.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors shadow-xs flex items-center gap-1"
              title="Guardar o compartir enlace"
            >
              <Share2 size={15} className="text-indigo-600 dark:text-indigo-400" />
              <span className="hidden sm:inline text-xs font-bold">Guardar</span>
            </button>

            {/* VOLVER A LA SUITE COMPLETA (OPCIÓN PROFESIONAL) */}
            {onExitPatientMode && (
              <button
                onClick={onExitPatientMode}
                className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white border border-slate-200 dark:border-slate-700 text-[11px] font-bold transition-all"
                title="Volver a la vista clínica completa"
              >
                <ArrowLeft size={13} />
                <span>Suite Médica</span>
              </button>
            )}
          </div>
        </div>
      </header>

      {/* =========================================================================
          BANNER TERAPÉUTICO SUPERIOR DE CALMA
         ========================================================================= */}
      <div className="max-w-7xl mx-auto w-full px-3 sm:px-6 pt-4 pb-1">
        <div className="p-3.5 sm:p-4 rounded-2xl bg-gradient-to-r from-purple-500/10 via-indigo-500/10 to-cyan-500/10 border border-purple-200/80 dark:border-purple-900/40 backdrop-blur-md flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-xs">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-purple-600/20 text-purple-700 dark:text-purple-300 flex items-center justify-center shrink-0">
              <Sparkles size={18} />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-800 dark:text-slate-200">
                Espacio de Apoyo &amp; Descompresión Personal
              </p>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Utiliza las técnicas de respiración, surfeo de impulsos y protocolo SOS en cualquier momento de necesidad.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
            <a
              href="tel:1412"
              className="px-3 py-1.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800 text-[11px] font-bold flex items-center gap-1 hover:bg-rose-100 transition-colors"
            >
              <PhoneCall size={12} />
              <span>Fono SENDA 1412 (Gratis 24/7)</span>
            </a>
          </div>
        </div>
      </div>

      {/* =========================================================================
          CONTENIDO PRINCIPAL: SOLO EL MÓDULO GATILLANTES & AFRONTAMIENTO
         ========================================================================= */}
      <main className="max-w-7xl mx-auto w-full px-3 sm:px-6 py-4 flex-1">
        <GatillantesYAfrontamiento isStandalonePatientView={true} />
      </main>

      {/* =========================================================================
          FOOTER INSTITUCIONAL DEL PACIENTE
         ========================================================================= */}
      <footer className="mt-auto border-t border-purple-100 dark:border-slate-800 py-6 px-4 bg-white/40 dark:bg-slate-900/40 backdrop-blur-md">
        <div className="max-w-7xl mx-auto w-full flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300 flex items-center justify-center font-bold">
              <Building2 size={16} />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-800 dark:text-slate-200">
                COSAM Rinconada de San Ramón
              </p>
              <p className="text-[10px] text-slate-500 dark:text-slate-400">
                Centro de Salud Mental Comunitario • Atención Primaria de Salud
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-4 text-xs font-bold text-slate-500 dark:text-slate-400">
            <span>Fono Drogas SENDA: <strong className="text-rose-600 dark:text-rose-400">1412</strong></span>
            <span>•</span>
            <span>Salud Responde: <strong className="text-purple-600 dark:text-purple-400">600 360 7777</strong></span>
          </div>
        </div>
      </footer>

      {/* =========================================================================
          MODAL DE LÍNEAS DE AYUDA Y CONTACTOS DE EMERGENCIA SOS
         ========================================================================= */}
      <AnimatePresence>
        {isSosModalOpen && (
          <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-md flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-slate-900 rounded-3xl p-6 max-w-md w-full border border-rose-200 dark:border-rose-900/60 shadow-2xl space-y-4"
            >
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-10 h-10 rounded-2xl bg-rose-500/20 text-rose-600 dark:text-rose-400 flex items-center justify-center">
                    <PhoneCall size={20} />
                  </div>
                  <div>
                    <h3 className="text-base font-black text-slate-900 dark:text-white">
                      Líneas Gratuitas de Ayuda 24/7
                    </h3>
                    <p className="text-xs text-slate-500">Orientación confidencial en cualquier momento</p>
                  </div>
                </div>
                <button
                  onClick={() => setIsSosModalOpen(false)}
                  className="p-1.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500"
                >
                  ✕
                </button>
              </div>

              <div className="space-y-3">
                <a
                  href="tel:1412"
                  className="p-4 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 flex items-center justify-between gap-3 hover:bg-rose-100 transition-colors group"
                >
                  <div>
                    <span className="text-[10px] font-black uppercase text-rose-700 dark:text-rose-400 block">
                      SENDA • GRATIS &amp; CONFIDENCIAL
                    </span>
                    <h4 className="text-lg font-black text-slate-900 dark:text-white group-hover:text-rose-600 transition-colors">
                      Fono Drogas: 1412
                    </h4>
                    <p className="text-xs text-slate-600 dark:text-slate-400">
                      Especialistas en adicciones y contención de crisis las 24 horas del día.
                    </p>
                  </div>
                  <div className="w-10 h-10 rounded-xl bg-rose-600 text-white flex items-center justify-center shrink-0 shadow-md">
                    <PhoneCall size={18} />
                  </div>
                </a>

                <a
                  href="tel:6003607777"
                  className="p-4 rounded-2xl bg-purple-50 dark:bg-purple-950/40 border border-purple-200 dark:border-purple-800 flex items-center justify-between gap-3 hover:bg-purple-100 transition-colors group"
                >
                  <div>
                    <span className="text-[10px] font-black uppercase text-purple-700 dark:text-purple-400 block">
                      MINISTERIO DE SALUD
                    </span>
                    <h4 className="text-lg font-black text-slate-900 dark:text-white group-hover:text-purple-600 transition-colors">
                      Salud Responde: 600 360 7777
                    </h4>
                    <p className="text-xs text-slate-600 dark:text-slate-400">
                      Orientación médica y psiquiátrica continua en toda la red de salud.
                    </p>
                  </div>
                  <div className="w-10 h-10 rounded-xl bg-purple-600 text-white flex items-center justify-center shrink-0 shadow-md">
                    <PhoneCall size={18} />
                  </div>
                </a>
              </div>

              <div className="pt-2 text-center">
                <button
                  onClick={() => setIsSosModalOpen(false)}
                  className="w-full py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-200 font-bold text-xs"
                >
                  Entendido, volver a las técnicas
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* =========================================================================
          MODAL DE GUARDAR Y COMPARTIR ENLACE
         ========================================================================= */}
      <AnimatePresence>
        {isQrModalOpen && (
          <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-md flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-slate-900 rounded-3xl p-6 max-w-md w-full border border-purple-200 dark:border-purple-800 shadow-2xl space-y-4"
            >
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold">
                    <Smartphone size={20} />
                  </div>
                  <div>
                    <h3 className="text-base font-black text-slate-900 dark:text-white">
                      Guardar en Mi Dispositivo
                    </h3>
                    <p className="text-xs text-slate-500">Accede rápidamente cada vez que lo necesites</p>
                  </div>
                </div>
                <button
                  onClick={() => setIsQrModalOpen(false)}
                  className="p-1.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500"
                >
                  ✕
                </button>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950/80 border border-slate-200 dark:border-slate-800 space-y-2 text-xs">
                <div className="flex items-center gap-2 text-purple-700 dark:text-purple-300 font-bold">
                  <Info size={16} />
                  <span>Cómo guardarlo en tu teléfono:</span>
                </div>
                <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                  1. En tu navegador (Chrome o Safari), pulsa el menú de <strong>tres puntos (⋮)</strong> o el botón <strong>Compartir</strong>.
                </p>
                <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                  2. Selecciona <strong>"Agregar a la pantalla principal"</strong> o <strong>"Añadir a marcadores"</strong>.
                </p>
                <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                  3. Quedará guardado como una app directa para usarla ante cualquier momento de ansiedad.
                </p>
              </div>

              <div className="space-y-2 pt-1">
                <button
                  onClick={handleCopyPatientLink}
                  className="w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-all"
                >
                  {copiedLink ? <Check size={16} /> : <Copy size={16} />}
                  <span>{copiedLink ? "¡Enlace Copiado al Portapapeles!" : "Copiar Enlace Directo"}</span>
                </button>

                <button
                  onClick={handleShareWhatsApp}
                  className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-all"
                >
                  <Share2 size={16} />
                  <span>Guardar o Enviar por WhatsApp</span>
                </button>
              </div>

              <div className="text-center pt-2 border-t border-slate-100 dark:border-slate-800">
                <button
                  onClick={() => setIsQrModalOpen(false)}
                  className="text-xs font-bold text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
                >
                  Cerrar
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
