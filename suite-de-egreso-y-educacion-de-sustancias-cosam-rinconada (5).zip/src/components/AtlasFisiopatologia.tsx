import { useState } from "react";
import { ATLAS_FISIOPATOLOGICO_DATA } from "../data/atlasData";
import { AtlasFisiopatologicoItem } from "../types";
import { motion, AnimatePresence } from "motion/react";
import {
  Flame,
  Scale,
  Sparkles,
  Activity,
  Droplets,
  HeartPulse,
  UtensilsCrossed,
  Shield,
  Search,
  Stethoscope,
  Pill,
  Leaf,
  Apple,
  ChevronRight
} from "lucide-react";

export default function AtlasFisiopatologia() {
  const [selectedItem, setSelectedItem] = useState<AtlasFisiopatologicoItem>(ATLAS_FISIOPATOLOGICO_DATA[0]);
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [categoryFilter, setCategoryFilter] = useState<string>("Todas");

  const getIcon = (name: string) => {
    switch (name) {
      case "Flame": return <Flame size={18} />;
      case "Scale": return <Scale size={18} />;
      case "Sparkles": return <Sparkles size={18} />;
      case "Activity": return <Activity size={18} />;
      case "Droplets": return <Droplets size={18} />;
      case "HeartPulse": return <HeartPulse size={18} />;
      case "UtensilsCrossed": return <UtensilsCrossed size={18} />;
      default: return <Shield size={18} />;
    }
  };

  const categories = ["Todas", "Fisiopatología Base", "Dermatológico", "Musculoesquelético", "Endocrino", "Cardiovascular", "Digestivo"];

  const filteredItems = ATLAS_FISIOPATOLOGICO_DATA.filter((item) => {
    const matchesCat = categoryFilter === "Todas" || item.categoria === categoryFilter;
    const matchesSearch =
      !searchTerm.trim() ||
      item.titulo.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.sistema.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.descripcion.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.recommendations.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCat && matchesSearch;
  });

  return (
    <div className="space-y-6 animate-fadeIn pb-12 max-w-7xl mx-auto">
      {/* HEADER BANNER ESTILO iOS */}
      <section className="ios-card rounded-3xl p-6 md:p-7 border border-black/[0.04] dark:border-white/[0.06] shadow-sm relative overflow-hidden">
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 relative z-10">
          <div className="space-y-1.5 max-w-3xl">
            <div className="flex items-center gap-2">
              <span className="text-slate-700 dark:text-slate-300 bg-black/[0.04] dark:bg-white/[0.08] text-[11px] font-semibold px-2.5 py-0.5 rounded-full">
                Atlas Clínico &amp; Fisiopatología
              </span>
              <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                COSAM Rinconada · San Ramón
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white tracking-tight flex items-center gap-2.5">
              <Stethoscope className="text-slate-900 dark:text-white" size={24} />
              Atlas Clínico de Daño Fisiológico &amp; Manejo Integral
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 font-normal leading-relaxed">
              Mapeo de neuroinflamación, resistencia a insulina, alteraciones endocrinas y pautas de prescripción nutricional en box ambulatorio.
            </p>
          </div>

          <div className="bg-black/[0.04] dark:bg-white/[0.08] px-3.5 py-2 rounded-2xl text-slate-800 dark:text-slate-200 flex items-center gap-2 shrink-0 border border-black/[0.04] dark:border-white/[0.06]">
            <Shield size={15} className="text-slate-600 dark:text-slate-400" />
            <span className="text-xs font-semibold">Herramienta Médica</span>
          </div>
        </div>
      </section>

      {/* BUSCADOR Y FILTROS TIPO iOS */}
      <div className="flex flex-col md:flex-row gap-3 items-center">
        <div className="w-full md:flex-1 relative">
          <Search className="absolute left-4 top-3 text-slate-400" size={15} />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Buscar cuadro clínico (ej. 'insulina', 'neuroinflamación', 'alopecia', 'metformina')..."
            className="w-full pl-10 pr-4 py-2.5 ios-card rounded-2xl text-xs font-medium text-slate-800 dark:text-slate-200 outline-none border border-black/[0.05] dark:border-white/[0.08] focus:border-slate-900 dark:focus:border-white placeholder:text-slate-400"
          />
        </div>

        <div className="ios-segmented flex flex-wrap gap-1 shadow-3xs overflow-x-auto w-full md:w-auto">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setCategoryFilter(cat)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer whitespace-nowrap ${
                categoryFilter === cat
                  ? "bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-2xs"
                  : "text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* CUERPO EN 2 COLUMNAS: LISTADO Y DETALLE CLÍNICO */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* LISTADO DE CUADROS CLÍNICOS */}
        <div className="lg:col-span-5 space-y-2">
          {filteredItems.map((item) => {
            const isSelected = selectedItem.id === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setSelectedItem(item)}
                className={`w-full text-left p-3.5 rounded-2xl border transition-all flex items-start justify-between gap-3 cursor-pointer ${
                  isSelected
                    ? "bg-slate-900 text-white dark:bg-white dark:text-slate-900 border-slate-900 dark:border-white shadow-xs"
                    : "ios-card hover:bg-black/[0.02] dark:hover:bg-white/[0.04] border-black/[0.04] dark:border-white/[0.06]"
                }`}
              >
                <div className="flex items-start gap-3 min-w-0">
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center text-sm shrink-0 mt-0.5 ${
                      isSelected
                        ? "bg-white/20 dark:bg-slate-900/15 text-white dark:text-slate-900"
                        : "bg-black/[0.04] dark:bg-white/[0.06] text-slate-700 dark:text-slate-300"
                    }`}
                  >
                    {getIcon(item.icono)}
                  </div>
                  <div className="min-w-0">
                    <span className={`text-[9px] font-semibold uppercase tracking-wider block ${
                      isSelected ? "text-slate-300 dark:text-slate-600" : "text-slate-400 dark:text-slate-500"
                    }`}>
                      {item.categoria}
                    </span>
                    <h4 className="text-xs font-bold leading-snug truncate">
                      {item.titulo}
                    </h4>
                    <p className={`text-[11px] truncate mt-0.5 font-normal ${
                      isSelected ? "text-slate-300 dark:text-slate-600" : "text-slate-500 dark:text-slate-400"
                    }`}>
                      {item.sistema}
                    </p>
                  </div>
                </div>
                <ChevronRight
                  size={15}
                  className={`shrink-0 mt-2 transition-transform ${
                    isSelected ? "text-white dark:text-slate-900 translate-x-0.5" : "text-slate-400"
                  }`}
                />
              </button>
            );
          })}
        </div>

        {/* DETALLE CLÍNICO INTEGRAL */}
        <div className="lg:col-span-7">
          <AnimatePresence mode="wait">
            <motion.div
              key={selectedItem.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.18 }}
              className="ios-card rounded-3xl p-6 md:p-7 border border-black/[0.04] dark:border-white/[0.06] space-y-6 shadow-sm"
            >
              {/* Header del Síntoma */}
              <div className="border-b border-black/[0.04] dark:border-white/[0.06] pb-5">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-slate-900 dark:bg-white text-white dark:text-slate-900 flex items-center justify-center shrink-0 shadow-xs">
                    {getIcon(selectedItem.icono)}
                  </div>
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-[10px] font-semibold text-slate-700 dark:text-slate-300 bg-black/[0.04] dark:bg-white/[0.08] px-2.5 py-0.5 rounded-full">
                        {selectedItem.categoria}
                      </span>
                      <span className="text-xs font-medium text-slate-500 dark:text-slate-400">· {selectedItem.sistema}</span>
                    </div>
                    <h3 className="text-xl md:text-2xl font-bold text-slate-900 dark:text-white tracking-tight">
                      {selectedItem.titulo}
                    </h3>
                  </div>
                </div>
                <p className="text-xs md:text-sm text-slate-600 dark:text-slate-300 font-normal leading-relaxed mt-4 bg-black/[0.02] dark:bg-white/[0.04] p-4 rounded-2xl border border-black/[0.03] dark:border-white/[0.05]">
                  {selectedItem.descripcion}
                </p>
              </div>

              {/* 2 Columnas: Déficits & Nutrición vs Manejo Clínico Integral */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                {/* Columna Nutricional */}
                <div className="bg-rose-50/50 dark:bg-rose-950/20 p-5 rounded-2xl border border-rose-200/60 dark:border-rose-900/40 flex flex-col justify-between">
                  <div>
                    <h4 className="text-xs font-bold text-rose-900 dark:text-rose-300 uppercase tracking-wider mb-3 flex items-center gap-2">
                      <Apple size={15} className="text-rose-600" />
                      Déficits y Nutrición Crítica:
                    </h4>
                    <ul className="space-y-2.5">
                      {selectedItem.nutritionalCauses.map((cause, idx) => (
                        <li key={idx} className="flex items-start gap-2 text-xs text-rose-950 font-semibold leading-snug">
                          <span className="w-1.5 h-1.5 rounded-full bg-rose-600 shrink-0 mt-1.5"></span>
                          <span>{cause}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Columna Manejo Clínico Integral */}
                <div className="bg-black/[0.02] dark:bg-white/[0.04] p-5 rounded-2xl border border-black/[0.04] dark:border-white/[0.06] space-y-3 flex flex-col justify-between">
                  <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-2">
                    <Stethoscope size={15} className="text-slate-700 dark:text-slate-300" />
                    Manejo Clínico Integral:
                  </h4>

                  <div className="space-y-2 text-xs">
                    <div className="p-3 bg-white dark:bg-slate-800/80 rounded-xl border border-black/[0.04] dark:border-white/[0.06] shadow-3xs">
                      <span className="font-semibold text-slate-900 dark:text-white block mb-0.5 flex items-center gap-1.5">
                        <Pill size={12} className="text-indigo-600 dark:text-indigo-400" /> Farmacológico:
                      </span>
                      <p className="text-slate-600 dark:text-slate-300 font-normal leading-snug">
                        {selectedItem.medicalManagement.pharma}
                      </p>
                    </div>

                    <div className="p-3 bg-white dark:bg-slate-800/80 rounded-xl border border-black/[0.04] dark:border-white/[0.06] shadow-3xs">
                      <span className="font-semibold text-emerald-900 dark:text-emerald-300 block mb-0.5 flex items-center gap-1.5">
                        <Leaf size={12} className="text-emerald-600 dark:text-emerald-400" /> No Farmacológico / Hábitos:
                      </span>
                      <p className="text-slate-600 dark:text-slate-300 font-normal leading-snug">
                        {selectedItem.medicalManagement.nonPharma}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Recomendación Práctica Final */}
              <div className="bg-black/[0.03] dark:bg-white/[0.05] border border-black/[0.05] dark:border-white/[0.08] p-5 rounded-2xl space-y-1.5">
                <span className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-2">
                  <Sparkles size={14} className="text-amber-500" /> Prescripción Nutricional Práctica para el Paciente:
                </span>
                <p className="text-xs md:text-sm text-slate-700 dark:text-slate-300 font-medium leading-relaxed">
                  {selectedItem.recommendations}
                </p>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
