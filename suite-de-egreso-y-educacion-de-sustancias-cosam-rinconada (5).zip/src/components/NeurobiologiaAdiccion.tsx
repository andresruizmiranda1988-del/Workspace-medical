import { useState, useEffect } from "react";
import { ESTACIONES_CIRCUITO, NEUROTRANSMISORES_DATA, ETAPAS_CICLO_ADICCION, EstacionCircuitoExtendida } from "../data/neurobiologyData";
import { NeurotransmisorInfo } from "../types";
import SimuladorCircuitoRecompensa from "./SimuladorCircuitoRecompensa";
import PanelNeuroplasticidad from "./PanelNeuroplasticidad";
import { motion, AnimatePresence } from "motion/react";
import {
  Brain,
  Zap,
  Shield,
  Activity,
  Heart,
  Flame,
  Sliders,
  RefreshCw,
  CheckCircle2,
  AlertTriangle,
  Lightbulb,
  ArrowRight,
  Target,
  Bookmark,
  Volume2,
  VolumeX,
  Copy,
  Check,
  Layers,
  Sparkles,
  Compass,
  FileCheck,
  Dna,
  GitCommit
} from "lucide-react";

export default function NeurobiologiaAdiccion() {
  // Estado de carga para garantizar que el contenido esté completamente montado y listo antes de desplegar
  const [isContentReady, setIsContentReady] = useState(false);
  const [loadingStep, setLoadingStep] = useState("Cargando estaciones anatómicas y receptores...");

  const [selectedStation, setSelectedStation] = useState<EstacionCircuitoExtendida>(ESTACIONES_CIRCUITO[0]);
  const [selectedNeuro, setSelectedNeuro] = useState<NeurotransmisorInfo>(NEUROTRANSMISORES_DATA[0]);
  const [dopamineSimState, setDopamineSimState] = useState<"basal" | "pico" | "crash" | "recuperacion">("pico");
  const [activeSubTab, setActiveSubTab] = useState<"circuito" | "simulador" | "neuroplasticidad" | "neurotransmisores" | "dopamina" | "ciclo">("circuito");
  const [hierarchyFilter, setHierarchyFilter] = useState<"all" | "mesolimbica" | "mesocortical" | "limbico">("all");
  const [circuitViewMode, setCircuitViewMode] = useState<"cards_flow" | "detail_focus">("cards_flow");
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [isSpeaking, setIsSpeaking] = useState(false);

  // Simulación y garantía de carga completa estructurada
  useEffect(() => {
    const t1 = setTimeout(() => {
      setLoadingStep("Sincronizando mapeo neuronal de 5 niveles...");
    }, 150);

    const t2 = setTimeout(() => {
      setLoadingStep("Optimizando tarjetas interactivas y laboratorio sináptico...");
    }, 300);

    const t3 = setTimeout(() => {
      setIsContentReady(true);
    }, 450);

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
      if (window.speechSynthesis) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2500);
  };

  const handleSpeak = (text: string) => {
    if (!("speechSynthesis" in window)) return;
    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = "es-CL";
    utterance.rate = 0.95;
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);
    setIsSpeaking(true);
    window.speechSynthesis.speak(utterance);
  };

  const filteredStations = ESTACIONES_CIRCUITO.filter((station) => {
    if (hierarchyFilter === "all") return true;
    if (hierarchyFilter === "mesolimbica") return station.id === "vta" || station.id === "accumbens";
    if (hierarchyFilter === "mesocortical") return station.id === "vta" || station.id === "prefrontal";
    if (hierarchyFilter === "limbico") return station.id === "amigdala" || station.id === "hipocampo";
    return true;
  });

  const getStationIcon = (tipo: string, size = 18) => {
    switch (tipo) {
      case "zap": return <Zap size={size} className="text-amber-500" />;
      case "target": return <Target size={size} className="text-indigo-500" />;
      case "shield": return <Shield size={size} className="text-emerald-500" />;
      case "alert": return <AlertTriangle size={size} className="text-rose-500" />;
      case "bookmark": return <Bookmark size={size} className="text-purple-500" />;
      default: return <Brain size={size} className="text-purple-500" />;
    }
  };

  const getNeuroIcon = (name: string) => {
    switch (name) {
      case "Zap": return <Zap size={18} />;
      case "Shield": return <Shield size={18} />;
      case "Activity": return <Activity size={18} />;
      case "Heart": return <Heart size={18} />;
      case "Flame": return <Flame size={18} />;
      default: return <Brain size={18} />;
    }
  };

  // PANTALLA DE CARGA ROBUSTA: Garantiza que la interfaz no parpadee y esté lista al 100%
  if (!isContentReady) {
    return (
      <div className="min-h-[420px] liquid-glass rounded-3xl p-8 border border-indigo-500/25 flex flex-col items-center justify-center text-center space-y-4 shadow-xl led-glow-indigo">
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-indigo-600 to-purple-600 flex items-center justify-center text-white shadow-lg border border-indigo-400/40 led-glow-indigo">
          <Brain className="w-8 h-8 animate-pulse text-white" />
        </div>
        <div className="space-y-1 max-w-sm">
          <h3 className="text-xs font-black text-slate-900 dark:text-white uppercase tracking-widest">
            Inicializando Red Neurobiológica
          </h3>
          <p className="text-xs text-indigo-600 dark:text-indigo-400 font-semibold">{loadingStep}</p>
        </div>
        <div className="w-48 h-1.5 bg-black/[0.06] dark:bg-white/[0.08] rounded-full overflow-hidden">
          <div className="h-full bg-gradient-to-r from-indigo-500 via-purple-500 to-cyan-400 rounded-full animate-[progress_1s_ease-in-out_infinite]" style={{ width: "85%" }} />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fadeIn pb-12 max-w-7xl mx-auto">
      {/* BANNER PSICOEDUCATIVO SUPERIOR CON DISEÑO CYBER-CLÍNICO */}
      <section className="liquid-glass rounded-3xl p-6 md:p-8 shadow-xl border border-indigo-500/20 dark:border-indigo-400/20 relative overflow-hidden led-glow-indigo">
        <div className="absolute -right-16 -bottom-16 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-5 relative z-10">
          <div className="space-y-2 max-w-3xl">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-indigo-700 dark:text-indigo-300 bg-indigo-500/10 dark:bg-indigo-400/15 border border-indigo-500/20 text-[11px] font-bold px-3 py-0.5 rounded-full flex items-center gap-1.5 shadow-2xs">
                <Dna size={13} className="text-indigo-600 dark:text-indigo-400" /> Bases Neurobiológicas
              </span>
              <span className="text-slate-400 dark:text-slate-500 text-xs font-semibold">COSAM Rinconada · San Ramón</span>
              <span className="text-[11px] text-emerald-700 dark:text-emerald-300 font-bold bg-emerald-500/15 border border-emerald-500/25 px-2.5 py-0.5 rounded-full flex items-center gap-1.5 led-glow-emerald">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 led-pulse-emerald" />
                5 Estaciones Sinápticas
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white tracking-tight">
              Bases Neurobiológicas de la Adicción: El Circuito Secuestrado
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 font-medium leading-relaxed">
              La adicción es una alteración crónica de circuitos que compromete las 5 estaciones del sistema de recompensa, afectando el balance entre el deseo límbico y el control prefrontal.
            </p>
          </div>

          <div className="liquid-glass border border-indigo-500/25 p-4 rounded-2xl shrink-0 text-left max-w-xs shadow-md">
            <div className="flex items-center gap-1.5 text-indigo-700 dark:text-indigo-300 font-bold text-[11px] uppercase tracking-wider mb-1">
              <Sparkles size={14} className="text-amber-500" />
              <span>Premisa Clínica:</span>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-300 font-medium leading-snug">
              Comprender la base biológica del circuito disminuye la culpa patológica y fortalece la adherencia terapéutica del paciente.
            </p>
          </div>
        </div>
      </section>

      {/* SUB-TABS INTERACTIVOS PRINCIPALES (ESTILO CYBER-SEGMENTED) */}
      <nav className="liquid-glass p-1 rounded-2xl border border-indigo-500/20 dark:border-indigo-400/20 flex flex-wrap gap-1 shadow-md overflow-x-auto">
        {[
          { id: "circuito", label: "Circuito Anatómico", icon: Brain },
          { id: "simulador", label: "Simulador Sináptico", icon: Sliders },
          { id: "neuroplasticidad", label: "Neuroplasticidad & D2", icon: Activity },
          { id: "neurotransmisores", label: "Neurotransmisores", icon: Zap },
          { id: "dopamina", label: "Dinámica de Dopamina", icon: Sparkles },
          { id: "ciclo", label: "Ciclo Trifásico", icon: RefreshCw }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeSubTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveSubTab(tab.id as any)}
              className={`py-2 px-3.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap active:scale-95 ${
                isActive
                  ? "bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 dark:from-white dark:via-slate-100 dark:to-slate-200 text-white dark:text-slate-900 shadow-md led-glow-indigo border border-indigo-400/30"
                  : "text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-black/[0.04] dark:hover:bg-white/[0.06]"
              }`}
            >
              <Icon size={14} strokeWidth={isActive ? 2.4 : 2} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </nav>

      {/* ========================================================
          SUB-TAB 1: CIRCUITO DE RECOMPENSA (DISEÑO JERÁRQUICO)
         ======================================================== */}
      {activeSubTab === "circuito" && (
        <div className="space-y-6">
          {/* BARRA DE CONTROLES: FILTRO POR VÍA & MODO DE VISTA */}
          <div className="liquid-glass rounded-2xl p-4 border border-indigo-500/20 dark:border-indigo-400/20 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 shadow-md">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider flex items-center gap-1.5 mr-1">
                <Compass size={14} className="text-indigo-600 dark:text-indigo-400" />
                Vía Jerárquica:
              </span>
              {[
                { id: "all", label: "Todos los 5 Niveles" },
                { id: "mesolimbica", label: "Vía Mesolímbica (Acelerador)" },
                { id: "mesocortical", label: "Vía Mesocortical (Freno)" },
                { id: "limbico", label: "Circuito Límbico (Alarma & Memoria)" }
              ].map((f) => (
                <button
                  key={f.id}
                  onClick={() => setHierarchyFilter(f.id as any)}
                  className={`text-xs font-bold px-3 py-1.5 rounded-xl transition-all cursor-pointer active:scale-95 ${
                    hierarchyFilter === f.id
                      ? "bg-indigo-600 text-white led-glow-indigo border border-indigo-400/40"
                      : "bg-black/[0.04] dark:bg-white/[0.06] text-slate-700 dark:text-slate-300 hover:bg-black/[0.08] dark:hover:bg-white/[0.1] border border-black/[0.05] dark:border-white/[0.08]"
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>

            {/* Selector de modo de vista */}
            <div className="flex items-center gap-1 bg-black/[0.04] dark:bg-white/[0.06] p-1 rounded-xl shrink-0 self-end md:self-auto border border-black/[0.05] dark:border-white/[0.08]">
              <button
                onClick={() => setCircuitViewMode("cards_flow")}
                className={`text-xs font-bold px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-all cursor-pointer ${
                  circuitViewMode === "cards_flow"
                    ? "bg-white dark:bg-slate-800 text-indigo-700 dark:text-indigo-300 shadow-xs font-black"
                    : "text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
                }`}
              >
                <Layers size={13} />
                Tarjetas en Cascada
              </button>
              <button
                onClick={() => setCircuitViewMode("detail_focus")}
                className={`text-xs font-bold px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-all cursor-pointer ${
                  circuitViewMode === "detail_focus"
                    ? "bg-white dark:bg-slate-800 text-indigo-700 dark:text-indigo-300 shadow-xs font-black"
                    : "text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
                }`}
              >
                <Target size={13} />
                Foco &amp; Diálogo Clínico
              </button>
            </div>
          </div>

          {/* VISTA 1: TARJETAS EN CASCADA JERÁRQUICA */}
          {circuitViewMode === "cards_flow" && (
            <div className="space-y-5">
              {filteredStations.map((station, index) => {
                const isSelected = selectedStation.id === station.id;
                return (
                  <motion.div
                    key={station.id}
                    layout
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.25, delay: index * 0.05 }}
                    className={`liquid-glass rounded-3xl p-6 md:p-7 border transition-all relative overflow-hidden shadow-md ${
                      isSelected
                        ? "border-indigo-500/60 dark:border-indigo-400/60 led-glow-indigo ring-2 ring-indigo-500/20"
                        : "border-indigo-500/15 dark:border-indigo-400/15 hover:border-indigo-500/30"
                    }`}
                  >
                    {/* Indicador Jerárquico Lateral */}
                    <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-3 border-b border-indigo-500/10 dark:border-indigo-400/10 pb-4 mb-5">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-2xl bg-indigo-500/15 text-indigo-600 dark:text-indigo-300 border border-indigo-500/25 flex items-center justify-center shrink-0 shadow-xs">
                          {getStationIcon(station.iconoTipo, 20)}
                        </div>
                        <div>
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="text-[10px] font-black uppercase tracking-wider bg-indigo-500/10 dark:bg-indigo-400/15 text-indigo-700 dark:text-indigo-300 px-2.5 py-0.5 rounded-md border border-indigo-500/20">
                              {station.etiquetaJerarquia}
                            </span>
                            <span className="text-xs font-bold text-slate-400">
                              • {station.region}
                            </span>
                          </div>
                          <h3 className="text-base md:text-lg font-black text-slate-900 dark:text-white mt-1">
                            {station.nombre}
                          </h3>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 self-end md:self-auto">
                        <span className="text-[10px] font-extrabold uppercase px-2.5 py-1 bg-black/[0.04] dark:bg-white/[0.06] text-slate-700 dark:text-slate-300 rounded-lg border border-black/[0.05] dark:border-white/[0.08]">
                          Rol: {station.rolEnAdiccion}
                        </span>
                        <button
                          onClick={() => {
                            setSelectedStation(station);
                            setCircuitViewMode("detail_focus");
                          }}
                          className="text-xs font-bold text-indigo-700 dark:text-indigo-300 bg-indigo-500/10 hover:bg-indigo-500/20 px-3 py-1.5 rounded-xl border border-indigo-500/20 flex items-center gap-1 transition-all cursor-pointer active:scale-95"
                        >
                          Examinar Foco <ArrowRight size={13} />
                        </button>
                      </div>
                    </div>

                    {/* Contenido Modular Jerárquico: Función Normal vs. Secuestro */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                      <div className="bg-emerald-50/70 border border-emerald-200/80 p-4 rounded-2xl">
                        <div className="flex items-center gap-1.5 text-emerald-800 font-bold text-[11px] uppercase tracking-wider mb-2">
                          <CheckCircle2 size={14} className="text-emerald-600 shrink-0" />
                          <span>1. Función Fisiológica Normal</span>
                        </div>
                        <p className="text-xs text-emerald-950 font-medium leading-relaxed">
                          {station.funcionNormal}
                        </p>
                      </div>

                      <div className="bg-rose-50/70 border border-rose-200/80 p-4 rounded-2xl">
                        <div className="flex items-center gap-1.5 text-rose-800 font-bold text-[11px] uppercase tracking-wider mb-2">
                          <AlertTriangle size={14} className="text-rose-600 shrink-0" />
                          <span>2. El Secuestro por la Sustancia</span>
                        </div>
                        <p className="text-xs text-rose-950 font-medium leading-relaxed">
                          {station.secuestroAdiccion}
                        </p>
                      </div>
                    </div>

                    {/* Manifestación Conductual y Analogía para el Box */}
                    <div className="grid grid-cols-1 md:grid-cols-12 gap-4 pt-1">
                      <div className="md:col-span-6 bg-slate-50 border border-slate-200 p-4 rounded-2xl">
                        <span className="text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block mb-1.5">
                          Manifestación en la Consulta / Conducta:
                        </span>
                        <p className="text-xs text-slate-700 font-semibold leading-relaxed">
                          {station.manifestacionConductual}
                        </p>
                        <div className="mt-3 pt-3 border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-500">
                          <span className="font-bold">Reversibilidad celular:</span>
                          <span className="font-extrabold text-purple-700">{station.tiempoReversibilidad}</span>
                        </div>
                      </div>

                      <div className="md:col-span-6 bg-gradient-to-br from-purple-50 to-indigo-50 border border-purple-200 p-4 rounded-2xl flex flex-col justify-between">
                        <div>
                          <div className="flex items-center justify-between mb-1.5">
                            <span className="text-[10px] font-black text-purple-700 uppercase tracking-wider flex items-center gap-1.5">
                              <Sparkles size={13} /> Metáfora para Explicar en Box:
                            </span>
                            <div className="flex items-center gap-1">
                              <button
                                onClick={() => handleSpeak(station.analogiaPaciente)}
                                title="Escuchar metáfora"
                                className="p-1 rounded-lg text-purple-600 hover:bg-purple-200/60 transition-colors"
                              >
                                {isSpeaking ? <VolumeX size={14} /> : <Volume2 size={14} />}
                              </button>
                              <button
                                onClick={() => copyToClipboard(station.analogiaPaciente, station.id)}
                                title="Copiar analogía"
                                className="p-1 rounded-lg text-purple-600 hover:bg-purple-200/60 transition-colors flex items-center gap-1 text-[10px] font-bold"
                              >
                                {copiedId === station.id ? (
                                  <Check size={13} className="text-emerald-600" />
                                ) : (
                                  <Copy size={13} />
                                )}
                              </button>
                            </div>
                          </div>
                          <p className="text-xs font-bold text-purple-950 italic leading-relaxed">
                            &quot;{station.analogiaPaciente}&quot;
                          </p>
                        </div>

                        {/* Receptores Clave */}
                        <div className="mt-3 pt-2.5 border-t border-purple-200/60 flex flex-wrap items-center gap-1.5">
                          <span className="text-[10px] font-extrabold text-purple-800 uppercase">
                            Receptores:
                          </span>
                          {station.receptoresClave.map((rec, i) => (
                            <span
                              key={i}
                              className="text-[9px] font-extrabold bg-white/90 text-purple-900 border border-purple-200 px-2 py-0.5 rounded-md"
                            >
                              {rec}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          )}

          {/* VISTA 2: FOCO & DIÁLOGO CLÍNICO (SPLIT VIEW) */}
          {circuitViewMode === "detail_focus" && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Selector Lateral de los 5 Niveles */}
              <div className="lg:col-span-5 space-y-2.5">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[11px] font-black text-slate-400 uppercase tracking-wider">
                    Jerarquía de Niveles Anatómicos:
                  </span>
                  <span className="text-[10px] font-bold text-purple-600 bg-purple-50 px-2 py-0.5 rounded">
                    5 Estaciones
                  </span>
                </div>

                {ESTACIONES_CIRCUITO.map((st) => {
                  const isSelected = selectedStation.id === st.id;
                  return (
                    <button
                      key={st.id}
                      onClick={() => setSelectedStation(st)}
                      className={`w-full text-left p-4 rounded-2xl border transition-all flex items-center justify-between group ${
                        isSelected
                          ? "bg-white border-purple-500 shadow-md ring-2 ring-purple-100"
                          : "bg-white/80 border-purple-100/80 hover:bg-white hover:border-purple-200"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-xl bg-purple-50 border border-purple-100 flex items-center justify-center shrink-0">
                          {getStationIcon(st.iconoTipo, 16)}
                        </div>
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="text-[9px] font-black uppercase text-purple-600">
                              Nivel {st.nivelJerarquico}
                            </span>
                            <span className="text-[9px] font-semibold text-slate-400">
                              • {st.region}
                            </span>
                          </div>
                          <h4 className="text-xs font-bold text-slate-800 group-hover:text-purple-700 transition-colors">
                            {st.nombre}
                          </h4>
                        </div>
                      </div>
                      <ArrowRight
                        size={15}
                        className={`transition-transform shrink-0 ${
                          isSelected ? "text-purple-600 translate-x-1" : "text-slate-300 group-hover:text-slate-500"
                        }`}
                      />
                    </button>
                  );
                })}

                {/* Perla Clínica Rápida */}
                <div className="p-4 bg-amber-50/90 border border-amber-200 rounded-2xl mt-4">
                  <div className="flex items-center gap-2 text-amber-800 font-bold text-xs uppercase tracking-wider mb-1">
                    <Lightbulb size={14} className="text-amber-600 shrink-0" />
                    <span>Diálogo de 30 segundos en box:</span>
                  </div>
                  <p className="text-[11.5px] text-amber-950 leading-relaxed font-medium">
                    &quot;El cerebro tiene un acelerador (ATV y Accumbens) y un freno (Corteza Frontal). La sustancia rompe los cables del freno y pisa el acelerador a fondo. Nuestro tratamiento en COSAM Rinconada de San Ramón reconstruye el freno biológico.&quot;
                  </p>
                </div>
              </div>

              {/* Ficha Detallada de la Estación Seleccionada */}
              <div className="lg:col-span-7">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={selectedStation.id}
                    initial={{ opacity: 0, scale: 0.98 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.98 }}
                    transition={{ duration: 0.2 }}
                    className="bg-white rounded-3xl p-6 md:p-8 shadow-sm border border-purple-100 space-y-6"
                  >
                    <div className="border-b border-purple-50 pb-4 flex justify-between items-start">
                      <div>
                        <div className="flex items-center gap-2 mb-1.5">
                          <span className="text-[10px] font-black uppercase tracking-widest bg-purple-100 text-purple-700 px-3 py-1 rounded-md">
                            {selectedStation.etiquetaJerarquia}
                          </span>
                          <span className="text-xs font-bold text-slate-400">
                            {selectedStation.viaAnatomica}
                          </span>
                        </div>
                        <h3 className="text-lg md:text-xl font-black text-slate-800">
                          {selectedStation.nombre}
                        </h3>
                      </div>
                      <div className="w-12 h-12 rounded-2xl bg-purple-50 flex items-center justify-center text-purple-600 border border-purple-100 shadow-2xs">
                        {getStationIcon(selectedStation.iconoTipo, 24)}
                      </div>
                    </div>

                    {/* Función Normal vs Secuestro */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="bg-emerald-50/70 border border-emerald-200 p-4 rounded-2xl">
                        <span className="text-[10px] font-bold text-emerald-800 uppercase tracking-wider block mb-1.5 flex items-center gap-1.5">
                          <CheckCircle2 size={13} /> Función Fisiológica Normal
                        </span>
                        <p className="text-xs text-emerald-950 leading-relaxed font-medium">
                          {selectedStation.funcionNormal}
                        </p>
                      </div>

                      <div className="bg-rose-50/70 border border-rose-200 p-4 rounded-2xl">
                        <span className="text-[10px] font-bold text-rose-800 uppercase tracking-wider block mb-1.5 flex items-center gap-1.5">
                          <AlertTriangle size={13} /> El Secuestro por la Sustancia
                        </span>
                        <p className="text-xs text-rose-950 leading-relaxed font-medium">
                          {selectedStation.secuestroAdiccion}
                        </p>
                      </div>
                    </div>

                    {/* Conducta y Reversibilidad */}
                    <div className="bg-slate-50 border border-slate-200 p-4 rounded-2xl space-y-2">
                      <span className="text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block">
                        Manifestación en la Conducta del Paciente:
                      </span>
                      <p className="text-xs text-slate-700 font-semibold leading-relaxed">
                        {selectedStation.manifestacionConductual}
                      </p>
                      <div className="pt-2 border-t border-slate-200 flex flex-wrap items-center justify-between text-xs">
                        <span className="text-slate-500 font-bold">Tiempo estimado de recuperación:</span>
                        <span className="font-extrabold text-purple-700">{selectedStation.tiempoReversibilidad}</span>
                      </div>
                    </div>

                    {/* Analogía y Diálogo de Box */}
                    <div className="bg-gradient-to-r from-purple-50 to-indigo-50 border border-purple-200 p-5 rounded-2xl space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-black text-purple-700 uppercase tracking-widest flex items-center gap-1.5">
                          <Sparkles size={13} /> Analogía Clara para Decirle al Paciente:
                        </span>
                        <button
                          onClick={() => copyToClipboard(selectedStation.analogiaPaciente, selectedStation.id)}
                          className="text-xs font-bold text-purple-700 bg-white border border-purple-200 px-2.5 py-1 rounded-lg flex items-center gap-1 hover:bg-purple-50"
                        >
                          {copiedId === selectedStation.id ? (
                            <>
                              <Check size={13} className="text-emerald-600" /> Copiado
                            </>
                          ) : (
                            <>
                              <Copy size={13} /> Copiar
                            </>
                          )}
                        </button>
                      </div>
                      <p className="text-xs font-bold text-purple-950 italic leading-relaxed">
                        &quot;{selectedStation.analogiaPaciente}&quot;
                      </p>

                      <div className="pt-2 border-t border-purple-200/60">
                        <span className="text-[10px] font-extrabold text-purple-800 uppercase block mb-1">
                          Intervención Terapéutica en Box:
                        </span>
                        <p className="text-xs text-purple-900 font-medium leading-relaxed">
                          {selectedStation.intervencionClinicaBox}
                        </p>
                      </div>
                    </div>
                  </motion.div>
                </AnimatePresence>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ========================================================
          SUB-TAB 2: SIMULADOR DE FLUJO DE DOPAMINA & SINAPSIS
         ======================================================== */}
      {activeSubTab === "simulador" && (
        <SimuladorCircuitoRecompensa />
      )}

      {/* ========================================================
          SUB-TAB 3: PANEL DE NEUROPLASTICIDAD & REPARACIÓN D2
         ======================================================== */}
      {activeSubTab === "neuroplasticidad" && (
        <PanelNeuroplasticidad />
      )}

      {/* ========================================================
          SUB-TAB 4: LABORATORIO DE NEUROTRANSMISORES & RECEPTORES
         ======================================================== */}
      {activeSubTab === "neurotransmisores" && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
            {NEUROTRANSMISORES_DATA.map((nt) => {
              const isSelected = selectedNeuro.id === nt.id;
              return (
                <button
                  key={nt.id}
                  onClick={() => setSelectedNeuro(nt)}
                  className={`p-4 rounded-2xl border text-left transition-all relative overflow-hidden ${
                    isSelected
                      ? "bg-white border-purple-500 shadow-md ring-2 ring-purple-100"
                      : "bg-white/80 border-purple-100 hover:bg-white hover:border-purple-200"
                  }`}
                >
                  <div className={`w-8 h-8 rounded-xl bg-gradient-to-br ${nt.color} flex items-center justify-center text-white shadow-xs mb-3`}>
                    {getNeuroIcon(nt.icono)}
                  </div>
                  <h4 className="text-xs font-bold text-slate-800 leading-tight">
                    {nt.nombre}
                  </h4>
                  <span className="text-[9px] font-semibold text-slate-400 block mt-1">
                    {nt.id === "dopamina" ? "Motivación & Deseo" : nt.id === "gaba" ? "Freno & Calma" : nt.id === "glutamato" ? "Excitación & Memoria" : nt.id === "serotonina" ? "Ánimo & Estabilidad" : "Alerta & Estrés"}
                  </span>
                </button>
              );
            })}
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={selectedNeuro.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="bg-white rounded-3xl p-6 md:p-8 shadow-sm border border-purple-100 space-y-6"
            >
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-purple-50 pb-4">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-2xl bg-gradient-to-br ${selectedNeuro.color} flex items-center justify-center text-white shadow-md`}>
                    {getNeuroIcon(selectedNeuro.icono)}
                  </div>
                  <div>
                    <h3 className="text-lg font-black text-slate-800">
                      {selectedNeuro.nombre}
                    </h3>
                    <span className="text-xs text-slate-500 font-medium">
                      {selectedNeuro.rolFisiologico}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleSpeak(`${selectedNeuro.nombre}. ${selectedNeuro.analogiaPaciente}`)}
                    className="text-xs font-bold text-purple-700 bg-purple-50 hover:bg-purple-100 px-3 py-1.5 rounded-xl border border-purple-200 flex items-center gap-1.5"
                  >
                    {isSpeaking ? <VolumeX size={14} /> : <Volume2 size={14} />} Escuchar
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div className="space-y-4">
                  <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100">
                    <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wider block mb-1">
                      ¿Qué le hace el consumo a esta sustancia química?
                    </span>
                    <p className="text-xs text-slate-700 font-medium leading-relaxed">
                      {selectedNeuro.alteracionEnConsumo}
                    </p>
                  </div>

                  <div className="bg-rose-50/70 p-4 rounded-2xl border border-rose-100">
                    <span className="text-[10px] font-extrabold text-rose-700 uppercase tracking-wider block mb-1">
                      Síntoma Clínico al Estar Desbalanceado:
                    </span>
                    <p className="text-xs text-rose-950 font-bold leading-relaxed">
                      {selectedNeuro.sintomaClinico}
                    </p>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="bg-purple-50/80 p-4 rounded-2xl border border-purple-100">
                    <span className="text-[10px] font-extrabold text-purple-700 uppercase tracking-wider block mb-1 flex items-center gap-1.5">
                      <Lightbulb size={13} /> Metáfora para el Paciente en Box:
                    </span>
                    <p className="text-xs font-bold text-purple-950 italic leading-relaxed">
                      &quot;{selectedNeuro.analogiaPaciente}&quot;
                    </p>
                  </div>

                  <div className="bg-emerald-50/70 p-4 rounded-2xl border border-emerald-100">
                    <span className="text-[10px] font-extrabold text-emerald-800 uppercase tracking-wider block mb-1 flex items-center gap-1.5">
                      <CheckCircle2 size={13} /> Estrategia de Recuperación &amp; Neurogénesis:
                    </span>
                    <p className="text-xs text-emerald-950 font-medium leading-relaxed">
                      {selectedNeuro.estrategiaRecuperacion}
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
      )}

      {/* ========================================================
          SUB-TAB 3: LA CURVA DE LA DOPAMINA & CRAVING
         ======================================================== */}
      {activeSubTab === "dopamina" && (
        <div className="bg-white rounded-3xl p-6 md:p-8 shadow-sm border border-purple-100 space-y-8">
          <div className="border-b border-purple-50 pb-4">
            <span className="text-[10px] font-black uppercase tracking-widest text-purple-600 bg-purple-50 px-3 py-1 rounded-md">
              Simulador Visual de Dinámica Dopaminérgica
            </span>
            <h3 className="text-xl font-black text-slate-800 mt-2">
              El Subibaja de la Dopamina: Del Pico Artificial al Valle de la Angustia
            </h3>
            <p className="text-xs text-slate-500 font-medium mt-1">
              Utilice estos estados interactivos para mostrarle al paciente por qué siente tanta angustia y falta de placer en las primeras semanas de abstinencia, y cómo su cerebro se restaura con el tiempo.
            </p>
          </div>

          {/* Selector de Estados */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { id: "basal", label: "1. Estado Basal Normal", color: "border-blue-300 text-blue-800", percent: "100%" },
              { id: "pico", label: "2. Consumo / Binge", color: "border-amber-400 text-amber-800", percent: "800%" },
              { id: "crash", label: "3. El Crash / La Angustia", color: "border-rose-400 text-rose-800", percent: "25%" },
              { id: "recuperacion", label: "4. Recuperación (90 días)", color: "border-emerald-400 text-emerald-800", percent: "95%" }
            ].map((st) => {
              const isSelected = dopamineSimState === st.id;
              return (
                <button
                  key={st.id}
                  onClick={() => setDopamineSimState(st.id as any)}
                  className={`p-4 rounded-2xl border text-left transition-all ${
                    isSelected
                      ? "bg-slate-900 text-white border-slate-900 shadow-md ring-2 ring-purple-300"
                      : "bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100"
                  }`}
                >
                  <span className={`text-[10px] font-extrabold uppercase tracking-widest block mb-1 ${isSelected ? "text-purple-300" : "text-purple-600"}`}>
                    Nivel DA: {st.percent}
                  </span>
                  <h4 className="text-xs font-bold leading-snug">{st.label}</h4>
                </button>
              );
            })}
          </div>

          {/* Gráfico Visual Dinámico */}
          <div className="bg-slate-950 text-white p-6 rounded-3xl relative overflow-hidden border border-slate-800">
            <div className="flex justify-between items-center mb-4">
              <div>
                <span className="text-[10px] font-bold text-purple-400 uppercase tracking-widest">
                  Monitor de Neurotransmisión Mesolímbica
                </span>
                <h4 className="text-base font-bold text-white mt-0.5">
                  {dopamineSimState === "basal" && "Nivel Basal: Vida Cotidiana Saludable"}
                  {dopamineSimState === "pico" && "Descarga Suprafisiológica: Tormenta Dopaminérgica"}
                  {dopamineSimState === "crash" && "Hipoactividad Mesolímbica: El Valle del Craving"}
                  {dopamineSimState === "recuperacion" && "Reexpresión de Receptores D2: Homeostasis"}
                </h4>
              </div>

              <div className="text-right">
                <span className="text-2xl font-black text-purple-400">
                  {dopamineSimState === "basal" && "100 ng/dL"}
                  {dopamineSimState === "pico" && "850 ng/dL"}
                  {dopamineSimState === "crash" && "25 ng/dL"}
                  {dopamineSimState === "recuperacion" && "95 ng/dL"}
                </span>
                <span className="text-[9px] block text-slate-400 uppercase font-semibold">
                  Tono Dopaminérgico
                </span>
              </div>
            </div>

            {/* CURVA INTERACTIVA SVG DE DOPAMINA */}
            <div className="relative h-44 w-full bg-slate-900/40 rounded-2xl border border-slate-800/80 p-2 mb-5 overflow-hidden">
              <svg className="w-full h-full" viewBox="0 0 700 160" preserveAspectRatio="none">
                {/* Definiciones de Gradientes */}
                <defs>
                  <linearGradient id="dopamineGrad" x1="0" y1="0" x2="1" y2="0">
                    <stop offset="0%" stopColor="#8b5cf6" />
                    <stop offset="25%" stopColor="#f59e0b" />
                    <stop offset="45%" stopColor="#ef4444" />
                    <stop offset="70%" stopColor="#10b981" />
                  </linearGradient>
                </defs>

                {/* Líneas de Guía Horizontales */}
                {/* Umbral Basal (100%) */}
                <line x1="30" y1="110" x2="670" y2="110" stroke="#475569" strokeWidth="1" strokeDasharray="4 4" />
                {/* Nivel Sobrecarga (800%) */}
                <line x1="30" y1="15" x2="670" y2="15" stroke="#ef4444" strokeWidth="1" strokeDasharray="3 3" opacity="0.35" />

                {/* Etiquetas de Guía */}
                <text x="35" y="104" fill="#94a3b8" className="text-[9px] font-bold uppercase tracking-wider font-mono">Umbral Basal (100 ng/dL)</text>
                <text x="35" y="26" fill="#f87171" className="text-[9px] font-bold uppercase tracking-wider font-mono" opacity="0.8">Sobrecarga Tóxica (850 ng/dL)</text>
                <text x="35" y="152" fill="#fda4af" className="text-[9px] font-bold uppercase tracking-wider font-mono" opacity="0.8">Valle de Abstinencia (25 ng/dL)</text>

                {/* Trazo Principal de la Curva de la Dopamina */}
                <path
                  d="M 30,110 L 140,110 C 180,110 195,15 210,15 C 225,15 250,145 340,145 C 420,145 470,112 580,112 L 670,112"
                  fill="none"
                  stroke="url(#dopamineGrad)"
                  strokeWidth="3.5"
                  strokeLinecap="round"
                />

                {/* Indicador de Estado Activo (Punto Pulsante Interactivo) */}
                {dopamineSimState === "basal" && (
                  <>
                    <circle cx="85" cy="110" r="10" fill="#a78bfa" opacity="0.25" className="animate-ping" />
                    <circle cx="85" cy="110" r="5" fill="#8b5cf6" stroke="#ffffff" strokeWidth="1.5" />
                  </>
                )}

                {dopamineSimState === "pico" && (
                  <>
                    <circle cx="210" cy="15" r="12" fill="#fbbf24" opacity="0.3" className="animate-ping" />
                    <circle cx="210" cy="15" r="6" fill="#f59e0b" stroke="#ffffff" strokeWidth="1.5" />
                  </>
                )}

                {dopamineSimState === "crash" && (
                  <>
                    <circle cx="340" cy="145" r="12" fill="#f43f5e" opacity="0.3" className="animate-ping" />
                    <circle cx="340" cy="145" r="6" fill="#ef4444" stroke="#ffffff" strokeWidth="1.5" />
                  </>
                )}

                {dopamineSimState === "recuperacion" && (
                  <>
                    <circle cx="580" cy="112" r="10" fill="#34d399" opacity="0.25" className="animate-ping" />
                    <circle cx="580" cy="112" r="5" fill="#10b981" stroke="#ffffff" strokeWidth="1.5" />
                  </>
                )}
              </svg>

              {/* Leyendas del Eje de Tiempo */}
              <div className="absolute bottom-2 left-6 right-6 flex justify-between text-[8px] text-slate-500 font-extrabold uppercase tracking-widest font-mono">
                <span>Estado Basal (Normal)</span>
                <span>Consumo (0-30 min)</span>
                <span>Abstinencia Aguda (1-3 semanas)</span>
                <span>Regeneración (90+ días)</span>
              </div>
            </div>

            {/* Barra Visual Interactiva de Soporte */}
            <div className="space-y-1.5 mb-6">
              <div className="h-4 w-full bg-slate-900 rounded-full overflow-hidden p-0.5 border border-slate-800 flex items-center">
                <motion.div
                  initial={false}
                  animate={{
                    width:
                      dopamineSimState === "basal"
                        ? "15%"
                        : dopamineSimState === "pico"
                        ? "100%"
                        : dopamineSimState === "crash"
                        ? "4%"
                        : "13%"
                  }}
                  transition={{ type: "spring", stiffness: 120, damping: 15 }}
                  className={`h-full rounded-full ${
                    dopamineSimState === "pico"
                      ? "bg-gradient-to-r from-amber-500 to-rose-500 animate-pulse"
                      : dopamineSimState === "crash"
                      ? "bg-rose-600"
                      : dopamineSimState === "recuperacion"
                      ? "bg-emerald-500"
                      : "bg-purple-500"
                  }`}
                />
              </div>
            </div>

            {/* Explicación Contextualizada */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div className="bg-slate-900/90 p-4 rounded-2xl border border-slate-800">
                <span className="text-[10px] font-extrabold uppercase text-purple-400 tracking-wider block mb-1">
                  ¿Qué siente la persona?
                </span>
                <p className="text-slate-300 leading-relaxed font-medium">
                  {dopamineSimState === "basal" && "Capacidad de disfrutar la comida, una caminata, una conversación o un logro personal. Motivación estable para emprender tareas cotidianas."}
                  {dopamineSimState === "pico" && "Euforia explosiva, hiperfocalización, desinhibición total, pérdida del sentido del peligro. El cerebro 'graba' la sustancia como lo más importante para sobrevivir."}
                  {dopamineSimState === "crash" && "Vacío absoluto, irritabilidad atroz, sensación de que nada vale la pena, dolor en el pecho, craving obsesivo: el cerebro suplica otra dosis para salir del pozo."}
                  {dopamineSimState === "recuperacion" && "Retorno paulatino del disfrute de las pequeñas cosas. El paciente redescubre la risa genuina, la calma mental y la energía para planificar su futuro."}
                </p>
              </div>

              <div className="bg-slate-900/90 p-4 rounded-2xl border border-slate-800">
                <span className="text-[10px] font-extrabold uppercase text-emerald-400 tracking-wider block mb-1">
                  Mensaje Esperanza para el Paciente en Box
                </span>
                <p className="text-slate-300 leading-relaxed font-medium italic">
                  {dopamineSimState === "basal" && "El equilibrio es el estado natural de salud del ser humano."}
                  {dopamineSimState === "pico" && "Todo lo que sube a la fuerza artificialmente, cobra una factura biológica multiplicada por diez al caer."}
                  {dopamineSimState === "crash" && "Esta angustia no es su personalidad ni su destino: es un cerebro deshidratado químicamente pidiendo tiempo para fabricar nuevos receptores."}
                  {dopamineSimState === "recuperacion" && "La neurobiología demuestra que con paciencia, buena alimentación y terapia, el cerebro humano tiene una asombrosa capacidad de regenerarse."}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          SUB-TAB 4: EL CICLO DE LAS 3 ETAPAS DE GEORGE KOOB
         ======================================================== */}
      {activeSubTab === "ciclo" && (
        <div className="bg-white rounded-3xl p-6 md:p-8 shadow-sm border border-purple-100 space-y-6">
          <div className="border-b border-purple-50 pb-4">
            <span className="text-[10px] font-black uppercase tracking-widest text-purple-600 bg-purple-50 px-3 py-1 rounded-md">
              Modelo Teórico de George Koob &amp; Nora Volkow
            </span>
            <h3 className="text-xl font-black text-slate-800 mt-2">
              El Ciclo Trifásico de la Adicción: La Trampa Sin Fin
            </h3>
            <p className="text-xs text-slate-500 font-medium mt-1">
              Explique al paciente cómo la conducta transita desde buscar placer inicial (refuerzo positivo) a consumir únicamente para apagar el dolor y la disforia (refuerzo negativo).
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {ETAPAS_CICLO_ADICCION.map((et) => (
              <div
                key={et.fase}
                className="bg-slate-50 border border-slate-200/80 p-5 rounded-3xl space-y-4 relative overflow-hidden"
              >
                <div className={`w-3 h-3 rounded-full ${et.color} absolute top-5 right-5`}></div>
                <div>
                  <span className="text-[9px] font-extrabold uppercase tracking-widest text-slate-400">
                    Fase Neurobiológica {et.fase}
                  </span>
                  <h4 className="text-sm font-bold text-slate-800 mt-0.5">{et.nombre}</h4>
                </div>

                <div className="bg-white p-3 rounded-xl border border-slate-100">
                  <span className="text-[9px] font-extrabold uppercase tracking-wider text-purple-700 block mb-1">
                    Estructuras Involucradas:
                  </span>
                  <p className="text-[11px] text-slate-600 font-bold">{et.estructuras}</p>
                </div>

                <div className="space-y-1.5">
                  <span className="text-[9px] font-extrabold uppercase tracking-wider text-slate-400 block">
                    Mecanismo Fisiológico:
                  </span>
                  <p className="text-xs text-slate-600 font-medium leading-relaxed">{et.mecanismo}</p>
                </div>

                <div className="bg-purple-50/70 p-3 rounded-xl border border-purple-100/70">
                  <span className="text-[9px] font-extrabold uppercase tracking-wider text-purple-700 block mb-0.5">
                    Estado Emocional:
                  </span>
                  <p className="text-xs font-bold text-purple-950">{et.estadoEmocional}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
