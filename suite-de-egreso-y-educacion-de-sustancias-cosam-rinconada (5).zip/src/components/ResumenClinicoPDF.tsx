import { useState, useRef } from "react";
import { motion } from "motion/react";
import {
  FileText,
  Printer,
  Copy,
  Check,
  Download,
  Stethoscope,
  Building2,
  Calendar,
  User,
  ShieldAlert,
  Brain,
  Apple,
  Activity,
  Heart,
  CheckCircle2,
  AlertTriangle,
  FileCheck,
  RefreshCw,
  Eye,
  Sliders,
  Sparkles,
  Layers,
  ChevronDown,
  Wand2,
  Cpu,
  PenTool,
  ShieldCheck,
  FileSignature,
  Clock,
  Pill,
  RotateCcw
} from "lucide-react";
import { generateClinicalAI } from "../services/geminiService";
import { exportElementToPdf } from "../utils/pdfExport";
import { ESTACIONES_CIRCUITO, NEUROTRANSMISORES_DATA, ETAPAS_CICLO_ADICCION } from "../data/neurobiologyData";
import { SINTOMAS_CLINICOS_DATA } from "../data/symptomsData";
import { MICRONUTRIENTES_DATA, PILARES_MICRORREHABILITACION } from "../data/nutritionData";
import { SISTEMAS_FISIOLOGICOS_DATA } from "../data/systemicData";

interface ModulosSeleccionados {
  datosPaciente: boolean;
  notasEvolucionIA: boolean;
  neurobiologia: boolean;
  sintomatologia: boolean;
  nutricion: boolean;
  neuroplasticidad: boolean;
  sistemas: boolean;
  planFarmacologico: boolean;
  alertasEmergencia: boolean;
  compromisoTerapeutico: boolean;
}

interface DatosPacienteForm {
  nombrePaciente: string;
  rut: string;
  edad: string;
  fechaAtencion: string;
  diagnosticoPrincipal: string;
  sustanciaPrincipal: string;
  tiempoConsumo: string;
  estadoConsumo: "Consumo Activo" | "Desintoxicación Aguda" | "Abstinencia Temprana (1-3m)" | "Mantenimiento / Consolidación (>6m)";
  medicoTratante: string;
  registroColegio: string;
  centroSalud: string;
  comuna: string;
  notasMedicasBox: string;
  proximoControl: string;
}

interface RegistroRayenAPS {
  id: string;
  fecha: string;
  profesional: string;
  estamento: string;
  tipoRegistro: "Control Médico PAI" | "Evaluación Psicológica" | "Intervención Trabajo Social" | "Terapia Ocupacional" | "Administración Fármacos / TENS";
  resumenEntrada: string;
  fucReportado: string;
  cravingScore: number;
  adherenciaFarmacos: "Completa (100%)" | "Parcial con olvidos" | "Abandono / Suspensión";
}

interface SintesisEvolucionIA {
  resumenEvolutivoGlobal: string;
  analisisSubjetivoSOAP: string;
  hallazgosObjetivosRayen: string;
  juicioClinicoEvolutivo: string;
  frecuenciaConsumoYFUC: string;
  planIntegralAcordado: string;
  indicacionesFarmacologicasFirma: string;
  fechaGeneracion: string;
  modeloUtilizado: string;
  folioValidacion: string;
}

const REGISTROS_RAYEN_INICIALES: RegistroRayenAPS[] = [
  {
    id: "ray-01",
    fecha: "24/08/2026",
    profesional: "Dr. Andrés Felipe Ruiz Miranda",
    estamento: "Médico Cirujano (Psiquiatría / Enlace)",
    tipoRegistro: "Control Médico PAI",
    resumenEntrada: "Control mensual. Paciente refiere 18 días de abstinencia estricta a PBC y tabaco. Refiere reducción del craving (EVA 3/10) gracias a pauta de rescate con respiración 4-4-8 y magnesio bisglicinato. Buen patrón de sueño (7 hrs continuas). Se mantiene Sertralina 100mg y Complejo B Forte.",
    fucReportado: "06/08/2026 (18 días)",
    cravingScore: 3,
    adherenciaFarmacos: "Completa (100%)"
  },
  {
    id: "ray-02",
    fecha: "18/08/2026",
    profesional: "Ps. Marcela Paz Bustamante",
    estamento: "Psicóloga Clínica COSAM",
    tipoRegistro: "Evaluación Psicológica",
    resumenEntrada: "Sesión individual de psicoterapia focalizada en prevención de recaídas. Se abordan gatillantes emocionales (discusión intrafamiliar en fin de semana). Paciente logró activar red de apoyo y no consumió. Buena alianza terapéutica, consolidando etapa de Acción (Prochaska-DiClemente).",
    fucReportado: "06/08/2026",
    cravingScore: 4,
    adherenciaFarmacos: "Completa (100%)"
  },
  {
    id: "ray-03",
    fecha: "12/08/2026",
    profesional: "T.S. Rodrigo Valenzuela G.",
    estamento: "Trabajador Social",
    tipoRegistro: "Intervención Trabajo Social",
    resumenEntrada: "Entrevista familiar y visita diagnóstica. Red primaria (madre y hermana) comprometida en supervisión de administración de psicofármacos y resguardo de ingresos económicos en días de pago. Se gestiona derivación a taller de capacitación laboral OMIL San Ramón.",
    fucReportado: "06/08/2026",
    cravingScore: 5,
    adherenciaFarmacos: "Completa (100%)"
  },
  {
    id: "ray-04",
    fecha: "06/08/2026",
    profesional: "T.O. Camila Soto Navarrete",
    estamento: "Terapeuta Ocupacional",
    tipoRegistro: "Terapia Ocupacional",
    resumenEntrada: "Taller grupal de estructuración de rutina diaria y manejo de tiempo libre. Paciente identifica franjas horarias de alto riesgo (viernes noche). Se planifican actividades deportivas y de caminata aeróbica en parque La Bandera.",
    fucReportado: "06/08/2026 (Episodio de consumo aislado previo al ingreso del taller)",
    cravingScore: 6,
    adherenciaFarmacos: "Parcial con olvidos"
  }
];

export default function ResumenClinicoPDF() {
  const [copiedRayen, setCopiedRayen] = useState(false);
  const [copiedIASintesis, setCopiedIASintesis] = useState(false);
  const [isExportingPdf, setIsExportingPdf] = useState(false);
  const [viewMode, setViewMode] = useState<"editor" | "vista_previa">("vista_previa");
  const [isGeneratingAI, setIsGeneratingAI] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);

  // Módulos a compilar en el PDF
  const [modulos, setModulos] = useState<ModulosSeleccionados>({
    datosPaciente: true,
    notasEvolucionIA: true,
    neurobiologia: true,
    sintomatologia: true,
    nutricion: true,
    neuroplasticidad: true,
    sistemas: false,
    planFarmacologico: true,
    alertasEmergencia: true,
    compromisoTerapeutico: true
  });

  // Registros de la ficha Rayen APS alimentadores de la IA
  const [registrosRayen, setRegistrosRayen] = useState<RegistroRayenAPS[]>(REGISTROS_RAYEN_INICIALES);
  const [nuevoRegistroTexto, setNuevoRegistroTexto] = useState("");
  const [nuevoRegistroEstamento, setNuevoRegistroEstamento] = useState<RegistroRayenAPS["tipoRegistro"]>("Control Médico PAI");

  // Síntesis de evolución IA estructurada lista para firma
  const [sintesisIA, setSintesisIA] = useState<SintesisEvolucionIA>({
    resumenEvolutivoGlobal: "Paciente masculino de 34 años con diagnóstico de Dependencia Severa a Pasta Base de Cocaína (F14.2) en seguimiento activo en PAI COSAM Rinconada. A lo largo del último ciclo de atenciones multidisciplinarias en Rayen APS (Médica, Psicológica, Trabajo Social y T.O.), se constata una favorable curva de estabilización clínica, logrando una abstinencia sostenida de 24 días con re-regulación del ritmo circadiano y remisión de los picos de craving.",
    analisisSubjetivoSOAP: "S: Refiere encontrarse eutímico y motivado. Describe reducción sustantiva del deseo de consumo (EVA craving 3/10). Expresa satisfacción por haber evitado recaída ante estresores familiares aplicando el protocolo de respiración diafragmática y red de apoyo familiar.",
    hallazgosObjetivosRayen: "O: Vigil, orientado globalmente, colaborador, sin signos de intoxicación ni de síndrome de privación adrenérgico. Temblor distal ausente. Signos vitales: PA 120/75 mmHg, FC 74 lpm. FUC verificada: 06/08/2026. Registros Rayen confirman asistencia al 100% de controles pactados y red de apoyo supervisora activa.",
    juicioClinicoEvolutivo: "A: Trastorno por uso de estimulantes (PBC) en Abstinencia Temprana (1-3m) con remisión progresiva de la hipofrontalidad y anhedonia dopaminérgica. Freno inhibitorio prefrontal fortalecido por intervención cognitivo-conductual y estabilidad psicofarmacológica.",
    frecuenciaConsumoYFUC: "FUC: 06/08/2026 (24 días continuos sin consumo). Patrón previo: Binge episódico de fin de semana -> Actual: Abstinencia documentada en Rayen.",
    planIntegralAcordado: "P: 1) Mantener Sertralina 100 mg/día vo matinal y Tiamina 300 mg/d. 2) Continuar taller de microrrehabilitación y psicoterapia grupal semanal. 3) Prescripción de 150 min/sem de ejercicio aeróbico para estimulación de BDNF. 4) Seguimiento por dupla psicosocial para vinculación a OMIL.",
    indicacionesFarmacologicasFirma: "R/ 1. Sertralina 100 mg - 1 comp vía oral cada mañana por 30 días. \n2. Tiamina (Vit B1) 100 mg - 1 comp cada 8 horas por 30 días. \n3. Citrato de Magnesio 400 mg - 1 dosis nocturna por 30 días.",
    fechaGeneracion: new Date().toLocaleDateString("es-CL", { day: "2-digit", month: "2-digit", year: "numeric" }),
    modeloUtilizado: "Gemini 3.7 Flash • Protocolo Síntesis Rayen APS COSAM",
    folioValidacion: `COSAM-EVO-${Math.floor(100000 + Math.random() * 900000)}`
  });

  // Datos clínicos del informe
  const [datosPaciente, setDatosPaciente] = useState<DatosPacienteForm>({
    nombrePaciente: "Juan Carlos Morales Valenzuela",
    rut: "18.432.901-K",
    edad: "34 años",
    fechaAtencion: new Date().toLocaleDateString("es-CL", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric"
    }),
    diagnosticoPrincipal: "F14.2 Trastorno por dependencia de Pasta Base de Cocaína (CIE-10)",
    sustanciaPrincipal: "Pasta Base de Cocaína (PBC) + Tabaco",
    tiempoConsumo: "4 años de evolución, frecuencia diaria/episódica",
    estadoConsumo: "Abstinencia Temprana (1-3m)",
    medicoTratante: "Dr. Andrés Felipe Ruiz Miranda",
    registroColegio: "Médico Cirujano • Reg. SIS N° 492014",
    centroSalud: "COSAM Rinconada de San Ramón",
    comuna: "San Ramón, Región Metropolitana - Servicio de Salud Metropolitano Sur Oriente",
    notasMedicasBox: "Paciente acude a control de seguimiento con buena adherencia al plan ambulatorio intensivo (PAI). Se refuerza la comprensión de la anhedonia como un proceso neurobiológico transitorio por down-regulation de receptores D2 en el núcleo accumbens. Se indica pauta de microrrehabilitación con suplementación antioxidante, complejo B y ejercicio aeróbico estructurado.",
    proximoControl: "14 días (Control Médico + Taller Psicoterapéutico Grupal COSAM)"
  });

  // Selección específica de ítems dentro de cada módulo para el informe
  const [selectedNeurotransmisores, setSelectedNeurotransmisores] = useState<string[]>(["dopamina", "gaba", "glutamato"]);
  const [selectedSintomas, setSelectedSintomas] = useState<string[]>(["perdida-peso", "anemia", "alteracion-menstrual", "insomnio-rebote"]);
  const [selectedNutrientes, setSelectedNutrientes] = useState<string[]>(["b1-tiamina", "b6-piridoxina", "b12-cobalamina", "vitamina-c", "magnesio", "l-tirosina"]);

  // Cargar caso clínico modelo rápido
  const handleCargarCasoPBC = () => {
    setDatosPaciente({
      nombrePaciente: "Juan Carlos M. V.",
      rut: "16.894.312-3",
      edad: "38 años",
      fechaAtencion: new Date().toLocaleDateString("es-CL"),
      diagnosticoPrincipal: "F14.20 Trastorno por dependencia de Pasta Base de Cocaína, en abstinencia temprana (CIE-10)",
      sustanciaPrincipal: "Pasta Base de Cocaína (PBC) + Alcohol (F10.1)",
      tiempoConsumo: "6 años de evolución con binging episódico",
      estadoConsumo: "Desintoxicación Aguda",
      medicoTratante: "Dr. Andrés Felipe Ruiz Miranda",
      registroColegio: "Médico Cirujano • Reg. SIS N° 492014",
      centroSalud: "COSAM Rinconada de San Ramón",
      comuna: "San Ramón, Región Metropolitana - SSM Sur Oriente",
      notasMedicasBox: "Presenta marcada labilidad emocional, temblor fino distal y anorexia severa secundaria a hiperestimulación dopaminérgica y daño oxidativo mitocondrial. Se pacta inicio de micronutrición con Tiamina 300 mg/d, Magnesio Bisglicinato 400 mg noche y N-Acetilcisteína (NAC) para modulación glutamatérgica.",
      proximoControl: "7 días (Control Médico Prioritario)"
    });
    setSelectedSintomas(["perdida-peso", "anemia", "bruxismo-dental", "insomnio-rebote"]);
  };

  const handleCargarCasoAlcohol = () => {
    setDatosPaciente({
      nombrePaciente: "María Elena S. R.",
      rut: "14.205.811-9",
      edad: "45 años",
      fechaAtencion: new Date().toLocaleDateString("es-CL"),
      diagnosticoPrincipal: "F10.2 Trastorno por dependencia de Alcohol, síndrome de abstinencia no complicado (CIE-10)",
      sustanciaPrincipal: "Alcohol (Destilados / Cerveza)",
      tiempoConsumo: "10 años con patrón diario matutino",
      estadoConsumo: "Abstinencia Temprana (1-3m)",
      medicoTratante: "Dr. Andrés Felipe Ruiz Miranda",
      registroColegio: "Médico Cirujano • Reg. SIS N° 492014",
      centroSalud: "COSAM Rinconada de San Ramón",
      comuna: "San Ramón, Región Metropolitana - SSM Sur Oriente",
      notasMedicasBox: "Evolución favorable sin signos de delirium tremens ni encefalopatía de Wernicke. Persiste hipomagnesemia e insomnio de conciliación. Se prescribe Tiamina de mantenimiento, Complejo B oral, hidratación oral con sales de rehidratación y contención en grupo terapéutico de los martes.",
      proximoControl: "14 días (Control Psiquiátrico)"
    });
    setSelectedSintomas(["anemia", "alteracion-hepatica", "insomnio-rebote"]);
  };

  // Generador Inteligente con Gemini IA para sintetizar fichas Rayen APS en formato listo para firma
  const handleGenerarSintesisIA = async () => {
    setIsGeneratingAI(true);
    setAiError(null);

    const promptText = `Eres un Médico Psiquiatra Especialista en Adicciones y Salud Mental del COSAM Rinconada de San Ramón (Servicio de Salud Metropolitano Sur Oriente).
Tu tarea es sintetizar automáticamente los siguientes registros longitudinales de la Ficha Clínica Rayen APS de un paciente en tratamiento en el PAI:

DATOS DEL PACIENTE:
- Nombre: ${datosPaciente.nombrePaciente} | RUT: ${datosPaciente.rut} | Edad: ${datosPaciente.edad}
- Diagnóstico: ${datosPaciente.diagnosticoPrincipal}
- Sustancia(s): ${datosPaciente.sustanciaPrincipal} (${datosPaciente.tiempoConsumo})
- Estado de Consumo: ${datosPaciente.estadoConsumo}
- Médico Tratante: ${datosPaciente.medicoTratante} (${datosPaciente.registroColegio})

REGISTROS HISTÓRICOS EXTRAÍDOS DE FICHA RAYEN APS:
${registrosRayen
  .map(
    (r, idx) =>
      `[${idx + 1}] Fecha: ${r.fecha} | Profesional: ${r.profesional} (${r.estamento}) | Tipo: ${r.tipoRegistro}
       Entrada: ${r.resumenEntrada}
       FUC: ${r.fucReportado} | Escala Craving: ${r.cravingScore}/10 | Adherencia a Fármacos: ${r.adherenciaFarmacos}`
  )
  .join("\n\n")}

Genera una respuesta en formato JSON estrictamente válido con los siguientes campos para ser incorporada como sección oficial de "Notas de Evolución IA" en el Resumen Clínico imprimible y listo para firma:
{
  "resumenEvolutivoGlobal": "Párrafo conciso y riguroso sintetizando la trayectoria evolutiva, logros y puntos críticos del paciente.",
  "analisisSubjetivoSOAP": "S (Subjetivo): Relato del estado anímico, craving, estresores vitales y percepción del paciente.",
  "hallazgosObjetivosRayen": "O (Objetivo): Examen mental, estado biológico, signos vitales, días de FUC documentados y trazabilidad en Rayen.",
  "juicioClinicoEvolutivo": "A (Análisis/Apreciación): Diagnóstico nosológico y funcional, etapa de cambio de Prochaska, estado del circuito de recompensa dopaminérgico.",
  "frecuenciaConsumoYFUC": "Resumen claro de FUC, días continuos de abstinencia y evolución del craving.",
  "planIntegralAcordado": "P (Plan): Acuerdos psicoterapéuticos, derivaciones (T.O., T.S., grupos), neuroplasticidad (BDNF) y control.",
  "indicacionesFarmacologicasFirma": "Receta / Indicaciones farmacológicas detalladas con fármaco, dosis, vía, horario y duración lista para la firma médica."
}`;

    try {
      const response = await generateClinicalAI({
        prompt: promptText,
        systemInstruction:
          "Eres un asistente médico experto en psiquiatría de adicciones en APS chilena (COSAM/Rayen). Responde única y exclusivamente en formato JSON válido, sin bloques de código markdown ni texto adicional.",
        temperature: 0.15,
        model: "gemini-3.7-flash"
      });

      // Parse JSON from response
      let cleanJson = response.trim();
      if (cleanJson.startsWith("```json")) {
        cleanJson = cleanJson.replace(/```json\n?/, "").replace(/```$/, "").trim();
      } else if (cleanJson.startsWith("```")) {
        cleanJson = cleanJson.replace(/```\n?/, "").replace(/```$/, "").trim();
      }

      const parsed = JSON.parse(cleanJson);
      setSintesisIA({
        resumenEvolutivoGlobal: parsed.resumenEvolutivoGlobal || "Evolución clínica favorable con adecuada adherencia a las indicaciones del equipo COSAM.",
        analisisSubjetivoSOAP: parsed.analisisSubjetivoSOAP || "S: Paciente colaborador, refiere disminución en la frecuencia de episodios de craving.",
        hallazgosObjetivosRayen: parsed.hallazgosObjetivosRayen || "O: Examen mental dentro de límites esperados para fase de abstinencia temprana.",
        juicioClinicoEvolutivo: parsed.juicioClinicoEvolutivo || "A: Consolidación de abstinencia y fortalecimiento del control prefrontal.",
        frecuenciaConsumoYFUC: parsed.frecuenciaConsumoYFUC || "FUC documentada en ficha Rayen con adherencia verificada.",
        planIntegralAcordado: parsed.planIntegralAcordado || "P: Mantener controles multidisciplinarios y psicofarmacoterapia.",
        indicacionesFarmacologicasFirma: parsed.indicacionesFarmacologicasFirma || "R/ Continuar esquema habitual.",
        fechaGeneracion: new Date().toLocaleDateString("es-CL", { day: "2-digit", month: "2-digit", year: "numeric" }),
        modeloUtilizado: "Gemini 3.7 Flash • Protocolo Síntesis Rayen APS COSAM",
        folioValidacion: `COSAM-EVO-${Math.floor(100000 + Math.random() * 900000)}`
      });
      setModulos((prev) => ({ ...prev, notasEvolucionIA: true }));
    } catch (err: any) {
      console.error("Error al sintetizar evolución IA:", err);
      setAiError(err.message || "Error al conectar con el motor de IA. Se conservan los datos de base.");
    } finally {
      setIsGeneratingAI(false);
    }
  };

  // Agregar nuevo registro manual de Rayen
  const handleAgregarRegistroRayen = () => {
    if (!nuevoRegistroTexto.trim()) return;
    const nuevo: RegistroRayenAPS = {
      id: `ray-${Date.now()}`,
      fecha: new Date().toLocaleDateString("es-CL"),
      profesional: datosPaciente.medicoTratante,
      estamento: "Médico Cirujano (Psiquiatría / Enlace)",
      tipoRegistro: nuevoRegistroEstamento,
      resumenEntrada: nuevoRegistroTexto,
      fucReportado: new Date().toLocaleDateString("es-CL"),
      cravingScore: 3,
      adherenciaFarmacos: "Completa (100%)"
    };
    setRegistrosRayen([nuevo, ...registrosRayen]);
    setNuevoRegistroTexto("");
  };

  // Copiar solo la síntesis IA estructurada
  const handleCopySintesisIA = () => {
    const texto = `=== NOTA DE EVOLUCIÓN CLÍNICA IA - COSAM RINCONADA (RAYEN APS) ===
FOLIO: ${sintesisIA.folioValidacion} | FECHA: ${sintesisIA.fechaGeneracion}
PACIENTE: ${datosPaciente.nombrePaciente} | RUT: ${datosPaciente.rut} | EDAD: ${datosPaciente.edad}
DIAGNÓSTICO: ${datosPaciente.diagnosticoPrincipal}

RESUMEN EVOLUTIVO:
${sintesisIA.resumenEvolutivoGlobal}

ESTRUCTURA SOAP:
${sintesisIA.analisisSubjetivoSOAP}
${sintesisIA.hallazgosObjetivosRayen}
${sintesisIA.juicioClinicoEvolutivo}
${sintesisIA.planIntegralAcordado}

INDICACIONES FARMACOLÓGICAS Y RECETA:
${sintesisIA.indicacionesFarmacologicasFirma}

MÉDICO TRATANTE: ${datosPaciente.medicoTratante} (${datosPaciente.registroColegio})`;

    navigator.clipboard.writeText(texto);
    setCopiedIASintesis(true);
    setTimeout(() => setCopiedIASintesis(false), 3000);
  };

  // Exportar a PDF nativo con html2canvas / jspdf
  const handleExportarPDFNativo = async () => {
    setIsExportingPdf(true);
    try {
      await exportElementToPdf("documento-resumen-clinico-pdf", {
        filename: `Resumen_Clinico_COSAM_${datosPaciente.rut.replace(/[^0-9kK]/g, "")}_${Date.now()}.pdf`,
        title: "Informe Resumen Clínico COSAM Rinconada"
      });
    } catch (e) {
      console.error(e);
      window.print();
    } finally {
      setIsExportingPdf(false);
    }
  };

  // Función para imprimir o guardar como PDF mediante el diálogo del navegador
  const handlePrint = () => {
    window.print();
  };

  // Copiar resumen en formato texto para pegar en Ficha Clínica Rayen APS
  const handleCopyRayen = () => {
    const textoRayen = `*** INFORME RESUMEN CLÍNICO - COSAM RINCONADA DE SAN RAMÓN ***
MÉDICO TRATANTE: ${datosPaciente.medicoTratante} (${datosPaciente.registroColegio})
FECHA: ${datosPaciente.fechaAtencion} | CENTRO: ${datosPaciente.centroSalud}
PACIENTE: ${datosPaciente.nombrePaciente} | RUT: ${datosPaciente.rut} | EDAD: ${datosPaciente.edad}
DIAGNÓSTICO: ${datosPaciente.diagnosticoPrincipal}
SUSTANCIA(S): ${datosPaciente.sustanciaPrincipal} (${datosPaciente.tiempoConsumo})
FASE ACTUAL: ${datosPaciente.estadoConsumo}

1. NOTAS DE EVOLUCIÓN IA & REGISTROS RAYEN APS:
${sintesisIA.resumenEvolutivoGlobal}

ESTRUCTURA SOAP:
${sintesisIA.analisisSubjetivoSOAP}
${sintesisIA.hallazgosObjetivosRayen}
${sintesisIA.juicioClinicoEvolutivo}
${sintesisIA.planIntegralAcordado}

2. EVALUACIÓN NEUROBIOLÓGICA & FISIOPATOLÓGICA:
- Circuito Recompensa: ATV -> Núcleo Accumbens (Down-regulation receptores D2 postsinápticos).
- Freno Prefrontal: Disfunción córtico-estriatal transitoria, labilidad en toma de decisiones y control inhibitorio.
- Ciclo Koob: Fase de afecto negativo / anhedonia por aumento de CRF y dinorfina amigdalina.

3. SINTOMATOLOGÍA Y FOCOS CLÍNICOS ABORDADOS:
${selectedSintomas
  .map((sId) => {
    const s = SINTOMAS_CLINICOS_DATA.find((item) => item.id === sId);
    return s ? `- ${s.titulo}: ${s.subtitulo} (Manejo: ${s.intervencionEnBox})` : "";
  })
  .filter(Boolean)
  .join("\n")}

4. PLAN DE MICRORREHABILITACIÓN Y NUTRICIÓN CLÍNICA:
${selectedNutrientes
  .map((nId) => {
    const n = MICRONUTRIENTES_DATA.find((item) => item.id === nId);
    return n ? `- ${n.nombre}: ${n.dosisSugeridaReposicion} (Fuentes: ${n.alimentosFuentes.slice(0, 2).join(", ")})` : "";
  })
  .filter(Boolean)
  .join("\n")}

5. INDICACIONES Y COMPROMISO TERAPÉUTICO COSAM:
- Ejercicio aeróbico (BDNF) 150 min/semana.
- Asistencia semanal obligatoria a Taller Grupal de Psicoeducación en COSAM.
- Próximo Control Médico: ${datosPaciente.proximoControl}.

INDICACIONES FARMACOLÓGICAS PARA FIRMA:
${sintesisIA.indicacionesFarmacologicasFirma}

OBSERVACIONES CLÍNICAS:
${datosPaciente.notasMedicasBox}
--------------------------------------------------`;

    navigator.clipboard.writeText(textoRayen);
    setCopiedRayen(true);
    setTimeout(() => setCopiedRayen(false), 3000);
  };

  return (
    <div className="space-y-8 animate-fadeIn pb-12">
      {/* HEADER DE CONTROL Y HERRAMIENTAS */}
      <section className="liquid-glass rounded-3xl p-6 md:p-8 border border-purple-200/80 shadow-md relative overflow-hidden">
        <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-purple-600 via-teal-500 to-indigo-600 led-glow-purple"></div>

        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
          <div className="space-y-2 max-w-3xl">
            <div className="flex flex-wrap items-center gap-2">
              <span className="bg-purple-100 text-purple-900 border border-purple-200 text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-lg">
                Documentación Clínica Oficial
              </span>
              <span className="text-slate-500 text-xs font-semibold flex items-center gap-1">
                <Building2 size={13} className="text-purple-600" /> COSAM Rinconada de San Ramón • SSM Sur Oriente
              </span>
              <span className="bg-teal-100 text-teal-900 text-[10px] font-extrabold px-2.5 py-0.5 rounded-md border border-teal-200">
                Dr. Andrés Felipe Ruiz Miranda
              </span>
            </div>

            <h2 className="text-2xl md:text-3xl font-black text-slate-900 tracking-tight">
              Generador de <span className="bg-gradient-to-r from-purple-700 via-indigo-600 to-teal-700 bg-clip-text text-transparent">Resumen Clínico PDF &amp; Ficha</span>
            </h2>

            <p className="text-xs md:text-sm text-slate-700 font-medium leading-relaxed">
              Compile la información clave de <strong>Neurobiología</strong>, <strong>Sintomatología</strong>, <strong>Microrrehabilitación Nutricional</strong> y <strong>Neuroplasticidad</strong> en un documento médico formal, personalizado y listo para imprimir o exportar a PDF para el paciente o la ficha Rayen APS.
            </p>
          </div>

          {/* BOTONES DE ACCIÓN RÁPIDA */}
          <div className="flex flex-wrap items-center gap-2.5 shrink-0 w-full sm:w-auto">
            <button
              onClick={handlePrint}
              id="btn-imprimir-pdf"
              className="flex-1 sm:flex-initial py-3 px-5 bg-gradient-to-r from-purple-700 to-indigo-700 hover:from-purple-800 hover:to-indigo-800 text-white rounded-2xl text-xs font-black uppercase tracking-wider transition-all shadow-md flex items-center justify-center gap-2 led-pulse-purple"
            >
              <Printer size={16} />
              <span>Imprimir / Guardar PDF</span>
            </button>

            <button
              onClick={handleCopyRayen}
              className={`flex-1 sm:flex-initial py-3 px-4 rounded-2xl text-xs font-black uppercase tracking-wider transition-all flex items-center justify-center gap-2 border shadow-sm ${
                copiedRayen
                  ? "bg-emerald-600 text-white border-emerald-500"
                  : "bg-white text-slate-800 border-purple-200 hover:bg-purple-50"
              }`}
            >
              {copiedRayen ? <Check size={16} /> : <Copy size={16} />}
              <span>{copiedRayen ? "¡Copiado a Rayen!" : "Copiar a Rayen"}</span>
            </button>

            <div className="flex bg-slate-900 p-1 rounded-2xl border border-slate-700 shrink-0">
              <button
                onClick={() => setViewMode("vista_previa")}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                  viewMode === "vista_previa"
                    ? "bg-purple-600 text-white shadow-sm"
                    : "text-slate-400 hover:text-slate-200"
                }`}
              >
                <Eye size={13} />
                <span>Vista Informe</span>
              </button>
              <button
                onClick={() => setViewMode("editor")}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                  viewMode === "editor"
                    ? "bg-purple-600 text-white shadow-sm"
                    : "text-slate-400 hover:text-slate-200"
                }`}
              >
                <Sliders size={13} />
                <span>Personalizar</span>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* MODO EDITOR / PERSONALIZADOR DE CONTENIDOS */}
      {viewMode === "editor" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* PANEL DE MÓDULOS A COMPILAR */}
          <div className="lg:col-span-5 space-y-6">
            <div className="liquid-glass rounded-3xl p-6 border border-purple-200/80 shadow-md space-y-5">
              <div className="flex items-center justify-between border-b border-purple-100 pb-3">
                <div className="flex items-center gap-2">
                  <Layers size={18} className="text-purple-700" />
                  <h3 className="text-xs font-black uppercase tracking-wider text-slate-900">
                    Módulos a Incluir en el Informe:
                  </h3>
                </div>
                <span className="text-[11px] font-bold text-purple-700">
                  {Object.values(modulos).filter(Boolean).length} seleccionados
                </span>
              </div>

              <div className="space-y-2.5">
                {[
                  { key: "datosPaciente", label: "1. Identificación del Paciente & Ficha", icon: User },
                  { key: "notasEvolucionIA", label: "2. Notas de Evolución IA (Síntesis Rayen APS)", icon: Sparkles },
                  { key: "neurobiologia", label: "3. Diagnóstico Neurobiológico (ATV / D2 / Koob)", icon: Brain },
                  { key: "sintomatologia", label: "4. Focos de Sintomatología & Banderas Rojas", icon: AlertTriangle },
                  { key: "nutricion", label: "5. Pauta de Microrrehabilitación & Nutrientes", icon: Apple },
                  { key: "neuroplasticidad", label: "6. Plan de Neuroplasticidad & BDNF", icon: Activity },
                  { key: "sistemas", label: "7. Evaluación Multisistémica Ampliada", icon: Heart },
                  { key: "planFarmacologico", label: "8. Indicaciones Médicas & Farmacoterapia", icon: Stethoscope },
                  { key: "alertasEmergencia", label: "9. Protocolo de Urgencia & Contacto SOS", icon: ShieldAlert },
                  { key: "compromisoTerapeutico", label: "10. Compromiso Terapéutico y Firmas", icon: FileCheck }
                ].map((item) => {
                  const Icon = item.icon;
                  const isChecked = modulos[item.key as keyof ModulosSeleccionados];
                  return (
                    <label
                      key={item.key}
                      className={`flex items-center justify-between p-3 rounded-2xl border transition-all cursor-pointer ${
                        isChecked
                          ? "bg-purple-50/90 border-purple-300 text-purple-950 font-bold"
                          : "bg-white/60 border-slate-200 text-slate-600 hover:bg-white"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <Icon size={16} className={isChecked ? "text-purple-700" : "text-slate-400"} />
                        <span className="text-xs">{item.label}</span>
                      </div>
                      <input
                        type="checkbox"
                        checked={isChecked}
                        onChange={(e) =>
                          setModulos({ ...modulos, [item.key]: e.target.checked })
                        }
                        className="w-4 h-4 rounded text-purple-600 focus:ring-purple-500 cursor-pointer accent-purple-700"
                      />
                    </label>
                  );
                })}
              </div>

              {/* PLANTILLAS RÁPIDAS DE CASOS CLÍNICOS COSAM */}
              <div className="pt-3 border-t border-purple-100 space-y-2">
                <span className="text-[11px] font-black uppercase tracking-wider text-slate-500 block">
                  Autocompletar con Casos Típicos de COSAM:
                </span>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={handleCargarCasoPBC}
                    className="p-2.5 bg-purple-100/80 hover:bg-purple-200 text-purple-900 rounded-xl text-xs font-bold text-left transition-all border border-purple-200 flex flex-col"
                  >
                    <span>Caso Pasta Base</span>
                    <span className="text-[10px] text-purple-700 font-normal">PBC + Caquexia + D2</span>
                  </button>
                  <button
                    onClick={handleCargarCasoAlcohol}
                    className="p-2.5 bg-teal-100/80 hover:bg-teal-200 text-teal-900 rounded-xl text-xs font-bold text-left transition-all border border-teal-200 flex flex-col"
                  >
                    <span>Caso Alcoholismo</span>
                    <span className="text-[10px] text-teal-700 font-normal">Tiamina B1 + Hepático</span>
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* PANEL DE FORMULARIO DE DATOS DEL PACIENTE */}
          <div className="lg:col-span-7 space-y-6">
            <div className="liquid-glass rounded-3xl p-6 border border-purple-200/80 shadow-md space-y-4">
              <div className="border-b border-purple-100 pb-3">
                <h3 className="text-xs font-black uppercase tracking-wider text-slate-900 flex items-center gap-2">
                  <User size={16} className="text-purple-700" />
                  Datos Clínicos para el Encabezado del Documento:
                </h3>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Nombre del Paciente:</label>
                  <input
                    type="text"
                    value={datosPaciente.nombrePaciente}
                    onChange={(e) => setDatosPaciente({ ...datosPaciente, nombrePaciente: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-purple-500 font-medium"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">RUT / Ficha Rayen:</label>
                  <input
                    type="text"
                    value={datosPaciente.rut}
                    onChange={(e) => setDatosPaciente({ ...datosPaciente, rut: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-purple-500 font-medium"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Edad:</label>
                  <input
                    type="text"
                    value={datosPaciente.edad}
                    onChange={(e) => setDatosPaciente({ ...datosPaciente, edad: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-purple-500 font-medium"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Fecha de Atención:</label>
                  <input
                    type="text"
                    value={datosPaciente.fechaAtencion}
                    onChange={(e) => setDatosPaciente({ ...datosPaciente, fechaAtencion: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-purple-500 font-medium"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Diagnóstico CIE-10 / CIE-11:</label>
                  <input
                    type="text"
                    value={datosPaciente.diagnosticoPrincipal}
                    onChange={(e) => setDatosPaciente({ ...datosPaciente, diagnosticoPrincipal: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-purple-500 font-medium"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Sustancia(s) Principal(es):</label>
                  <input
                    type="text"
                    value={datosPaciente.sustanciaPrincipal}
                    onChange={(e) => setDatosPaciente({ ...datosPaciente, sustanciaPrincipal: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-purple-500 font-medium"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Fase / Estado de Consumo:</label>
                  <select
                    value={datosPaciente.estadoConsumo}
                    onChange={(e) => setDatosPaciente({ ...datosPaciente, estadoConsumo: e.target.value as any })}
                    className="w-full p-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-purple-500 font-medium bg-white"
                  >
                    <option value="Consumo Activo">Consumo Activo</option>
                    <option value="Desintoxicación Aguda">Desintoxicación Aguda (0-14 días)</option>
                    <option value="Abstinencia Temprana (1-3m)">Abstinencia Temprana (1-3 meses)</option>
                    <option value="Mantenimiento / Consolidación (>6m)">Mantenimiento / Consolidación (&gt;6 meses)</option>
                  </select>
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Notas Médicas y Observaciones del Box:</label>
                  <textarea
                    rows={3}
                    value={datosPaciente.notasMedicasBox}
                    onChange={(e) => setDatosPaciente({ ...datosPaciente, notasMedicasBox: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-purple-500 font-medium leading-relaxed"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Próxima Cita / Control en COSAM:</label>
                  <input
                    type="text"
                    value={datosPaciente.proximoControl}
                    onChange={(e) => setDatosPaciente({ ...datosPaciente, proximoControl: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-purple-500 font-medium"
                  />
                </div>
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  onClick={() => setViewMode("vista_previa")}
                  className="py-2.5 px-5 bg-purple-700 hover:bg-purple-800 text-white rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center gap-2 shadow-sm"
                >
                  <Eye size={14} /> Ver Vista Previa del Informe
                </button>
              </div>
            </div>

            {/* PANEL DE SÍNTESIS INTELIGENTE CON IA DESDE REGISTROS RAYEN APS */}
            <div className="liquid-glass rounded-3xl p-6 border border-teal-200/80 shadow-md space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-teal-100 pb-3">
                <div className="flex items-center gap-2">
                  <Sparkles size={18} className="text-teal-700 animate-pulse" />
                  <div>
                    <h3 className="text-xs font-black uppercase tracking-wider text-slate-900">
                      Motor de Síntesis IA de Ficha Rayen APS
                    </h3>
                    <span className="text-[10px] text-slate-500 font-medium">
                      Compila atenciones de Médicos, Psicólogos, T.S. y T.O. en una nota SOAP lista para firma.
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleGenerarSintesisIA}
                    disabled={isGeneratingAI}
                    className="py-2 px-4 bg-gradient-to-r from-teal-700 to-purple-800 hover:from-teal-800 hover:to-purple-900 text-white rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center gap-2 shadow-sm disabled:opacity-50"
                  >
                    {isGeneratingAI ? <RefreshCw size={14} className="animate-spin" /> : <Wand2 size={14} />}
                    <span>{isGeneratingAI ? "Sintetizando..." : "Sintetizar con Gemini IA"}</span>
                  </button>
                  <button
                    onClick={handleCopySintesisIA}
                    className="py-2 px-3 bg-white hover:bg-teal-50 text-slate-700 border border-teal-200 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5"
                    title="Copiar solo síntesis IA"
                  >
                    {copiedIASintesis ? <Check size={13} className="text-teal-600" /> : <Copy size={13} />}
                    <span>{copiedIASintesis ? "¡Copiada!" : "Copiar"}</span>
                  </button>
                </div>
              </div>

              {aiError && (
                <div className="p-3 bg-rose-50 text-rose-800 text-xs rounded-xl border border-rose-200 flex items-center gap-2">
                  <AlertTriangle size={14} className="shrink-0" />
                  <span>{aiError}</span>
                </div>
              )}

              {/* LISTA DE REGISTROS DE LA FICHA RAYEN ALIMENTADORES */}
              <div className="space-y-3">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-700">Registros Multidisciplinarios en Rayen ({registrosRayen.length}):</span>
                  <span className="text-[10px] text-teal-800 font-semibold bg-teal-50 px-2 py-0.5 rounded-md border border-teal-200">
                    Historial Longitudinal PAI
                  </span>
                </div>

                <div className="max-h-56 overflow-y-auto space-y-2 pr-1">
                  {registrosRayen.map((reg) => (
                    <div
                      key={reg.id}
                      className="p-3 bg-white/80 rounded-2xl border border-slate-200 text-xs space-y-1.5 hover:border-teal-300 transition-colors"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="font-black text-purple-900 bg-purple-50 px-2 py-0.5 rounded text-[10px]">
                            {reg.tipoRegistro}
                          </span>
                          <span className="text-[10px] text-slate-500 font-bold">{reg.fecha}</span>
                        </div>
                        <span className="text-[10px] font-bold text-slate-600">{reg.profesional}</span>
                      </div>
                      <p className="text-[11px] text-slate-700 leading-relaxed font-medium">
                        {reg.resumenEntrada}
                      </p>
                      <div className="flex items-center gap-3 text-[10px] text-slate-500 pt-1 border-t border-slate-100">
                        <span><strong>FUC:</strong> {reg.fucReportado}</span>
                        <span><strong>Craving:</strong> {reg.cravingScore}/10</span>
                        <span><strong>Adherencia:</strong> {reg.adherenciaFarmacos}</span>
                      </div>
                    </div>
                  ))}
                </div>

                {/* FORMULARIO PARA AGREGAR NUEVO REGISTRO RAYEN */}
                <div className="pt-2 border-t border-teal-100 space-y-2">
                  <span className="text-[11px] font-bold text-slate-700 block">
                    + Agregar Registro de Ficha Rayen para Sintetizar:
                  </span>
                  <div className="flex flex-col sm:flex-row gap-2">
                    <select
                      value={nuevoRegistroEstamento}
                      onChange={(e) => setNuevoRegistroEstamento(e.target.value as any)}
                      className="p-2 text-xs rounded-xl border border-slate-300 bg-white font-medium sm:w-1/3"
                    >
                      <option value="Control Médico PAI">Control Médico PAI</option>
                      <option value="Evaluación Psicológica">Evaluación Psicológica</option>
                      <option value="Intervención Trabajo Social">Intervención Trabajo Social</option>
                      <option value="Terapia Ocupacional">Terapia Ocupacional</option>
                      <option value="Administración Fármacos / TENS">Administración Fármacos / TENS</option>
                    </select>
                    <input
                      type="text"
                      placeholder="Ingrese texto de la evolución clínica en Rayen..."
                      value={nuevoRegistroTexto}
                      onChange={(e) => setNuevoRegistroTexto(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") handleAgregarRegistroRayen();
                      }}
                      className="flex-1 p-2 text-xs rounded-xl border border-slate-300 font-medium"
                    />
                    <button
                      onClick={handleAgregarRegistroRayen}
                      className="py-2 px-3 bg-teal-700 hover:bg-teal-800 text-white rounded-xl text-xs font-bold transition-all"
                    >
                      Agregar
                    </button>
                  </div>
                </div>
              </div>

              {/* CAMPOS EDITABLES DE LA SÍNTESIS IA */}
              <div className="space-y-3 pt-3 border-t border-teal-100 text-xs">
                <span className="font-bold text-slate-800 block uppercase tracking-wider text-[10px]">
                  Campos Estructurados de la Síntesis IA (Editables):
                </span>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Resumen Evolutivo Global:
                  </label>
                  <textarea
                    rows={2}
                    value={sintesisIA.resumenEvolutivoGlobal}
                    onChange={(e) =>
                      setSintesisIA({ ...sintesisIA, resumenEvolutivoGlobal: e.target.value })
                    }
                    className="w-full p-2 rounded-xl border border-slate-300 font-medium text-xs leading-relaxed"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-700 mb-1">
                      S (Subjetivo - SOAP):
                    </label>
                    <textarea
                      rows={2}
                      value={sintesisIA.analisisSubjetivoSOAP}
                      onChange={(e) =>
                        setSintesisIA({ ...sintesisIA, analisisSubjetivoSOAP: e.target.value })
                      }
                      className="w-full p-2 rounded-xl border border-slate-300 font-medium text-[11px]"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-700 mb-1">
                      O (Objetivo - Rayen):
                    </label>
                    <textarea
                      rows={2}
                      value={sintesisIA.hallazgosObjetivosRayen}
                      onChange={(e) =>
                        setSintesisIA({ ...sintesisIA, hallazgosObjetivosRayen: e.target.value })
                      }
                      className="w-full p-2 rounded-xl border border-slate-300 font-medium text-[11px]"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-700 mb-1">
                      A (Análisis / Diagnóstico):
                    </label>
                    <textarea
                      rows={2}
                      value={sintesisIA.juicioClinicoEvolutivo}
                      onChange={(e) =>
                        setSintesisIA({ ...sintesisIA, juicioClinicoEvolutivo: e.target.value })
                      }
                      className="w-full p-2 rounded-xl border border-slate-300 font-medium text-[11px]"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-700 mb-1">
                      P (Plan &amp; Acuerdos PAI):
                    </label>
                    <textarea
                      rows={2}
                      value={sintesisIA.planIntegralAcordado}
                      onChange={(e) =>
                        setSintesisIA({ ...sintesisIA, planIntegralAcordado: e.target.value })
                      }
                      className="w-full p-2 rounded-xl border border-slate-300 font-medium text-[11px]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Indicaciones Farmacológicas &amp; Receta para Firma:
                  </label>
                  <textarea
                    rows={2}
                    value={sintesisIA.indicacionesFarmacologicasFirma}
                    onChange={(e) =>
                      setSintesisIA({
                        ...sintesisIA,
                        indicacionesFarmacologicasFirma: e.target.value
                      })
                    }
                    className="w-full p-2 rounded-xl border border-slate-300 font-medium text-xs font-mono"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          VISTA PREVIA DEL INFORME MÉDICO / DOCUMENTO IMPRIMIBLE (ESTILO OFICIAL COSAM)
          Este contenedor tiene la clase 'informe-clinico-print' para el CSS @media print
         ========================================================================= */}
      <div className="informe-clinico-container max-w-4xl mx-auto">
        <div
          id="documento-resumen-clinico-pdf"
          className="informe-clinico-paper bg-white text-slate-900 p-8 sm:p-12 rounded-3xl shadow-xl border border-slate-200 space-y-8 relative"
        >
          
          {/* ENCABEZADO INSTITUCIONAL OFICIAL */}
          <header className="border-b-2 border-purple-900/80 pb-6 space-y-4">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <div className="w-10 h-10 rounded-xl bg-purple-900 text-white flex items-center justify-center font-black text-sm shadow-md">
                    SSMSO
                  </div>
                  <div>
                    <h1 className="text-sm font-black text-purple-950 uppercase tracking-tight leading-tight">
                      Servicio de Salud Metropolitano Sur Oriente
                    </h1>
                    <h2 className="text-xs font-bold text-slate-700">
                      Municipalidad de San Ramón • Dirección de Salud
                    </h2>
                    <h3 className="text-xs font-black text-purple-800 tracking-wide">
                      COSAM Rinconada de San Ramón — Programa de Adicciones (PAI)
                    </h3>
                  </div>
                </div>
              </div>

              <div className="text-left sm:text-right border-l-2 sm:border-l-0 sm:border-r-0 border-purple-200 pl-3 sm:pl-0">
                <span className="text-[10px] font-black uppercase tracking-widest text-slate-400 block">
                  Documento Médico Oficial
                </span>
                <span className="text-sm font-black text-slate-900 block">
                  INFORME RESUMEN CLÍNICO
                </span>
                <span className="text-xs font-bold text-purple-900 block">
                  Fecha: {datosPaciente.fechaAtencion}
                </span>
              </div>
            </div>

            <div className="pt-2 flex flex-wrap justify-between items-center text-[11px] text-slate-600 font-medium bg-slate-50 p-2.5 rounded-xl border border-slate-200">
              <span><strong>Médico Tratante:</strong> {datosPaciente.medicoTratante}</span>
              <span><strong>Registro SIS:</strong> {datosPaciente.registroColegio}</span>
              <span><strong>Comuna:</strong> San Ramón, RM</span>
            </div>
          </header>

          {/* SECCIÓN 1: DATOS DEL PACIENTE Y DIAGNÓSTICO */}
          {modulos.datosPaciente && (
            <section className="space-y-3">
              <div className="flex items-center gap-2 border-b border-slate-200 pb-1.5">
                <User size={15} className="text-purple-800" />
                <h4 className="text-xs font-black uppercase tracking-wider text-purple-950">
                  1. Identificación del Paciente y Estado Diagnóstico
                </h4>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs bg-purple-50/50 p-4 rounded-2xl border border-purple-100">
                <div>
                  <span className="text-[10px] font-bold text-slate-500 uppercase block">Nombre:</span>
                  <strong className="text-slate-900 font-bold">{datosPaciente.nombrePaciente}</strong>
                </div>
                <div>
                  <span className="text-[10px] font-bold text-slate-500 uppercase block">RUT / Ficha:</span>
                  <strong className="text-slate-900 font-bold">{datosPaciente.rut}</strong>
                </div>
                <div>
                  <span className="text-[10px] font-bold text-slate-500 uppercase block">Edad:</span>
                  <strong className="text-slate-900 font-bold">{datosPaciente.edad}</strong>
                </div>
                <div>
                  <span className="text-[10px] font-bold text-slate-500 uppercase block">Estado Clínico:</span>
                  <span className="inline-block font-black text-purple-900 bg-purple-200/80 px-2 py-0.5 rounded text-[10.5px]">
                    {datosPaciente.estadoConsumo}
                  </span>
                </div>
                <div className="col-span-2 sm:col-span-3">
                  <span className="text-[10px] font-bold text-slate-500 uppercase block">Diagnóstico Principal:</span>
                  <strong className="text-purple-950 font-bold">{datosPaciente.diagnosticoPrincipal}</strong>
                </div>
                <div>
                  <span className="text-[10px] font-bold text-slate-500 uppercase block">Sustancia Principal:</span>
                  <strong className="text-slate-900 font-bold">{datosPaciente.sustanciaPrincipal}</strong>
                </div>
              </div>
            </section>
          )}

          {/* SECCIÓN 2: NOTAS DE EVOLUCIÓN IA (SÍNTESIS ESTRUCTURADA RAYEN APS & LISTA PARA FIRMA) */}
          {modulos.notasEvolucionIA && (
            <section className="space-y-3">
              <div className="flex items-center justify-between border-b border-slate-200 pb-1.5">
                <div className="flex items-center gap-2">
                  <Sparkles size={15} className="text-teal-800" />
                  <h4 className="text-xs font-black uppercase tracking-wider text-purple-950">
                    2. Notas de Evolución IA — Síntesis Longitudinal Rayen APS
                  </h4>
                </div>
                <span className="text-[10px] font-mono font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                  Folio: {sintesisIA.folioValidacion}
                </span>
              </div>

              {/* RESUMEN GLOBAL SINTETIZADO */}
              <div className="p-4 rounded-2xl bg-teal-50/50 border border-teal-200 space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-black uppercase tracking-wider text-teal-900 flex items-center gap-1.5">
                    <ShieldCheck size={13} className="text-teal-700" />
                    Síntesis Multidisciplinaria Oficial (Médica, Psicológica, T.S. y T.O.)
                  </span>
                  <span className="text-[10px] text-teal-800 font-bold">
                    Generado: {sintesisIA.fechaGeneracion}
                  </span>
                </div>
                <p className="text-[11.5px] text-slate-800 leading-relaxed font-medium">
                  {sintesisIA.resumenEvolutivoGlobal}
                </p>
                <div className="pt-1.5 border-t border-teal-200/80 flex flex-wrap items-center gap-4 text-[10.5px] text-teal-900 font-semibold">
                  <span><strong>FUC &amp; Remisión:</strong> {sintesisIA.frecuenciaConsumoYFUC}</span>
                </div>
              </div>

              {/* ESTRUCTURA SOAP DETALLADA DE LA EVOLUCIÓN */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="p-3 bg-white rounded-xl border border-slate-200 space-y-1">
                  <span className="text-[10px] font-black uppercase text-purple-900 block">
                    [S] Subjetivo — Relato &amp; Craving:
                  </span>
                  <p className="text-[11px] text-slate-700 leading-relaxed font-medium">
                    {sintesisIA.analisisSubjetivoSOAP}
                  </p>
                </div>

                <div className="p-3 bg-white rounded-xl border border-slate-200 space-y-1">
                  <span className="text-[10px] font-black uppercase text-purple-900 block">
                    [O] Objetivo — Examen &amp; Registros Rayen:
                  </span>
                  <p className="text-[11px] text-slate-700 leading-relaxed font-medium">
                    {sintesisIA.hallazgosObjetivosRayen}
                  </p>
                </div>

                <div className="p-3 bg-white rounded-xl border border-slate-200 space-y-1">
                  <span className="text-[10px] font-black uppercase text-purple-900 block">
                    [A] Análisis / Juicio Clínico Evolutivo:
                  </span>
                  <p className="text-[11px] text-slate-700 leading-relaxed font-medium">
                    {sintesisIA.juicioClinicoEvolutivo}
                  </p>
                </div>

                <div className="p-3 bg-white rounded-xl border border-slate-200 space-y-1">
                  <span className="text-[10px] font-black uppercase text-purple-900 block">
                    [P] Plan Acordado &amp; Derivaciones PAI:
                  </span>
                  <p className="text-[11px] text-slate-700 leading-relaxed font-medium">
                    {sintesisIA.planIntegralAcordado}
                  </p>
                </div>
              </div>

              {/* INDICACIONES FARMACOLÓGICAS Y RECETA OFICIAL LISTA PARA FIRMAR */}
              <div className="p-3.5 bg-slate-900 text-slate-100 rounded-2xl border border-slate-800 space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <FileSignature size={14} className="text-teal-400" />
                    <span className="text-[10.5px] font-black uppercase tracking-wider text-teal-300">
                      Prescripción Farmacológica Oficial Estructurada para Firma
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-400 font-mono">
                    Validez en Farmacia APS
                  </span>
                </div>
                <pre className="font-mono text-[11px] text-slate-200 whitespace-pre-wrap bg-slate-950/60 p-2.5 rounded-xl border border-slate-800 leading-relaxed">
                  {sintesisIA.indicacionesFarmacologicasFirma}
                </pre>
              </div>
            </section>
          )}

          {/* SECCIÓN 3: BASES NEUROBIOLÓGICAS (CIRCUITO DE RECOMPENSA & D2) */}
          {modulos.neurobiologia && (
            <section className="space-y-3">
              <div className="flex items-center gap-2 border-b border-slate-200 pb-1.5">
                <Brain size={15} className="text-purple-800" />
                <h4 className="text-xs font-black uppercase tracking-wider text-purple-950">
                  3. Hallazgos Neurobiológicos &amp; Circuito Dopaminérgico
                </h4>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                <div className="p-3.5 rounded-xl border border-slate-200 bg-white space-y-1">
                  <span className="text-[10px] font-black uppercase text-purple-800 block">
                    Área Tegmental Ventral (ATV)
                  </span>
                  <p className="text-[11px] text-slate-700 leading-relaxed font-medium">
                    Liberación suprafisiológica masiva de dopamina provocada por las sustancias, fijando la memoria del consumo como prioridad máxima de supervivencia.
                  </p>
                </div>

                <div className="p-3.5 rounded-xl border border-slate-200 bg-white space-y-1">
                  <span className="text-[10px] font-black uppercase text-purple-800 block">
                    Núcleo Accumbens (Receptores D2)
                  </span>
                  <p className="text-[11px] text-slate-700 leading-relaxed font-medium">
                    <strong>Down-regulation severa de receptores D2</strong>. Explica la anhedonia y la incapacidad transitoria para disfrutar de los estímulos naturales.
                  </p>
                </div>

                <div className="p-3.5 rounded-xl border border-slate-200 bg-white space-y-1">
                  <span className="text-[10px] font-black uppercase text-purple-800 block">
                    Corteza Prefrontal (Freno Ejecutivo)
                  </span>
                  <p className="text-[11px] text-slate-700 leading-relaxed font-medium">
                    Hipofrontalidad transitoria con deterioro del control inhibitorio y labilidad ante gatillantes contextuales de craving.
                  </p>
                </div>
              </div>

              <div className="p-3 bg-purple-50 rounded-xl border border-purple-200 text-[11px] text-purple-950 font-medium">
                <strong>Fundamento Clínico para el Paciente:</strong> La apatía y el deseo de consumo son consecuencias biológicas directas del agotamiento de receptores en el cerebro, no una debilidad moral. Con abstinencia y tratamiento, los receptores D2 vuelven a expresarse.
              </div>
            </section>
          )}

          {/* SECCIÓN 4: SINTOMATOLOGÍA & BANDERAS ROJAS DETECTADAS */}
          {modulos.sintomatologia && (
            <section className="space-y-3">
              <div className="flex items-center gap-2 border-b border-slate-200 pb-1.5">
                <AlertTriangle size={15} className="text-amber-700" />
                <h4 className="text-xs font-black uppercase tracking-wider text-purple-950">
                  4. Síntomas Físicos, Metabólicos y Psíquicos en Tratamiento
                </h4>
              </div>

              <div className="space-y-2">
                {selectedSintomas.map((sId) => {
                  const s = SINTOMAS_CLINICOS_DATA.find((item) => item.id === sId);
                  if (!s) return null;
                  return (
                    <div key={s.id} className="p-3 rounded-xl border border-slate-200 bg-slate-50/80 flex flex-col sm:flex-row justify-between sm:items-center gap-2 text-xs">
                      <div>
                        <strong className="text-slate-900 font-bold block">{s.titulo}</strong>
                        <span className="text-[11px] text-slate-600 block">{s.fisiopatologiaExplicada}</span>
                      </div>
                      <div className="text-left sm:text-right shrink-0">
                        <span className="text-[10px] font-black text-purple-900 bg-purple-100 px-2 py-0.5 rounded block sm:inline-block">
                          Reversibilidad: {s.tiempoEstimado}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </section>
          )}

          {/* SECCIÓN 5: PAUTA DE MICRORREHABILITACIÓN NUTRICIONAL */}
          {modulos.nutricion && (
            <section className="space-y-3">
              <div className="flex items-center gap-2 border-b border-slate-200 pb-1.5">
                <Apple size={15} className="text-teal-800" />
                <h4 className="text-xs font-black uppercase tracking-wider text-purple-950">
                  5. Plan de Microrrehabilitación &amp; Suplementación Dopaminérgica
                </h4>
              </div>

              <div className="border border-slate-200 rounded-xl overflow-hidden text-xs">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-purple-900 text-white text-[10px] font-black uppercase tracking-wider">
                      <th className="p-2.5">Micronutriente</th>
                      <th className="p-2.5">Rol en Salud Mental &amp; Adicciones</th>
                      <th className="p-2.5">Dosis Sugerida</th>
                      <th className="p-2.5">Alimentos Fuentes Clave</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {selectedNutrientes.map((nId) => {
                      const n = MICRONUTRIENTES_DATA.find((item) => item.id === nId);
                      if (!n) return null;
                      return (
                        <tr key={n.id} className="hover:bg-purple-50/50">
                          <td className="p-2.5 font-bold text-purple-950">{n.nombre}</td>
                          <td className="p-2.5 text-slate-700 text-[11px]">{n.rolEnSaludMental}</td>
                          <td className="p-2.5 font-semibold text-slate-900 text-[11px]">{n.dosisSugeridaReposicion}</td>
                          <td className="p-2.5 text-slate-600 text-[11px]">{n.alimentosFuentes.slice(0, 3).join(", ")}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </section>
          )}

          {/* SECCIÓN 6: NEUROPLASTICIDAD & FACTORES PROTECTORES */}
          {modulos.neuroplasticidad && (
            <section className="space-y-3">
              <div className="flex items-center gap-2 border-b border-slate-200 pb-1.5">
                <Activity size={15} className="text-indigo-800" />
                <h4 className="text-xs font-black uppercase tracking-wider text-purple-950">
                  6. Prescripción de Neuroplasticidad &amp; Factores Protectores
                </h4>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                <div className="p-3 bg-teal-50/80 rounded-xl border border-teal-200 space-y-1">
                  <span className="text-[10px] font-black uppercase text-teal-950 block">
                    Actividad Física Aeróbica (BDNF)
                  </span>
                  <p className="text-[11px] text-teal-900 font-medium leading-relaxed">
                    150 min/semana de caminata rápida, trote o bicicleta. Aumenta el BDNF en 200%, acelerando la creación de nuevas espinas dendríticas.
                  </p>
                </div>

                <div className="p-3 bg-indigo-50/80 rounded-xl border border-indigo-200 space-y-1">
                  <span className="text-[10px] font-black uppercase text-indigo-950 block">
                    Vínculo &amp; Grupo Psicoterapéutico COSAM
                  </span>
                  <p className="text-[11px] text-indigo-900 font-medium leading-relaxed">
                    Asistencia semanal a los talleres del programa. La oxitocina y la pertenencia reducen el cortisol (estrés alostático) en la amígdala.
                  </p>
                </div>

                <div className="p-3 bg-amber-50/80 rounded-xl border border-amber-200 space-y-1">
                  <span className="text-[10px] font-black uppercase text-amber-950 block">
                    Higiene de Sueño Delta Profundo
                  </span>
                  <p className="text-[11px] text-amber-900 font-medium leading-relaxed">
                    Horarios regulares de descanso para activar la depuración glinfática nocturna y la síntesis de hormona de crecimiento reparadora.
                  </p>
                </div>
              </div>
            </section>
          )}

          {/* SECCIÓN 7: OBSERVACIONES MÉDICAS & FARMACOTERAPIA */}
          {modulos.planFarmacologico && (
            <section className="space-y-3">
              <div className="flex items-center gap-2 border-b border-slate-200 pb-1.5">
                <Stethoscope size={15} className="text-purple-800" />
                <h4 className="text-xs font-black uppercase tracking-wider text-purple-950">
                  7. Indicaciones Médicas, Farmacoterapia &amp; Plan de Box
                </h4>
              </div>

              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2 text-xs">
                <p className="text-slate-800 font-medium leading-relaxed">
                  {datosPaciente.notasMedicasBox}
                </p>
                <div className="pt-2 border-t border-slate-200 flex justify-between items-center text-xs">
                  <span className="font-bold text-slate-700">Próximo Control en COSAM:</span>
                  <strong className="text-purple-900 font-black">{datosPaciente.proximoControl}</strong>
                </div>
              </div>
            </section>
          )}

          {/* SECCIÓN 8: ALERTAS DE EMERGENCIA & SOS */}
          {modulos.alertasEmergencia && (
            <section className="p-3.5 bg-rose-50 rounded-2xl border border-rose-200 space-y-1.5 text-xs text-rose-950">
              <div className="flex items-center gap-2 font-black uppercase text-[11px] text-rose-900">
                <ShieldAlert size={15} className="text-rose-700" />
                8. Signos de Alarma para Consultar a Urgencias (SAPU / Hospital Padre Hurtado / Fono Drogas 1412):
              </div>
              <p className="text-[11px] font-medium leading-relaxed">
                Dolor torácico opresivo, palpitaciones incontrolables (&gt;130 lpm), ideación autolítica activa, alucinaciones auditivas/visuales persecutorias o convulsiones. En caso de craving de alta intensidad, activar protocolo de la herramienta <strong>Pausa y Control SOS</strong>.
              </p>
            </section>
          )}

          {/* SECCIÓN 9: COMPROMISO TERAPÉUTICO Y FIRMAS */}
          {modulos.compromisoTerapeutico && (
            <footer className="pt-8 border-t-2 border-purple-900/80 space-y-8">
              <div className="grid grid-cols-2 gap-12 text-center text-xs">
                <div className="space-y-2">
                  <div className="border-b border-slate-400 w-4/5 mx-auto h-12"></div>
                  <strong className="text-slate-900 block font-black">{datosPaciente.medicoTratante}</strong>
                  <span className="text-[11px] text-slate-600 block">{datosPaciente.registroColegio}</span>
                  <span className="text-[10px] text-purple-900 uppercase font-black block">Médico Tratante • COSAM Rinconada</span>
                </div>

                <div className="space-y-2">
                  <div className="border-b border-slate-400 w-4/5 mx-auto h-12"></div>
                  <strong className="text-slate-900 block font-black">{datosPaciente.nombrePaciente}</strong>
                  <span className="text-[11px] text-slate-600 block">RUT: {datosPaciente.rut}</span>
                  <span className="text-[10px] text-slate-500 uppercase font-bold block">Firma del Paciente / Familiar Responsable</span>
                </div>
              </div>

              <div className="text-center text-[10px] text-slate-400 font-medium">
                COSAM Rinconada de San Ramón • Av. Santa Rosa / Calle Alpatacal, San Ramón • Teléfono: (2) 2585 1200 • Red de Salud Sur Oriente
              </div>
            </footer>
          )}
        </div>
      </div>
    </div>
  );
}
