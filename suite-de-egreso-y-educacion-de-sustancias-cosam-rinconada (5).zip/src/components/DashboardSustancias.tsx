import { useState } from "react";
import { Sustancia } from "../types";
import { motion, AnimatePresence } from "motion/react";
import {
  Brain,
  Heart,
  Activity,
  AlertTriangle,
  Users,
  ShieldAlert,
  Flame,
  Layers,
  Sparkles,
  ArrowRight,
  TrendingUp,
  RotateCcw,
  Printer
} from "lucide-react";

const SUBSTANCES_DATA: Sustancia[] = [
  {
    id: "cera-pb",
    nombre: "Cera de Pasta Base",
    alias: '"Fentanilo Chileno" / "Cera"',
    categoria: "Estimulante sintético/químico altamente adulterado",
    naturaleza: "Alcaloide estimulante degradado y adulterado (derivado químico)",
    principioActivo: "Sulfato de cocaína y residuos de precursores químicos",
    mecanismoExtraccion: "Desechos residuales (borra) de la maceración de la hoja de coca",
    perfilConsumidor: "Poblaciones en extrema vulnerabilidad, menores marginados, personas en situación de calle",
    duracionEfecto: "Extremadamente breve y explosiva (no superior a 40 segundos)",
    secuelaCrash: 'Disforia severa ("angustia"), paranoia extrema, craving compulsivo irrefrenable',
    riesgoVital: "Extremo",
    descripcion: "Variante super-estimulante y alucinógena resultante de precipitaciones incompletas y retención de solventes industriales no evaporados, mezclados con adulterantes de bajo costo para abultar el peso.",
    sistemasImpacto: {
      sistemaNervioso: {
        nivel: "Extremo",
        detalles: "Apoptosis (muerte celular programada) en la corteza prefrontal y estriado. Induce psicosis tóxica, delirio de Ekbom (parasitosis táctil: insectos bajo la piel que causan autolesiones graves) y abolición total del raciocinio por secuestro del circuito de recompensa."
      },
      sistemaRespiratorio: {
        nivel: "Extremo",
        detalles: "Necrosis del epitelio alveolar por gases corrosivos de la combustión. Produce quemaduras químicas en mucosas, broncoespasmos severos e insuficiencia respiratoria paulatina debido al humo de solventes y metales pesados."
      },
      sistemaCardiovascular: {
        nivel: "Extremo",
        detalles: "Taquicardia severa refleja, arritmias letales y riesgo agudo de paro cardíaco debido a la hiperdosificación compulsiva y las trazas de solventes orgánicos y precursores ácidos."
      },
      sistemaDigestivoYOtros: {
        nivel: "Extremo",
        detalles: "Caída prematura y corrosión de piezas dentales por vapores ácidos directamente en la boca. Ulceraciones en mucosa oral, caquexia extrema (desnutrición proteica severa por supresión del hipotálamo) y envejecimiento cutáneo acelerado."
      }
    },
    impactoSocial: "Deserción escolar inmediata, ruptura absoluta de vínculos familiares, deambulación errática incesante (fenotipo 'zombi' de 24/7) y transición irreversible a la vida de calle e involucración en círculos de violencia armada.",
    datosEpidemiologicos: "1.8% de prevalencia basal escolar en Chile. Su extrema adicción genera una demanda inelástica con compras continuas cada pocos minutos (comercializado en dosis de 500 a 1000 CLP 'quina' o 'luca').",
    sintomasClinicos: ["Psicosis inducida", "Alucinaciones táctiles (Ekbom)", "Marcha errática", "Caquexia extrema", "Pérdida dental rápida", "Ansiedad vegetativa incontrolable"]
  },
  {
    id: "cera-marihuana",
    nombre: "Cera de Marihuana",
    alias: '"Wax" / "BHO" / "Rosin"',
    categoria: "Fitocannabinoide concentrado",
    naturaleza: "Derivado botánico concentrado",
    principioActivo: "Tetrahidrocannabinol (THC) en altas concentraciones (hasta 80-90%)",
    mecanismoExtraccion: "Solventes orgánicos (gas butano) o termopresión",
    perfilConsumidor: "Usuarios recreativos, policonsumidores con poder adquisitivo medio-alto",
    duracionEfecto: "Prolongada (varias horas)",
    secuelaCrash: "Apatía generalizada, letargo, distorsión cognitiva, somnolencia profunda",
    riesgoVital: "Medio",
    descripcion: "Extractos concentrados de la planta de cannabis sativa que hiperestimulan el sistema endocannabinoide, con una potencia y pureza enormemente superiores al cogollo tradicional.",
    sistemasImpacto: {
      sistemaNervioso: {
        nivel: "Alto",
        detalles: "Hiperestimulación endocannabinoide. Deterioro severo de la atención, memoria de trabajo y funciones ejecutivas del lóbulo frontal. Puede desencadenar brotes psicóticos agudos e ideación paranoide."
      },
      sistemaRespiratorio: {
        nivel: "Alto",
        detalles: "Daño pulmonar obstructivo crónico comparable al tabaquismo severo. Riesgo de bronquitis, sibilancias e hipoxia pulmonar, ocasionalmente neumotórax por inhalaciones forzadas de vapores de alta temperatura."
      },
      sistemaCardiovascular: {
        nivel: "Medio",
        detalles: "Incremento agudo de la frecuencia cardíaca (taquicardia leve a moderada) y fluctuaciones de la presión arterial."
      },
      sistemaDigestivoYOtros: {
        nivel: "Bajo",
        detalles: "Hiperemia conjuntival severa (ojos rojos), incremento desmedido del apetito y vértigo o vómitos paradójicos por sobredosis de THC."
      }
    },
    impactoSocial: "Deserción escolar silenciosa por síndrome amotivacional, aislamiento de redes de apoyo, apatía severa que detiene proyectos vitales y vulnerabilidad a transitar a otras sustancias.",
    datosEpidemiologicos: "Sustancia de alta penetración recreativa. Chile supera el 10% de prevalencia anual de consumo de cannabis general, de la cual la cera es la variante más concentrada y cara.",
    sintomasClinicos: ["Brotes psicóticos", "Paranoia aguda", "Síndrome amotivacional", "Ojos rojos persistentes", "Déficit cognitivo frontal", "Bronquitis obstructiva"]
  },
  {
    id: "cocaina",
    nombre: "Clorhidrato de Cocaína",
    alias: '"Coca" / "Nieve" / "Fino"',
    categoria: "Estimulante del SNC refinado",
    naturaleza: "Alcaloide natural procesado (sal clorhidrato soluble)",
    principioActivo: "Clorhidrato de cocaína purificado",
    mecanismoExtraccion: "Precipitación ácida y cristalización con solventes refinados (éter, acetona)",
    perfilConsumidor: "Población transversal, ligado comúnmente a contextos laborales estresantes o recreativos",
    duracionEfecto: "Moderada (20 a 45 minutos)",
    secuelaCrash: "Disforia moderada, fatiga, irritabilidad, insomnio, rebote depresivo",
    riesgoVital: "Alto",
    descripcion: "Sal cristalina refinada que se inhala por vía nasal, actuando como un potente simpaticomimético y estimulante que eleva bruscamente la dopamina sin combustión de precursores sucios.",
    sistemasImpacto: {
      sistemaNervioso: {
        nivel: "Alto",
        detalles: "Bloqueo de la recaptación de dopamina. Provoca hiperalerta, euforia, irritabilidad y conductas de riesgo. Crónicamente causa trastornos depresivos severos y ansiedad paranoide."
      },
      sistemaRespiratorio: {
        nivel: "Medio",
        detalles: "Vasoconstricción local nasal. Produce necrosis crónica del tabique nasal, sinusitis y anosmia. Si se fuma en base libre (crack), causa el síndrome de 'pulmón de crack' con hemorragia alveolar."
      },
      sistemaCardiovascular: {
        nivel: "Extremo",
        detalles: "Vasoespasmo coronario agudo, hipertensión arterial severa, taquiarritmias e infartos agudos de miocardio, incluso en jóvenes sin cardiopatías preexistentes."
      },
      sistemaDigestivoYOtros: {
        nivel: "Medio",
        detalles: "Pérdida del apetito, bruxismo severo con desgaste dental por tensión muscular y riesgo de úlceras gástricas por isquemia esplácnica."
      }
    },
    impactoSocial: "Alto gasto económico que erosiona el patrimonio familiar, problemas legales, conductas de infidelidad y agresión bajo efectos de omnipotencia, aislamiento social progresivo.",
    datosEpidemiologicos: "Sustancia con alta tasa de tratamiento en centros urbanos. Chile cuenta con una de las tasas de consumo de cocaína más estables y elevadas de Sudamérica.",
    sintomasClinicos: ["Taquicardia extrema", "Vasoconstricción nasal", "Paranoia persecutoria", "Insomnio severo", "Mandibuleo / Bruxismo", "Conductas impulsivas"]
  },
  {
    id: "pasta-base",
    nombre: "Pasta Base de Cocaína (Tradicional)",
    alias: '"Pasta" / "Mono" / "Bazuco" / "Paco"',
    categoria: "Estimulante del SNC crudo",
    naturaleza: "Sulfato de cocaína sin purificar (base libre rústica)",
    principioActivo: "Sulfato de cocaína con trazas de precursores químicos",
    mecanismoExtraccion: "Maceración primaria de hoja de coca con ácido sulfúrico y queroseno",
    perfilConsumidor: "Sectores marginados, poblaciones con alta vulnerabilidad económica",
    duracionEfecto: "Breve (5 a 10 minutos)",
    secuelaCrash: 'Angustia severa, disforia, compulsión por repetir la dosis ("antojo")',
    riesgoVital: "Alto",
    descripcion: "Producto intermedio crudo del proceso de refinamiento de la cocaína. Se fuma en pipas improvisadas, facilitando la llegada instantánea del alcaloide al cerebro.",
    sistemasImpacto: {
      sistemaNervioso: {
        nivel: "Alto",
        detalles: "Inundación dopaminérgica instantánea en el circuito mesolímbico. Provoca angustia inmediata post-efecto, impulsividad descontrolada, paranoia y alucinaciones transitorias."
      },
      sistemaRespiratorio: {
        nivel: "Alto",
        detalles: "Enfisema pulmonar acelerado, bronquitis crónica e irritación de la mucosa respiratoria por la inhalación de hollín, queroseno y residuos corrosivos del sulfato."
      },
      sistemaCardiovascular: {
        nivel: "Alto",
        detalles: "Cardiopatía isquémica, arritmias, hipertensión reactiva y alto riesgo de crisis hipertensiva debido a las múltiples caladas en periodos de tiempo cortos."
      },
      sistemaDigestivoYOtros: {
        nivel: "Alto",
        detalles: "Inapetencia grave, desnutrición acelerada, sequedad bucal extrema y caries rampantes debido a la acidez de la combustión y la inhibición de la salivación."
      }
    },
    impactoSocial: "Estigmatización extrema, asimilación rápida a la delincuencia instrumental de sobrevivencia, destrucción de la red familiar y comunitaria, alta prevalencia en barrios marginales.",
    datosEpidemiologicos: "Históricamente el principal flagelo de los barrios precarizados de Chile desde la década de los 90. Es el antecesor directo que hoy está siendo desplazado por la letalidad de la 'cera'.",
    sintomasClinicos: ["Angustia / Craving", "Quemaduras en labios", "Pérdida acelerada de peso", "Bruxismo agudo", "Tos con esputo carbonáceo", "Suspicacia extrema"]
  }
];

export default function DashboardSustancias() {
  const [selectedSubstance, setSelectedSubstance] = useState<Sustancia | null>(null);
  const [compareSource, setCompareSource] = useState<string>("cera-pb");
  const [compareTarget, setCompareTarget] = useState<string>("cera-marihuana");
  const [selectedSystemTab, setSelectedSystemTab] = useState<"nervioso" | "respiratorio" | "cardiovascular" | "otros">("nervioso");

  const handleDownloadPDF = (sust: Sustancia) => {
    const printWindow = window.open("", "_blank");
    if (!printWindow) {
      alert("Por favor, permita las ventanas emergentes (popups) para descargar la ficha educativa en PDF.");
      return;
    }

    printWindow.document.title = `Ficha_Educativa_${sust.nombre.replace(/\s+/g, "_")}`;

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <title>Ficha Educativa - ${sust.nombre}</title>
          <style>
            @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap');
            
            body {
              font-family: 'Plus Jakarta Sans', -apple-system, sans-serif;
              color: #1e293b;
              margin: 0;
              padding: 40px;
              background-color: #ffffff;
              line-height: 1.5;
              -webkit-print-color-adjust: exact;
              print-color-adjust: exact;
            }

            @page {
              size: A4;
              margin: 15mm 20mm;
            }

            .header {
              border-bottom: 3px solid #7c3aed;
              padding-bottom: 20px;
              margin-bottom: 25px;
              display: flex;
              justify-content: space-between;
              align-items: flex-start;
            }

            .header-info h1 {
              font-size: 26px;
              font-weight: 800;
              color: #0f172a;
              margin: 0 0 5px 0;
              letter-spacing: -0.025em;
            }

            .header-info p {
              font-size: 13px;
              color: #64748b;
              margin: 0;
              font-weight: 600;
            }

            .badge {
              background-color: #f3e8ff;
              color: #6b21a8;
              border: 1px solid #e9d5ff;
              font-size: 10px;
              font-weight: 800;
              text-transform: uppercase;
              padding: 5px 12px;
              border-radius: 6px;
              letter-spacing: 0.05em;
            }

            .riesgo-badge {
              font-size: 10px;
              font-weight: 800;
              text-transform: uppercase;
              padding: 5px 12px;
              border-radius: 6px;
              letter-spacing: 0.05em;
              margin-top: 5px;
              display: inline-block;
            }

            .riesgo-extremo { background-color: #fee2e2; color: #991b1b; border: 1px solid #fca5a5; }
            .riesgo-alto { background-color: #ffedd5; color: #9a3412; border: 1px solid #fed7aa; }
            .riesgo-medio { background-color: #fef9c3; color: #854d0e; border: 1px solid #fef08a; }
            .riesgo-bajo { background-color: #dcfce7; color: #166534; border: 1px solid #bbf7d0; }

            .desc-box {
              background-color: #f8fafc;
              border: 1px solid #e2e8f0;
              padding: 15px 20px;
              border-radius: 12px;
              font-size: 13px;
              color: #475569;
              margin-bottom: 25px;
              line-height: 1.6;
            }

            .section-title {
              font-size: 14px;
              font-weight: 800;
              text-transform: uppercase;
              color: #7c3aed;
              letter-spacing: 0.05em;
              border-bottom: 1px solid #e2e8f0;
              padding-bottom: 6px;
              margin: 25px 0 15px 0;
            }

            .grid-2 {
              display: grid;
              grid-template-columns: 1fr 1fr;
              gap: 20px;
              margin-bottom: 20px;
            }

            .card {
              border: 1px solid #f1f5f9;
              background-color: #fafbfd;
              padding: 15px;
              border-radius: 10px;
            }

            .card h3 {
              font-size: 12px;
              font-weight: 800;
              color: #334155;
              text-transform: uppercase;
              margin: 0 0 10px 0;
              letter-spacing: 0.025em;
            }

            .meta-item {
              display: flex;
              border-bottom: 1px solid #f1f5f9;
              padding: 8px 0;
              font-size: 12px;
            }
            .meta-item:last-child {
              border-bottom: none;
            }

            .meta-label {
              font-weight: 700;
              color: #64748b;
              width: 110px;
              flex-shrink: 0;
            }

            .meta-value {
              color: #334155;
              font-weight: 500;
            }

            .system-grid {
              display: grid;
              grid-template-columns: 1fr 1fr;
              gap: 15px;
            }

            .system-box {
              border: 1px solid #e2e8f0;
              border-radius: 10px;
              padding: 12px 15px;
              background-color: #ffffff;
            }

            .system-header {
              display: flex;
              justify-content: space-between;
              align-items: center;
              margin-bottom: 8px;
            }

            .system-name {
              font-size: 11px;
              font-weight: 800;
              text-transform: uppercase;
              color: #1e293b;
            }

            .system-desc {
              font-size: 11.5px;
              color: #475569;
              margin: 0;
              line-height: 1.5;
            }

            .sintomas-container {
              display: flex;
              flex-wrap: wrap;
              gap: 8px;
              margin-top: 10px;
            }

            .sintoma-pill {
              background-color: #f5f3ff;
              border: 1px solid #ddd6fe;
              color: #5b21b6;
              font-size: 11px;
              font-weight: 700;
              padding: 5px 10px;
              border-radius: 6px;
            }

            .footer {
              margin-top: 40px;
              border-top: 1px solid #e2e8f0;
              padding-top: 15px;
              text-align: center;
              font-size: 10px;
              font-weight: 700;
              color: #94a3b8;
              text-transform: uppercase;
              letter-spacing: 0.1em;
            }
          </style>
        </head>
        <body>
          <div class="header">
            <div class="header-info">
              <p>COSAM Rinconada de San Ramón — Programa de Adicciones</p>
              <h1>Ficha Educativa: ${sust.nombre}</h1>
              <p>Denominación Común: <strong>${sust.alias}</strong></p>
            </div>
            <div style="text-align: right;">
              <span class="badge">${sust.categoria}</span>
              <br/>
              <span class="riesgo-badge riesgo-${sust.riesgoVital.toLowerCase()}">Riesgo Vital: ${sust.riesgoVital}</span>
            </div>
          </div>

          <div class="desc-box">
            <strong>Descripción General:</strong><br/>
            ${sust.descripcion}
          </div>

          <div class="grid-2">
            <div class="card">
              <h3>Ficha Química &amp; Farmacológica</h3>
              <div class="meta-item">
                <span class="meta-label">Naturaleza:</span>
                <span class="meta-value">${sust.naturaleza}</span>
              </div>
              <div class="meta-item">
                <span class="meta-label">P. Activo:</span>
                <span class="meta-value">${sust.principioActivo}</span>
              </div>
              <div class="meta-item">
                <span class="meta-label">Extracción:</span>
                <span class="meta-value">${sust.mecanismoExtraccion}</span>
              </div>
              <div class="meta-item">
                <span class="meta-label">Duración:</span>
                <span class="meta-value" style="color: #dc2626; font-weight: 700;">${sust.duracionEfecto}</span>
              </div>
              <div class="meta-item">
                <span class="meta-label">Efecto Crash:</span>
                <span class="meta-value" style="color: #ea580c; font-weight: 700;">${sust.secuelaCrash}</span>
              </div>
            </div>

            <div class="card">
              <h3>Dinámicas Sociales &amp; Perfil</h3>
              <div class="meta-item">
                <span class="meta-label">Población:</span>
                <span class="meta-value">${sust.perfilConsumidor}</span>
              </div>
              <div class="meta-item">
                <span class="meta-label">Epidemiología:</span>
                <span class="meta-value">${sust.datosEpidemiologicos}</span>
              </div>
              <div class="meta-item" style="flex-direction: column; align-items: flex-start; border-bottom: none;">
                <span class="meta-label" style="width: 100%; margin-bottom: 4px;">Impacto Social:</span>
                <span class="meta-value" style="font-size: 11px; line-height: 1.4;">${sust.impactoSocial}</span>
              </div>
            </div>
          </div>

          <div class="section-title">Impacto Fisiológico por Sistemas del Cuerpo</div>
          <div class="system-grid">
            <div class="system-box">
              <div class="system-header">
                <span class="system-name">Sistema Nervioso Central</span>
                <span class="riesgo-badge riesgo-${sust.sistemasImpacto.sistemaNervioso.nivel.toLowerCase()}" style="padding: 2px 6px; font-size: 8px;">${sust.sistemasImpacto.sistemaNervioso.nivel}</span>
              </div>
              <p class="system-desc">${sust.sistemasImpacto.sistemaNervioso.detalles}</p>
            </div>

            <div class="system-box">
              <div class="system-header">
                <span class="system-name">Sistema Respiratorio</span>
                <span class="riesgo-badge riesgo-${sust.sistemasImpacto.sistemaRespiratorio.nivel.toLowerCase()}" style="padding: 2px 6px; font-size: 8px;">${sust.sistemasImpacto.sistemaRespiratorio.nivel}</span>
              </div>
              <p class="system-desc">${sust.sistemasImpacto.sistemaRespiratorio.detalles}</p>
            </div>

            <div class="system-box">
              <div class="system-header">
                <span class="system-name">Sistema Cardiovascular</span>
                <span class="riesgo-badge riesgo-${sust.sistemasImpacto.sistemaCardiovascular.nivel.toLowerCase()}" style="padding: 2px 6px; font-size: 8px;">${sust.sistemasImpacto.sistemaCardiovascular.nivel}</span>
              </div>
              <p class="system-desc">${sust.sistemasImpacto.sistemaCardiovascular.detalles}</p>
            </div>

            <div class="system-box">
              <div class="system-header">
                <span class="system-name">Sistema Digestivo / Somático</span>
                <span class="riesgo-badge riesgo-${sust.sistemasImpacto.sistemaDigestivoYOtros.nivel.toLowerCase()}" style="padding: 2px 6px; font-size: 8px;">${sust.sistemasImpacto.sistemaDigestivoYOtros.nivel}</span>
              </div>
              <p class="system-desc">${sust.sistemasImpacto.sistemaDigestivoYOtros.detalles}</p>
            </div>
          </div>

          <div class="section-title">Sintomatología Clínica Primaria</div>
          <div class="sintomas-container">
            ${sust.sintomasClinicos.map(s => `<span class="sintoma-pill">${s}</span>`).join('')}
          </div>

          <div class="footer">
            Documentación de Referencia Técnica • COSAM Rinconada de San Ramón • San Ramón, Chile
          </div>

          <script>
            window.onload = function() {
              setTimeout(function() {
                window.print();
              }, 350);
            };
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  // Predictor State
  const [predSustancia, setPredSustancia] = useState<string>("cera-pb");
  const [predFrecuencia, setPredFrecuencia] = useState<number>(3); // 1: Ocasional, 2: Frecuente, 3: Diario Compulsivo (Binge)
  const [predEkbom, setPredEkbom] = useState<boolean>(false);
  const [predDental, setPredDental] = useState<boolean>(false);
  const [predVulnerabilidad, setPredVulnerabilidad] = useState<boolean>(true);
  const [predictionResult, setPredictionResult] = useState<any | null>(null);

  const substanceSource = SUBSTANCES_DATA.find((s) => s.id === compareSource)!;
  const substanceTarget = SUBSTANCES_DATA.find((s) => s.id === compareTarget)!;

  const handlePredict = () => {
    const substance = SUBSTANCES_DATA.find((s) => s.id === predSustancia)!;
    
    // Calculate a score between 0 and 100
    let score = 0;
    
    // 1. Substance multiplier
    if (substance.id === "cera-pb") score += 45;
    else if (substance.id === "pasta-base") score += 30;
    else if (substance.id === "cocaina") score += 25;
    else if (substance.id === "cera-marihuana") score += 15;

    // 2. Frequency score
    score += predFrecuencia * 12; // Max 36

    // 3. Clinical symptoms markers
    if (predEkbom) score += 10;
    if (predDental) score += 8;
    if (predVulnerabilidad) score += 11;

    score = Math.min(score, 100);

    let riesgoLabel = "Bajo";
    let colorClass = "text-emerald-600 bg-emerald-50 border-emerald-200";
    let colorBar = "bg-emerald-500";
    let pronostico = "";
    let recomendaciones: string[] = [];

    if (score > 85) {
      riesgoLabel = "Crítico / Vital Inminente";
      colorClass = "text-red-700 bg-red-50 border-red-200 animate-pulse";
      colorBar = "bg-red-600";
      pronostico = "Riesgo inminente de colapso multisistémico, daño cerebral cortical irreversible y/o desenlace fatal prematuro por sobredosis o violencia sistémica. Requiere internación psiquiátrica prolongada de urgencia y desintoxicación farmacológica.";
      recomendaciones = [
        "Internación psiquiátrica cerrada de inmediato para contención de la angustia severa.",
        "Monitoreo hemodinámico y neurológico continuo por riesgo de infarto o convulsiones.",
        "Tratamiento intensivo para la psicosis tóxica y delirios de Ekbom.",
        "Ingreso inmediato a programa de alta complejidad de SENDA / COSAM."
      ];
    } else if (score > 60) {
      riesgoLabel = "Alto";
      colorClass = "text-orange-700 bg-orange-50 border-orange-200";
      colorBar = "bg-orange-500";
      pronostico = "Deterioro biopsicosocial grave con alta probabilidad de cronificación en situación de calle y pérdida total de funciones ejecutivas frontales. El pronóstico es desfavorable sin un soporte institucional robusto de mediano plazo.";
      recomendaciones = [
        "Evaluación por psiquiatra de adicciones para tratamiento farmacológico del craving compulsivo.",
        "Terapia ocupacional diaria para reestructurar rutinas saludables fuera del circuito de consumo.",
        "Psicoterapia individual con enfoque en control de impulsos.",
        "Vinculación urgente de familiares o tutores legales como red de apoyo activa."
      ];
    } else if (score > 35) {
      riesgoLabel = "Moderado";
      colorClass = "text-yellow-700 bg-yellow-50 border-yellow-200";
      colorBar = "bg-yellow-500";
      pronostico = "Deterioro clínico en fase inicial de consolidación. Se observan déficits en memoria de trabajo y lóbulo frontal. Pronóstico favorable si se interviene inmediatamente en régimen ambulatorio intensivo.";
      recomendaciones = [
        "Ingreso a Programa Ambulatorio Intensivo (PAI) COSAM.",
        "Controles periódicos de orina (tamizaje toxicológico) para incentivar la abstinencia.",
        "Psicoeducación familiar sobre dinámicas de codependencia.",
        "Acompañamiento psicopedagógico o reinserción escolar formal."
      ];
    } else {
      riesgoLabel = "Bajo";
      colorClass = "text-emerald-700 bg-emerald-50 border-emerald-200";
      colorBar = "bg-emerald-500";
      pronostico = "Deterioro fisiológico mínimo detectado, sin embargo, el riesgo de progresión adictiva está latente. Pronóstico altamente favorable.";
      recomendaciones = [
        "Consejería preventiva breve y psicoeducación de sustancias.",
        "Participación en actividades comunitarias, deportivas o culturales protegidas.",
        "Seguimiento semestral preventivo en Atención Primaria de Salud (APS)."
      ];
    }

    setPredictionResult({
      score,
      riesgoLabel,
      colorClass,
      colorBar,
      pronostico,
      recomendaciones
    });
  };

  const getRiesgoBadge = (riesgo: string) => {
    switch (riesgo) {
      case "Extremo":
        return <span className="text-[10px] font-bold uppercase tracking-widest bg-red-100 text-red-700 border border-red-200 px-2.5 py-1 rounded-full flex items-center gap-1"><ShieldAlert size={12} className="animate-pulse" /> Extremo</span>;
      case "Alto":
        return <span className="text-[10px] font-bold uppercase tracking-widest bg-orange-100 text-orange-700 border border-orange-200 px-2.5 py-1 rounded-full flex items-center gap-1"><AlertTriangle size={12} /> Alto</span>;
      case "Medio":
        return <span className="text-[10px] font-bold uppercase tracking-widest bg-yellow-100 text-yellow-700 border border-yellow-200 px-2.5 py-1 rounded-full flex items-center gap-1"><TrendingUp size={12} /> Medio</span>;
      default:
        return <span className="text-[10px] font-bold uppercase tracking-widest bg-emerald-100 text-emerald-700 border border-emerald-200 px-2.5 py-1 rounded-full flex items-center gap-1"><ShieldAlert size={12} /> Bajo</span>;
    }
  };

  const getNivelColorClass = (nivel: "Bajo" | "Medio" | "Alto" | "Extremo") => {
    switch (nivel) {
      case "Extremo": return "text-red-600 bg-red-50 border-red-100";
      case "Alto": return "text-orange-600 bg-orange-50 border-orange-100";
      case "Medio": return "text-yellow-600 bg-yellow-50 border-yellow-100";
      default: return "text-emerald-600 bg-emerald-50 border-emerald-100";
    }
  };

  return (
    <div className="space-y-12">
      {/* 1. SECCIÓN DE TARJETAS DE SUSTANCIAS */}
      <section id="tarjetas-sustancias">
        <div className="flex flex-col gap-2 mb-6">
          <span className="text-xs font-bold text-purple-600 uppercase tracking-widest flex items-center gap-1.5">
            <Layers size={14} /> Módulo Educativo Profesional
          </span>
          <h2 className="text-2xl font-bold text-slate-800 tracking-tight">
            Dashboard de Análisis Taxonómico de Sustancias
          </h2>
          <p className="text-slate-500 text-sm max-w-3xl">
            Explore los perfiles farmacológicos y el impacto fisiológico sistémico de las sustancias psicoactivas comunes en el contexto chileno, con especial detalle en la irrupción de la <strong>Cera de Pasta Base</strong>.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {SUBSTANCES_DATA.map((subst) => (
            <motion.div
              key={subst.id}
              whileHover={{ y: -4, scale: 1.01 }}
              transition={{ duration: 0.2 }}
              onClick={() => setSelectedSubstance(subst)}
              className="bg-white/80 border border-purple-100/60 rounded-2xl p-5 shadow-sm hover:shadow-md cursor-pointer relative overflow-hidden flex flex-col justify-between group"
            >
              <div className="absolute top-0 left-0 w-1.5 h-full bg-purple-500 group-hover:bg-purple-600 transition-colors" />
              
              <div className="space-y-3">
                <div className="flex justify-between items-start gap-2">
                  <span className="text-[10px] font-bold text-purple-600 bg-purple-50 px-2 py-1 rounded border border-purple-100 uppercase tracking-wider block truncate max-w-[130px]">
                    {subst.categoria}
                  </span>
                  {getRiesgoBadge(subst.riesgoVital)}
                </div>

                <div>
                  <h3 className="font-bold text-slate-800 text-lg leading-tight group-hover:text-purple-700 transition-colors">
                    {subst.nombre}
                  </h3>
                  <p className="text-xs text-slate-400 font-medium italic mt-0.5">
                    {subst.alias}
                  </p>
                </div>

                <p className="text-xs text-slate-500 leading-relaxed line-clamp-3">
                  {subst.descripcion}
                </p>
              </div>

              <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] font-bold text-purple-600 group-hover:translate-x-1 transition-transform">
                <span>Ver Impacto Detallado</span>
                <ArrowRight size={14} />
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* 2. MODAL DE SUSTANCIA DETALLADA */}
      <AnimatePresence>
        {selectedSubstance && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-3xl w-full max-w-4xl max-h-[90vh] overflow-y-auto shadow-2xl border border-purple-100 flex flex-col"
            >
              {/* Header */}
              <div className="p-6 md:p-8 bg-gradient-to-r from-purple-50 to-slate-50 border-b border-purple-100 relative">
                <button
                  onClick={() => setSelectedSubstance(null)}
                  className="absolute top-6 right-6 w-8 h-8 rounded-full bg-slate-200/60 hover:bg-slate-200 text-slate-600 flex items-center justify-center transition-colors text-sm font-bold"
                >
                  ✕
                </button>

                <div className="space-y-2 max-w-[90%]">
                  <div className="flex flex-wrap items-center gap-3">
                    <span className="text-xs font-bold text-purple-700 bg-purple-100/60 border border-purple-200 px-3 py-1 rounded-md uppercase tracking-wider">
                      {selectedSubstance.categoria}
                    </span>
                    {getRiesgoBadge(selectedSubstance.riesgoVital)}
                  </div>
                  <h2 className="text-2xl md:text-3xl font-bold text-slate-800 tracking-tight">
                    {selectedSubstance.nombre}
                  </h2>
                  <p className="text-sm text-slate-500 font-semibold">
                    Denominaciones comunes: <span className="text-purple-600 italic font-bold">{selectedSubstance.alias}</span>
                  </p>
                </div>
              </div>

              {/* Body */}
              <div className="p-6 md:p-8 space-y-8 flex-1">
                {/* Descripcion */}
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1.5">Descripción General</h4>
                  <p className="text-sm text-slate-600 leading-relaxed">{selectedSubstance.descripcion}</p>
                </div>

                {/* Tabla de Taxonomia */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h3 className="font-bold text-slate-800 text-sm uppercase tracking-wider border-b border-slate-100 pb-2 flex items-center gap-2">
                      <Sparkles size={16} className="text-purple-600" /> Ficha Química y Farmacológica
                    </h3>
                    <div className="space-y-3 text-xs">
                      <div className="grid grid-cols-3 py-1.5 border-b border-slate-50">
                        <span className="font-bold text-slate-400">Naturaleza:</span>
                        <span className="col-span-2 text-slate-700 font-medium">{selectedSubstance.naturaleza}</span>
                      </div>
                      <div className="grid grid-cols-3 py-1.5 border-b border-slate-50">
                        <span className="font-bold text-slate-400">Principio Activo:</span>
                        <span className="col-span-2 text-slate-700 font-bold">{selectedSubstance.principioActivo}</span>
                      </div>
                      <div className="grid grid-cols-3 py-1.5 border-b border-slate-50">
                        <span className="font-bold text-slate-400">Extracción:</span>
                        <span className="col-span-2 text-slate-700 font-medium">{selectedSubstance.mecanismoExtraccion}</span>
                      </div>
                      <div className="grid grid-cols-3 py-1.5 border-b border-slate-50">
                        <span className="font-bold text-slate-400">Duración Aguda:</span>
                        <span className="col-span-2 text-red-600 font-bold">{selectedSubstance.duracionEfecto}</span>
                      </div>
                      <div className="grid grid-cols-3 py-1.5">
                        <span className="font-bold text-slate-400">Efecto Crash:</span>
                        <span className="col-span-2 text-orange-600 font-bold">{selectedSubstance.secuelaCrash}</span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="font-bold text-slate-800 text-sm uppercase tracking-wider border-b border-slate-100 pb-2 flex items-center gap-2">
                      <Users size={16} className="text-purple-600" /> Dinámicas Sociales y Perfil
                    </h3>
                    <div className="space-y-3 text-xs">
                      <div className="grid grid-cols-3 py-1.5 border-b border-slate-50">
                        <span className="font-bold text-slate-400">Población Objetivo:</span>
                        <span className="col-span-2 text-slate-700 font-medium">{selectedSubstance.perfilConsumidor}</span>
                      </div>
                      <div className="grid grid-cols-3 py-1.5 border-b border-slate-50">
                        <span className="font-bold text-slate-400">Epidemiología:</span>
                        <span className="col-span-2 text-slate-700 font-medium">{selectedSubstance.datosEpidemiologicos}</span>
                      </div>
                      <div className="py-1.5">
                        <span className="font-bold text-slate-400 block mb-1">Impacto Social y Familiar:</span>
                        <span className="text-slate-600 font-medium leading-relaxed">{selectedSubstance.impactoSocial}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Sistemas Afectados */}
                <div className="space-y-4">
                  <h3 className="font-bold text-slate-800 text-sm uppercase tracking-wider border-b border-slate-100 pb-2 flex items-center gap-2">
                    <Activity size={16} className="text-purple-600" /> Impacto Fisiológico por Sistemas del Cuerpo
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Nervioso */}
                    <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 flex gap-3">
                      <div className="w-10 h-10 rounded-lg bg-purple-100 flex items-center justify-center text-purple-600 shrink-0">
                        <Brain size={20} />
                      </div>
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <h4 className="text-xs font-bold text-slate-700 uppercase">Sistema Nervioso Central</h4>
                          <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded border uppercase ${getNivelColorClass(selectedSubstance.sistemasImpacto.sistemaNervioso.nivel)}`}>
                            {selectedSubstance.sistemasImpacto.sistemaNervioso.nivel}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 leading-relaxed">{selectedSubstance.sistemasImpacto.sistemaNervioso.detalles}</p>
                      </div>
                    </div>

                    {/* Respiratorio */}
                    <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 flex gap-3">
                      <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center text-blue-600 shrink-0">
                        <Flame size={20} />
                      </div>
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <h4 className="text-xs font-bold text-slate-700 uppercase">Sistema Respiratorio</h4>
                          <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded border uppercase ${getNivelColorClass(selectedSubstance.sistemasImpacto.sistemaRespiratorio.nivel)}`}>
                            {selectedSubstance.sistemasImpacto.sistemaRespiratorio.nivel}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 leading-relaxed">{selectedSubstance.sistemasImpacto.sistemaRespiratorio.detalles}</p>
                      </div>
                    </div>

                    {/* Cardiovascular */}
                    <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 flex gap-3">
                      <div className="w-10 h-10 rounded-lg bg-red-100 flex items-center justify-center text-red-600 shrink-0">
                        <Heart size={20} />
                      </div>
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <h4 className="text-xs font-bold text-slate-700 uppercase">Sistema Cardiovascular</h4>
                          <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded border uppercase ${getNivelColorClass(selectedSubstance.sistemasImpacto.sistemaCardiovascular.nivel)}`}>
                            {selectedSubstance.sistemasImpacto.sistemaCardiovascular.nivel}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 leading-relaxed">{selectedSubstance.sistemasImpacto.sistemaCardiovascular.detalles}</p>
                      </div>
                    </div>

                    {/* Digestivo / Somatico */}
                    <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 flex gap-3">
                      <div className="w-10 h-10 rounded-lg bg-emerald-100 flex items-center justify-center text-emerald-600 shrink-0">
                        <Activity size={20} />
                      </div>
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <h4 className="text-xs font-bold text-slate-700 uppercase">Sistema Digestivo / Somático</h4>
                          <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded border uppercase ${getNivelColorClass(selectedSubstance.sistemasImpacto.sistemaDigestivoYOtros.nivel)}`}>
                            {selectedSubstance.sistemasImpacto.sistemaDigestivoYOtros.nivel}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 leading-relaxed">{selectedSubstance.sistemasImpacto.sistemaDigestivoYOtros.detalles}</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Marcadores Clinicos Clave */}
                <div className="space-y-3">
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Sintomatología Clínica Primaria</h4>
                  <div className="flex flex-wrap gap-2">
                    {selectedSubstance.sintomasClinicos.map((sint, idx) => (
                      <span key={idx} className="bg-purple-50 text-purple-700 text-xs px-3 py-1.5 rounded-lg border border-purple-100/60 font-semibold">
                        • {sint}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Footer */}
              <div className="p-6 bg-slate-50 border-t border-slate-100 flex flex-col sm:flex-row justify-between items-center gap-4">
                <button
                  onClick={() => handleDownloadPDF(selectedSubstance)}
                  className="w-full sm:w-auto px-5 py-2.5 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-bold uppercase tracking-wider transition-colors flex items-center justify-center gap-2 shadow-sm"
                >
                  <Printer size={14} />
                  <span>Descargar Ficha PDF / Imprimir</span>
                </button>
                <button
                  onClick={() => setSelectedSubstance(null)}
                  className="w-full sm:w-auto px-6 py-2.5 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold uppercase tracking-wider transition-colors"
                >
                  Cerrar Análisis
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 3. SECCIÓN COMPARATIVA DE SUSTANCIAS Y SISTEMAS */}
      <section id="comparador-sistemas" className="bg-white border border-purple-100/80 rounded-3xl p-6 md:p-8 shadow-sm">
        <div className="flex flex-col gap-2 mb-6">
          <span className="text-xs font-bold text-purple-600 uppercase tracking-widest flex items-center gap-1.5">
            <Layers size={14} /> Módulo Clínico Comparativo
          </span>
          <h2 className="text-xl font-bold text-slate-800 tracking-tight">
            Matriz de Comparación Fisiológica e Impacto Sistémico
          </h2>
          <p className="text-slate-500 text-xs max-w-3xl">
            Seleccione dos compuestos para contrastar sus mecanismos bioquímicos de toxicidad pulmonar, neurológica y cardiovascular lado a lado, facilitando la comprensión de la letalidad de la cera de pasta base frente a cannabis u otros estimulantes.
          </p>
        </div>

        {/* Selectors */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-slate-50 p-4 rounded-2xl border border-slate-100 mb-6">
          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">Compuesto de Referencia (A)</label>
            <select
              value={compareSource}
              onChange={(e) => setCompareSource(e.target.value)}
              className="w-full p-2.5 bg-white border border-purple-100 rounded-xl text-xs font-bold text-slate-700 focus:ring-2 focus:ring-purple-500 outline-none"
            >
              {SUBSTANCES_DATA.map((s) => (
                <option key={s.id} value={s.id}>{s.nombre} ({s.alias})</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">Compuesto de Contraste (B)</label>
            <select
              value={compareTarget}
              onChange={(e) => setCompareTarget(e.target.value)}
              className="w-full p-2.5 bg-white border border-purple-100 rounded-xl text-xs font-bold text-slate-700 focus:ring-2 focus:ring-purple-500 outline-none"
            >
              {SUBSTANCES_DATA.filter((s) => s.id !== compareSource).map((s) => (
                <option key={s.id} value={s.id}>{s.nombre} ({s.alias})</option>
              ))}
            </select>
          </div>
        </div>

        {/* Tabs de Sistemas */}
        <div className="flex border-b border-purple-100 mb-6 overflow-x-auto gap-2">
          <button
            onClick={() => setSelectedSystemTab("nervioso")}
            className={`px-4 py-3 text-xs font-bold uppercase tracking-wider border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap ${
              selectedSystemTab === "nervioso"
                ? "border-purple-600 text-purple-700"
                : "border-transparent text-slate-400 hover:text-slate-600"
            }`}
          >
            <Brain size={14} /> Sistema Nervioso
          </button>
          <button
            onClick={() => setSelectedSystemTab("respiratorio")}
            className={`px-4 py-3 text-xs font-bold uppercase tracking-wider border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap ${
              selectedSystemTab === "respiratorio"
                ? "border-purple-600 text-purple-700"
                : "border-transparent text-slate-400 hover:text-slate-600"
            }`}
          >
            <Flame size={14} /> Sistema Respiratorio
          </button>
          <button
            onClick={() => setSelectedSystemTab("cardiovascular")}
            className={`px-4 py-3 text-xs font-bold uppercase tracking-wider border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap ${
              selectedSystemTab === "cardiovascular"
                ? "border-purple-600 text-purple-700"
                : "border-transparent text-slate-400 hover:text-slate-600"
            }`}
          >
            <Heart size={14} /> Sistema Cardiovascular
          </button>
          <button
            onClick={() => setSelectedSystemTab("otros")}
            className={`px-4 py-3 text-xs font-bold uppercase tracking-wider border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap ${
              selectedSystemTab === "otros"
                ? "border-purple-600 text-purple-700"
                : "border-transparent text-slate-400 hover:text-slate-600"
            }`}
          >
            <Activity size={14} /> Físico / Somático
          </button>
        </div>

        {/* Comparison Details Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Compuesto A */}
          <div className="bg-purple-50/20 border border-purple-100 rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-purple-100/60 pb-3">
              <div>
                <h4 className="font-bold text-slate-800 text-base">{substanceSource.nombre}</h4>
                <p className="text-xs text-slate-400 font-semibold italic">{substanceSource.alias}</p>
              </div>
              <span className="text-[10px] font-bold bg-purple-500 text-white px-2.5 py-1 rounded-full uppercase tracking-wider">
                Compuesto A
              </span>
            </div>

            {selectedSystemTab === "nervioso" && (
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-slate-400">Severidad:</span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded border uppercase ${getNivelColorClass(substanceSource.sistemasImpacto.sistemaNervioso.nivel)}`}>
                    {substanceSource.sistemasImpacto.sistemaNervioso.nivel}
                  </span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed font-medium">
                  {substanceSource.sistemasImpacto.sistemaNervioso.detalles}
                </p>
              </div>
            )}

            {selectedSystemTab === "respiratorio" && (
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-slate-400">Severidad:</span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded border uppercase ${getNivelColorClass(substanceSource.sistemasImpacto.sistemaRespiratorio.nivel)}`}>
                    {substanceSource.sistemasImpacto.sistemaRespiratorio.nivel}
                  </span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed font-medium">
                  {substanceSource.sistemasImpacto.sistemaRespiratorio.detalles}
                </p>
              </div>
            )}

            {selectedSystemTab === "cardiovascular" && (
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-slate-400">Severidad:</span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded border uppercase ${getNivelColorClass(substanceSource.sistemasImpacto.sistemaCardiovascular.nivel)}`}>
                    {substanceSource.sistemasImpacto.sistemaCardiovascular.nivel}
                  </span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed font-medium">
                  {substanceSource.sistemasImpacto.sistemaCardiovascular.detalles}
                </p>
              </div>
            )}

            {selectedSystemTab === "otros" && (
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-slate-400">Severidad:</span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded border uppercase ${getNivelColorClass(substanceSource.sistemasImpacto.sistemaDigestivoYOtros.nivel)}`}>
                    {substanceSource.sistemasImpacto.sistemaDigestivoYOtros.nivel}
                  </span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed font-medium">
                  {substanceSource.sistemasImpacto.sistemaDigestivoYOtros.detalles}
                </p>
              </div>
            )}

            <div className="pt-3 border-t border-slate-100 text-xs">
              <span className="font-bold text-slate-400 block mb-1">Duración del efecto agudo:</span>
              <p className="font-bold text-purple-700">{substanceSource.duracionEfecto}</p>
            </div>
            <div className="text-xs">
              <span className="font-bold text-slate-400 block mb-1">Secuela crash inmediata:</span>
              <p className="font-medium text-slate-600">{substanceSource.secuelaCrash}</p>
            </div>
          </div>

          {/* Compuesto B */}
          <div className="bg-purple-50/20 border border-purple-100 rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-purple-100/60 pb-3">
              <div>
                <h4 className="font-bold text-slate-800 text-base">{substanceTarget.nombre}</h4>
                <p className="text-xs text-slate-400 font-semibold italic">{substanceTarget.alias}</p>
              </div>
              <span className="text-[10px] font-bold bg-slate-700 text-white px-2.5 py-1 rounded-full uppercase tracking-wider">
                Compuesto B
              </span>
            </div>

            {selectedSystemTab === "nervioso" && (
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-slate-400">Severidad:</span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded border uppercase ${getNivelColorClass(substanceTarget.sistemasImpacto.sistemaNervioso.nivel)}`}>
                    {substanceTarget.sistemasImpacto.sistemaNervioso.nivel}
                  </span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed font-medium">
                  {substanceTarget.sistemasImpacto.sistemaNervioso.detalles}
                </p>
              </div>
            )}

            {selectedSystemTab === "respiratorio" && (
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-slate-400">Severidad:</span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded border uppercase ${getNivelColorClass(substanceTarget.sistemasImpacto.sistemaRespiratorio.nivel)}`}>
                    {substanceTarget.sistemasImpacto.sistemaRespiratorio.nivel}
                  </span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed font-medium">
                  {substanceTarget.sistemasImpacto.sistemaRespiratorio.detalles}
                </p>
              </div>
            )}

            {selectedSystemTab === "cardiovascular" && (
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-slate-400">Severidad:</span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded border uppercase ${getNivelColorClass(substanceTarget.sistemasImpacto.sistemaCardiovascular.nivel)}`}>
                    {substanceTarget.sistemasImpacto.sistemaCardiovascular.nivel}
                  </span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed font-medium">
                  {substanceTarget.sistemasImpacto.sistemaCardiovascular.detalles}
                </p>
              </div>
            )}

            {selectedSystemTab === "otros" && (
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-slate-400">Severidad:</span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded border uppercase ${getNivelColorClass(substanceTarget.sistemasImpacto.sistemaDigestivoYOtros.nivel)}`}>
                    {substanceTarget.sistemasImpacto.sistemaDigestivoYOtros.nivel}
                  </span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed font-medium">
                  {substanceTarget.sistemasImpacto.sistemaDigestivoYOtros.detalles}
                </p>
              </div>
            )}

            <div className="pt-3 border-t border-slate-100 text-xs">
              <span className="font-bold text-slate-400 block mb-1">Duración del efecto agudo:</span>
              <p className="font-bold text-purple-700">{substanceTarget.duracionEfecto}</p>
            </div>
            <div className="text-xs">
              <span className="font-bold text-slate-400 block mb-1">Secuela crash inmediata:</span>
              <p className="font-medium text-slate-600">{substanceTarget.secuelaCrash}</p>
            </div>
          </div>
        </div>
      </section>

      {/* 4. SECCIÓN DE PREDICCIÓN DE RIESGO CLÍNICO */}
      <section id="predictor-deterioro" className="bg-white border border-purple-100/80 rounded-3xl p-6 md:p-8 shadow-sm relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-purple-100 rounded-full mix-blend-multiply filter blur-2xl opacity-40 -z-0"></div>

        <div className="flex flex-col gap-2 mb-6 z-10 relative">
          <span className="text-xs font-bold text-purple-600 uppercase tracking-widest flex items-center gap-1.5">
            <ShieldAlert size={14} /> Módulo Analítico Predictivo
          </span>
          <h2 className="text-xl font-bold text-slate-800 tracking-tight">
            Calculadora de Predicción de Deterioro Clínico y Somático
          </h2>
          <p className="text-slate-500 text-xs max-w-3xl">
            Simulador predictivo clínico para evaluar el índice de riesgo acumulado de un paciente basado en la sustancia de elección, patrón de consumo, marcadores somáticos y red de soporte psicosocial.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start relative z-10">
          {/* Inputs */}
          <div className="lg:col-span-5 space-y-5 bg-slate-50 p-5 rounded-2xl border border-slate-100">
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-2">
                Sustancia de Elección Predominante
              </label>
              <select
                value={predSustancia}
                onChange={(e) => setPredSustancia(e.target.value)}
                className="w-full p-2.5 bg-white border border-purple-100 rounded-xl text-xs font-bold text-slate-700 outline-none"
              >
                {SUBSTANCES_DATA.map((s) => (
                  <option key={s.id} value={s.id}>{s.nombre}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-2">
                Patrón / Frecuencia de Consumo
              </label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { value: 1, label: "Ocasional" },
                  { value: 2, label: "Frecuente" },
                  { value: 3, label: "Diario / Binge" }
                ].map((item) => (
                  <button
                    key={item.value}
                    type="button"
                    onClick={() => setPredFrecuencia(item.value)}
                    className={`py-2 px-1 text-center rounded-lg border text-[10px] font-bold uppercase transition-all ${
                      predFrecuencia === item.value
                        ? "bg-purple-600 border-purple-600 text-white"
                        : "bg-white border-purple-100 text-slate-500 hover:bg-purple-50"
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-3 pt-2">
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                Marcadores Clínicos Presentes
              </label>
              
              <div className="space-y-2">
                <label className="flex items-center gap-2.5 p-2 bg-white rounded-xl border border-purple-100/50 cursor-pointer hover:bg-purple-50/40 select-none">
                  <input
                    type="checkbox"
                    checked={predEkbom}
                    onChange={(e) => setPredEkbom(e.target.checked)}
                    className="rounded text-purple-600 focus:ring-purple-500 h-4 w-4"
                  />
                  <div>
                    <span className="text-xs font-bold text-slate-700 block">Delirio de Ekbom / Parasitosis Táctil</span>
                    <span className="text-[9px] text-slate-400 block leading-tight">Alucinaciones táctiles que causan rascado compulsivo y lesiones</span>
                  </div>
                </label>

                <label className="flex items-center gap-2.5 p-2 bg-white rounded-xl border border-purple-100/50 cursor-pointer hover:bg-purple-50/40 select-none">
                  <input
                    type="checkbox"
                    checked={predDental}
                    onChange={(e) => setPredDental(e.target.checked)}
                    className="rounded text-purple-600 focus:ring-purple-500 h-4 w-4"
                  />
                  <div>
                    <span className="text-xs font-bold text-slate-700 block">Deterioro Bucodental Severo</span>
                    <span className="text-[9px] text-slate-400 block leading-tight">Pérdida acelerada de piezas dentales o ulceración oral</span>
                  </div>
                </label>

                <label className="flex items-center gap-2.5 p-2 bg-white rounded-xl border border-purple-100/50 cursor-pointer hover:bg-purple-50/40 select-none">
                  <input
                    type="checkbox"
                    checked={predVulnerabilidad}
                    onChange={(e) => setPredVulnerabilidad(e.target.checked)}
                    className="rounded text-purple-600 focus:ring-purple-500 h-4 w-4"
                  />
                  <div>
                    <span className="text-xs font-bold text-slate-700 block">Ausencia de Red de Apoyo / Calle</span>
                    <span className="text-[9px] text-slate-400 block leading-tight">Ruptura familiar severa, situación de calle o abandono escolar</span>
                  </div>
                </label>
              </div>
            </div>

            <button
              onClick={handlePredict}
              className="w-full bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 px-4 rounded-xl text-xs uppercase tracking-widest transition-all shadow-md flex items-center justify-center gap-2"
            >
              <Activity size={14} /> Calcular Riesgo Clínico
            </button>
          </div>

          {/* Results Output */}
          <div className="lg:col-span-7 h-full flex flex-col justify-between">
            {predictionResult ? (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-5 h-full"
              >
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-slate-800 text-sm uppercase tracking-wider">Índice de Riesgo Predictivo</h4>
                  <span className={`text-[11px] font-bold px-3 py-1.5 rounded-xl border uppercase ${predictionResult.colorClass}`}>
                    Riesgo: {predictionResult.riesgoLabel}
                  </span>
                </div>

                {/* Score Bar */}
                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs font-bold text-slate-500">
                    <span>Deterioro Multidimensional</span>
                    <span>{predictionResult.score}%</span>
                  </div>
                  <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden border border-slate-200">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${predictionResult.score}%` }}
                      transition={{ duration: 0.5, ease: "easeOut" }}
                      className={`h-full ${predictionResult.colorBar}`}
                    />
                  </div>
                </div>

                {/* Pronóstico */}
                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 space-y-1.5">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Proyección Pronóstica Clínica</span>
                  <p className="text-xs text-slate-600 leading-relaxed font-semibold">
                    {predictionResult.pronostico}
                  </p>
                </div>

                {/* Recomendaciones */}
                <div className="space-y-2">
                  <span className="text-[10px] font-bold text-purple-600 uppercase tracking-widest block">Acciones Recomendadas Prioritarias</span>
                  <ul className="space-y-1.5">
                    {predictionResult.recomendaciones.map((rec: string, idx: number) => (
                      <li key={idx} className="text-xs text-slate-600 font-medium flex items-start gap-2">
                        <span className="text-purple-500 mt-0.5">•</span>
                        <span>{rec}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Reset button */}
                <button
                  type="button"
                  onClick={() => setPredictionResult(null)}
                  className="mt-4 text-purple-600 hover:text-purple-700 text-xs font-bold flex items-center gap-1 uppercase tracking-wider"
                >
                  <RotateCcw size={12} /> Reiniciar Simulación
                </button>
              </motion.div>
            ) : (
              <div className="h-64 border-2 border-dashed border-purple-100 rounded-3xl flex flex-col items-center justify-center p-6 text-center text-slate-400 gap-3">
                <ShieldAlert size={40} className="text-purple-200" />
                <div className="space-y-1">
                  <h4 className="font-bold text-slate-600 text-xs uppercase tracking-wider">Aún sin Simulación de Riesgo</h4>
                  <p className="text-[11px] text-slate-400 max-w-sm">
                    Configure las variables del paciente en el panel de la izquierda y presione el botón para proyectar el riesgo biológico e instruir recomendaciones clínicas.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      </section>
    </div>
  );
}
