import { useState, useId } from "react";
import PanelSincronizacionRayen from "./PanelSincronizacionRayen";

export default function WorkspaceRayen() {
  const [workspaceMode, setWorkspaceMode] = useState<"sync_panel" | "classic_form">("sync_panel");
  const patientNameId = useId();
  const rutId = useId();
  const ageId = useId();
  const substanceId = useId();
  const fucId = useId();
  const patternId = useId();
  const stageId = useId();
  const disulfiramDoseId = useId();
  const disulfiramAdminId = useId();
  const agreementsId = useId();

  // Patient & Clinical state
  const [patientName, setPatientName] = useState("");
  const [rut, setRut] = useState("");
  const [age, setAge] = useState("");
  const [primarySubstance, setPrimarySubstance] = useState("Alcohol");
  const [fucDate, setFucDate] = useState("");
  const [consumptionPattern, setConsumptionPattern] = useState("Abstinente en programa");
  const [cravingLevel, setCravingLevel] = useState<number>(2);
  const [stageOfChange, setStageOfChange] = useState("Acción");

  // Mental Health & Biological Rhythms
  const [mood, setMood] = useState("Eutímico / Estable");
  const [sleep, setSleep] = useState("Conservado (7-8 hrs sin interrupciones)");
  const [appetite, setAppetite] = useState("Normorexia");
  const [suicidalIdeation, setSuicidalIdeation] = useState("Negativa (Sin ideación suicida activa ni pasiva)");
  const [psychoticSymptoms, setPsychoticSymptoms] = useState("Negativos (Sin sensopercepciones anómalas)");

  // Disulfiram Monitoring
  const [takingDisulfiram, setTakingDisulfiram] = useState<boolean>(false);
  const [disulfiramDose, setDisulfiramDose] = useState("250 mg/día (1 comprimido)");
  const [disulfiramAdherence, setDisulfiramAdherence] = useState("Supervisada por familiar / red de apoyo");
  const [disulfiramRAMs, setDisulfiramRAMs] = useState("Sin reacciones adversas reportadas");

  // Triggers & Coping
  const [selectedTriggers, setSelectedTriggers] = useState<string[]>([
    "Estrés laboral / familiar",
    "Lugares de consumo previo"
  ]);
  const [selectedCoping, setSelectedCoping] = useState<string[]>([
    "Respiración 4-4-8",
    "Llamar a red de apoyo",
    "Asistencia a taller COSAM"
  ]);

  // Agreements & Plan
  const [agreements, setAgreements] = useState(
    "Se mantiene esquema psicofarmacológico actual. Asistencia a psicoterapia individual y taller grupal de adicciones. Próximo control médico en 3 semanas con exámenes de perfil hepático y hemograma."
  );

  const [copied, setCopied] = useState(false);

  // Calculate days of abstinence
  const calculateDaysAbstinence = () => {
    if (!fucDate) return null;
    const fuc = new Date(fucDate);
    const today = new Date();
    const diffTime = today.getTime() - fuc.getTime();
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    return diffDays >= 0 ? diffDays : 0;
  };

  const daysAbstinent = calculateDaysAbstinence();

  // Triggers options
  const triggerOptions = [
    "Estrés laboral / familiar",
    "Lugares de consumo previo",
    "Encuentro con pares de consumo",
    "Días de pago / dinero disponible",
    "Aislamiento / Soledad",
    "Insomnio / Fatiga",
    "Eventos sociales / Fiestas"
  ];

  // Coping strategies options
  const copingOptions = [
    "Respiración 4-4-8",
    "Llamar a red de apoyo",
    "Asistencia a taller COSAM",
    "Uso de Caja SOS (Choque térmico)",
    "Paseo / Actividad física",
    "Pausa y Control App",
    "Distracción cognitiva (5-4-3-2-1)"
  ];

  const toggleTrigger = (item: string) => {
    setSelectedTriggers((prev) =>
      prev.includes(item) ? prev.filter((t) => t !== item) : [...prev, item]
    );
  };

  const toggleCoping = (item: string) => {
    setSelectedCoping((prev) =>
      prev.includes(item) ? prev.filter((c) => c !== item) : [...prev, item]
    );
  };

  // Generate Rayen formatted clinical note
  const generateRayenNote = () => {
    const todayStr = new Date().toLocaleDateString("es-CL");
    const note = `=== NOTA DE EVOLUCIÓN CLÍNICA - PROGRAMA ADICCIONES COSAM RINCONADA DE SAN RAMÓN ===
FECHA: ${todayStr} | BOX DE PSIQUIATRÍA / SALUD MENTAL

1. ANTECEDENTES Y MOTIVO DE CONSULTA:
- Paciente: ${patientName || "[Nombre del Paciente]"} | RUT: ${rut || "[RUT]"} | Edad: ${age || "[Edad]"} años.
- Sustancia Principal: ${primarySubstance}.
- FUC (Fecha Último Consumo): ${fucDate || "No registrada"} (${daysAbstinent !== null ? `${daysAbstinent} días de abstinencia documentada` : "En evaluación"}).
- Patrón Actual: ${consumptionPattern}.
- Etapa de Cambio (Prochaska-DiClemente): ${stageOfChange}.

2. ESTADO PSICOPATOLÓGICO Y RITMOS BIOLÓGICOS:
- Nivel de Craving: ${cravingLevel}/10 (${cravingLevel > 6 ? "Alto / Alerta de reactivación" : cravingLevel > 3 ? "Moderado" : "Bajo / Controlado"}).
- Estado de Ánimo: ${mood}.
- Ritmo Sueño-Vigilia: ${sleep}.
- Apetito / Nutrición: ${appetite}.
- Riesgo Suicida: ${suicidalIdeation}.
- Síntomas Psicóticos / Sensopercepción: ${psychoticSymptoms}.

3. GATILLANTES Y ESTRATEGIAS DE AFRONTAMIENTO:
- Gatillantes identificados: ${selectedTriggers.length > 0 ? selectedTriggers.join(", ") : "Ninguno relevante"}.
- Estrategias de Afrontamiento validadas: ${selectedCoping.length > 0 ? selectedCoping.join(", ") : "En estructuración"}.

4. MONITOREO ESPECIALIZADO DE DISULFIRAM:
${
  takingDisulfiram
    ? `- Tratamiento Activo con Disulfiram: SÍ.
  * Dosis: ${disulfiramDose}.
  * Modalidad de Administración: ${disulfiramAdherence}.
  * Reacciones Adversas / Tolerancia: ${disulfiramRAMs}.
  * Educación Reforzada: Se reitera prohibición absoluta de alcohol en alimentos, medicamentos, vinagres y perfumes. Advertencia de reacción acetaldehídica severa.`
    : `- Tratamiento con Disulfiram: NO activo en esta sesión.`
}

5. PLAN TERAPÉUTICO, ACUERDOS Y PSICOEDUCACIÓN EN BOX:
- ${agreements}
- Se entrega psicoeducación en neurobiología del craving, microrrehabilitación nutricional y uso de herramientas de contención de crisis (App Pausa y Control).

Firma: Dr. Andrés Felipe Ruiz Miranda | Médico / Programa de Tratamiento en Adicciones | COSAM Rinconada de San Ramón`;

    return note;
  };

  const copyToClipboard = () => {
    const text = generateRayenNote();
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 3000);
  };

  const resetForm = () => {
    setPatientName("");
    setRut("");
    setAge("");
    setFucDate("");
    setCravingLevel(2);
    setTakingDisulfiram(false);
  };

  return (
    <div className="space-y-8 animate-fadeIn pb-12">
      {/* SELECTOR DE VISTA: PANEL SINCRONIZACIÓN vs FORMULARIO DETALLADO */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 bg-white dark:bg-slate-900 p-3 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider">Modo de Trabajo:</span>
          <span className="text-xs text-slate-500 dark:text-slate-400">Seleccione la herramienta para su box</span>
        </div>
        <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-xl w-full sm:w-auto">
          <button
            onClick={() => setWorkspaceMode("sync_panel")}
            className={`flex-1 sm:flex-initial px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
              workspaceMode === "sync_panel"
                ? "bg-indigo-600 text-white shadow-xs"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
            }`}
          >
            Panel Sincronización (Atajos 1-Clic)
          </button>
          <button
            onClick={() => setWorkspaceMode("classic_form")}
            className={`flex-1 sm:flex-initial px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
              workspaceMode === "classic_form"
                ? "bg-indigo-600 text-white shadow-xs"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
            }`}
          >
            Formulario Clínico Detallado
          </button>
        </div>
      </div>

      {workspaceMode === "sync_panel" ? (
        <PanelSincronizacionRayen />
      ) : (
        <>
          {/* HEADER */}
          <section className="bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-xs border border-slate-200 dark:border-slate-800">
            <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
              <div>
                <div className="flex items-center gap-2 mb-1.5">
                  <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                    Área Clínica &amp; Ficha Médica • COSAM Rinconada
                  </span>
                </div>
                <h2 className="text-xl font-bold text-slate-900 dark:text-white tracking-tight">
                  Workspace Clínico &amp; Generador de Evolución Rayen APS
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400 max-w-3xl mt-1 leading-relaxed">
                  Registro para el box de psiquiatría: cálculo automático de días de abstinencia, termómetro de craving, monitoreo de Disulfiram y exportación para Rayen APS.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={resetForm}
                  className="px-3.5 py-2 bg-transparent hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-300 dark:border-slate-700 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
                >
                  Limpiar
                </button>
                <button
                  onClick={copyToClipboard}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold shadow-xs transition-colors cursor-pointer"
                >
                  {copied ? "¡Copiado a Rayen!" : "Copiar Ficha Rayen"}
                </button>
              </div>
            </div>
          </section>

      {/* FORMULARIO CLÍNICO EN 2 COLUMNAS */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* COLUMNA IZQUIERDA: INPUTS CLÍNICOS */}
        <div className="lg:col-span-7 space-y-5">
          
          {/* 1. Datos del Paciente & Consumo */}
          <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl shadow-xs border border-slate-200 dark:border-slate-800 space-y-4">
            <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider border-b border-slate-100 dark:border-slate-800 pb-2.5">
              1. Identificación &amp; Patrón de Consumo
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label htmlFor={patientNameId} className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Nombre Paciente</label>
                <input
                  id={patientNameId}
                  type="text"
                  placeholder="Ej. Juan Pérez"
                  value={patientName}
                  onChange={(e) => setPatientName(e.target.value)}
                  className="w-full p-2 bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-800 dark:text-slate-100 outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label htmlFor={rutId} className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">RUT</label>
                <input
                  id={rutId}
                  type="text"
                  placeholder="Ej. 12.345.678-9"
                  value={rut}
                  onChange={(e) => setRut(e.target.value)}
                  className="w-full p-2 bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-800 dark:text-slate-100 outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label htmlFor={ageId} className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Edad</label>
                <input
                  id={ageId}
                  type="number"
                  placeholder="Ej. 34"
                  value={age}
                  onChange={(e) => setAge(e.target.value)}
                  className="w-full p-2 bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-800 dark:text-slate-100 outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              <div>
                <label htmlFor={substanceId} className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Sustancia Principal</label>
                <select
                  id={substanceId}
                  value={primarySubstance}
                  onChange={(e) => setPrimarySubstance(e.target.value)}
                  className="w-full p-2 bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-800 dark:text-slate-100 outline-none focus:border-indigo-500"
                >
                  <option value="Alcohol">Alcohol (Dependencia / Uso Perjudicial)</option>
                  <option value="Pasta Base de Cocaína (PBC)">Pasta Base de Cocaína (PBC)</option>
                  <option value="Clorhidrato de Cocaína">Clorhidrato de Cocaína</option>
                  <option value="Cannabis">Cannabis</option>
                  <option value="Benzodiacepinas">Benzodiacepinas (Uso no médico)</option>
                  <option value="Opioides / Tramadol">Opioides / Tramadol / Fentanilo</option>
                  <option value="Policonsumo">Policonsumo de Sustancias</option>
                </select>
              </div>

              <div>
                <label htmlFor={fucId} className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                  FUC (Fecha Último Consumo)
                </label>
                <input
                  id={fucId}
                  type="date"
                  value={fucDate}
                  onChange={(e) => setFucDate(e.target.value)}
                  className="w-full p-2 bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-800 dark:text-slate-100 outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            {/* Banner de Días de Abstinencia Calculados */}
            {daysAbstinent !== null && (
              <div className="bg-slate-100 dark:bg-slate-800 border-l-2 border-l-emerald-500 border border-slate-200 dark:border-slate-700 p-3 rounded-xl flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-7 h-7 rounded-lg bg-slate-900 dark:bg-slate-700 text-white flex items-center justify-center font-bold text-xs">
                    {daysAbstinent}
                  </div>
                  <div>
                    <span className="text-xs font-bold text-slate-900 dark:text-white">Días de Abstinencia Continua</span>
                    <span className="text-[11px] text-slate-500 dark:text-slate-400 block">
                      Calculado automáticamente desde la fecha FUC.
                    </span>
                  </div>
                </div>
                <span className="text-xs font-medium text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-700 px-2.5 py-0.5 rounded border border-slate-200 dark:border-slate-600">
                  {daysAbstinent > 90 ? "Consolidación" : daysAbstinent > 30 ? "Fase Temprana" : "Desintoxicación"}
                </span>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              <div>
                <label htmlFor={patternId} className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Patrón de Consumo Actual</label>
                <select
                  id={patternId}
                  value={consumptionPattern}
                  onChange={(e) => setConsumptionPattern(e.target.value)}
                  className="w-full p-2 bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-800 dark:text-slate-100 outline-none focus:border-indigo-500"
                >
                  <option value="Abstinente en programa">Abstinente en programa</option>
                  <option value="Consumo episódico (Lapse)">Consumo episódico / Lapse puntual</option>
                  <option value="Recaída activa (Relapse)">Recaída activa (Relapse)</option>
                  <option value="Reducción de daños / Microconsumo">Reducción de daños / Microconsumo</option>
                  <option value="Consumo diario sostenido">Consumo diario sostenido</option>
                </select>
              </div>

              <div>
                <label htmlFor={stageId} className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Etapa de Cambio (Prochaska)</label>
                <select
                  id={stageId}
                  value={stageOfChange}
                  onChange={(e) => setStageOfChange(e.target.value)}
                  className="w-full p-2 bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-800 dark:text-slate-100 outline-none focus:border-indigo-500"
                >
                  <option value="Precontemplación">Precontemplación (Sin conciencia de problema)</option>
                  <option value="Contemplación">Contemplación (Ambivalencia)</option>
                  <option value="Preparación">Preparación (Decidido al cambio)</option>
                  <option value="Acción">Acción (Comprometido en tratamiento)</option>
                  <option value="Mantenimiento">Mantenimiento (Sosteniendo logros)</option>
                  <option value="Recaída">Recaída (Reinicio de ciclo)</option>
                </select>
              </div>
            </div>
          </div>

          {/* 2. Termómetro de Craving & Ritmos Biológicos */}
          <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl shadow-xs border border-slate-200 dark:border-slate-800 space-y-4">
            <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider border-b border-slate-100 dark:border-slate-800 pb-2.5">
              2. Termómetro de Craving &amp; Psicopatología
            </h3>

            {/* Slider Craving */}
            <div className="bg-slate-50 dark:bg-slate-800/50 p-3.5 rounded-xl border border-slate-200 dark:border-slate-700">
              <div className="flex justify-between items-center mb-2">
                <span className="text-xs font-medium text-slate-700 dark:text-slate-300">Intensidad del Craving Actual:</span>
                <span className="text-xs font-bold px-2 py-0.5 rounded bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200">
                  {cravingLevel} / 10
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="10"
                value={cravingLevel}
                onChange={(e) => setCravingLevel(Number(e.target.value))}
                className="w-full h-2 bg-slate-200 dark:bg-slate-700 rounded-lg accent-indigo-600 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-400 font-medium mt-1">
                <span>0 (Sin deseo)</span>
                <span>5 (Manejable)</span>
                <span>10 (Craving abrumador)</span>
              </div>
            </div>

            {/* Ritmos y Esferas */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Estado de Ánimo</label>
                <select
                  value={mood}
                  onChange={(e) => setMood(e.target.value)}
                  className="w-full p-2 bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-800 dark:text-slate-100 outline-none"
                >
                  <option value="Eutímico / Estable">Eutímico / Estable</option>
                  <option value="Hipotímico / Disfórico">Hipotímico / Disfórico</option>
                  <option value="Ansioso / Hiperalerta">Ansioso / Hiperalerta</option>
                  <option value="Irritable / Lábil">Irritable / Lábil</option>
                  <option value="Anhedónico marcado">Anhedónico marcado</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Sueño / Ritmo Circadiano</label>
                <select
                  value={sleep}
                  onChange={(e) => setSleep(e.target.value)}
                  className="w-full p-2 bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-800 dark:text-slate-100 outline-none"
                >
                  <option value="Conservado (7-8 hrs sin interrupciones)">Conservado (7-8 hrs sin interrupciones)</option>
                  <option value="Insomnio de conciliación">Insomnio de conciliación</option>
                  <option value="Insomnio de mantenimiento / Despertar precoz">Insomnio de mantenimiento</option>
                  <option value="Pesadillas vívidas / Sueño no reparador">Sueño no reparador / Pesadillas</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Ideación Suicida / Muerte</label>
                <select
                  value={suicidalIdeation}
                  onChange={(e) => setSuicidalIdeation(e.target.value)}
                  className="w-full p-2 bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-800 dark:text-slate-100 outline-none"
                >
                  <option value="Negativa (Sin ideación suicida activa ni pasiva)">Negativa (Sin ideación)</option>
                  <option value="Ideas de muerte pasivas sin planificación">Ideas de muerte pasivas</option>
                  <option value="Ideación suicida activa estructurada (ALERTA)">Ideación activa (ALERTA)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Síntomas Psicóticos / Sensopercepción</label>
                <select
                  value={psychoticSymptoms}
                  onChange={(e) => setPsychoticSymptoms(e.target.value)}
                  className="w-full p-2 bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-800 dark:text-slate-100 outline-none"
                >
                  <option value="Negativos (Sin sensopercepciones anómalas)">Negativos (Sin alucinaciones)</option>
                  <option value="Alucinosis auditiva o táctil leve">Alucinosis leve</option>
                  <option value="Ideas delirantes de daño o persecución">Ideas delirantes de daño/persecución</option>
                </select>
              </div>
            </div>
          </div>

          {/* 3. Monitoreo Especializado de Disulfiram */}
          <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl shadow-xs border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2.5">
              <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                3. Monitoreo de Disulfiram (Tratamiento Aversivo)
              </h3>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={takingDisulfiram}
                  onChange={(e) => setTakingDisulfiram(e.target.checked)}
                  className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 accent-indigo-600 cursor-pointer"
                />
                <span className="text-xs font-medium text-slate-700 dark:text-slate-300">¿En tratamiento con Disulfiram?</span>
              </label>
            </div>

            {takingDisulfiram && (
              <div className="space-y-3 pt-1 animate-fadeIn">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label htmlFor={disulfiramDoseId} className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Dosis Prescrita</label>
                    <input
                      id={disulfiramDoseId}
                      type="text"
                      value={disulfiramDose}
                      onChange={(e) => setDisulfiramDose(e.target.value)}
                      className="w-full p-2 bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-800 dark:text-slate-100 outline-none"
                    />
                  </div>

                  <div>
                    <label htmlFor={disulfiramAdminId} className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Supervisión de Toma</label>
                    <select
                      id={disulfiramAdminId}
                      value={disulfiramAdherence}
                      onChange={(e) => setDisulfiramAdherence(e.target.value)}
                      className="w-full p-2 bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-800 dark:text-slate-100 outline-none"
                    >
                      <option value="Supervisada por familiar / red de apoyo">Supervisada por familiar / red</option>
                      <option value="Autoadministrada por el paciente">Autoadministrada</option>
                      <option value="Supervisada en COSAM / CESFAM">Supervisada en centro asistencial</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Reacciones Adversas (RAMs) o Tolerancia</label>
                  <select
                    value={disulfiramRAMs}
                    onChange={(e) => setDisulfiramRAMs(e.target.value)}
                    className="w-full p-2 bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-800 dark:text-slate-100 outline-none"
                  >
                    <option value="Sin reacciones adversas reportadas">Sin reacciones adversas reportadas</option>
                    <option value="Sabor metálico / Disgeusia leve">Sabor metálico en boca (leve)</option>
                    <option value="Somnolencia / Fatiga matinal">Somnolencia / Fatiga matinal</option>
                    <option value="Dermatitis o erupción cutánea">Dermatitis o erupción cutánea</option>
                    <option value="Elevación asintomática de transaminasas">Elevación de transaminasas (requiere control)</option>
                  </select>
                </div>

                <div className="bg-slate-100 dark:bg-slate-800 border-l-2 border-l-amber-500 border border-slate-200 dark:border-slate-700 p-3 rounded-xl text-xs text-slate-700 dark:text-slate-300">
                  <span>
                    <strong>Pauta de Seguridad:</strong> Recordar al paciente y acompañante que la ingesta de alcohol desencadena reacción tipo antabús severa.
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* 4. Gatillantes y Coping Tags */}
          <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl shadow-xs border border-slate-200 dark:border-slate-800 space-y-3">
            <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider border-b border-slate-100 dark:border-slate-800 pb-2.5">
              4. Gatillantes &amp; Estrategias de Afrontamiento
            </h3>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-2">Gatillantes Detectados:</label>
              <div className="flex flex-wrap gap-1.5">
                {triggerOptions.map((trig) => {
                  const isSelected = selectedTriggers.includes(trig);
                  return (
                    <button
                      key={trig}
                      type="button"
                      onClick={() => toggleTrigger(trig)}
                      className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                        isSelected
                          ? "bg-slate-900 dark:bg-slate-700 text-white"
                          : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-750"
                      }`}
                    >
                      {isSelected ? "✓ " : "+ "}
                      {trig}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="pt-2">
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-2">Estrategias de Afrontamiento Acordadas:</label>
              <div className="flex flex-wrap gap-1.5">
                {copingOptions.map((cop) => {
                  const isSelected = selectedCoping.includes(cop);
                  return (
                    <button
                      key={cop}
                      type="button"
                      onClick={() => toggleCoping(cop)}
                      className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                        isSelected
                          ? "bg-indigo-600 text-white"
                          : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-750"
                      }`}
                    >
                      {isSelected ? "✓ " : "+ "}
                      {cop}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* 5. Plan y Acuerdos */}
          <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl shadow-xs border border-slate-200 dark:border-slate-800 space-y-2.5">
            <label htmlFor={agreementsId} className="block text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider cursor-pointer">
              5. Acuerdos y Plan Terapéutico
            </label>
            <textarea
              id={agreementsId}
              rows={3}
              value={agreements}
              onChange={(e) => setAgreements(e.target.value)}
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-100 outline-none focus:border-indigo-500"
            />
          </div>
        </div>

        {/* COLUMNA DERECHA: VISTA PREVIA FORMATO FICHA RAYEN APS */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 p-5 rounded-2xl shadow-xs border border-slate-200 dark:border-slate-800 flex flex-col justify-between h-full space-y-3">
            <div className="flex justify-between items-center border-b border-slate-100 dark:border-slate-800 pb-2.5">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                Formato Ficha Rayen APS
              </span>
              <button
                onClick={copyToClipboard}
                className="px-3 py-1 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                {copied ? "¡Copiado!" : "Copiar"}
              </button>
            </div>

            <div className="flex-1 bg-slate-50 dark:bg-slate-950 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 font-mono text-[11px] text-slate-700 dark:text-slate-300 overflow-y-auto max-h-[580px] leading-relaxed whitespace-pre-wrap select-all">
              {generateRayenNote()}
            </div>

            <div className="text-xs text-slate-500 dark:text-slate-400 bg-slate-50 dark:bg-slate-800/60 p-2.5 rounded-xl border border-slate-200 dark:border-slate-800">
              Haga clic en <strong>Copiar</strong> y pegue directamente en Rayen APS en su box.
            </div>
          </div>
        </div>
      </div>
        </>
      )}
    </div>
  );
}
