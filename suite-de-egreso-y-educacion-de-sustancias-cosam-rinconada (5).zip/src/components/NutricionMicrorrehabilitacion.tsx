import { useState } from "react";
import { MICRONUTRIENTES_DATA, PILARES_MICRORREHABILITACION } from "../data/nutritionData";
import { MicronutrienteInfo } from "../types";
import { motion, AnimatePresence } from "motion/react";
import {
  Apple,
  Pill,
  Printer,
  ChevronRight,
  Search
} from "lucide-react";

export default function NutricionMicrorrehabilitacion() {
  const [selectedNutrient, setSelectedNutrient] = useState<MicronutrienteInfo>(MICRONUTRIENTES_DATA[0]);
  const [filterCat, setFilterCat] = useState<string>("Todas");
  const [searchWord, setSearchWord] = useState<string>("");

  const handlePrintPauta = () => {
    const printWindow = window.open("", "_blank");
    if (!printWindow) {
      alert("Por favor permita las ventanas emergentes para generar la pauta de microrrehabilitación.");
      return;
    }

    printWindow.document.title = "Pauta_Microrrehabilitacion_Nutricional_COSAM_San_Ramon";
    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <title>Pauta de Microrrehabilitación Nutricional - COSAM Rinconada de San Ramón</title>
          <style>
            @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap');
            body {
              font-family: 'Plus Jakarta Sans', sans-serif;
              color: #1e293b;
              padding: 40px;
              line-height: 1.5;
              -webkit-print-color-adjust: exact;
              print-color-adjust: exact;
            }
            @page { size: A4; margin: 15mm 20mm; }
            .header {
              border-bottom: 3px solid #7c3aed;
              padding-bottom: 20px;
              margin-bottom: 25px;
              display: flex;
              justify-content: space-between;
              align-items: flex-start;
            }
            .header h1 { font-size: 22px; font-weight: 800; color: #0f172a; margin: 0 0 4px 0; }
            .header p { font-size: 12px; color: #64748b; margin: 0; }
            .intro-box {
              background-color: #f5f3ff;
              border: 1px solid #ddd6fe;
              padding: 15px 20px;
              border-radius: 12px;
              font-size: 12.5px;
              color: #4c1d95;
              margin-bottom: 25px;
            }
            .section-title {
              font-size: 14px;
              font-weight: 800;
              text-transform: uppercase;
              color: #7c3aed;
              letter-spacing: 0.05em;
              border-bottom: 1px solid #e2e8f0;
              padding-bottom: 6px;
              margin: 25px 0 15px 0;
            }
            .grid-2 {
              display: grid;
              grid-template-columns: 1fr 1fr;
              gap: 15px;
              margin-bottom: 20px;
            }
            .card {
              border: 1px solid #e2e8f0;
              background-color: #fafbfd;
              padding: 15px;
              border-radius: 10px;
            }
            .card h3 {
              font-size: 12px;
              font-weight: 800;
              color: #0f172a;
              margin: 0 0 6px 0;
            }
            .card p { font-size: 11.5px; color: #475569; margin: 0; }
            .badge {
              display: inline-block;
              font-size: 10px;
              font-weight: 800;
              text-transform: uppercase;
              background-color: #ede9fe;
              color: #6d28d9;
              padding: 2px 8px;
              border-radius: 6px;
              margin-bottom: 6px;
            }
            .footer {
              margin-top: 40px;
              border-top: 1px solid #e2e8f0;
              padding-top: 15px;
              font-size: 11px;
              color: #94a3b8;
              text-align: center;
            }
          </style>
        </head>
        <body>
          <div class="header">
            <div>
              <span class="badge">COSAM Rinconada de San Ramón • Psiquiatría y Salud Mental</span>
              <h1>Pauta de Microrrehabilitación & Reposición Nutricional</h1>
              <p>Tratamiento de Soporte Metabólico en Trastornos por Uso de Sustancias</p>
            </div>
            <div style="text-align: right;">
              <p><strong>Médico:</strong> Dr. Andrés Felipe Ruiz Miranda</p>
              <p style="font-size: 10.5px; color: #6d28d9;">Médico / Programa de Tratamiento en Adicciones</p>
              <p><strong>Fecha:</strong> ${new Date().toLocaleDateString("es-CL")}</p>
            </div>
          </div>

          <div class="intro-box">
            <strong>¿Por qué es indispensable la nutrición en la recuperación cerebral?</strong><br>
            El cerebro no puede fabricar neurotransmisores del bienestar (dopamina, serotonina, GABA) sin materia prima biológica. El consumo crónico genera desnutrición celular oculta, neuroinflamación e hiperpermeabilidad intestinal. Esta pauta busca reponer los nutrientes críticos para acelerar la recuperación física y mental.
          </div>

          <div class="section-title">4 Pilares de Hábitos en Box</div>
          <div class="grid-2">
            ${PILARES_MICRORREHABILITACION.map((pil) => `
              <div class="card">
                <h3>${pil.titulo}</h3>
                <p style="margin-bottom: 6px;">${pil.descripcion}</p>
                <p style="font-weight: 700; color: #7c3aed;">Indicación: ${pil.indicacionBox}</p>
              </div>
            `).join("")}
          </div>

          <div class="section-title">Micronutrientes Clave y Alimentos Recomendados</div>
          <div class="grid-2">
            ${MICRONUTRIENTES_DATA.slice(0, 8).map((nutri) => `
              <div class="card">
                <span class="badge">${nutri.categoria}</span>
                <h3>${nutri.nombre} (Dosis sugerida: ${nutri.dosisSugeridaReposicion})</h3>
                <p style="margin-bottom: 6px;"><strong>Para qué sirve:</strong> ${nutri.rolEnSaludMental}</p>
                <p><strong>Alimentos con este nutriente:</strong> ${nutri.alimentosFuentes.join(", ")}</p>
              </div>
            `).join("")}
          </div>

          <div class="footer">
            Documento institucional para uso clínico y psicoeducación del paciente • COSAM Rinconada de San Ramón
          </div>
        </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => {
      printWindow.print();
    }, 500);
  };

  const categories = ["Todas", "Complejo B", "Minerales & Oligoelementos", "Antioxidantes & Lipidos", "Aminoacidos"];

  const filteredNutrients = MICRONUTRIENTES_DATA.filter((n) => {
    const matchesCat = filterCat === "Todas" || n.categoria === filterCat;
    const matchesSearch =
      !searchWord.trim() ||
      n.nombre.toLowerCase().includes(searchWord.toLowerCase()) ||
      n.rolEnSaludMental.toLowerCase().includes(searchWord.toLowerCase()) ||
      n.alimentosFuentes.some((a) => a.toLowerCase().includes(searchWord.toLowerCase()));
    return matchesCat && matchesSearch;
  });

  return (
    <div className="space-y-6 animate-fadeIn pb-12 max-w-7xl mx-auto">
      {/* BANNER PRINCIPAL ESTILO iOS */}
      <section className="ios-card rounded-3xl p-6 md:p-7 shadow-sm border border-black/[0.04] dark:border-white/[0.06] relative overflow-hidden">
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 relative z-10">
          <div className="space-y-1.5 max-w-3xl">
            <div className="flex items-center gap-2">
              <span className="text-slate-700 dark:text-slate-300 bg-black/[0.04] dark:bg-white/[0.08] text-[11px] font-semibold px-2.5 py-0.5 rounded-full">
                Nutrición &amp; Neuroplasticidad
              </span>
              <span className="text-slate-500 dark:text-slate-400 text-xs font-medium">COSAM Rinconada · San Ramón</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white tracking-tight">
              Microrrehabilitación Nutricional &amp; Reposición de Neurotransmisores
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 font-normal leading-relaxed">
              El consumo crónico vacía las reservas de vitaminas B, zinc, magnesio y aminoácidos. Sin ellos, las neuronas carecen de sustrato para la biosíntesis de monoaminas.
            </p>
          </div>

          {/* BOTÓN DESCARGAR PAUTA IMPRIMIBLE */}
          <button
            onClick={handlePrintPauta}
            className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-900 rounded-2xl text-xs font-semibold transition-all flex items-center gap-2 shadow-xs shrink-0 cursor-pointer active:scale-95"
          >
            <Printer size={14} />
            <span>Imprimir Pauta para Paciente</span>
          </button>
        </div>
      </section>

      {/* LOS 4 PILARES CLÍNICOS DE LA MICRORREHABILITACIÓN */}
      <div className="space-y-3">
        <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
          Protocolo de 4 Pilares en Box:
        </span>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {PILARES_MICRORREHABILITACION.map((pil) => (
            <div
              key={pil.pilar}
              className="ios-card p-5 rounded-2xl border border-black/[0.04] dark:border-white/[0.06] shadow-3xs space-y-3 flex flex-col justify-between"
            >
              <div className="space-y-1.5">
                <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500 block">
                  Pilar {pil.pilar}
                </span>
                <h4 className="text-xs font-bold text-slate-900 dark:text-white leading-snug">
                  {pil.titulo.replace(/^\d+\.\s*/, "")}
                </h4>
                <p className="text-[11px] text-slate-600 dark:text-slate-300 font-normal leading-relaxed">
                  {pil.descripcion}
                </p>
              </div>

              <div className="p-3 bg-black/[0.02] dark:bg-white/[0.04] rounded-xl border border-black/[0.03] dark:border-white/[0.05] text-[11px] text-slate-700 dark:text-slate-300 font-medium leading-snug">
                <span className="text-[9px] font-semibold text-slate-900 dark:text-white uppercase tracking-wider block mb-0.5">
                  Indicación en Box:
                </span>
                {pil.indicacionBox}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* EXPLORADOR DE VITAMINAS Y OLIGOELEMENTOS */}
      <div className="space-y-4 pt-4 border-t border-black/[0.04] dark:border-white/[0.06]">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-3">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Vademécum de Micronutrientes y Oligoelementos
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 font-normal">
              Seleccione un micronutriente para revisar su depleción, clínica por deficiencia y fuentes accesibles.
            </p>
          </div>

          {/* Filtros */}
          <div className="ios-segmented flex flex-wrap gap-1 shadow-3xs">
            {categories.map((c) => (
              <button
                key={c}
                onClick={() => setFilterCat(c)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer whitespace-nowrap ${
                  filterCat === c
                    ? "bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-2xs"
                    : "text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
                }`}
              >
                {c}
              </button>
            ))}
          </div>
        </div>

        {/* Buscador */}
        <div className="relative">
          <Search className="absolute left-4 top-3 text-slate-400" size={15} />
          <input
            type="text"
            value={searchWord}
            onChange={(e) => setSearchWord(e.target.value)}
            placeholder="Buscar nutriente o alimento (ej. 'tiamina', 'magnesio', 'pescados', 'wernicke')..."
            className="w-full pl-10 pr-4 py-2.5 ios-card rounded-2xl text-xs font-medium text-slate-800 dark:text-slate-200 outline-none border border-black/[0.05] dark:border-white/[0.08] focus:border-slate-900 dark:focus:border-white placeholder:text-slate-400"
          />
        </div>

        {/* 2 Columnas: Lista de Micronutrientes y Detalle */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Lista */}
          <div className="lg:col-span-5 space-y-2">
            {filteredNutrients.map((nutri) => {
              const isSelected = selectedNutrient.id === nutri.id;
              return (
                <button
                  key={nutri.id}
                  onClick={() => setSelectedNutrient(nutri)}
                  className={`w-full text-left p-3.5 rounded-2xl border transition-all flex items-center justify-between gap-3 cursor-pointer ${
                    isSelected
                      ? "bg-slate-900 text-white dark:bg-white dark:text-slate-900 border-slate-900 dark:border-white shadow-xs"
                      : "ios-card hover:bg-black/[0.02] dark:hover:bg-white/[0.04] border-black/[0.04] dark:border-white/[0.06]"
                  }`}
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className={`text-[9px] font-semibold uppercase tracking-wider ${
                        isSelected ? "text-slate-300 dark:text-slate-600" : "text-slate-400 dark:text-slate-500"
                      }`}>
                        {nutri.categoria}
                      </span>
                      <span className={`text-[8px] font-semibold uppercase px-2 py-0.5 rounded-full ${
                        nutri.prioridadBox === "Crítica"
                          ? isSelected ? "bg-rose-500/30 text-white" : "bg-rose-100 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300"
                          : isSelected ? "bg-amber-500/30 text-white" : "bg-amber-100 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300"
                      }`}>
                        Prioridad {nutri.prioridadBox}
                      </span>
                    </div>
                    <h4 className="text-xs font-bold leading-snug truncate">
                      {nutri.nombre}
                    </h4>
                  </div>
                  <ChevronRight
                    size={15}
                    className={`shrink-0 transition-transform ${
                      isSelected ? "text-white dark:text-slate-900 translate-x-0.5" : "text-slate-400"
                    }`}
                  />
                </button>
              );
            })}
          </div>

          {/* Ficha Detallada del Nutriente */}
          <div className="lg:col-span-7">
            <AnimatePresence mode="wait">
              <motion.div
                key={selectedNutrient.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.18 }}
                className="ios-card rounded-3xl p-6 md:p-7 border border-black/[0.04] dark:border-white/[0.06] space-y-5 shadow-sm"
              >
                <div className="flex justify-between items-start border-b border-black/[0.04] dark:border-white/[0.06] pb-4">
                  <div>
                    <span className="text-[10px] font-semibold text-slate-700 dark:text-slate-300 bg-black/[0.04] dark:bg-white/[0.08] px-2.5 py-0.5 rounded-full">
                      {selectedNutrient.categoria}
                    </span>
                    <h3 className="text-xl md:text-2xl font-bold text-slate-900 dark:text-white mt-2 tracking-tight">
                      {selectedNutrient.nombre}
                    </h3>
                  </div>

                  <div className="text-right">
                    <span className="text-[9px] font-semibold text-slate-400 uppercase tracking-wider block">
                      Dosis Sugerida:
                    </span>
                    <span className="text-xs font-semibold text-slate-900 dark:text-white bg-black/[0.04] dark:bg-white/[0.08] px-3 py-1 rounded-xl inline-block mt-0.5 border border-black/[0.04] dark:border-white/[0.06]">
                      {selectedNutrient.dosisSugeridaReposicion}
                    </span>
                  </div>
                </div>

                <div className="p-4 bg-black/[0.02] dark:bg-white/[0.04] rounded-2xl border border-black/[0.03] dark:border-white/[0.05]">
                  <span className="text-[10px] font-semibold text-slate-400 dark:text-slate-500 uppercase tracking-wider block mb-1">
                    Rol en Salud Mental:
                  </span>
                  <p className="text-xs text-slate-700 dark:text-slate-300 font-medium leading-relaxed">
                    {selectedNutrient.rolEnSaludMental}
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 bg-rose-50/50 dark:bg-rose-950/20 border border-rose-200/60 dark:border-rose-900/40 rounded-2xl">
                    <span className="text-[10px] font-bold text-rose-900 dark:text-rose-300 uppercase tracking-wider block mb-1">
                      ¿Por qué el consumo lo agota?
                    </span>
                    <p className="text-xs text-rose-950 dark:text-rose-200 font-normal leading-relaxed">
                      {selectedNutrient.mecanismoDeDeplecionPorConsumo}
                    </p>
                  </div>

                  <div className="p-4 bg-amber-50/50 dark:bg-amber-950/20 border border-amber-200/60 dark:border-amber-900/40 rounded-2xl">
                    <span className="text-[10px] font-bold text-amber-900 dark:text-amber-300 uppercase tracking-wider block mb-1">
                      Consecuencia del Déficit:
                    </span>
                    <p className="text-xs text-amber-950 dark:text-amber-200 font-normal leading-relaxed">
                      {selectedNutrient.consecuenciaClinicaDeficiencia}
                    </p>
                  </div>
                </div>

                {/* Fuentes de Alimentos */}
                <div className="p-4 bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-200/60 dark:border-emerald-900/40 rounded-2xl space-y-2">
                  <span className="text-[10px] font-bold text-emerald-900 dark:text-emerald-300 uppercase tracking-wider flex items-center gap-1.5">
                    <Apple size={13} className="text-emerald-600 dark:text-emerald-400" /> Fuentes Accesibles para el Paciente:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {selectedNutrient.alimentosFuentes.map((ali, idx) => (
                      <span
                        key={idx}
                        className="px-3 py-1 bg-white border border-emerald-200 text-emerald-950 rounded-xl text-xs font-bold shadow-2xs"
                      >
                        {ali}
                      </span>
                    ))}
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </div>
    </div>
  );
}
