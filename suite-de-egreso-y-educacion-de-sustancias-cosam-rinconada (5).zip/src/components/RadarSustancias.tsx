import { useState } from "react";
import { motion } from "motion/react";
import {
  Brain,
  HeartPulse,
  Activity,
  Flame,
  Shield,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  Lightbulb,
  Info,
  Clock,
  Zap,
  Droplets,
  Layers
} from "lucide-react";

interface SubstanceData {
  id: string;
  name: string;
  category: string;
  badge: string;
  accent: string;
  systemDamage: {
    snc: number;
    cardio: number;
    digestivo: number;
    endocrino: number;
    inmune: number;
    metabolico: number;
  };
  reversibilityRate: number; // 0 to 100%
  timeframeRecovery: string;
  analogia: string;
  mecanismoEmpatico: string;
  mito: string;
  realidad: string;
  perlaMedica: string;
}

const SUBSTANCES_RADAR: SubstanceData[] = [
  {
    id: "alcohol",
    name: "Alcohol",
    category: "Depresor del SNC",
    badge: "Alta Toxicidad Sistémica",
    accent: "text-purple-700 bg-purple-50 border-purple-200",
    systemDamage: {
      snc: 90,
      cardio: 80,
      digestivo: 95,
      endocrino: 75,
      inmune: 85,
      metabolico: 80
    },
    reversibilityRate: 85,
    timeframeRecovery: "3 a 12 meses de abstinencia continua",
    analogia:
      "Es como un disolvente orgánico que barre el barniz protector de las neuronas y satura los filtros del hígado. Al detener el consumo, el hígado y el cerebro activan un programa de auto-limpieza intensiva.",
    mecanismoEmpatico:
      "Altera la membrana celular y sobreestimula el receptor GABA mientras apaga el glutamato. Cuando el alcohol desaparece de golpe, el cerebro entra en hiperalerta (abstinencia). Con tiempo, los receptores se reequilibran.",
    mito: "Un par de tragos me ayudan a relajarme y dormir mejor.",
    realidad:
      "El alcohol fragmenta la arquitectura del sueño REM y eleva el cortisol nocturno, provocando despertares de pánico y ansiedad de rebote al día siguiente.",
    perlaMedica:
      "Déficit crítico de Tiamina (B1) y Magnesio. Riesgo de Esteatohepatitis y Neuroinflamación glial difusa."
  },
  {
    id: "cocaina",
    name: "Clorhidrato de Cocaína",
    category: "Estimulante Mayor",
    badge: "Alto Riesgo Cardiovascular",
    accent: "text-rose-700 bg-rose-50 border-rose-200",
    systemDamage: {
      snc: 95,
      cardio: 95,
      digestivo: 60,
      endocrino: 85,
      inmune: 70,
      metabolico: 80
    },
    reversibilityRate: 80,
    timeframeRecovery: "6 a 18 meses para restauración de transportadores DAT",
    analogia:
      "Imagina acelerar el motor de un auto a máxima velocidad mientras frenas con el freno de mano. El corazón sufre micro-infartos y los cables dopaminérgicos del placer natural quedan quemados temporalmente.",
    mecanismoEmpatico:
      "Bloquea agresivamente la recaptación de dopamina, noradrenalina y serotonina. El cerebro se queda sin reservas ('crash'), lo que genera anhedonia y desesperanza transitoria en los primeros días sin consumo.",
    mito: "Puedo controlarlo si solo consumo los fines de semana.",
    realidad:
      "El vasoespasmo coronario y la remodelación de las espinas dendríticas en el núcleo accumbens ocurren desde las primeras dosis, consolidando la necesidad compulsiva.",
    perlaMedica:
      "Causa hipertrofia ventricular izquierda, arritmias fatales y desregulación del eje hipotálamo-hipófisis-adrenal."
  },
  {
    id: "pbc",
    name: "Pasta Base de Cocaína (PBC)",
    category: "Estimulante Fumado",
    badge: "Máxima Toxicidad Aguda",
    accent: "text-purple-800 bg-purple-100 border-purple-300",
    systemDamage: {
      snc: 98,
      cardio: 96,
      digestivo: 85,
      endocrino: 90,
      inmune: 92,
      metabolico: 95
    },
    reversibilityRate: 75,
    timeframeRecovery: "12 a 24 meses de neuroestabilización guiada",
    analogia:
      "Es una llamarada química instantánea que entra al cerebro en 5 segundos, sobrecalentando el circuito de supervivencia e induciendo un estado de alarma biológica extrema.",
    mecanismoEmpatico:
      "Su biodisponibilidad inhalatoria produce picos masivos de dopamina seguidos de hipofunción prefrontal aguda, desconectando el juicio reflexivo y priorizando la búsqueda sobre la supervivencia.",
    mito: "La pasta base destruye el cerebro de forma irreversible en un mes.",
    realidad:
      "Aunque el daño estructural y respiratorio es veloz, la neurogénesis hipocampal y la plasticidad sináptica demuestran recuperación significativa tras 6 meses de abstinencia y nutrición de choque.",
    perlaMedica:
      "Monitorear daño alveolar pulmonar, desnutrición severa, hipoalbuminemia y comorbilidad con trastornos psicóticos inducidos."
  },
  {
    id: "cannabis",
    name: "Cannabis de Alta Potencia",
    category: "Cannabinoide / Alucinógeno",
    badge: "Impacto Neurocognitivo",
    accent: "text-emerald-700 bg-emerald-50 border-emerald-200",
    systemDamage: {
      snc: 75,
      cardio: 55,
      digestivo: 50,
      endocrino: 70,
      inmune: 60,
      metabolico: 55
    },
    reversibilityRate: 90,
    timeframeRecovery: "1 a 3 meses para densidad receptores CB1",
    analogia:
      "Es como poner una niebla densa sobre la memoria de trabajo y la velocidad de procesamiento del cerebro. Al disiparse la niebla, las conexiones recuperan su nitidez.",
    mecanismoEmpatico:
      "El THC sobreestimula los receptores CB1 provocando su internalización (downregulation). Esto genera falta de motivación, bradipsiquia y alteraciones del sueño al suspender.",
    mito: "Como es una planta natural, no genera adicción ni daño cerebral.",
    realidad:
      "Las cepas modernas tienen concentraciones de THC superiores al 20%, con alta capacidad de inducir síndrome amotivacional y desencadenar psicosis en personas genéticamente vulnerables.",
    perlaMedica:
      "Monitorear síndrome de hiperemesis cannabinoide, deterioro en memoria episódica y síntomas afectivos amotivacionales."
  },
  {
    id: "benzos",
    name: "Benzodiacepinas no Supervisadas",
    category: "Hipnótico / Sedante",
    badge: "Dependencia Física Severa",
    accent: "text-indigo-700 bg-indigo-50 border-indigo-200",
    systemDamage: {
      snc: 85,
      cardio: 50,
      digestivo: 45,
      endocrino: 65,
      inmune: 55,
      metabolico: 60
    },
    reversibilityRate: 92,
    timeframeRecovery: "6 a 12 meses con protocolo de titulación lenta",
    analogia:
      "Es como usar una muleta para caminar cuando el pie está sano: los músculos naturales de la calma (GABA) se atrofian por falta de uso, haciendo que cualquier mínimo estímulo parezca una catástrofe.",
    mecanismoEmpatico:
      "Modula alostéricamente el receptor GABAA aumentando la afinidad por GABA. El cerebro reduce su propia producción endógena de inhibición, generando ansiedad de rebote extrema al faltar la dosis.",
    mito: "Si el médico me las recetó alguna vez, puedo tomarlas indefinidamente para los nervios.",
    realidad:
      "El uso continuo por más de 4 semanas induce tolerancia farmacológica, pérdida de memoria retrógrada y riesgo de demencia a largo plazo.",
    perlaMedica:
      "Requiere deshabituación lenta y programada. Nunca suspender de forma abrupta por riesgo de convulsiones y delirium tremens."
  }
];

export default function RadarSustancias() {
  const [selectedSubstance, setSelectedSubstance] = useState<SubstanceData>(SUBSTANCES_RADAR[0]);
  const [activeSystem, setActiveSystem] = useState<
    "snc" | "cardio" | "digestivo" | "endocrino" | "inmune" | "metabolico"
  >("snc");

  const getSystemDamageValue = (key: keyof SubstanceData["systemDamage"]) => {
    return selectedSubstance.systemDamage[key];
  };

  return (
    <div className="space-y-8 animate-fadeIn pb-12">
      {/* HEADER */}
      <section className="liquid-glass rounded-3xl p-6 md:p-8 shadow-sm border border-purple-200/70 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-2.5 h-full bg-gradient-to-b from-purple-700 via-indigo-600 to-slate-900"></div>
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="bg-purple-100 text-purple-900 border border-purple-200 text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-lg">
                NeuroMetabolix &amp; Daño Fisiológico
              </span>
              <span className="text-slate-500 text-xs font-semibold">• COSAM Rinconada de San Ramón</span>
            </div>
            <h2 className="text-xl md:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2.5">
              <Layers className="text-purple-700" size={24} />
              Perfil Fisiológico de Sustancias &amp; Tiempos de Reversibilidad
            </h2>
            <p className="text-xs md:text-sm text-slate-700 font-medium max-w-3xl mt-1 leading-relaxed">
              Herramienta visual para contrastar el nivel de estrés metabólico por sistema orgánico, con analogías empáticas, mitos desarticulados y evidencia de neuroplasticidad regenerativa.
            </p>
          </div>

          <div className="liquid-glass-purple flex items-center gap-2 px-4 py-2.5 rounded-2xl border border-purple-300 text-purple-950 font-black text-xs led-glow-purple shrink-0">
            <Sparkles size={16} className="text-purple-700" />
            <span>Neuroplasticidad Comprobada</span>
          </div>
        </div>
      </section>

      {/* SELECTOR DE SUSTANCIAS */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2.5">
        {SUBSTANCES_RADAR.map((sub) => {
          const isSelected = selectedSubstance.id === sub.id;
          return (
            <button
              key={sub.id}
              onClick={() => setSelectedSubstance(sub)}
              className={`p-3.5 rounded-2xl border text-left transition-all flex flex-col justify-between ${
                isSelected
                  ? "bg-gradient-to-br from-purple-700 to-slate-900 text-white border-purple-600 shadow-md led-pulse-purple scale-[1.02]"
                  : "liquid-glass text-slate-800 border-purple-200/60 hover:border-purple-300 hover:bg-white"
              }`}
            >
              <div>
                <span className={`text-[9px] font-black uppercase tracking-wider block ${isSelected ? "text-purple-200" : "text-slate-500"}`}>
                  {sub.category.split("/")[0]}
                </span>
                <h4 className="text-xs font-black leading-snug mt-0.5">{sub.name}</h4>
              </div>
              <span className={`text-[10px] font-bold mt-2 ${isSelected ? "text-purple-200" : "text-purple-700 font-extrabold"}`}>
                {sub.reversibilityRate}% Reversible
              </span>
            </button>
          );
        })}
      </div>

      {/* DASHBOARD PRINCIPAL DE DAÑO & REVERSIBILIDAD */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* COLUMNA 1: BARRAS DE IMPACTO POR SISTEMA */}
        <div className="lg:col-span-6 bg-white/95 backdrop-blur-md p-6 md:p-8 rounded-3xl shadow-sm border border-purple-200/80 space-y-6">
          <div className="flex justify-between items-start border-b border-purple-100 pb-4">
            <div>
              <span className="text-[10px] font-black uppercase tracking-widest text-purple-900 bg-purple-100 border border-purple-200 px-2.5 py-0.5 rounded-md">
                {selectedSubstance.badge}
              </span>
              <h3 className="text-xl font-black text-slate-900 mt-1">
                {selectedSubstance.name}
              </h3>
              <p className="text-xs text-slate-600 font-medium">{selectedSubstance.category}</p>
            </div>

            <div className="text-right">
              <span className="text-[10px] font-bold text-slate-500 block uppercase">Índice Reversibilidad</span>
              <span className="text-2xl font-black text-emerald-600">
                {selectedSubstance.reversibilityRate}%
              </span>
            </div>
          </div>

          {/* Barras de Sistemas */}
          <div className="space-y-4">
            <h4 className="text-xs font-black uppercase tracking-wider text-slate-700 flex items-center gap-2">
              <Activity size={14} className="text-purple-700" />
              Nivel de Estrés / Toxicidad por Sistema Orgánico:
            </h4>

            {[
              { key: "snc", label: "Sistema Nervioso Central (Cerebro)", icon: Brain, color: "bg-purple-600" },
              { key: "cardio", label: "Cardiovascular & Vascular", icon: HeartPulse, color: "bg-rose-600" },
              { key: "digestivo", label: "Digestivo & Hepático", icon: Flame, color: "bg-amber-600" },
              { key: "endocrino", label: "Endocrino & Hormonas", icon: Droplets, color: "bg-indigo-600" },
              { key: "inmune", label: "Inmunológico & Defensas", icon: Shield, color: "bg-teal-600" },
              { key: "metabolico", label: "Metabolismo & Músculo", icon: Zap, color: "bg-purple-800" }
            ].map((sys) => {
              const val = getSystemDamageValue(sys.key as any);
              const isHigh = val >= 85;
              const Icon = sys.icon;
              return (
                <div
                  key={sys.key}
                  onClick={() => setActiveSystem(sys.key as any)}
                  className={`p-3 rounded-2xl border transition-all cursor-pointer ${
                    activeSystem === sys.key
                      ? "bg-purple-50/70 border-purple-300 ring-2 ring-purple-100"
                      : "border-slate-200 hover:bg-slate-50"
                  }`}
                >
                  <div className="flex justify-between items-center text-xs font-bold text-slate-800 mb-1.5">
                    <span className="flex items-center gap-1.5">
                      <Icon size={14} className="text-purple-600" /> {sys.label}
                    </span>
                    <span className={isHigh ? "text-rose-700 font-black" : "text-slate-700 font-bold"}>
                      {val} / 100 {isHigh ? "(Crítico)" : "(Moderado)"}
                    </span>
                  </div>
                  <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${val}%` }}
                      transition={{ duration: 0.5 }}
                      className={`h-full ${sys.color} rounded-full`}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          {/* Banner de Tiempo de Recuperación */}
          <div className="bg-emerald-50/90 border border-emerald-200 p-4 rounded-2xl flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-sm">
              <Clock size={18} />
            </div>
            <div>
              <span className="text-[10px] font-black uppercase tracking-wider text-emerald-900 block">
                Ventana de Regeneración Celular:
              </span>
              <p className="text-xs font-black text-emerald-950">
                {selectedSubstance.timeframeRecovery}
              </p>
            </div>
          </div>
        </div>

        {/* COLUMNA 2: PSICOEDUCACIÓN EN BOX (ANALOGÍA, MITO VS REALIDAD, PERLA CLÍNICA) */}
        <div className="lg:col-span-6 space-y-4 flex flex-col justify-between">
          
          {/* Analogía para el Paciente */}
          <div className="liquid-glass-purple p-6 rounded-3xl border border-purple-300/80 space-y-3 led-glow-purple">
            <div className="flex items-center gap-2 text-purple-950">
              <Lightbulb size={18} className="text-purple-700" />
              <h4 className="text-xs font-black uppercase tracking-wider">
                Analogía Comprensible para Explicar en Box:
              </h4>
            </div>
            <p className="text-xs md:text-sm text-purple-950 font-bold leading-relaxed italic bg-white/80 p-4 rounded-2xl border border-purple-200">
              &quot;{selectedSubstance.analogia}&quot;
            </p>
          </div>

          {/* Mecanismo Empático */}
          <div className="bg-white/95 backdrop-blur-md p-6 rounded-3xl shadow-sm border border-purple-200/80 space-y-2">
            <h4 className="text-xs font-black uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
              <Brain size={14} className="text-purple-700" />
              ¿Por qué ocurre el craving / malestar? (Explicación Biológica):
            </h4>
            <p className="text-xs text-slate-700 font-medium leading-relaxed">
              {selectedSubstance.mecanismoEmpatico}
            </p>
          </div>

          {/* Mito vs Realidad */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="p-4 bg-rose-50/80 border border-rose-200 rounded-2xl space-y-1">
              <span className="text-[10px] font-black uppercase tracking-widest text-rose-800 flex items-center gap-1">
                <AlertTriangle size={12} /> Mito Frecuente
              </span>
              <p className="text-xs font-bold text-rose-950 leading-snug">
                &quot;{selectedSubstance.mito}&quot;
              </p>
            </div>

            <div className="p-4 bg-emerald-50/80 border border-emerald-200 rounded-2xl space-y-1">
              <span className="text-[10px] font-black uppercase tracking-widest text-emerald-800 flex items-center gap-1">
                <CheckCircle2 size={12} /> Realidad Médica
              </span>
              <p className="text-xs font-bold text-emerald-950 leading-snug">
                {selectedSubstance.realidad}
              </p>
            </div>
          </div>

          {/* Perla Médica */}
          <div className="liquid-glass-dark text-slate-100 p-5 rounded-2xl border border-slate-700/80 space-y-1.5 led-glow-purple">
            <span className="text-[10px] font-black uppercase tracking-widest text-purple-300 flex items-center gap-1.5">
              <Info size={12} /> Perla Clínica para el Tratante:
            </span>
            <p className="text-xs text-slate-200 font-medium leading-relaxed">
              {selectedSubstance.perlaMedica}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
