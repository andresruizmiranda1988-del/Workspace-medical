import { useState } from "react";
import { SISTEMAS_FISIOLOGICOS_DATA } from "../data/systemicData";
import { SistemaFisiologico } from "../types";
import { motion, AnimatePresence } from "motion/react";
import {
  Brain,
  UtensilsCrossed,
  Flame,
  Sparkles,
  ShieldAlert,
  HeartPulse,
  Activity,
  Shield,
  Clock,
  Lightbulb,
  CheckCircle2,
  AlertCircle,
  Search,
  Eye,
  Stethoscope
} from "lucide-react";

export default function TableroSistemico() {
  const [selectedSystem, setSelectedSystem] = useState<SistemaFisiologico>(SISTEMAS_FISIOLOGICOS_DATA[0]);
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [viewMode, setViewMode] = useState<"paciente" | "medico">("paciente");

  const getIcon = (name: string) => {
    switch (name) {
      case "Brain": return <Brain size={18} />;
      case "UtensilsCrossed": return <UtensilsCrossed size={18} />;
      case "Flame": return <Flame size={18} />;
      case "Sparkles": return <Sparkles size={18} />;
      case "ShieldAlert": return <ShieldAlert size={18} />;
      case "HeartPulse": return <HeartPulse size={18} />;
      case "Activity": return <Activity size={18} />;
      default: return <Shield size={18} />;
    }
  };

  const filteredSystems = SISTEMAS_FISIOLOGICOS_DATA.filter((s) => {
    if (!searchTerm.trim()) return true;
    const term = searchTerm.toLowerCase();
    return (
      s.nombre.toLowerCase().includes(term) ||
      s.manifestacionesClinicas.some((m) => m.toLowerCase().includes(term)) ||
      s.resumenImpacto.toLowerCase().includes(term)
    );
  });

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* BANNER INICIAL */}
      <section className="liquid-glass rounded-3xl p-6 md:p-8 shadow-sm border border-purple-200/70 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-2.5 h-full bg-gradient-to-b from-purple-700 via-indigo-600 to-slate-900"></div>
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="bg-purple-100 text-purple-900 border border-purple-200 text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-lg">
                Fisiopatología Clínica
              </span>
              <span className="text-slate-500 text-xs font-semibold">• Explorador Sistémico en Box</span>
            </div>
            <h2 className="text-xl md:text-2xl font-black text-slate-900 tracking-tight">
              Impacto Fisiológico Multisistémico del Consumo de Sustancias
            </h2>
            <p className="text-xs md:text-sm text-slate-700 font-medium max-w-3xl mt-1 leading-relaxed">
              La adicción afecta a la totalidad de la economía corporal. Este panel desglosa el impacto biológico a través de 8 sistemas clave, permitiendo alternar entre explicaciones en lenguaje cercano para el paciente y perlas de manejo clínico para el médico tratante.
            </p>
          </div>

          {/* TOGGLE MODO PACIENTE / MODO MÉDICO */}
          <div className="liquid-glass-dark p-1.5 rounded-2xl flex items-center gap-1 border border-slate-700/80 shrink-0 led-glow-purple">
            <button
              onClick={() => setViewMode("paciente")}
              className={`px-3.5 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 ${
                viewMode === "paciente"
                  ? "bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-md led-glow-purple"
                  : "text-slate-300 hover:text-white"
              }`}
            >
              <Eye size={14} />
              <span>Modo Paciente</span>
            </button>
            <button
              onClick={() => setViewMode("medico")}
              className={`px-3.5 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 ${
                viewMode === "medico"
                  ? "bg-gradient-to-r from-purple-700 to-slate-900 text-white shadow-md led-glow-purple"
                  : "text-slate-300 hover:text-white"
              }`}
            >
              <Stethoscope size={14} />
              <span>Modo Médico</span>
            </button>
          </div>
        </div>
      </section>

      {/* BUSCADOR DE SÍNTOMAS O SISTEMAS */}
      <div className="relative">
        <Search className="absolute left-4 top-3.5 text-slate-400" size={16} />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Buscar síntoma o sistema (ej. 'amenorrea', 'boca seca', 'osteopenia', 'cortisol', 'psicosis')..."
          className="w-full pl-11 pr-4 py-3 bg-white/90 border border-purple-200/80 rounded-2xl text-xs font-semibold text-slate-800 focus:ring-2 focus:ring-purple-600 focus:border-purple-600 outline-none shadow-2xs placeholder:text-slate-400"
        />
      </div>

      {/* GRILLA DE LOS 8 SISTEMAS (DISEÑO BENTO GRID ASIMÉTRICO DE ALTA DENSIDAD) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4" id="bento-grid-sistemas">
        {filteredSystems.map((sys, idx) => {
          const isSelected = selectedSystem.id === sys.id;
          const isProminentCard = idx === 0 || idx === 4; // Sistema Nervioso y Sistema Cardiovascular/Inmune
          return (
            <button
              key={sys.id}
              onClick={() => setSelectedSystem(sys)}
              className={`p-5 rounded-3xl border text-left transition-all duration-200 relative overflow-hidden flex flex-col justify-between min-h-[150px] shadow-3xs cursor-pointer group hover:-translate-y-0.5 ${
                isProminentCard ? "sm:col-span-2" : "col-span-1"
              } ${
                isSelected
                  ? "bg-white dark:bg-slate-800/95 border-purple-600 dark:border-purple-500 shadow-md ring-2 ring-purple-100 dark:ring-purple-950/50 led-glow-purple"
                  : "bg-white/80 dark:bg-slate-900/85 hover:bg-white dark:hover:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-purple-300 dark:hover:border-purple-800"
              }`}
            >
              {/* Parte Superior: Icono y Badge */}
              <div className="flex items-center justify-between mb-3 w-full">
                <div className={`w-9 h-9 rounded-xl ${isSelected ? "bg-gradient-to-br from-purple-700 to-slate-900 text-white led-glow-purple" : "bg-purple-100/95 dark:bg-purple-950/80 text-purple-800 dark:text-purple-300 border border-purple-200/60 dark:border-purple-800/60"} flex items-center justify-center shrink-0`}>
                  {getIcon(sys.icono)}
                </div>
                <div className="flex items-center gap-1.5">
                  <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded-md ${isSelected ? "bg-purple-600 text-white" : "bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 border border-slate-200 dark:border-slate-700"}`}>
                    {sys.tiempoReversibilidad.split(" ")[0]} {sys.tiempoReversibilidad.split(" ")[1] || ""}
                  </span>
                  {isSelected && (
                    <span className="w-2 h-2 rounded-full bg-purple-600 dark:bg-purple-400 animate-pulse"></span>
                  )}
                </div>
              </div>

              {/* Parte Inferior: Título y Extracto de Información */}
              <div className="space-y-1.5 mt-auto w-full">
                <h4 className="text-xs font-black text-slate-900 dark:text-slate-100 leading-tight group-hover:text-purple-700 dark:group-hover:text-purple-400 transition-colors">
                  {sys.nombre}
                </h4>
                
                {/* Extracto disponible en tarjetas grandes para enriquecer la densidad de información */}
                {isProminentCard && (
                  <p className="text-[10px] text-slate-500 dark:text-slate-400 font-medium leading-snug line-clamp-2 pt-0.5 border-t border-slate-100 dark:border-slate-800/60">
                    {sys.resumenImpacto}
                  </p>
                )}

                <span className="text-[9px] font-bold text-slate-400 dark:text-slate-500 block">
                  {sys.manifestacionesClinicas.length} manifestaciones clínicas
                </span>
              </div>
            </button>
          );
        })}
      </div>

      {/* DETALLE DEL SISTEMA SELECCIONADO */}
      <AnimatePresence mode="wait">
        <motion.div
          key={selectedSystem.id}
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -12 }}
          transition={{ duration: 0.2 }}
          className="bg-white/95 backdrop-blur-md rounded-3xl p-6 md:p-8 shadow-sm border border-purple-200/80 space-y-6"
        >
          {/* Header del Sistema */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-purple-100 pb-5">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-purple-700 to-slate-900 text-white flex items-center justify-center shadow-md led-glow-purple border border-purple-300/30">
                {getIcon(selectedSystem.icono)}
              </div>
              <div>
                <span className="text-[10px] font-black uppercase tracking-widest text-purple-700 block">
                  Sistema Orgánico Seleccionado
                </span>
                <h3 className="text-xl font-black text-slate-900">
                  {selectedSystem.nombre}
                </h3>
              </div>
            </div>

            <div className="flex items-center gap-2 liquid-glass-purple border border-purple-300/70 px-3.5 py-1.5 rounded-xl led-glow-purple">
              <Clock size={14} className="text-purple-700" />
              <div className="text-left">
                <span className="text-[9px] font-black text-purple-900 uppercase tracking-wider block">
                  Reversibilidad Estimada:
                </span>
                <span className="text-xs font-black text-purple-950">
                  {selectedSystem.tiempoReversibilidad}
                </span>
              </div>
            </div>
          </div>

          {/* Resumen del Impacto */}
          <div className="p-4 bg-slate-50/90 rounded-2xl border border-slate-200">
            <span className="text-[10px] font-black uppercase tracking-wider text-slate-500 block mb-1">
              Cuadro Clínico General:
            </span>
            <p className="text-xs text-slate-800 font-semibold leading-relaxed">
              {selectedSystem.resumenImpacto}
            </p>
          </div>

          {/* CUERPO PRINCIPAL SEGÚN MODO SELECCIONADO */}
          {viewMode === "paciente" ? (
            /* VISTA PACIENTE: Metáfora + Síntomas visuales */
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              <div className="lg:col-span-6 space-y-4">
                <div className="liquid-glass-purple p-5 rounded-3xl border border-purple-300/80 space-y-2 led-glow-purple">
                  <span className="text-[10px] font-black text-purple-900 uppercase tracking-widest flex items-center gap-1.5">
                    <Sparkles size={14} className="text-purple-700" /> Metáfora para Explicarle al Paciente:
                  </span>
                  <p className="text-xs md:text-sm font-bold text-purple-950 italic leading-relaxed">
                    &quot;{selectedSystem.analogiaParaElPaciente}&quot;
                  </p>
                </div>

                <div className="bg-emerald-50/80 p-4 rounded-2xl border border-emerald-200">
                  <span className="text-[10px] font-black text-emerald-900 uppercase tracking-wider block mb-1 flex items-center gap-1.5">
                    <CheckCircle2 size={13} className="text-emerald-700" /> Mensaje de Recuperación Biológica:
                  </span>
                  <p className="text-xs text-emerald-950 font-semibold leading-relaxed">
                    Este sistema comienza su proceso de sanación activa una vez suspendida la sustancia y con adecuado aporte nutricional. El tiempo estimado de recuperación es de <strong>{selectedSystem.tiempoReversibilidad}</strong>.
                  </p>
                </div>
              </div>

              <div className="lg:col-span-6 space-y-2.5">
                <span className="text-[10px] font-black text-slate-500 uppercase tracking-wider block mb-1">
                  Síntomas y Signos que Usted Puede Estar Sintiendo:
                </span>
                <div className="space-y-2">
                  {selectedSystem.manifestacionesClinicas.map((m, idx) => (
                    <div
                      key={idx}
                      className="p-3 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-800 flex items-start gap-2.5 shadow-2xs"
                    >
                      <span className="w-5 h-5 rounded-full bg-purple-100 text-purple-800 text-[10px] font-black flex items-center justify-center shrink-0 mt-0.5 border border-purple-200">
                        {idx + 1}
                      </span>
                      <span className="leading-snug">{m}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            /* VISTA MÉDICA: Fisiopatología Técnica + Perla Clínica Box + Sustancias de Mayor Riesgo */
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              <div className="lg:col-span-7 space-y-4">
                <div className="bg-slate-900/95 backdrop-blur-md text-white p-5 rounded-3xl space-y-2 border border-slate-700/80 led-glow-purple">
                  <span className="text-[10px] font-black text-purple-300 uppercase tracking-widest block">
                    Mecanismo Fisiopatológico Detallado:
                  </span>
                  <p className="text-xs text-slate-200 font-medium leading-relaxed">
                    {selectedSystem.mecanismoFisiopatologico}
                  </p>
                </div>

                <div className="bg-amber-50/90 p-4 rounded-2xl border border-amber-200">
                  <span className="text-[10px] font-black text-amber-900 uppercase tracking-wider block mb-1 flex items-center gap-1.5">
                    <Lightbulb size={13} className="text-amber-700" /> Perla de Manejo Clínico en Box (Dr. Andrés Felipe Ruiz Miranda — Médico / Programa de Tratamiento en Adicciones):
                  </span>
                  <p className="text-xs text-amber-950 font-bold leading-relaxed">
                    {selectedSystem.perlaClinicaBox}
                  </p>
                </div>
              </div>

              <div className="lg:col-span-5 space-y-4">
                <div>
                  <span className="text-[10px] font-black text-slate-500 uppercase tracking-wider block mb-2">
                    Sustancias con Mayor Toxicidad sobre este Sistema:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {selectedSystem.sustanciasDeMayorRiesgo.map((s, idx) => (
                      <span
                        key={idx}
                        className="px-3 py-1 bg-rose-50 text-rose-800 border border-rose-200 rounded-lg text-xs font-black"
                      >
                        {s}
                      </span>
                    ))}
                  </div>
                </div>

                <div>
                  <span className="text-[10px] font-black text-slate-500 uppercase tracking-wider block mb-2">
                    Signos Clínicos a Monitorear en Ficha:
                  </span>
                  <div className="space-y-1.5">
                    {selectedSystem.manifestacionesClinicas.map((m, idx) => (
                      <div
                        key={idx}
                        className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 flex items-center gap-2"
                      >
                        <AlertCircle size={13} className="text-purple-700 shrink-0" />
                        <span className="line-clamp-1">{m}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
