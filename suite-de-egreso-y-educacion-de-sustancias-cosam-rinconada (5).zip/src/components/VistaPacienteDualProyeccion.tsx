import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Brain,
  Zap,
  Waves,
  Apple,
  ChevronLeft,
  ChevronRight,
  RotateCcw,
  Play,
  Pause,
  HelpCircle,
  Tv,
  Type,
  Sun,
  Moon,
  Crosshair,
  Maximize2,
  Minimize2,
  CheckCircle2,
  ShieldCheck,
  Columns,
  Flame,
  Activity,
  X,
  Radio
} from "lucide-react";
import SimuladorCircuitoRecompensa from "./SimuladorCircuitoRecompensa";

interface VistaPacienteDualProyeccionProps {
  onClose?: () => void;
  isEmbedded?: boolean;
}

export default function VistaPacienteDualProyeccion({
  onClose,
  isEmbedded = false
}: VistaPacienteDualProyeccionProps) {
  // Visual Mode / Active Section
  const [activeTab, setActiveTab] = useState<"circuito" | "diapositivas" | "surf_timer" | "faqs">("circuito");
  const [currentSlide, setCurrentSlide] = useState<number>(0);

  // Styling & Projection Accessibility
  const [theme, setTheme] = useState<"dark" | "light">("dark");
  const [textScale, setTextScale] = useState<"normal" | "large" | "huge">("large");
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [isLaserActive, setIsLaserActive] = useState<boolean>(false);
  const [laserPos, setLaserPos] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isConnectedToDoctor, setIsConnectedToDoctor] = useState<boolean>(false);
  const [lastSyncAction, setLastSyncAction] = useState<string>("");

  // Urge Surfing Timer (15 min)
  const [timerSeconds, setTimerSeconds] = useState<number>(15 * 60);
  const [isTimerRunning, setIsTimerRunning] = useState<boolean>(false);
  const [timerPhase, setTimerPhase] = useState<"inicio" | "pico" | "descenso" | "calma">("inicio");

  const containerRef = useRef<HTMLDivElement>(null);

  // Timer Tick
  useEffect(() => {
    let interval: any = null;
    if (isTimerRunning && timerSeconds > 0) {
      interval = setInterval(() => {
        setTimerSeconds((prev) => {
          const next = prev - 1;
          if (next > 12 * 60) setTimerPhase("inicio");
          else if (next > 7 * 60) setTimerPhase("pico");
          else if (next > 2 * 60) setTimerPhase("descenso");
          else setTimerPhase("calma");
          return next;
        });
      }, 1000);
    } else if (timerSeconds === 0) {
      setIsTimerRunning(false);
      setTimerPhase("calma");
    }
    return () => clearInterval(interval);
  }, [isTimerRunning, timerSeconds]);

  // Real-time synchronization with Doctor screen via BroadcastChannel & localStorage
  useEffect(() => {
    let channel: BroadcastChannel | null = null;
    try {
      if (typeof window !== "undefined" && "BroadcastChannel" in window) {
        channel = new BroadcastChannel("cosam_dual_sync");
        channel.onmessage = (event) => {
          const data = event.data;
          if (!data || !data.type) return;

          setIsConnectedToDoctor(true);

          if (data.type === "PING_DOCTOR") {
            // Respond back so doctor knows dual window is alive
            channel?.postMessage({ type: "PONG_PATIENT", timestamp: Date.now() });
          } else if (data.type === "SET_TAB") {
            if (data.tab) {
              setActiveTab(data.tab);
              setLastSyncAction(`Sección: ${data.tab}`);
            }
          } else if (data.type === "SET_SLIDE") {
            if (typeof data.slideIndex === "number") {
              setCurrentSlide(data.slideIndex);
              setActiveTab("diapositivas");
              setLastSyncAction(`Diapositiva ${data.slideIndex + 1}`);
            }
          } else if (data.type === "TIMER_ACTION") {
            if (data.action === "start") {
              setIsTimerRunning(true);
              setActiveTab("surf_timer");
            } else if (data.action === "pause") {
              setIsTimerRunning(false);
            } else if (data.action === "reset") {
              setIsTimerRunning(false);
              setTimerSeconds(15 * 60);
              setTimerPhase("inicio");
            } else if (data.action === "set" && typeof data.seconds === "number") {
              setTimerSeconds(data.seconds);
            }
            setLastSyncAction(`Temporizador: ${data.action}`);
          } else if (data.type === "SET_THEME") {
            if (data.theme) setTheme(data.theme);
          } else if (data.type === "SET_TEXT_SCALE") {
            if (data.scale) setTextScale(data.scale);
          } else if (data.type === "LASER_MOVE") {
            setIsLaserActive(Boolean(data.active));
            if (typeof data.x === "number" && typeof data.y === "number") {
              setLaserPos({ x: data.x, y: data.y });
            }
          }
        };

        // Announce presence to doctor window
        channel.postMessage({ type: "PONG_PATIENT", timestamp: Date.now() });
      }
    } catch {
      // Fallback handles gracefully
    }

    // Secondary fallback using localStorage storage event
    const handleStorage = (e: StorageEvent) => {
      if (e.key === "cosam_dual_sync_payload" && e.newValue) {
        try {
          const payload = JSON.parse(e.newValue);
          setIsConnectedToDoctor(true);
          if (payload.tab) setActiveTab(payload.tab);
          if (typeof payload.slideIndex === "number") setCurrentSlide(payload.slideIndex);
          if (payload.theme) setTheme(payload.theme);
          if (payload.textScale) setTextScale(payload.textScale);
          if (payload.timerAction) {
            if (payload.timerAction === "start") setIsTimerRunning(true);
            if (payload.timerAction === "pause") setIsTimerRunning(false);
            if (payload.timerAction === "reset") {
              setIsTimerRunning(false);
              setTimerSeconds(15 * 60);
            }
          }
        } catch {
          // ignore
        }
      }
    };

    window.addEventListener("storage", handleStorage);

    return () => {
      if (channel) channel.close();
      window.removeEventListener("storage", handleStorage);
    };
  }, []);

  // Format Timer string
  const formatTimer = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
  };

  // Toggle Fullscreen
  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      if (containerRef.current?.requestFullscreen) {
        containerRef.current.requestFullscreen().catch(() => {});
        setIsFullscreen(true);
      }
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen().catch(() => {});
        setIsFullscreen(false);
      }
    }
  };

  // Keyboard navigation for projection remote or patient
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight" || e.key === "PageDown") {
        if (activeTab === "diapositivas") {
          setCurrentSlide((prev) => Math.min(slides.length - 1, prev + 1));
        }
      } else if (e.key === "ArrowLeft" || e.key === "PageUp") {
        if (activeTab === "diapositivas") {
          setCurrentSlide((prev) => Math.max(0, prev - 1));
        }
      } else if (e.key === " " && activeTab === "surf_timer") {
        e.preventDefault();
        setIsTimerRunning((prev) => !prev);
      } else if (e.key === "f" || e.key === "F") {
        toggleFullscreen();
      } else if (e.key === "Escape" && onClose) {
        onClose();
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [activeTab, onClose]);

  // Slides data
  const slides = [
    {
      title: "1. ¿Qué es una Adicción? No es falta de voluntad",
      badge: "Concepto Fundamental",
      subtitle: "Una condición médica real en los circuitos del cerebro",
      icon: Brain,
      leadText: "La adicción es una enfermedad médica del cerebro, igual que la diabetes lo es del páncreas o el asma de los pulmones.",
      takeaway: "Nadie elige enfermarse. Las sustancias químicas alteran los circuitos de supervivencia y autocontrol. La culpa no ayuda a sanar; el tratamiento médico y psicosocial sí.",
      points: [
        {
          label: "El Mito Antiguo",
          text: "«Si tuviera fuerza de voluntad, pararía cuando quisiera. Es un vicio o falta de carácter».",
          status: "FALSO / ESTIGMA",
          color: "rose"
        },
        {
          label: "La Evidencia Médica",
          text: "El freno biológico frontal está temporalmente apagado por el tóxico. Con tratamiento se recupera.",
          status: "CIENCIA COSAM",
          color: "emerald"
        }
      ]
    },
    {
      title: "2. El Acelerador y el Freno del Cerebro",
      badge: "Neurobiología Simple",
      subtitle: "Por qué la mente quiere parar pero el cuerpo siente un impulso incontrolable",
      icon: Zap,
      leadText: "El cerebro tiene dos partes en conflicto: un Acelerador primitivo de supervivencia y un Freno consciente de decisiones.",
      takeaway: "La sustancia pisa el acelerador con 10 veces más dopamina que la comida, desgastando el freno. El objetivo en COSAM es reparar ese freno biológico.",
      points: [
        {
          label: "El Acelerador (Núcleo Accumbens)",
          text: "Centro del impulso urgente. Cree falsamente que consumir es tan vital como respirar o comer.",
          status: "DOPAMINA ALTA",
          color: "amber"
        },
        {
          label: "El Freno (Corteza Prefrontal)",
          text: "Piensa en el futuro, hijos, salud y trabajo. Se desgasta con el consumo crónico pero vuelve a formarse.",
          status: "AUTOCONTROL",
          color: "blue"
        }
      ]
    },
    {
      title: "3. Surfear la Ola del Craving (15 Minutos)",
      badge: "Herramienta Práctica",
      subtitle: "El deseo intenso no dura para siempre: sube, alcanza un pico y baja por sí solo",
      icon: Waves,
      leadText: "El craving no es una pared fija infinita: tiene forma de ola en el mar y su pico fisiológico dura entre 15 y 20 minutos.",
      takeaway: "Si no alimentas el pensamiento y te concentras en respirar y mover el cuerpo, la dopamina baja espontáneamente sin necesidad de consumir.",
      points: [
        {
          label: "1. Reconocer la Ola",
          text: "«Esto es solo un impulso químico temporal, no es una orden real de mi cuerpo».",
          status: "PAUSA COGNITIVA",
          color: "teal"
        },
        {
          label: "2. Respiración Vagal 4-2-6",
          text: "Inhalar en 4s, retener 2s, botar el aire lento en 6s. Envía una señal de calma al corazón.",
          status: "FRENO FÍSICO",
          color: "emerald"
        }
      ]
    },
    {
      title: "4. La Trampa de la Anhedonia (Cerebro en Mantención)",
      badge: "Paciencia Biológica",
      subtitle: "Por qué al principio nada produce alegría y cómo se revierte",
      icon: Flame,
      leadText: "Ante las inundaciones químicas repetidas, las neuronas esconden sus antenas (receptores D2) para no quemarse.",
      takeaway: "Al dejar la sustancia, las cosas normales de la vida se sienten planas. No es que tu vida sea triste: tus sensores están en mantención y volverán a funcionar.",
      points: [
        {
          label: "Las Primeras Semanas",
          text: "Los receptores están 'adormecidos'. Se siente vacío o desgana, es un síntoma biológico normal.",
          status: "ETAPA DE ADAPTACIÓN",
          color: "amber"
        },
        {
          label: "A Partir del Día 90",
          text: "Comienzan a brotar nuevos receptores D2. El café, la risa de un hijo y la comida vuelven a dar placer.",
          status: "RECUPERACIÓN REAL",
          color: "emerald"
        }
      ]
    },
    {
      title: "5. Neuroplasticidad & BDNF: El Cerebro Sí Sana",
      badge: "Esperanza Basada en Evidencia",
      subtitle: "Cómo el tratamiento, el deporte y la comida sana fertilizan nuevas neuronas",
      icon: Apple,
      leadText: "El cerebro no es una piedra fija; es como un músculo plástico que puede crear nuevos caminos saludables.",
      takeaway: "Cada día sin consumir y cada caminata rápida libera BDNF (fertilizante cerebral), ayudando a reconectar el lóbulo frontal.",
      points: [
        {
          label: "El Fertilizante Natural (BDNF)",
          text: "Se activa caminando 30 minutos al día, durmiendo bien y tomando agua limpia.",
          status: "GIMNASIA CEREBRAL",
          color: "emerald"
        },
        {
          label: "El Apoyo del COSAM",
          text: "Psicoterapia, pautas médicas y talleres grupales aceleran la reconstrucción de tu vida.",
          status: "RED DE APOYO",
          color: "purple"
        }
      ]
    }
  ];

  // FAQs data
  const faqs = [
    {
      q: "¿Por qué siento que nada me da alegría ni me motiva al principio?",
      a: "Es absolutamente normal en las primeras semanas. Al retirar el tóxico, los receptores de dopamina quedaron temporalmente dormidos. No significa que tu vida sea triste: tus sensores están en mantención biológica. Con las semanas volverás a sentir alegría natural."
    },
    {
      q: "¿Cómo actúa el Disulfiram (Antabuse) y qué precauciones debo tener?",
      a: "El Disulfiram actúa como un escudo biológico protector. Bloquea la descomposición del alcohol en el hígado para que el impulso de beber no se concrete. No daña tu salud mientras no consumas alcohol en bebidas, comidas con vinagre, enjuagues bucales o repostería."
    },
    {
      q: "¿Qué diferencia hay entre una 'caída' puntual y una 'recaída'?",
      a: "Una caída es un consumo aislado de una sola ocasión. Si te detienes inmediatamente y vuelves a tu control en COSAM, no se pierde lo avanzado: aprendemos del error y seguimos adelante. Una recaída es volver al patrón antiguo abandonando el tratamiento. ¡Nunca dejes de venir si tuviste una caída!"
    },
    {
      q: "¿Cómo puede mi familia o pareja ayudarme mejor en este proceso?",
      a: "Con comprensión afectiva y límites saludables: acompañándote a tomar la medicación con cariño, manteniendo el hogar libre de alcohol o sustancias, y valorando cada día limpio en lugar de reprochar momentos del pasado."
    }
  ];

  // Font scale helper
  const getScaleClasses = () => {
    if (textScale === "huge") {
      return {
        title: "text-3xl md:text-5xl font-black",
        subtitle: "text-xl md:text-2xl font-semibold",
        lead: "text-2xl md:text-3xl font-black leading-relaxed",
        body: "text-lg md:text-xl font-medium leading-relaxed",
        badge: "text-sm font-black px-4 py-1.5"
      };
    }
    if (textScale === "large") {
      return {
        title: "text-2xl md:text-4xl font-black",
        subtitle: "text-lg md:text-xl font-semibold",
        lead: "text-xl md:text-2xl font-black leading-relaxed",
        body: "text-base md:text-lg font-medium leading-relaxed",
        badge: "text-xs font-black px-3.5 py-1"
      };
    }
    return {
      title: "text-xl md:text-3xl font-black",
      subtitle: "text-base md:text-lg font-semibold",
      lead: "text-lg md:text-xl font-bold leading-normal",
      body: "text-sm md:text-base font-medium leading-normal",
      badge: "text-xs font-bold px-3 py-0.5"
    };
  };

  const scale = getScaleClasses();
  const isDark = theme === "dark";

  return (
    <div
      ref={containerRef}
      id="vista-paciente-dual-container"
      className={`min-h-screen w-full transition-colors duration-300 select-none antialiased flex flex-col justify-between ${
        isDark ? "bg-[#04060f] text-slate-100" : "bg-white text-slate-900"
      } ${isEmbedded ? "p-4" : "p-4 md:p-8"}`}
    >
      {/* PUNTERO LÁSER VIRTUAL SINCRONIZADO */}
      {isLaserActive && (
        <div
          className="fixed pointer-events-none z-50 w-7 h-7 rounded-full bg-rose-500/90 blur-2xs border-2 border-white shadow-[0_0_25px_#f43f5e] -translate-x-1/2 -translate-y-1/2 transition-transform duration-75"
          style={{ left: `${laserPos.x}px`, top: `${laserPos.y}px` }}
        />
      )}

      {/* =========================================================================
          BARRA SUPERIOR LIMPIA DE PROYECCIÓN (ALTA LEGIBILIDAD, SIN DATOS MÉDICOS)
         ========================================================================= */}
      <header
        className={`sticky top-0 z-40 rounded-2xl p-3 md:p-4 mb-6 border shadow-2xl flex flex-wrap items-center justify-between gap-4 backdrop-blur-md transition-all ${
          isDark
            ? "bg-slate-900/95 border-slate-800/80 text-white"
            : "bg-slate-100/95 border-slate-300 text-slate-900"
        }`}
      >
        {/* Identificador Limpio */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-600 via-indigo-600 to-teal-500 flex items-center justify-center text-white shadow-lg shrink-0">
            <Tv size={20} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-black uppercase tracking-widest px-2 py-0.5 rounded bg-purple-600/30 text-purple-300 border border-purple-500/40">
                Pantalla Paciente • Proyección Box
              </span>
              {isConnectedToDoctor && (
                <span className="text-[10px] font-bold text-emerald-400 flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                  Sincronizado con Box Médico
                </span>
              )}
            </div>
            <h1 className="text-sm md:text-base font-black tracking-tight leading-tight">
              Espacio de Diálogo &amp; Psicoeducación Médica
            </h1>
          </div>
        </div>

        {/* Selector de Contenidos para el Paciente */}
        <div
          className={`flex items-center p-1 rounded-xl border gap-1 flex-wrap ${
            isDark ? "bg-black/50 border-white/10" : "bg-white border-slate-300"
          }`}
        >
          <button
            onClick={() => setActiveTab("circuito")}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === "circuito"
                ? "bg-purple-600 text-white shadow-md ring-1 ring-white/20"
                : isDark
                ? "text-slate-300 hover:text-white"
                : "text-slate-700 hover:text-slate-950"
            }`}
          >
            <Brain size={14} />
            <span>Circuito Cerebral</span>
          </button>

          <button
            onClick={() => setActiveTab("diapositivas")}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === "diapositivas"
                ? "bg-indigo-600 text-white shadow-md ring-1 ring-white/20"
                : isDark
                ? "text-slate-300 hover:text-white"
                : "text-slate-700 hover:text-slate-950"
            }`}
          >
            <Columns size={14} />
            <span>Diapositivas ({currentSlide + 1}/5)</span>
          </button>

          <button
            onClick={() => setActiveTab("surf_timer")}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === "surf_timer"
                ? "bg-teal-600 text-white shadow-md ring-1 ring-white/20"
                : isDark
                ? "text-slate-300 hover:text-white"
                : "text-slate-700 hover:text-slate-950"
            }`}
          >
            <Waves size={14} />
            <span>Surfeo Craving (15 min)</span>
          </button>

          <button
            onClick={() => setActiveTab("faqs")}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === "faqs"
                ? "bg-emerald-600 text-white shadow-md ring-1 ring-white/20"
                : isDark
                ? "text-slate-300 hover:text-white"
                : "text-slate-700 hover:text-slate-950"
            }`}
          >
            <HelpCircle size={14} />
            <span>Dudas Frecuentes</span>
          </button>
        </div>

        {/* Herramientas de Accesibilidad para Proyección */}
        <div
          className={`flex items-center gap-1.5 p-1 rounded-xl border ${
            isDark ? "bg-black/50 border-white/10" : "bg-white border-slate-300"
          }`}
        >
          {/* Alternar Tema */}
          <button
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            className="p-2 rounded-lg text-slate-300 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            title={isDark ? "Cambiar a Fondo Claro de Alto Contraste" : "Cambiar a Fondo Oscuro Proyector"}
          >
            {isDark ? <Sun size={16} className="text-amber-400" /> : <Moon size={16} className="text-indigo-600" />}
          </button>

          {/* Tamaño de Letra para Proyector en Pared */}
          <button
            onClick={() => {
              if (textScale === "normal") setTextScale("large");
              else if (textScale === "large") setTextScale("huge");
              else setTextScale("normal");
            }}
            className="px-2.5 py-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-white/10 transition-colors text-xs font-black cursor-pointer flex items-center gap-1"
            title="Ajustar tamaño de letra para proyección"
          >
            <Type size={14} />
            <span className="font-mono">{textScale === "huge" ? "A++" : textScale === "large" ? "A+" : "A"}</span>
          </button>

          {/* Pantalla Completa */}
          <button
            onClick={toggleFullscreen}
            className="p-2 rounded-lg text-slate-300 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            title={isFullscreen ? "Salir de Pantalla Completa (F)" : "Pantalla Completa (F)"}
          >
            {isFullscreen ? <Minimize2 size={16} /> : <Maximize2 size={16} />}
          </button>

          {/* Botón Cerrar si fue abierto como modal o ventana */}
          {onClose && (
            <button
              onClick={onClose}
              className="p-2 rounded-lg bg-rose-600/80 hover:bg-rose-600 text-white transition-colors cursor-pointer"
              title="Cerrar vista de proyección (Esc)"
            >
              <X size={16} />
            </button>
          )}
        </div>
      </header>

      {/* =========================================================================
          CONTENIDO 1: CIRCUITO DE RECOMPENSA NEUROBIOLÓGICO
         ========================================================================= */}
      {activeTab === "circuito" && (
        <main className="flex-1 space-y-6">
          <div
            className={`p-6 rounded-3xl border shadow-2xl ${
              isDark ? "bg-slate-900/80 border-slate-800" : "bg-slate-50 border-slate-300"
            }`}
          >
            <div className="mb-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-3 border-b pb-4 border-white/10">
              <div>
                <span className="text-xs font-black uppercase tracking-widest text-purple-400">
                  Visualización Anatómica &amp; Dinámica
                </span>
                <h2 className={scale.title}>
                  El Circuito de Recompensa: Cómo se Recupera el Cerebro
                </h2>
                <p className={`${scale.subtitle} text-slate-400`}>
                  Observa en vivo el acelerador dopaminérgico (Accumbens) y el freno consciente (Corteza Prefrontal).
                </p>
              </div>

              <div className="flex items-center gap-2">
                <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-bold flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  Visualización Limpia para Paciente
                </span>
              </div>
            </div>

            <div className="p-1 sm:p-3">
              <SimuladorCircuitoRecompensa />
            </div>
          </div>
        </main>
      )}

      {/* =========================================================================
          CONTENIDO 2: DIAPOSITIVAS PSICOEDUCATIVAS DE ALTO IMPACTO
         ========================================================================= */}
      {activeTab === "diapositivas" && (
        <main className="flex-1 space-y-6">
          {/* Navegador de Diapositivas */}
          <div
            className={`flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 p-4 rounded-3xl border shadow-xl ${
              isDark ? "bg-slate-900/80 border-slate-800" : "bg-slate-50 border-slate-300"
            }`}
          >
            <div className="flex items-center gap-3">
              <span className="text-xs font-black uppercase tracking-wider text-purple-400">
                Diapositiva {currentSlide + 1} de {slides.length}:
              </span>
              <span className={`rounded-xl bg-purple-600 text-white ${scale.badge}`}>
                {slides[currentSlide].badge}
              </span>
            </div>

            <div className="flex items-center gap-3 w-full sm:w-auto justify-between sm:justify-end">
              <button
                onClick={() => setCurrentSlide((prev) => Math.max(0, prev - 1))}
                disabled={currentSlide === 0}
                className="px-5 py-2.5 rounded-2xl border text-xs font-black uppercase tracking-wider flex items-center gap-1.5 transition-all disabled:opacity-30 disabled:cursor-not-allowed bg-slate-800 text-white hover:bg-slate-700 cursor-pointer"
              >
                <ChevronLeft size={18} /> Anterior
              </button>

              <div className="flex gap-2">
                {slides.map((s, idx) => (
                  <button
                    key={idx}
                    onClick={() => setCurrentSlide(idx)}
                    title={s.title}
                    className={`h-3 rounded-full transition-all cursor-pointer ${
                      currentSlide === idx ? "w-12 bg-purple-500 shadow-md" : "w-3 bg-slate-700 hover:bg-purple-400"
                    }`}
                  />
                ))}
              </div>

              <button
                onClick={() => setCurrentSlide((prev) => Math.min(slides.length - 1, prev + 1))}
                disabled={currentSlide === slides.length - 1}
                className="px-6 py-2.5 rounded-2xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-black uppercase tracking-wider flex items-center gap-1.5 shadow-lg disabled:opacity-30 disabled:cursor-not-allowed transition-all cursor-pointer"
              >
                Siguiente <ChevronRight size={18} />
              </button>
            </div>
          </div>

          {/* Lienzo de la Diapositiva */}
          <AnimatePresence mode="wait">
            <motion.div
              key={currentSlide}
              initial={{ opacity: 0, scale: 0.98, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.98, y: -15 }}
              transition={{ duration: 0.2 }}
              className={`rounded-3xl p-6 md:p-12 border shadow-2xl flex flex-col justify-between min-h-[560px] ${
                isDark ? "bg-slate-900/90 border-slate-800" : "bg-white border-slate-300"
              }`}
            >
              <div className="space-y-8">
                {/* Título & Subtítulo */}
                <div className="space-y-3 border-b pb-6 border-white/10">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-black uppercase tracking-widest px-3 py-1 rounded-full bg-purple-600 text-white">
                      {slides[currentSlide].badge}
                    </span>
                    <span className="text-xs font-bold opacity-60">
                      • Concepto Clave
                    </span>
                  </div>

                  <h2 className={scale.title}>
                    {slides[currentSlide].title}
                  </h2>

                  <p className={`${scale.subtitle} text-slate-400`}>
                    {slides[currentSlide].subtitle}
                  </p>
                </div>

                {/* Mensaje Principal en Gran Formato */}
                <div
                  className={`p-8 md:p-10 rounded-3xl border shadow-xl space-y-4 ${
                    isDark
                      ? "bg-purple-950/40 border-purple-700/80 text-purple-100"
                      : "bg-purple-50 border-purple-300 text-purple-950"
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className="w-3.5 h-3.5 rounded-full bg-purple-400 animate-ping" />
                    <span className="text-xs font-black uppercase tracking-widest text-purple-300">
                      Idea Fundamental para Recordar
                    </span>
                  </div>
                  <h3 className={scale.lead}>
                    {slides[currentSlide].leadText}
                  </h3>
                  <p className={`${scale.body} opacity-90`}>
                    {slides[currentSlide].takeaway}
                  </p>
                </div>

                {/* Tarjetas Comparativas */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
                  {slides[currentSlide].points.map((pt, pIdx) => (
                    <div
                      key={pIdx}
                      className={`p-6 rounded-2xl border space-y-3 shadow-lg ${
                        isDark ? "bg-slate-950/80 border-slate-800" : "bg-slate-100 border-slate-200"
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs font-black uppercase tracking-wider text-purple-300">
                          {pt.label}
                        </span>
                        <span
                          className={`text-xs font-black uppercase px-3 py-1 rounded-lg ${
                            pt.color === "emerald"
                              ? "bg-emerald-600 text-white"
                              : pt.color === "rose"
                              ? "bg-rose-600 text-white"
                              : pt.color === "amber"
                              ? "bg-amber-600 text-white"
                              : "bg-indigo-600 text-white"
                          }`}
                        >
                          {pt.status}
                        </span>
                      </div>
                      <p className={scale.body}>
                        {pt.text}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Pie de Diapositiva */}
              <div className="flex items-center justify-between pt-6 mt-8 border-t border-white/10 text-xs font-bold opacity-60">
                <span>Diálogo Clínico Guiado • COSAM Rinconada</span>
                <span>Usa las teclas [←] [→] para avanzar diapositivas</span>
              </div>
            </motion.div>
          </AnimatePresence>
        </main>
      )}

      {/* =========================================================================
          CONTENIDO 3: TEMPORIZADOR DE SURFEO DE CRAVING (URGE SURFING 15 MIN)
         ========================================================================= */}
      {activeTab === "surf_timer" && (
        <main className="flex-1 space-y-8">
          <div
            className={`rounded-3xl p-8 md:p-14 border shadow-2xl space-y-10 ${
              isDark ? "bg-slate-900/90 border-slate-800" : "bg-white border-slate-300"
            }`}
          >
            <div className="text-center max-w-3xl mx-auto space-y-4">
              <span className="text-xs font-black uppercase tracking-widest bg-teal-600 text-white px-4 py-1.5 rounded-full shadow-md">
                Práctica Terapéutica en Vivo
              </span>
              <h2 className={scale.title}>
                Surfear la Ola del Deseo (Urge Surfing)
              </h2>
              <p className={`${scale.subtitle} text-slate-400`}>
                El craving no es permanente: tiene forma de ola y su pico fisiológico dura entre 15 y 20 minutos. Respira lento y acompáñanos a dejarla pasar.
              </p>
            </div>

            {/* Círculo Cronómetro Gigante */}
            <div
              className={`flex flex-col items-center justify-center p-10 md:p-16 rounded-3xl border space-y-8 ${
                isDark ? "bg-black/80 border-slate-800" : "bg-teal-50 border-teal-200"
              }`}
            >
              <div
                className={`relative w-80 h-80 md:w-96 md:h-96 rounded-full flex flex-col items-center justify-center space-y-4 shadow-2xl border-8 transition-colors ${
                  timerPhase === "pico"
                    ? "border-rose-500 bg-rose-950/20 shadow-rose-900/40 animate-pulse"
                    : timerPhase === "descenso"
                    ? "border-teal-400 bg-teal-950/20 shadow-teal-900/40"
                    : timerPhase === "calma"
                    ? "border-emerald-500 bg-emerald-950/20 shadow-emerald-900/40"
                    : "border-purple-500 bg-purple-950/20 shadow-purple-900/40"
                } ${isDark ? "bg-black" : "bg-white"}`}
              >
                <span className="text-7xl md:text-9xl font-black font-mono tracking-tight text-white">
                  {formatTimer(timerSeconds)}
                </span>

                <span
                  className={`text-xs md:text-sm font-black uppercase tracking-widest px-6 py-2 rounded-full ${
                    timerPhase === "inicio"
                      ? "bg-amber-500 text-white"
                      : timerPhase === "pico"
                      ? "bg-rose-600 text-white animate-pulse"
                      : timerPhase === "descenso"
                      ? "bg-teal-600 text-white"
                      : "bg-emerald-600 text-white"
                  }`}
                >
                  Fase: {timerPhase.toUpperCase()}
                </span>
              </div>

              {/* Mensajes de Respiración y Reaseguro */}
              <div className="text-center max-w-2xl space-y-3">
                <h3 className={scale.lead}>
                  {timerPhase === "inicio" && "Inhala profundo y reconoce el cuerpo: la urgencia es solo una corriente química pasajera."}
                  {timerPhase === "pico" && "Estamos en el punto más alto de la ola. Respira lento: tu cuerpo no corre peligro y la ola va a caer."}
                  {timerPhase === "descenso" && "La ola ya comenzó a bajar espontáneamente. Siente tus pies firmes sobre el suelo."}
                  {timerPhase === "calma" && "¡Impulso superado! Cada minuto que aguantas es una nueva conexión de freno en tu cerebro."}
                </h3>
                <p className={`${scale.body} text-teal-400 font-bold`}>
                  Pauta respiratoria 4-2-6: Inhala por la nariz (4s) • Pausa suave (2s) • Exhala largo por la boca (6s).
                </p>
              </div>

              {/* Controles del Cronómetro */}
              <div className="flex items-center gap-4">
                <button
                  onClick={() => setIsTimerRunning(!isTimerRunning)}
                  className={`px-10 py-4 rounded-2xl text-sm font-black uppercase tracking-wider transition-all flex items-center gap-2.5 shadow-xl cursor-pointer active:scale-95 ${
                    isTimerRunning ? "bg-amber-600 hover:bg-amber-700 text-white" : "bg-teal-600 hover:bg-teal-700 text-white"
                  }`}
                >
                  {isTimerRunning ? <Pause size={20} /> : <Play size={20} />}
                  <span>{isTimerRunning ? "Pausar" : "Comenzar Surfeo (15 Min)"}</span>
                </button>

                <button
                  onClick={() => {
                    setIsTimerRunning(false);
                    setTimerSeconds(15 * 60);
                    setTimerPhase("inicio");
                  }}
                  className="px-6 py-4 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white text-sm font-black uppercase tracking-wider transition-all flex items-center gap-2 cursor-pointer"
                >
                  <RotateCcw size={18} />
                  <span>Reiniciar</span>
                </button>
              </div>
            </div>
          </div>
        </main>
      )}

      {/* =========================================================================
          CONTENIDO 4: PREGUNTAS FRECUENTES DEL TRATAMIENTO (EN FOCO PACIENTE)
         ========================================================================= */}
      {activeTab === "faqs" && (
        <main className="flex-1 space-y-6">
          <div
            className={`rounded-3xl p-6 md:p-10 border shadow-2xl space-y-6 ${
              isDark ? "bg-slate-900/90 border-slate-800" : "bg-white border-slate-300"
            }`}
          >
            <div className="border-b pb-4 border-white/10">
              <span className="text-xs font-black uppercase tracking-widest text-emerald-400">
                Información Médica Comprensible
              </span>
              <h2 className={scale.title}>
                Preguntas Habituales en la Consulta Médica
              </h2>
              <p className={`${scale.subtitle} text-slate-400`}>
                Respuestas médicas claras para disipar miedos y avanzar con seguridad en tu proceso.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {faqs.map((faq, idx) => (
                <div
                  key={idx}
                  className={`p-6 rounded-3xl border shadow-xl space-y-4 flex flex-col justify-between ${
                    isDark ? "bg-slate-950/80 border-slate-800" : "bg-slate-50 border-slate-200"
                  }`}
                >
                  <div className="space-y-3">
                    <div className="flex items-center gap-2.5">
                      <span className="w-7 h-7 rounded-full bg-emerald-600 text-white text-xs font-black flex items-center justify-center shrink-0">
                        {idx + 1}
                      </span>
                      <h3 className="text-base md:text-lg font-black leading-snug">
                        {faq.q}
                      </h3>
                    </div>
                    <p className={`${scale.body} leading-relaxed opacity-90 pl-9`}>
                      {faq.a}
                    </p>
                  </div>

                  <div className="pt-3 border-t border-white/10 flex items-center gap-2 text-xs font-bold text-emerald-400 pl-9">
                    <ShieldCheck size={16} />
                    <span>Equipo Médico &amp; Psicosocial COSAM Rinconada</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </main>
      )}

      {/* Pie de pantalla discreto */}
      <footer className="mt-8 pt-4 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between text-xs font-semibold opacity-60 gap-2">
        <div className="flex items-center gap-2">
          <span>COSAM Rinconada de San Ramón • SSM Sur Oriente</span>
          {lastSyncAction && (
            <span className="text-purple-400">• Última acción: {lastSyncAction}</span>
          )}
        </div>
        <span>Material Clínico Exclusivo para Pacientes &amp; Familias</span>
      </footer>
    </div>
  );
}
