import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Stethoscope,
  ArrowRight,
  Brain,
  Phone,
  Search,
  MapPin,
  Mail,
  ChevronDown,
  Lock,
  Copy,
  Check,
  ExternalLink,
  Pencil,
  RotateCcw
} from "lucide-react";

interface ClinicalGatewayProps {
  onSelectMode: (mode: "clinico" | "psicoeducacion") => void;
  onLockBox?: () => void;
}

export default function ClinicalGateway({ onSelectMode, onLockBox }: ClinicalGatewayProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [emailSearchTerm, setEmailSearchTerm] = useState("");
  const [selectedEmailCategory, setSelectedEmailCategory] = useState<string>("todos");
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [isDirectorioOpen, setIsDirectorioOpen] = useState(false);
  const [isEmailDirectorioOpen, setIsEmailDirectorioOpen] = useState(false);

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const DEFAULT_EMAIL_CONTACTS = [
    {
      id: "mail_sm_labandera",
      name: "Equipo de Salud Mental - CESFAM La Bandera",
      category: "cesfam",
      categoryLabel: "CESFAMs San Ramón",
      email: "saludmental.labandera@sanramon.cl",
      unit: "CESFAM La Bandera",
      desc: "Coordinación de ingresos, contrarreferencia APS y seguimiento de casos compartidos con COSAM."
    },
    {
      id: "mail_sm_gabrielamistral",
      name: "Equipo de Salud Mental - CESFAM Gabriela Mistral",
      category: "cesfam",
      categoryLabel: "CESFAMs San Ramón",
      email: "saludmental.gabrielamistral@sanramon.cl",
      unit: "CESFAM Gabriela Mistral",
      desc: "Enlace clínico APS-COSAM, psicólogos, médicos de sector y coordinación de casos territoriales."
    },
    {
      id: "mail_sm_salvadorallende",
      name: "Equipo de Salud Mental - CESFAM Salvador Allende",
      category: "cesfam",
      categoryLabel: "CESFAMs San Ramón",
      email: "saludmental.salvadorallende@sanramon.cl",
      unit: "CESFAM Salvador Allende",
      desc: "Seguimiento conjunto de pacientes crónicos, reuniones de sector y apoyo clínico directo."
    },
    {
      id: "mail_adicciones_rinconada",
      name: "Referente Tratamiento Adicciones - COSAM Rinconada",
      category: "adicciones",
      categoryLabel: "Tratamiento Adicciones",
      email: "adicciones.rinconada@sanramon.cl",
      unit: "COSAM Rinconada",
      desc: "Programa de alcohol y drogas, ingresos PAI adicciones ambulatorio intensivo y planes individuales."
    },
    {
      id: "mail_adicciones_labandera",
      name: "Referente Tratamiento Adicciones - CESFAM La Bandera",
      category: "adicciones",
      categoryLabel: "Tratamiento Adicciones",
      email: "adicciones.labandera@sanramon.cl",
      unit: "CESFAM La Bandera",
      desc: "Detección temprana y pesquisa, programa de adicciones en APS y articulación territorial con COSAM."
    },
    {
      id: "mail_some_cosam",
      name: "SOME Central COSAM Rinconada",
      category: "cosam_directiva",
      categoryLabel: "COSAM & Dirección",
      email: "some.cosam@sanramon.cl",
      unit: "SOME COSAM Rinconada",
      desc: "Gestión de agenda médica de box, citación y rescate de pacientes, confirmación de horas y SOME."
    },
    {
      id: "mail_directora_cosam",
      name: "Directora COSAM Rinconada",
      category: "cosam_directiva",
      categoryLabel: "COSAM & Dirección",
      email: "direccion.cosam@sanramon.cl",
      unit: "Dirección Técnica COSAM",
      desc: "Jefatura técnica y clínica, convenios asistenciales, resoluciones administrativas y directivas."
    }
  ];

  const [emailContacts, setEmailContacts] = useState(() => {
    try {
      const saved = localStorage.getItem("cosam_directory_emails");
      if (saved) return JSON.parse(saved);
    } catch {}
    return DEFAULT_EMAIL_CONTACTS;
  });

  const [editingEmailId, setEditingEmailId] = useState<string | null>(null);
  const [editedEmailValue, setEditedEmailValue] = useState<string>("");

  const handleStartEditEmail = (item: { id: string; email: string }) => {
    setEditingEmailId(item.id);
    setEditedEmailValue(item.email);
  };

  const handleSaveEditedEmail = (id: string) => {
    const updated = emailContacts.map((c: any) =>
      c.id === id ? { ...c, email: editedEmailValue.trim() || c.email } : c
    );
    setEmailContacts(updated);
    try {
      localStorage.setItem("cosam_directory_emails", JSON.stringify(updated));
    } catch {}
    setEditingEmailId(null);
  };

  const handleResetEmails = () => {
    setEmailContacts(DEFAULT_EMAIL_CONTACTS);
    try {
      localStorage.removeItem("cosam_directory_emails");
    } catch {}
    setEditingEmailId(null);
  };

  const filteredEmails = emailContacts.filter((item) => {
    const matchesCategory =
      selectedEmailCategory === "todos" || item.category === selectedEmailCategory;
    const matchesSearch =
      item.name.toLowerCase().includes(emailSearchTerm.toLowerCase()) ||
      item.email.toLowerCase().includes(emailSearchTerm.toLowerCase()) ||
      item.unit.toLowerCase().includes(emailSearchTerm.toLowerCase()) ||
      item.desc.toLowerCase().includes(emailSearchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const contacts = [
    {
      id: "cosam_rinc",
      name: "COSAM Rinconada de San Ramón",
      type: "Salud Mental Secundaria",
      address: "Av. Rinconada 8460, San Ramón",
      phone: "+56 2 2555 9811",
      email: "cosam.rinconada@sanramon.cl",
      desc: "Centro de derivación especializada para patología psiquiátrica moderada-severa y adicciones complejas."
    },
    {
      id: "cesfam_sr",
      name: "CESFAM San Ramón",
      type: "Atención Primaria (APS)",
      address: "Almirante Latorre 987, San Ramón",
      phone: "+56 2 2555 4321",
      email: "cesfam.sanramon@saludsr.cl",
      desc: "Unidad APS. Pesquisa, aplicación de tamizaje (AUDIT/DAST) y derivación vía interconsulta digital."
    },
    {
      id: "cesfam_bandera",
      name: "CESFAM La Bandera",
      type: "Atención Primaria (APS)",
      address: "Santa Rosa Paradero 25, San Ramón",
      phone: "+56 2 2555 7766",
      email: "cesfam.labandera@saludsr.cl",
      desc: "Centro de salud familiar con equipo de salud mental integrado y derivaciones directas a COSAM."
    },
    {
      id: "hosp_padre_h",
      name: "Servicio de Urgencia Hospital Padre Hurtado",
      type: "Urgencia 24/7",
      address: "Av. Esperanza 2150, San Ramón",
      phone: "+56 2 2508 2000",
      email: "urgencia.hph@redsalud.gov.cl",
      desc: "Referencia para crisis agudas, intoxicaciones, riesgo vital y síndrome de abstinencia severo."
    },
    {
      id: "hosp_dia",
      name: "Hospital de Día Rinconada",
      type: "Soporte Diurno",
      address: "Av. Rinconada 8480, San Ramón",
      phone: "+56 2 2555 9815",
      email: "hospitaldia.rinconada@sanramon.cl",
      desc: "Hospitalización parcial para estabilización intensiva con mantención del vínculo comunitario."
    }
  ];

  const filteredContacts = contacts.filter(c =>
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.desc.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen flex flex-col justify-between py-8 px-4 sm:px-8 bg-slate-50 dark:bg-slate-950 font-sans text-slate-900 dark:text-slate-100 transition-colors">
      
      {/* Encabezado Superior Limpio y Sobrio */}
      <header className="max-w-5xl mx-auto w-full flex items-center justify-between gap-4 pb-6 border-b border-slate-200/80 dark:border-slate-800/80">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 flex items-center justify-center font-bold text-xs tracking-tight shadow-xs">
            CR
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-semibold text-slate-900 dark:text-white tracking-tight">
                COSAM Rinconada
              </span>
              <span className="text-[11px] text-slate-500 dark:text-slate-400">
                · San Ramón
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Consulta Ambulatoria en Salud Mental & Adicciones
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          {onLockBox && (
            <button
              onClick={onLockBox}
              className="px-3 py-1.5 rounded-lg bg-white dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-850 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-800 text-xs font-medium transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
              title="Bloquear pantalla del box"
            >
              <Lock size={13} strokeWidth={1.75} className="text-slate-400" />
              <span>Bloquear Box</span>
            </button>
          )}

          <div className="bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200 px-3 py-1.5 rounded-lg flex items-center gap-2 border border-slate-200 dark:border-slate-800 text-xs font-medium shadow-xs">
            <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block" />
            <span>Dr. Andrés Ruiz</span>
          </div>
        </div>
      </header>

      {/* Selector Central de Modalidad */}
      <main className="max-w-4xl mx-auto w-full my-auto py-10 space-y-8">
        <div className="text-center space-y-1.5 max-w-xl mx-auto">
          <h1 className="text-2xl font-semibold text-slate-900 dark:text-white tracking-tight">
            Selección de Entorno
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
            Selecciona la modalidad de atención para iniciar la sesión en box.
          </p>
        </div>

        {/* Dos tarjetas limpias y serenas */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          
          {/* TARJETA 1: TRABAJO CLÍNICO */}
          <div
            onClick={() => onSelectMode("clinico")}
            className="group relative p-6 sm:p-7 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 shadow-xs hover:shadow-sm transition-all flex flex-col justify-between cursor-pointer"
          >
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white flex items-center justify-center">
                  <Stethoscope size={20} strokeWidth={1.75} />
                </div>
                <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                  Uso Médico
                </span>
              </div>

              <div>
                <h2 className="text-lg font-semibold text-slate-900 dark:text-white tracking-tight group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
                  Atención Médica & Registro
                </h2>
                <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed mt-1.5">
                  Evoluciones SOAP estructuradas, formulación PAI 5Ps, análisis de laboratorio IA, vademécum y derivaciones.
                </p>
              </div>
            </div>

            <div className="pt-6">
              <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-indigo-600 dark:text-indigo-400 group-hover:translate-x-0.5 transition-transform">
                Iniciar consulta médica
                <ArrowRight size={13} strokeWidth={2} />
              </span>
            </div>
          </div>

          {/* TARJETA 2: PSICOEDUCACIÓN */}
          <div
            onClick={() => onSelectMode("psicoeducacion")}
            className="group relative p-6 sm:p-7 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 shadow-xs hover:shadow-sm transition-all flex flex-col justify-between cursor-pointer"
          >
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white flex items-center justify-center">
                  <Brain size={20} strokeWidth={1.75} />
                </div>
                <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                  Proyección Box
                </span>
              </div>

              <div>
                <h2 className="text-lg font-semibold text-slate-900 dark:text-white tracking-tight group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
                  Psicoeducación con Paciente
                </h2>
                <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed mt-1.5">
                  Guías visuales interactivas para consulta: manejo del deseo de consumo, curvas de recuperación y hábitos biológicos.
                </p>
              </div>
            </div>

            <div className="pt-6">
              <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-indigo-600 dark:text-indigo-400 group-hover:translate-x-0.5 transition-transform">
                Abrir proyector en box
                <ArrowRight size={13} strokeWidth={2} />
              </span>
            </div>
          </div>

        </div>

        {/* DIRECTORIO DE RED ASISTENCIAL (DESPLEGABLE LIMPIO) */}
        <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
          <button
            onClick={() => setIsDirectorioOpen(!isDirectorioOpen)}
            className="w-full p-4 sm:p-5 flex items-center justify-between text-left hover:bg-slate-50 dark:hover:bg-slate-850/50 transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <Phone size={16} strokeWidth={1.75} className="text-slate-500" />
              <div>
                <h3 className="text-xs sm:text-sm font-semibold text-slate-900 dark:text-white">
                  Directorio de la Red de Salud San Ramón
                </h3>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  Contactos de CESFAM, Hospital de Urgencia y dispositivos de enlace
                </p>
              </div>
            </div>
            <ChevronDown
              size={16}
              className={`text-slate-400 transition-transform duration-200 ${isDirectorioOpen ? "rotate-180" : ""}`}
            />
          </button>

          <AnimatePresence initial={false}>
            {isDirectorioOpen && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.2 }}
                className="overflow-hidden border-t border-slate-200 dark:border-slate-800 p-4 sm:p-5 space-y-4"
              >
                {/* Buscador */}
                <div className="relative max-w-sm">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                  <input
                    type="text"
                    placeholder="Filtrar centros o dispositivos..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-9 pr-3 py-1.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:border-slate-400 dark:focus:border-slate-500"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {filteredContacts.map((contact) => (
                    <div
                      key={contact.id}
                      className="p-3.5 rounded-xl border border-slate-200/80 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/40 flex flex-col justify-between space-y-2.5"
                    >
                      <div>
                        <div className="flex items-center justify-between gap-2 mb-1">
                          <span className="text-[10px] font-medium text-slate-500 dark:text-slate-400">
                            {contact.type}
                          </span>
                        </div>
                        <h4 className="text-xs font-semibold text-slate-900 dark:text-white">
                          {contact.name}
                        </h4>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 leading-relaxed">
                          {contact.desc}
                        </p>
                      </div>

                      <div className="pt-2 border-t border-slate-200/60 dark:border-slate-800/80 text-[11px] space-y-1">
                        <div className="flex items-center justify-between text-slate-600 dark:text-slate-300">
                          <span className="flex items-center gap-1.5 truncate">
                            <MapPin size={11} className="text-slate-400 shrink-0" />
                            <span className="truncate">{contact.address}</span>
                          </span>
                          <button
                            onClick={() => handleCopy(contact.address, `${contact.id}_addr`)}
                            className="text-[10px] text-slate-500 hover:text-slate-900 dark:hover:text-white shrink-0 ml-2"
                          >
                            {copiedKey === `${contact.id}_addr` ? <Check size={11} className="text-emerald-500" /> : <Copy size={11} />}
                          </button>
                        </div>

                        <div className="flex items-center justify-between text-slate-600 dark:text-slate-300">
                          <span className="flex items-center gap-1.5 truncate">
                            <Phone size={11} className="text-slate-400 shrink-0" />
                            <a href={`tel:${contact.phone.replace(/\s+/g, "")}`} className="hover:underline">
                              {contact.phone}
                            </a>
                          </span>
                          <button
                            onClick={() => handleCopy(contact.phone, `${contact.id}_tel`)}
                            className="text-[10px] text-slate-500 hover:text-slate-900 dark:hover:text-white shrink-0 ml-2"
                          >
                            {copiedKey === `${contact.id}_tel` ? <Check size={11} className="text-emerald-500" /> : <Copy size={11} />}
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}

                  {filteredContacts.length === 0 && (
                    <div className="col-span-full py-4 text-center text-slate-400 text-xs">
                      No se encontraron centros que coincidan con la búsqueda.
                    </div>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* DIRECTORIO DE CORREOS ELECTRÓNICOS RELEVANTES */}
        <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
          <button
            onClick={() => setIsEmailDirectorioOpen(!isEmailDirectorioOpen)}
            className="w-full p-4 sm:p-5 flex items-center justify-between text-left hover:bg-slate-50 dark:hover:bg-slate-850/50 transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <Mail size={16} strokeWidth={1.75} className="text-slate-500" />
              <div>
                <h3 className="text-xs sm:text-sm font-semibold text-slate-900 dark:text-white">
                  Directorio de Correos Electrónicos Relevantes
                </h3>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  Contactos de Interconsultas SIC, Psiquiatría de Enlace HPH, SOME, Farmacia Comunal y GES
                </p>
              </div>
            </div>
            <ChevronDown
              size={16}
              className={`text-slate-400 transition-transform duration-200 ${isEmailDirectorioOpen ? "rotate-180" : ""}`}
            />
          </button>

          <AnimatePresence initial={false}>
            {isEmailDirectorioOpen && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.2 }}
                className="overflow-hidden border-t border-slate-200 dark:border-slate-800 p-4 sm:p-5 space-y-4"
              >
                {/* Controles: Buscador y Categorías */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="relative max-w-sm w-full">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                    <input
                      type="text"
                      placeholder="Filtrar por unidad, correo o servicio..."
                      value={emailSearchTerm}
                      onChange={(e) => setEmailSearchTerm(e.target.value)}
                      className="w-full pl-9 pr-3 py-1.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:border-slate-400 dark:focus:border-slate-500"
                    />
                  </div>

                  {/* Filtro de categorías */}
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {[
                      { id: "todos", label: "Todos" },
                      { id: "cesfam", label: "CESFAMs Salud Mental" },
                      { id: "adicciones", label: "Tratamiento Adicciones" },
                      { id: "cosam_directiva", label: "COSAM & Dirección" }
                    ].map((cat) => (
                      <button
                        key={cat.id}
                        onClick={() => setSelectedEmailCategory(cat.id)}
                        className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition-colors cursor-pointer ${
                          selectedEmailCategory === cat.id
                            ? "bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 shadow-xs"
                            : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
                        }`}
                      >
                        {cat.label}
                      </button>
                    ))}
                    {localStorage.getItem("cosam_directory_emails") && (
                      <button
                        onClick={handleResetEmails}
                        className="px-2 py-1 rounded-md text-[10px] text-slate-500 hover:text-rose-500 transition-colors flex items-center gap-1 cursor-pointer"
                        title="Restablecer correos originales"
                      >
                        <RotateCcw size={10} />
                        <span>Restablecer</span>
                      </button>
                    )}
                  </div>
                </div>

                {/* Grid de Correos */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {filteredEmails.map((item: any) => (
                    <div
                      key={item.id}
                      className="p-3.5 rounded-xl border border-slate-200/80 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/40 flex flex-col justify-between space-y-2.5"
                    >
                      <div>
                        <div className="flex items-center justify-between gap-2 mb-1">
                          <span className="text-[10px] font-medium text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/40 px-2 py-0.5 rounded border border-indigo-200/60 dark:border-indigo-900/40">
                            {item.categoryLabel}
                          </span>
                          <span className="text-[10px] text-slate-400">
                            {item.unit}
                          </span>
                        </div>
                        <h4 className="text-xs font-semibold text-slate-900 dark:text-white">
                          {item.name}
                        </h4>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 leading-relaxed">
                          {item.desc}
                        </p>
                      </div>

                      <div className="pt-2 border-t border-slate-200/60 dark:border-slate-800/80 text-[11px] flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        {editingEmailId === item.id ? (
                          <div className="flex items-center gap-1 w-full sm:max-w-[240px]">
                            <input
                              type="email"
                              value={editedEmailValue}
                              onChange={(e) => setEditedEmailValue(e.target.value)}
                              className="w-full px-2 py-1 bg-white dark:bg-slate-900 border border-indigo-400 rounded text-[11px] font-mono outline-hidden"
                              placeholder="correo@sanramon.cl"
                              autoFocus
                            />
                            <button
                              onClick={() => handleSaveEditedEmail(item.id)}
                              className="p-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-[10px]"
                              title="Guardar"
                            >
                              <Check size={12} />
                            </button>
                            <button
                              onClick={() => setEditingEmailId(null)}
                              className="p-1 bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-300 rounded text-[10px]"
                              title="Cancelar"
                            >
                              ✕
                            </button>
                          </div>
                        ) : (
                          <div className="flex items-center gap-1.5 truncate">
                            <Mail size={12} className="text-slate-400 shrink-0" />
                            <span className="font-mono text-slate-800 dark:text-slate-200 text-[11px] truncate">
                              {item.email}
                            </span>
                            <button
                              onClick={() => handleStartEditEmail(item)}
                              className="text-slate-400 hover:text-indigo-500 dark:hover:text-indigo-400 p-0.5 transition-colors cursor-pointer"
                              title="Editar este correo institucional"
                            >
                              <Pencil size={11} />
                            </button>
                          </div>
                        )}

                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            onClick={() => handleCopy(item.email, item.id)}
                            className="px-2 py-1 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-750 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 rounded-md text-[10px] font-medium transition-colors flex items-center gap-1 cursor-pointer shadow-xs"
                            title="Copiar dirección de correo"
                          >
                            {copiedKey === item.id ? (
                              <>
                                <Check size={10} className="text-emerald-500" />
                                <span className="text-emerald-600 dark:text-emerald-400 font-semibold">Copiado</span>
                              </>
                            ) : (
                              <>
                                <Copy size={10} />
                                <span>Copiar</span>
                              </>
                            )}
                          </button>

                          <a
                            href={`mailto:${item.email}?subject=Coordinaci%C3%B3n%20Cl%C3%ADnica%20-%20COSAM%20Rinconada`}
                            className="px-2 py-1 bg-slate-900 dark:bg-slate-100 hover:bg-slate-800 dark:hover:bg-white text-white dark:text-slate-900 rounded-md text-[10px] font-medium transition-colors flex items-center gap-1 cursor-pointer shadow-xs"
                            title="Redactar correo institucional"
                          >
                            <ExternalLink size={10} />
                            <span>Redactar</span>
                          </a>
                        </div>
                      </div>
                    </div>
                  ))}

                  {filteredEmails.length === 0 && (
                    <div className="col-span-full py-5 text-center text-slate-400 text-xs">
                      No se encontraron correos institucionales que coincidan con la búsqueda.
                    </div>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>

      {/* Pie de Página Minimalista */}
      <footer className="max-w-5xl mx-auto w-full text-center py-4 border-t border-slate-200/60 dark:border-slate-800/60">
        <p className="text-[11px] text-slate-400 dark:text-slate-500">
          COSAM Rinconada · Servicio de Salud Metropolitano Sur Oriente
        </p>
      </footer>

    </div>
  );
}
