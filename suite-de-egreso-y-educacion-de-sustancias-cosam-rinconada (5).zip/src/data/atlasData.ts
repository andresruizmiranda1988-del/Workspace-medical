import { AtlasFisiopatologicoItem } from "../types";

export const ATLAS_FISIOPATOLOGICO_DATA: AtlasFisiopatologicoItem[] = [
  {
    id: "neuroinflamacion",
    categoria: "Fisiopatología Base",
    icono: "Flame",
    titulo: "Neuroinflamación y Falla Mitocondrial",
    sistema: "Sistémico y Neurológico",
    descripcion:
      "El consumo somete al cerebro a un estrés oxidativo masivo. Las mitocondrias (motores celulares) fallan, provocando agotamiento profundo, y las células gliales se mantienen en un estado de inflamación crónica.",
    nutritionalCauses: [
      "Déficit de antioxidantes esenciales (Zinc, Vitamina C y E).",
      "Depleción de Complejo B (usado agresivamente por el hígado para desintoxicar).",
      "Déficit de Magnesio (el 'freno' natural del cerebro) y ácidos grasos Omega 3."
    ],
    medicalManagement: {
      pharma:
        "Estabilizadores del ánimo para reducir la excitabilidad neuronal. Complejos vitamínicos B de alta dosis si hay evidencia clínica de deficiencia severa.",
      nonPharma:
        "Higiene estricta del sueño (el sistema glinfático lava toxinas al dormir). Ejercicio aeróbico moderado (estimula neurogénesis y BDNF)."
    },
    recommendations:
      "Aumentar fuentes de Magnesio y B6 (nueces, almendras, espinacas). Consumir pescados grasos (Omega 3) para desinflamar el tejido neuronal. Mantener hidratación constante con electrolitos.",
    color: "text-purple-600 bg-purple-100",
    borderInfo: "border-purple-200"
  },
  {
    id: "metabolismo_farmacos",
    categoria: "Fisiopatología Base",
    icono: "Scale",
    titulo: "Resistencia a la Insulina y Psicofármacos",
    sistema: "Sistema Endocrino y Metabólico",
    descripcion:
      "Los psicofármacos (como antipsicóticos atípicos y estabilizadores) son vitales para proteger el cerebro inicialmente, pero frecuentemente alteran el metabolismo de la glucosa, promueven el apetito (bloqueo histaminérgico H1) y generan resistencia a la insulina.",
    nutritionalCauses: [
      "Consumo de carbohidratos refinados ('craving' de azúcar para buscar dopamina rápida).",
      "Falta de fibra que retrase la absorción de glucosa posprandial.",
      "Baja ingesta proteica que regule la saciedad y los picos de grelina."
    ],
    medicalManagement: {
      pharma:
        "Monitoreo de glicemia basal, HOMA-IR, perfil lipídico y enzimas hepáticas. Considerar Metformina si se consolida la resistencia a la insulina inducida por el tratamiento.",
      nonPharma:
        "Cambio rotundo en el patrón alimentario. Ejercicio de fuerza (pesas/bandas elásticas) para que el músculo capte glucosa por vía GLUT4 sin requerir tanta insulina."
    },
    recommendations:
      "Cero bebidas azucaradas. Reemplazar carbohidratos blancos por integrales con alto contenido de fibra. Incluir una porción de proteína magra en cada comida para frenar el apetito inducido por fármacos.",
    color: "text-rose-600 bg-rose-100",
    borderInfo: "border-rose-200"
  },
  {
    id: "alopecia",
    categoria: "Dermatológico",
    icono: "Sparkles",
    titulo: "Caída del Cabello y Fragilidad Capilar",
    sistema: "Sistema Integumentario",
    descripcion:
      "La pérdida de cabello refleja deficiencias crónicas de micronutrientes para la división celular y síntesis de queratina, o bien, efluvio telógeno por estrés oxidativo y desregulación del cortisol.",
    nutritionalCauses: [
      "Déficit de Hierro (ferritina baja reduce el aporte de oxígeno a los folículos).",
      "Déficit de Zinc (altera la división celular del bulbo piloso).",
      "Baja ingesta proteica y carencia de aminoácidos azufrados (metionina/cisteína)."
    ],
    medicalManagement: {
      pharma:
        "Minoxidil tópico (2%-5%), suplementación específica guiada por laboratorio (ej. Sulfato ferroso si ferritina <30 ng/mL, biotina y zinc).",
      nonPharma:
        "Manejo del estrés (el exceso de cortisol altera el ciclo folicular y acelera la fase telógena)."
    },
    recommendations:
      "Aumentar carnes magras, legumbres, huevos (fuente de biotina y colina), frutos secos y vegetales de hoja verde oscura.",
    color: "text-amber-600 bg-amber-100",
    borderInfo: "border-amber-200"
  },
  {
    id: "musculo",
    categoria: "Musculoesquelético",
    icono: "Activity",
    titulo: "Disminución de Masa Muscular (Sarcopenia)",
    sistema: "Sistema Musculoesquelético",
    descripcion:
      "La sarcopenia se acelera por un desbalance entre la síntesis y degradación de proteínas, asociado a inactividad, malnutrición calórico-proteica o resistencia anabólica inducida por tóxicos.",
    nutritionalCauses: [
      "Ingesta proteica total insuficiente o mal distribuida en el día.",
      "Baja ingesta calórica total (el cuerpo cataboliza el músculo para obtener energía).",
      "Resistencia a la insulina (altera la captación muscular de aminoácidos)."
    ],
    medicalManagement: {
      pharma:
        "Evaluación de función tiroidea y hormonal. Sensibilizadores a la insulina si hay resistencia metabólica asociada.",
      nonPharma:
        "Entrenamiento de fuerza progresivo (indispensable para activar la vía mTOR y síntesis proteica)."
    },
    recommendations:
      "Proteínas de alto valor biológico (huevos, pollo, pescado, legumbres con cereales), fraccionadas cada 3-4 horas. Obligatorio combinar con ejercicios de resistencia (pesas/bandas).",
    color: "text-orange-600 bg-orange-100",
    borderInfo: "border-orange-200"
  },
  {
    id: "menstruacion",
    categoria: "Endocrino",
    icono: "Droplets",
    titulo: "Alteraciones Menstruales y Amenorrea Secundaria",
    sistema: "Sistema Endocrino y Reproductor",
    descripcion:
      "Las irregularidades suelen ser adaptación del organismo ante un déficit severo de energía disponible (RED-S), estrés crónico con hipercortisolemia o alteraciones metabólicas secundarias (SOP).",
    nutritionalCauses: [
      "Baja disponibilidad de energía (dietas restrictivas o ayunos prolongados por consumo).",
      "Déficit de grasas saludables (precursores del anillo esteroideo para estrógenos y progesterona).",
      "Hiperinsulinemia asociada a dietas de ultraprocesados y azúcar simple."
    ],
    medicalManagement: {
      pharma:
        "Evaluación gineco-endocrina. Anticonceptivos o terapia de reemplazo según causa, Inositol (Mio/D-Chiro) para SOP, Metformina si hay hiperinsulinismo.",
      nonPharma:
        "Regulación de ritmos circadianos, higiene del sueño y reducción activa de estresores."
    },
    recommendations:
      "Restaurar balance calórico positivo. Incrementar grasas de buena calidad (palta, frutos secos, aceite de oliva virgen) y erradicar ultraprocesados.",
    color: "text-pink-600 bg-pink-100",
    borderInfo: "border-pink-200"
  },
  {
    id: "erectil",
    categoria: "Cardiovascular",
    icono: "HeartPulse",
    titulo: "Disfunción Eréctil y Daño Vascular Endotelial",
    sistema: "Sistema Vascular y Nervioso",
    descripcion:
      "Es frecuentemente un síntoma centinela de disfunción endotelial y problemas vasculares periféricos, altamente influenciado por el estado metabólico, tabaquismo y vasoespasmo por estimulantes.",
    nutritionalCauses: [
      "Dietas ricas en grasas trans y saturadas que generan aterosclerosis y disfunción endotelial.",
      "Bajo consumo de precursores de óxido nítrico (L-Arginina, L-Citrulina, nitratos naturales).",
      "Síndrome metabólico, hiperglicemia o diabetes no diagnosticada."
    ],
    medicalManagement: {
      pharma:
        "Inhibidores de la PDE5 (sildenafil/tadalafil) según evaluación cardiovascular previa. Manejo estricto de hipertensión arterial y dislipidemia.",
      nonPharma:
        "Cese radical del tabaquismo y estimulantes. Ejercicio cardiovascular aeróbico diario."
    },
    recommendations:
      "Patrón de dieta Mediterránea. Aumentar precursores de óxido nítrico: remolacha (betarraga), sandía, ajo, espinaca y cítricos.",
    color: "text-red-600 bg-red-100",
    borderInfo: "border-red-200"
  },
  {
    id: "gastro",
    categoria: "Digestivo",
    icono: "UtensilsCrossed",
    titulo: "Sintomatología Gastrointestinal, Disbiosis y Permeabilidad",
    sistema: "Sistema Digestivo y Microbioma",
    descripcion:
      "El meteorismo, estreñimiento, diarreas o dolor cólico suelen resultar de una disbiosis en la microbiota o el síndrome de intestino permeable derivado del impacto tóxico del alcohol o estimulantes.",
    nutritionalCauses: [
      "Baja ingesta de fibra dietética prebiótica o escasa hidratación hídrica.",
      "Exceso de ultraprocesados y tóxicos que alimentan bacterias patógenas.",
      "Estrés sostenido y daño en la mucosa epitelial intestinal."
    ],
    medicalManagement: {
      pharma:
        "Laxantes osmóticos (PEG) en crisis, antiespasmódicos, evaluación para SIBO o Helicobacter pylori si hay dispepsia refractaria.",
      nonPharma:
        "Optimización de postura defecatoria, masticación lenta y manejo del estrés con técnicas vagales."
    },
    recommendations:
      "Aumentar gradualmente fibra fermentable (frutas con piel, verduras cocidas), alimentos fermentados probióticos (kéfir, chucrut) y asegurar 2-3L de agua pura diaria.",
    color: "text-emerald-600 bg-emerald-100",
    borderInfo: "border-emerald-200"
  },
  {
    id: "piel_seca",
    categoria: "Dermatológico",
    icono: "Shield",
    titulo: "Piel Áspera, Resequedad y Pérdida de Elasticidad",
    sistema: "Sistema Integumentario",
    descripcion:
      "La alteración de la barrera hidrolipídica refleja carencias de hidratación profunda celular y lípidos que mantienen la cohesión de los corneocitos.",
    nutritionalCauses: [
      "Déficit de ácidos grasos esenciales (Omega 3 y ácido linoleico).",
      "Déficit de Vitamina A y carotenoides (indispensables para la regeneración epitelial).",
      "Baja ingesta hídrica diaria y consumo de diuréticos/estimulantes."
    ],
    medicalManagement: {
      pharma:
        "Emolientes formulados tópicos con Urea al 10-20% y Ceramidas.",
      nonPharma:
        "Baños cortos con agua tibia (evitar agua muy caliente), uso de sustitutos de jabón sin detergentes agresivos (Syndet)."
    },
    recommendations:
      "Fuentes de provitamina A (zanahoria, zapallo, camote), grasas protectoras (palta, nueces, semillas de chía) y mantener ingesta de agua pura distribuida a lo largo del día.",
    color: "text-teal-600 bg-teal-100",
    borderInfo: "border-teal-200"
  }
];
