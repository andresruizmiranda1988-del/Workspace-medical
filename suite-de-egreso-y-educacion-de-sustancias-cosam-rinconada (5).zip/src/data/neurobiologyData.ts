import { EstacionCircuito, NeurotransmisorInfo } from "../types";

export interface EstacionCircuitoExtendida extends EstacionCircuito {
  nivelJerarquico: number;
  etiquetaJerarquia: string;
  viaAnatomica: string;
  rolEnAdiccion: "Generador / Acelerador" | "Asignador de Placer & Deseo" | "Freno Ejecutivo & Control" | "Sistema de Alarma & Angustia" | "Grabadora de Contexto & Gatillantes";
  receptoresClave: string[];
  tiempoReversibilidad: string;
  intervencionClinicaBox: string;
  iconoTipo: "zap" | "target" | "shield" | "alert" | "bookmark";
}

export const ESTACIONES_CIRCUITO: EstacionCircuitoExtendida[] = [
  {
    id: "vta",
    nivelJerarquico: 1,
    etiquetaJerarquia: "Nivel 1: El Generador Dopaminérgico Mesencefálico",
    viaAnatomica: "Origen de las Vías Mesolímbica y Mesocortical",
    rolEnAdiccion: "Generador / Acelerador",
    nombre: "Área Tegmental Ventral (ATV)",
    region: "Mesencéfalo (Tronco Encefálico)",
    funcionNormal: "Fábrica y bomba de dopamina. Se activa ante recompensas evolutivas esenciales (comida, agua, sexo, afecto social) para asegurar la supervivencia de la especie.",
    secuestroAdiccion: "Las sustancias provocan una liberación artificial masiva y desproporcionada de dopamina (entre un 400% y 1000% sobre el nivel basal), inundando las vías de señalización y sobrecargando las neuronas dopaminérgicas.",
    manifestacionConductual: "Sensación súbita de euforia abrumadora y fijación instantánea del recuerdo como una 'prioridad vital' de máxima jerarquía biológica en el paciente.",
    analogiaPaciente: "Es el motor que bombea el combustible del deseo. La sustancia presiona el acelerador a fondo, sobrecargando la máquina.",
    receptoresClave: ["D2 Presináptico", "GABA-B", "Receptores μ-Opioides", "Nicotínicos α4β2"],
    tiempoReversibilidad: "60 a 90 días de abstinencia para normalizar la tasa de disparo espontáneo.",
    intervencionClinicaBox: "Explicar que la urgencia de consumo no es falta de carácter, sino una sobreactivación automática del motor mesencefálico.",
    iconoTipo: "zap"
  },
  {
    id: "accumbens",
    nivelJerarquico: 2,
    etiquetaJerarquia: "Nivel 2: Asignación Hedónica y Valor de Recompensa",
    viaAnatomica: "Vía Mesolímbica (ATV -> Núcleo Accumbens)",
    rolEnAdiccion: "Asignador de Placer & Deseo",
    nombre: "Núcleo Accumbens (Shell & Core)",
    region: "Estriado Ventral (Prosencéfalo Basal)",
    funcionNormal: "El 'centro del placer y valor hedónico'. Asigna relevancia emocional a las experiencias placenteras y coordina la motivación para repetirlas.",
    secuestroAdiccion: "Ante el bombardeo dopaminérgico crónico, el núcleo accumbens 'esconde' o destruye sus receptores D2 (downregulation). Como consecuencia, nada cotidiano produce placer (anhedonia profunda).",
    manifestacionConductual: "Tolerancia (necesidad de mayor dosis para sentir lo mismo) y profunda apatía o vacío hacia la vida cotidiana sin la sustancia.",
    analogiaPaciente: "Es como escuchar música con volumen 1000: para no romperse, el oído se vuelve sordo. Después, la conversación normal (la familia, el deporte) ya no se escucha.",
    receptoresClave: ["D2 / D1 Postsinápticos", "NMDA / AMPA", "Receptores CB1 Cannabinoides"],
    tiempoReversibilidad: "90 a 180 días para la reexpresión y resensibilización de receptores D2.",
    intervencionClinicaBox: "Prescribir actividades placenteras graduadas de bajo estímulo (micrologros, caminatas) y validar la anhedonia como un síntoma neurobiológico transitorio.",
    iconoTipo: "target"
  },
  {
    id: "prefrontal",
    nivelJerarquico: 3,
    etiquetaJerarquia: "Nivel 3: El Freno Ejecutivo y Control Cognitivo",
    viaAnatomica: "Vía Mesocortical (ATV -> Corteza Prefrontal)",
    rolEnAdiccion: "Freno Ejecutivo & Control",
    nombre: "Corteza Prefrontal (Dorsolateral, Ventromedial & Orbitofrontal)",
    region: "Lóbulo Frontal",
    funcionNormal: "El 'director de orquesta' y freno ejecutivo del cerebro. Responsable de la toma de decisiones, juicio moral, control de impulsos y evaluar consecuencias a largo plazo.",
    secuestroAdiccion: "Sufre hipofrontalidad funcional. Se desconecta el freno racional. Los circuitos automáticos subcorticales toman el control, anulando la capacidad de detener el impulso inmediato.",
    manifestacionConductual: "Pérdida del control voluntario: el paciente promete no consumir, pero ante el gatillante o el craving, la corteza prefrontal no logra frenar la conducta motora.",
    analogiaPaciente: "Es el pedal de freno de un auto. La adicción corta los cables del freno: la persona sabe que va directo a chocar, pero el pedal no responde.",
    receptoresClave: ["D1 Cortical", "5-HT2A Serotoninérgico", "Receptores Glutamatérgicos NMDA"],
    tiempoReversibilidad: "6 a 12 meses de rehabilitación para restablecer la conectividad fronto-estriatal.",
    intervencionClinicaBox: "Entrenar estrategias externas de contención (control de estímulos, barreras físicas de acceso al dinero/sustancia) mientras el freno biológico se repara.",
    iconoTipo: "shield"
  },
  {
    id: "amigdala",
    nivelJerarquico: 4,
    etiquetaJerarquia: "Nivel 4: El Sistema de Alarma y Afecto Negativo (Anti-Reward)",
    viaAnatomica: "Circuito Límbico Extendido (Amígdala + BNST + Habénula)",
    rolEnAdiccion: "Sistema de Alarma & Angustia",
    nombre: "Complejo Amigdalino & Núcleo del Lecho de la Estría Terminal",
    region: "Sistema Límbico (Polo Temporal Profundo)",
    funcionNormal: "Centro de procesamiento de amenazas, miedo, dolor y memoria emocional de supervivencia ante peligros reales.",
    secuestroAdiccion: "Se hiperactiva durante la abstinencia y el crash ('anti-reward system'). Recluta dinorfina y factor liberador de corticotropina (CRF), generando una intensa angustia física y psíquica.",
    manifestacionConductual: "Disforia severa, irritabilidad extrema, pánico e hiperreactividad emocional. El paciente consume no para buscar placer, sino para apagar el sufrimiento insoportable de la amígdala.",
    analogiaPaciente: "Es la alarma de incendios del cerebro. En la abstinencia, la alarma suena al máximo aunque no haya fuego, obligando a buscar la sustancia para apagar el ruido.",
    receptoresClave: ["CRF1 / CRF2", "Receptores κ-Opioides (Dinorfina)", "GABA-A Límbico", "Adrenérgicos α1/β"],
    tiempoReversibilidad: "30 a 60 días para atenuar la hiperreactividad basal del eje de estrés.",
    intervencionClinicaBox: "Técnicas de regulación vagal (respiración 4-4-8, inmersión facial fría) y psicoeducación sobre el refuerzo negativo.",
    iconoTipo: "alert"
  },
  {
    id: "hipocampo",
    nivelJerarquico: 5,
    etiquetaJerarquia: "Nivel 5: Memoria Contextual y Disparadores Ambientales",
    viaAnatomica: "Red Límbica Cingulada-Hipocámpica",
    rolEnAdiccion: "Grabadora de Contexto & Gatillantes",
    nombre: "Hipocampo & Corteza Cingulada Anterior",
    region: "Lóbulo Temporal Medial & Giro Cingulado",
    funcionNormal: "Consolidación de la memoria autobiográfica, contexto ambiental y aprendizaje espacial de seguridad/peligro.",
    secuestroAdiccion: "Graba memorias emocionales hiper-vívidas asociadas a los estímulos de consumo (olores, esquinas, papelillos, amigos, horarios, días de pago, música).",
    manifestacionConductual: "Craving condicionado e involuntario desencadenado automáticamente al exponerse a pistas visuales o situacionales previamente asociadas.",
    analogiaPaciente: "Es una grabadora en ultra alta definición. Cada vez que pasa cerca del lugar de consumo, la grabadora reproduce las ganas automáticamente sin pedir permiso.",
    receptoresClave: ["NMDA / GluA1", "Receptores 5-HT1A", "CB1 Presinápticos"],
    tiempoReversibilidad: "Proceso de extinción y re-aprendizaje activo a lo largo de 12 a 24 meses.",
    intervencionClinicaBox: "Mapa de gatillantes de alto riesgo, reestructuración ambiental y protocolos de evitación de señales condicionadas.",
    iconoTipo: "bookmark"
  }
];

export const NEUROTRANSMISORES_DATA: NeurotransmisorInfo[] = [
  {
    id: "dopamina",
    nombre: "Dopamina (DA)",
    rolFisiologico: "Molécula de la motivación, anticipación del deseo y búsqueda de recompensas. Marca lo que 'vale la pena hacer para sobrevivir'.",
    alteracionEnConsumo: "Disparos suprafisiológicos (400% a 1000% sobre basal) seguidos por una caída profunda bajo el umbral normal (depleción masiva). Provoca reducción de receptores D2 en el estriado.",
    sintomaClinico: "Anhedonia profunda (incapacidad de sentir placer por actividades habituales), desmotivación, aburrimiento intolerable, craving imperioso.",
    analogiaPaciente: "La dopamina es la 'batería de la motivación'. La sustancia descarga la batería por completo; cuando el efecto pasa, el cerebro queda en 0% de energía emocional.",
    icono: "Zap",
    color: "from-amber-500 to-orange-500",
    estrategiaRecuperacion: "Abstinencia sostenida de 60-90 días para permitir la neurogénesis y reexpresión de receptores D2. Ejercicio aeróbico regular, exposición a luz solar matinal y alimentos ricos en L-Tirosina."
  },
  {
    id: "gaba",
    nombre: "GABA (Ácido Gamma-Aminobutírico)",
    rolFisiologico: "El principal neurotransmisor inhibidor del Sistema Nervioso Central. Funciona como el 'tranquilizante natural' del cerebro, induciendo calma, relajación muscular y sueño.",
    alteracionEnConsumo: "Sustancias depresoras (alcohol, benzodiacepinas) sobreestimulan el receptor GABA-A. En respuesta, el cerebro disminuye su sensibilidad GABA para compensar la sedación.",
    sintomaClinico: "En abstinencia: hiperexcitabilidad cortical, taquicardia, temblores finos y gruesos, insomnio de conciliación, angustia paroxística e incluso convulsiones tónico-clónicas.",
    analogiaPaciente: "El GABA es el sistema de frenos y amortiguadores del cerebro. Al quitar bruscamente la sustancia, el auto queda sin frenos y el motor se sobrecalienta.",
    icono: "Shield",
    color: "from-blue-500 to-indigo-500",
    estrategiaRecuperacion: "Titulación y deshabituación gradual médica (nunca suspender bruscamente sedantes/alcohol). Suplementación con Magnesio bisglicinato, vitamina B6 y técnicas de respiración diafragmática."
  },
  {
    id: "glutamato",
    nombre: "Glutamato (Glu)",
    rolFisiologico: "El principal neurotransmisor excitador. Esencial para la plasticidad sináptica, fijación de memoria a largo plazo (LTP) y procesamiento del pensamiento rápido.",
    alteracionEnConsumo: "Hiperactividad glutamatérgica de rebote por sobreexpresión de receptores NMDA durante la desintoxicación. Puede inducir excitotoxicidad neuronal por entrada masiva de calcio intracelular.",
    sintomaClinico: "Pensamiento rumiante e intrusivo de consumo, estados de agitación psicomotriz, ansiedad insoportable, niebla mental e hiperalgesia (dolor difuso).",
    analogiaPaciente: "Es el volumen del parlante. Con el consumo repetido, el parlante queda pegado en volumen máximo, provocando acoples y chirridos insoportables en la cabeza.",
    icono: "Activity",
    color: "from-rose-500 to-red-500",
    estrategiaRecuperacion: "Protección con estabilizadores de membrana prescritos por psiquiatría, aminoácido N-Acetilcisteína (NAC) para modular el intercambio cistina-glutamato en el accumbens, y sueño reparador."
  },
  {
    id: "serotonina",
    nombre: "Serotonina (5-HT)",
    rolFisiologico: "Regulador clave del estado de ánimo, estabilidad afectiva, control de impulsos agresivos, saciedad alimentaria y arquitectura del sueño REM.",
    alteracionEnConsumo: "Agotamiento de las vesículas presinápticas tras consumo de estimulantes/empatógenos o desregulación por consumo crónico de alcohol/cannabis.",
    sintomaClinico: "Disforia profunda, irritabilidad desmedida, labilidad emocional con llanto fácil, insomnio fragmentado y ataques de pánico o impulsividad destructiva.",
    analogiaPaciente: "La serotonina es el termostato de la tranquilidad y la paciencia. Cuando está baja, cualquier pequeño problema cotidiano se siente como el fin del mundo.",
    icono: "Heart",
    color: "from-purple-500 to-pink-500",
    estrategiaRecuperacion: "Reposición de L-Triptófano dietario (huevos, legumbres, frutos secos), higiene rigurosa del sueño, reparación de la microbiota intestinal (donde se sintetiza el 90% de la serotonina corporal) y psicoterapia."
  },
  {
    id: "noradrenalina",
    nombre: "Noradrenalina (NA)",
    rolFisiologico: "Activa el sistema simpático, estado de alerta, reflejo de lucha o huida y tono vascular sistémico.",
    alteracionEnConsumo: "Disparo adrenérgico violento con estimulantes (pasta base, cocaína, metanfetamina) o tormenta autonómica noradrenérgica en abstinencia de opioides y alcohol.",
    sintomaClinico: "Sudoración fría, midriasis, hipertensión arterial, palpitaciones, hipervigilancia paranoide ('perseguida') y sensación de catástrofe inminente.",
    analogiaPaciente: "Es la sirena de emergencia militar. El cuerpo se prepara para pelear con un león imaginario las 24 horas del día.",
    icono: "Flame",
    color: "from-amber-600 to-red-600",
    estrategiaRecuperacion: "Manejo médico autonómico, evitar estimulantes adicionales (exceso de cafeína, bebidas energéticas), actividad física moderada para disipar el exceso de catecolaminas circulantes."
  }
];

export const ETAPAS_CICLO_ADICCION = [
  {
    fase: 1,
    nombre: "1. Binge / Intoxicación Aguda",
    estructuras: "Núcleo Accumbens, ATV, Estriado Dorsal",
    mecanismo: "Descarga dopaminérgica masiva. Refuerzo positivo inicial (búsqueda de placer). Formación de hábitos automatizados.",
    estadoEmocional: "Euforia, desinhibición, sensación transitoria de omnipotencia o desconexión emocional del dolor.",
    color: "bg-emerald-500"
  },
  {
    fase: 2,
    nombre: "2. Retiro / Afecto Negativo (La Angustia)",
    estructuras: "Amígdala Extendida, Habénula, Núcleo del Lecho de la Estría Terminal",
    mecanismo: "Depleción de dopamina por debajo del nivel basal + activación masiva del sistema de estrés (CRF, Dinorfina, Noradrenalina).",
    estadoEmocional: "Anhedonia, disforia, ansiedad extrema, dolor físico, sensación de vacío y desesperación intolerable.",
    color: "bg-rose-500"
  },
  {
    fase: 3,
    nombre: "3. Preocupación / Anticipación (Craving)",
    estructuras: "Corteza Prefrontal, Corteza Orbitofrontal, Ínsula, Hipocampo",
    mecanismo: "Disfunción ejecutiva + reactividad involuntaria ante pistas asociadas. Se pierde la capacidad de inhibir la respuesta de búsqueda.",
    estadoEmocional: "Obsesión mental centrada en conseguir la sustancia, ceguera ante las consecuencias destructivas y pérdida del autocontrol.",
    color: "bg-purple-600"
  }
];
