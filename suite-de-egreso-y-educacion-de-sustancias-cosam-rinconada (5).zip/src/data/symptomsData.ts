import { SintomaClinicoCard } from "../types";

export const SINTOMAS_CLINICOS_DATA: SintomaClinicoCard[] = [
  {
    id: "perdida-peso",
    titulo: "Pérdida de Peso Acelerada & Caquexia",
    categoria: "Metabolico",
    subtitulo: "Emaciación muscular, pérdida de panículo adiposo y balance calórico negativo",
    descripcion: "La persona experimenta una reducción drástica e involuntaria del 15% al 30% de su masa corporal en semanas o pocos meses de consumo compulsivo.",
    fisiopatologiaExplicada: "Los estimulantes bloquean el centro del apetito en el hipotálamo lateral (saciedad dopaminérgica artificial) y disparan el gasto metabólico basal mediante tormentas adrenérgicas. La persona puede pasar 3 a 5 días continuos de binge sin ingerir alimentos ni agua, recurriendo a la autofagia y degradación de proteínas musculares para obtener glucosa.",
    signosDeAlarma: [
      "Pérdida de más del 10% del peso habitual en menos de 1 mes",
      "Hundimiento de fosas temporales y prominencia de arcos costales",
      "Hipotensión ortostática con mareos al ponerse de pie",
      "Hipoalbuminemia y edemas maleolares por desnutrición proteica"
    ],
    comoSeRevierte: "Recuperación ponderal gradual mediante dieta hiperproteica e hipercalórica fraccionada (5-6 tomas diarias), evitando el síndrome de realimentación. Suplementación con ácidos grasos esenciales y batidos de alta densidad de nutrientes.",
    tiempoEstimado: "4 a 12 semanas para recuperar el peso funcional basal.",
    intervencionEnBox: "Pesar y tallar al paciente en cada control como indicador objetivo de evolución. Establecer metas de aumento de 0.5 a 1 kg por semana. Explicarle que comer no es solo 'llenar la guata', sino alimentar la fábrica de dopamina de su cerebro.",
    nutrientesClave: ["Proteínas de alto valor biológico", "Zinc", "Complejo B", "Creatina"],
    icono: "TrendingDown"
  },
  {
    id: "anemia",
    titulo: "Anemia & Ferropenia / Déficit de B12 y Folato",
    categoria: "Fisico",
    subtitulo: "Disminución de hemoglobina, transporte deficiente de oxígeno e hipoxia tisular",
    descripcion: "Fatiga extrema, palidez mucocutánea, taquicardia refleja y sensación de ahogo al caminar distancias cortas.",
    fisiopatologiaExplicada: "La anemia en personas con consumo problemático es multifactorial: 1) Ingesta nula de hierro hemínico y vegetales verdes; 2) Microhemorragias digestivas por gastritis erosiva química; 3) Déficit de Ácido Fólico (B9) y Vitamina B12 por alcohol o tóxicos que bloquean la eritropoyesis en la médula ósea.",
    signosDeAlarma: [
      "Hemoglobina menor a 10 g/dL en sangre",
      "Palidez marcada en conjuntivas oculares y lecho ungueal",
      "Lipotimias (desmayos) y taquicardias en reposo",
      "Glositis (lengua roja, lisa y dolorosa por déficit de B12/folato)"
    ],
    comoSeRevierte: "Tratamiento de la causa gástrica, reposición oral o parenteral de Sulfato Ferroso (junto a Vitamina C para favorecer su absorción) y suplementación con Ácido Fólico y Vitamina B12.",
    tiempoEstimado: "6 a 8 semanas para normalizar recuentos de glóbulos rojos.",
    intervencionEnBox: "Solicitar Hemograma completo, Ferritina sérica y perfil de hierro. Explicar al paciente que su cansancio crónico y desánimo muchas veces no es 'depresión pura', sino falta de oxígeno celular por anemia.",
    nutrientesClave: ["Hierro quelado / hemínico", "Vitamina C", "Vitamina B12", "Ácido Fólico"],
    icono: "Droplets"
  },
  {
    id: "alteracion-menstrual",
    titulo: "Alteraciones del Ciclo Menstrual & Amenorrea en Mujeres",
    categoria: "Reproductivo",
    subtitulo: "Amenorrea hipotalámica secundaria, anovulación e hipoestrogenismo",
    descripcion: "Cese completo de la menstruación por meses o años durante los períodos de consumo activo, a menudo confundido con infertilidad permanente o menopausia precoz.",
    fisiopatologiaExplicada: "El estrés físico masivo, el bajo porcentaje de grasa corporal (por debajo del 17% necesario para la aromatización estrogénica) y la disfunción dopaminérgica inhiben la secreción hipotalámica de GnRH. Sin estímulo de LH/FSH, los ovarios entran en quiescencia temporal (hipogonadismo hipogonadotrópico), con caída de estrógenos a niveles basales.",
    signosDeAlarma: [
      "Amenorrea superior a 6 meses consecutivos",
      "Sequedad vaginal severa con dolor en relaciones sexuales (dispareunia)",
      "Sofocos y labilidad emocional semejantes al climaterio",
      "Riesgo de embarazo no planificado por recuperación ovulatoria imprevista al subir de peso"
    ],
    comoSeRevierte: "Recuperación de la masa grasa corporal mínima crítica (>18-20%), normalización del aporte calórico diario y reducción del cortisol mediante abstinencia y sueño regular.",
    tiempoEstimado: "3 a 6 meses post-recuperación ponderal.",
    intervencionEnBox: "Romper el mito de que 'no sangro, por lo tanto no puedo quedar embarazada'. Educar sobre ovulación silenciosa. Monitorear salud ósea por el período de hipoestrogenismo (riesgo de osteopenia).",
    nutrientesClave: ["Ácidos grasos Omega-3", "Grasas saludables (palta, frutos secos)", "Vitamina D3", "Colesterol precursor"],
    icono: "CalendarX"
  },
  {
    id: "osteopenia",
    titulo: "Osteopenia & Fragilidad Ósea Acelerada",
    categoria: "Fisico",
    subtitulo: "Pérdida prematura de densidad mineral ósea y riesgo de fracturas patológicas",
    descripcion: "Deterioro silencioso de la microarquitectura trabecular del hueso en mujeres y hombres jóvenes con consumo crónico.",
    fisiopatologiaExplicada: "La falta de estrógenos protectores, el exceso crónico de cortisol (que estimula la resorción osteoclástica), la malabsorción de calcio intestinal y el déficit solar/dietario de Vitamina D provocan que el hueso pierda minerales a una tasa 5 veces mayor a la natural. Una persona de 25 años puede presentar la densidad ósea de una mujer postmenopáusica de 65 años.",
    signosDeAlarma: [
      "Dolores óseos profundos en columna lumbar y caderas",
      "Fracturas ante caídas leves desde la propia altura (muñeca, costillas, tobillos)",
      "Pérdida de estatura o cifosis dorsal incipiente",
      "Historial de amenorrea prolongada superior a 1 año"
    ],
    comoSeRevierte: "Suplementación combinada de Vitamina D3 (colecalciferol) + Calcio citrato + Magnesio bisglicinato + Vitamina K2. Inducción de ejercicio de fuerza resistida de impacto progresivo para estimular el osteoblasto.",
    tiempoEstimado: "12 a 24 meses de terapia de remineralización ósea continua.",
    intervencionEnBox: "Solicitar Densitometría Ósea (DEXA) y niveles de 25-OH-Vitamina D. Prescribir caminatas con carga y sol matinal seguro de 15 minutos diarios.",
    nutrientesClave: ["Vitamina D3", "Calcio", "Magnesio", "Vitamina K2", "Proteínas"],
    icono: "Shield"
  },
  {
    id: "lesiones-dermatologicas",
    titulo: "Lesiones Dermatológicas & Quemaduras Periorales",
    categoria: "Dermatologico",
    subtitulo: "Excoriaciones por rascado obsesivo, parasitosis delirante y quemaduras por pipa",
    descripcion: "Presencia de costras polimorfas, cicatrices hipo e hipercrómicas en brazos, rostro y pecho, junto a quemaduras periorales y en dedos.",
    fisiopatologiaExplicada: "La liberación desmedida de dopamina en receptores sensoriales centrales y periféricos produce formicación táctil (sensación de que insectos caminan bajo la piel). El paciente se rasca compulsivamente hasta arrancarse fragmentos de epidermis. Además, el uso de pipas metálicas caseras al rojo vivo genera quemaduras térmicas de 2° y 3° grado en labios y lengua.",
    signosDeAlarma: [
      "Heridas con signos de infección bacteriana activa (eritema expansivo, calor, pus, celulitis)",
      "Úlceras crónicas que no cicatrizan en más de 3 semanas",
      "Quemaduras labiales extensas con retracción cicatrizal",
      "Fiebre asociada a lesiones cutáneas (descartar bacteriemia o endocarditis)"
    ],
    comoSeRevierte: "Cese del estímulo dopaminérgico tóxico, curación avanzada de heridas con apósitos hidrocoloides, antibióticos tópicos/sistémicos si hay celulitis, y suplementación con Zinc y Vitamina C para reactivar la síntesis de colágeno.",
    tiempoEstimado: "4 a 8 semanas para epitelización de heridas activas.",
    intervencionEnBox: "Validar empáticamente el malestar sensorial sin reforzar el delirio. Ofrecer kits de curación básica e hidratantes cutáneos con ceramidas para reducir el prurito y la necesidad de rascado.",
    nutrientesClave: ["Zinc bisglicinato", "Vitamina C (ácido ascórbico)", "Colágeno", "Vitamina A"],
    icono: "Sparkles"
  },
  {
    id: "alteraciones-dentales",
    titulo: "Alteraciones Dentales Severas ('Boca de Pasta/Meth')",
    categoria: "Bucodental",
    subtitulo: "Caries rampantes en cuello dental, bruxismo masivo y fracturas coronarias",
    descripcion: "Destrucción rápida, ennegrecimiento y pérdida secuencial de piezas dentales en pocos meses de consumo.",
    fisiopatologiaExplicada: "Se produce por una tríada devastadora: 1) Xerostomía severa (la sustancia 'apaga' las glándulas salivales eliminando el buffer protector contra bacterias); 2) Bruxismo simpaticomimético extremo que fractura y fisura el esmalte; 3) Contacto directo con vapores corrosivos ácidos (ácido sulfúrico y solventes residuales en pasta base).",
    signosDeAlarma: [
      "Dolor odontológico insoportable o abscesos periodontales con flemón facial",
      "Raíces dentales expuestas y ennegrecidas con hemorragia gingival espontánea",
      "Dificultad mecánica severa para masticar alimentos sólidos",
      "Infecciones del espacio parafaríngeo (riesgo de angina de Ludwig)"
    ],
    comoSeRevierte: "Control del dolor e infecciones agudas con analgesia y antibióticos odontológicos. Tratamiento de conducto, extracciones de restos radiculares no viables y prótesis removibles o fijas.",
    tiempoEstimado: "Proceso multidisciplinario de rehabilitación odontológica (3 a 6 meses).",
    intervencionEnBox: "Recomendar uso de gomas de mascar sin azúcar con xilitol para estimular la saliva, cepillo ultra-suave y pasta con alto contenido de flúor (5000 ppm). Derivar prioritariamente a odontología.",
    nutrientesClave: ["Calcio", "Fósforo", "Vitamina D3", "Flúor", "Coenzima Q10"],
    icono: "Smile"
  },
  {
    id: "cuadros-digestivos",
    titulo: "Cuadros Digestivos, Gastritis Erosiva & Disbiosis",
    categoria: "Fisico",
    subtitulo: "Dolor epigástrico urente, reflujo ácido, náuseas matinales y permeabilidad intestinal",
    descripcion: "Ardor estomacal constante, vómitos biliosos, intolerancia a alimentos y diarreas líquidas alternadas con constipación pertinaz.",
    fisiopatologiaExplicada: "La ingesta de sustancias o la deglución de saliva con residuos tóxicos agrede la barrera de moco gástrico. El vasoespasmo isquémico de la microcirculación esplácnica genera microinfartos en la mucosa del estómago y duodeno. A nivel del colon, se destruyen las poblaciones bacterianas benéficas (Lactobacillus, Bifidobacterium), generando 'intestino permeable' e inflamación sistémica.",
    signosDeAlarma: [
      "Vómitos con sangre roja o 'concho de café' (hematemesis)",
      "Deposiciones negras alquitranadas y malolientes (melena / hemorragia digestiva)",
      "Dolor abdominal agudo súbito y abdomen en tabla (sospecha de perforación gástrica)",
      "Deshidratación severa con oliguria (poca orina)"
    ],
    comoSeRevierte: "Inhibidores de la bomba de protones (Omeprazol/Esomeprazol) por 4 a 8 semanas, suspensión de alcohol/picantes/cigarrillo, dieta blanda alcalina, probióticos y L-Glutamina para reparar el epitelio intestinal.",
    tiempoEstimado: "2 a 6 semanas para cicatrización mucosa.",
    intervencionEnBox: "Preguntar siempre por heces oscuras y acidez. Explicar cómo el intestino inflamado produce 'niebla mental' y empeora la ansiedad a través del nervio vago (eje intestino-cerebro).",
    nutrientesClave: ["L-Glutamina", "Probióticos multicepa", "Zinc carnosina", "Mucílago de linaza / Aloe"],
    icono: "UtensilsCrossed"
  },
  {
    id: "sindrome-afectivo-psiquico",
    titulo: "Afectaciones Psíquicas: Anhedonia, Paranoia, Insomnio & Disforia",
    categoria: "Psiquico",
    subtitulo: "El 'valle de la angustia', aplanamiento hedónico, hiperalerta persecutoria y crisis de pánico",
    descripcion: "Sensación devastadora de que la vida perdió todo color y sentido, acompañada de miedo intenso, desconfianza hacia los cercanos y desvelo total.",
    fisiopatologiaExplicada: "Al caer la dopamina tras el consumo, los receptores D2 están 'adormecidos'. Ningún estímulo normal (música, risas, familia) alcanza el umbral de activación. Simultáneamente, la amígdala hiperactiva y el cortisol elevado generan un estado de 'perseguida' (hipervigilancia paranoide), interpretando miradas cotidianas o ruidos como amenazas inminentes de muerte o captura.",
    signosDeAlarma: [
      "Ideación o conducta suicida activa en contexto de disforia post-consumo ('el bajón')",
      "Alucinaciones auditivas de comando o delirios paranoides no reductibles",
      "Insomnio total superior a 72 horas con riesgo de cuadro confusional agudo",
      "Agresividad impulsiva desregulada por terror o desesperación interna"
    ],
    comoSeRevierte: "Psicoeducación de que 'la angustia tiene fecha de vencimiento biológico'. Rebalanceo neuroquímico mediante psicofármacos estabilizadores del ánimo, antipsicóticos a bajas dosis si hay delirio, higiene del sueño y reestructuración cognitiva.",
    tiempoEstimado: "Alivio agudo de angustia en 7 a 14 días; recuperación del tono afectivo basal en 3 a 6 meses.",
    intervencionEnBox: "Transmitir esperanza fundamentada en la neurobiología: 'Su cerebro no está roto para siempre, está quemado y deshidratado. Con semanas de abstinencia y comida sana, las ramas vuelven a florecer'.",
    nutrientesClave: ["L-Triptófano", "Magnesio bisglicinato", "Omega-3 (EPA/DHA)", "Vitamina B6", "Complejo B"],
    icono: "Brain"
  }
];
