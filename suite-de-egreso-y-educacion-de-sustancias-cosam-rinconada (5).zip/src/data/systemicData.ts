import { SistemaFisiologico } from "../types";

export const SISTEMAS_FISIOLOGICOS_DATA: SistemaFisiologico[] = [
  {
    id: "snc-mental",
    nombre: "Sistema Nervioso & Salud Mental",
    icono: "Brain",
    color: "purple",
    resumenImpacto: "Daño en redes prefrontales, pérdida de plasticidad sináptica, neurotoxicidad glial, anhedonia refractaria y riesgo elevado de psicosis inducida.",
    mecanismoFisiopatologico: "El flujo de dopamina suprafisiológico induce excitotoxicidad glutamatérgica con sobrecarga mitocondrial de calcio, apoptosis neuronal en corteza frontal y pérdida de arborización dendrítica en el hipocampo. Al cesar el estímulo, los receptores D2 reducidos dejan al paciente en un estado de hipodopaminergia profunda.",
    manifestacionesClinicas: [
      "Anhedonia severa (incapacidad de disfrutar la vida cotidiana)",
      "Labilidad afectiva e impulsividad psicomotora desregulada",
      "Episodios psicóticos reactivos o paranoides ('la perseguida')",
      "Deterioro de la memoria de trabajo y de la función ejecutiva",
      "Insomnio de conciliación y fragmentación del sueño REM",
      "Aplanamiento afectivo y retraimiento social"
    ],
    analogiaParaElPaciente: "Imagine que el cerebro es una red de caminos de tierra: el consumo pasa con camiones pesados a 200 km/h todos los días, rompiendo los puentes de la paciencia y del juicio. Con el tiempo, el cerebro necesita semanas de tranquilidad para pavimentar nuevamente sus rutas naturales.",
    tiempoReversibilidad: "6 a 18 meses de abstinencia para recuperación parcial a significativa de densidad de receptores D2 y conectividad prefrontal.",
    perlaClinicaBox: "Diferenciar en el box entre psicosis primaria vs. psicosis inducida por estimulantes (pasta base/cocaína/cannabinoides sintéticos). En la inducida, suele haber conservación de la crítica post-detox y remisión parcial con neurolépticos a dosis bajas y abstinencia estricta.",
    sustanciasDeMayorRiesgo: ["Pasta Base / Cera PB", "Cocaína", "Metanfetamina", "Cannabinoides sintéticos", "Alcohol crónico"]
  },
  {
    id: "digestivo-dental",
    nombre: "Sistema Digestivo & Salud Bucodental",
    icono: "UtensilsCrossed",
    color: "emerald",
    resumenImpacto: "Gastritis erosiva, atrofia de vellosidades intestinales, xerostomía crónica, disbiosis y destrucción acelerada del esmalte dental ('Boca de Pasta/Meth').",
    mecanismoFisiopatologico: "Los vapores calientes y los residuos químicos corrosivos (ácido sulfúrico, solventes, amoníaco) erosionan directamente la mucosa bucal y el esmalte dental. La hiperactividad simpática suprime la secreción salival (xerostomía), anulando el lavado bacteriano natural. A nivel gástrico e intestinal, el vasoespasmo isquémico causa gastritis hemorrágica, disbiosis severa y malabsorción de micronutrientes.",
    manifestacionesClinicas: [
      "Xerostomía extrema (boca completamente seca) y bruxismo diurno/nocturno",
      "Caries rampantes en el cuello del diente y pérdida precoz de piezas dentales",
      "Epigastralgia urente, reflujo gastroesofágico y gastritis erosiva",
      "Quemaduras y úlceras orofaríngeas por pipas o vapores a altas temperaturas",
      "Disbiosis intestinal con diarreas crónicas o estreñimiento severo",
      "Síndrome de mala absorción intestinal (pérdida de vitaminas y minerales)"
    ],
    analogiaParaElPaciente: "La saliva es el escudo que baña y protege los dientes las 24 horas del día. La sustancia seca completamente la boca y quema el esmalte con calor y químicos, dejando los dientes desprotegidos como madera expuesta a termitas.",
    tiempoReversibilidad: "Mucosa gástrica: 4 a 8 semanas con dieta alcalina y protectores gástricos. Piezas dentales: requieren rehabilitación odontológica reconstructiva.",
    perlaClinicaBox: "La pérdida dental severa destruye la autoestima del paciente y dificulta la alimentación nutritiva. Fomentar la derivación precoz a odontología comunitaria como hito central de reinserción psicosocial.",
    sustanciasDeMayorRiesgo: ["Pasta Base", "Cera PB", "Metanfetamina", "Alcohol", "Tabaco"]
  },
  {
    id: "endocrino-metabolico",
    nombre: "Sistema Endocrino & Metabólico",
    icono: "Flame",
    color: "amber",
    resumenImpacto: "Hipercortisolemia crónica, desregulación del eje HPA, hipotiroidismo funcional, caquexia por hipercatabolismo y resistencia a la insulina.",
    mecanismoFisiopatologico: "El estrés sostenido del consumo y la abstinencia hiperactiva permanentemente el eje Hipotálamo-Hipófisis-Adrenal (HPA), vertiendo niveles tóxicos de cortisol en sangre. El cortisol crónico destruye la masa muscular (proteólisis), inhibe la síntesis de colágeno, eleva la glucosa y suprime la hormona de crecimiento (GH) y el eje tiroideo, llevando a una caquexia metabólica acelerada.",
    manifestacionesClinicas: [
      "Pérdida acelerada de masa muscular magra y grasa corporal (emaciación)",
      "Fatiga suprarrenal, astenia severa y sensación de agotamiento físico crónico",
      "Desregulación del metabolismo de la glucosa (picos y valles de azúcar que gatillan craving)",
      "Supresión tiroidea relativa (sensación de frío constante, piel seca, enlentecimiento)",
      "Desbalance electrolítico (hipopotasemia, hipomagnesemia)"
    ],
    analogiaParaElPaciente: "El cuerpo entra en un 'estado de guerra' permanente. Para alimentar la alarma, el organismo quema sus propios músculos y reservas en lugar de repararse durante la noche.",
    tiempoReversibilidad: "Normalización del eje HPA y cortisol tras 2 a 4 meses de regularidad circadiana, sueño estable y soporte nutricional.",
    perlaClinicaBox: "La hipoglicemia reactiva es uno de los mayores gatillantes inadvertidos de craving en el box. Enseñar al paciente a consumir colaciones proteicas complejas cada 3-4 horas para estabilizar la curva glicémica.",
    sustanciasDeMayorRiesgo: ["Estimulantes (PB, Cocaína, Anfetaminas)", "Alcohol crónico", "Opioides"]
  },
  {
    id: "dermatologico",
    nombre: "Sistema Dermatológico & Fanéreos",
    icono: "Sparkles",
    color: "rose",
    resumenImpacto: "Excoriaciones por rascado compulsivo (parasitosis delirante), úlceras tróficas, quemaduras periorales y envejecimiento cutáneo acelerado.",
    mecanismoFisiopatologico: "La estimulación dopaminérgica y táctil aberrante en las vías sensitivas primarias genera alucinaciones táctiles periféricas (formicación o sensación de 'bichos bajo la piel' / delirio de Ekbom). Esto induce un rascado compulsivo incontrolable con uñas o pinzas, produciendo infecciones bacterianas secundarias (celulitis, impétigo). Además, el vasoespasmo cutáneo reduce el aporte de oxígeno y nutrientes a la dermis.",
    manifestacionesClinicas: [
      "Lesiones por rascado crónico (neurodermitis excoriada, costras faciales y en extremidades)",
      "Quemaduras térmicas periorales y en pulpejos de los dedos por pipas de metal calientes",
      "Cicatrices hipercrómicas o queloides desfigurantes",
      "Caída difusa del cabello (efluvio telógeno) y fragilidad ungueal por déficit de zinc y biotina",
      "Palidez terrosa y adelgazamiento de la piel por hipoxia capilar",
      "Infecciones cutáneas bacterianas recidivantes por falta de barrera epitelial"
    ],
    analogiaParaElPaciente: "El cerebro engaña a la piel haciéndole creer que hay hormigas o insectos caminando por dentro. La persona se rasca para defenderse, pero el problema no está en la piel, sino en un 'cable cruzado' temporal en el cerebro.",
    tiempoReversibilidad: "Cicatrización epitelial activa en 3 a 6 semanas; las manchas y textura requieren 6 a 12 meses de regeneración con zinc, vitamina C y cuidados dérmicos básicos.",
    perlaClinicaBox: "En el box, revisar respetuosamente las manos, cara y brazos. Tratar con cremas cicatrizantes y antibióticos tópicos si hay sobreinfección, validando el sufrimiento del paciente sin confrontar agresivamente su síntoma sensorial.",
    sustanciasDeMayorRiesgo: ["Pasta Base / Cera PB", "Metanfetamina", "Cocaína adulterada", "Inyectables"]
  },
  {
    id: "inmunologico",
    nombre: "Sistema Inmunológico & Defensas",
    icono: "ShieldAlert",
    color: "red",
    resumenImpacto: "Inmunodepresión severa, neutropenia funcional, vulnerabilidad crítica a infecciones oportunistas (TBC, neumonías, sepsis) y seroconversión.",
    mecanismoFisiopatologico: "La combinación de malnutrición calórico-proteica, déficit de zinc/vitamina A/C/D y el efecto tóxico directo de las sustancias suprime la proliferación de linfocitos T y B, disminuye la actividad fagocítica de los macrófagos alveolares y altera las barreras mucosas. Esto deja al organismo indefenso ante patógenos respiratorios y sistémicos.",
    manifestacionesClinicas: [
      "Infecciones respiratorias bacterianas y fúngicas a repetición",
      "Alto riesgo de Tuberculosis Pulmonar (TBC) activa o reactivación latente",
      "Mayor susceptibilidad a Virus de Inmunodeficiencia Humana (VIH) y Hepatitis B/C",
      "Retardo marcado en la cicatrización de heridas quirúrgicas o traumáticas",
      "Aftas orales recidivantes y candidiasis orofaríngea"
    ],
    analogiaParaElPaciente: "El sistema inmune es el ejército de defensa de su cuerpo. La falta de comida y el tóxico dejan a los soldados sin municiones y desarmados; cualquier resfrío común puede convertirse en una neumonía grave.",
    tiempoReversibilidad: "Aumento progresivo del recuento leucocitario y competencia inmune a partir de los primeros 30 a 60 días con adecuada reposición de zinc, selenio, vitamina D y proteínas.",
    perlaClinicaBox: "Siempre mantener sospecha clínica de Tuberculosis en pacientes con consumo crónico de pasta base y tos de más de 15 días ('sintomático respiratorio'). Solicitar baciloscopías y test rápido de VIH/VHC en el centro.",
    sustanciasDeMayorRiesgo: ["Pasta Base", "Alcohol crónico", "Consumo por vía intravenosa", "Polisustancias"]
  },
  {
    id: "reproductivo-sexual",
    nombre: "Sistema Reproductivo & Eje Gonadal",
    icono: "HeartPulse",
    color: "pink",
    resumenImpacto: "Amenorrea hipotalámica en mujeres, hipogonadismo y disfunción eréctil en hombres, anorgasmia, infertilidad y riesgo obstétrico.",
    mecanismoFisiopatologico: "A nivel hipotalámico, el estrés biológico y la dopamina desregulada suprimen la secreción pulsátil de la Hormona Liberadora de Gonadotropinas (GnRH). En mujeres, esto anula la secreción de LH/FSH provocando anovulación, caída de estrógenos y amenorrea secundaria. En hombres, desciende la testosterona sérica libre, provocando atrofia testicular relativa y disfunción eréctil.",
    manifestacionesClinicas: [
      "Amenorrea secundaria prolongada (ausencia total de menstruación por meses/años)",
      "Infertilidad transitoria y síndrome de sequedad vaginal",
      "Pérdida dramática de la libido (deseo sexual) o conductas sexuales compulsivas desreguladas",
      "Disfunción eréctil y eyaculación retardada o anorgasmia",
      "Ginecomastia en hombres (por desbalance estrógeno/testosterona en alcoholismo)",
      "Riesgo crítico de prematurez, bajo peso al nacer y síndrome de abstinencia neonatal en embarazo"
    ],
    analogiaParaElPaciente: "El cuerpo es inteligente: cuando percibe que el organismo está en hambruna y peligro extremo por el consumo, 'apaga' el sistema reproductivo para ahorrar energía y evitar un embarazo de alto riesgo biológico.",
    tiempoReversibilidad: "Retorno de ciclos menstruales y niveles de testosterona habitualmente entre 3 y 6 meses tras recuperar peso corporal y suspender el consumo.",
    perlaClinicaBox: "¡Cuidado clínico!: Muchas pacientes asumen que por estar en amenorrea no pueden quedar embarazadas. Al reiniciar la nutrición en abstinencia, la ovulación se recupera ANTES del primer sangrado menstrual. Asesorar siempre sobre anticoncepción segura.",
    sustanciasDeMayorRiesgo: ["Pasta Base", "Opioides", "Alcohol", "Cannabis crónico de alta potencia", "Cocaína"]
  },
  {
    id: "cardiovascular",
    nombre: "Sistema Cardiovascular & Hemodinámico",
    icono: "Activity",
    color: "red",
    resumenImpacto: "Vasoespasmo coronario, arritmias ventriculares potencialmente letales, hipertensión arterial reactiva, hipertrofia miocárdica y miocardiopatía dilatada.",
    mecanismoFisiopatologico: "El bloqueo de la recaptación de noradrenalina y la activación simpática masiva provocan taquicardia extrema, vasoconstricción coronaria y aumento del consumo miocárdico de oxígeno. Esto predispone a infarto agudo de miocardio (incluso en arterias sanas sin placas de ateroma), disección aórtica, taquicardia ventricular y muerte súbita.",
    manifestacionesClinicas: [
      "Dolor torácico opresivo (angina de pecho por vasoespasmo)",
      "Palpitaciones paroxísticas, taquicardia sinusal y arritmias complejas",
      "Crisis hipertensivas con cefalea pulsátil y riesgo de accidente cerebrovascular (ACV)",
      "Cardiomiopatía dilatada tóxica con insuficiencia cardíaca y disnea de esfuerzo",
      "Extremidades frías y cianóticas por vasoconstricción periférica intensa"
    ],
    analogiaParaElPaciente: "Es como exigirle al motor de un auto que funcione a 8.000 revoluciones por minuto cuesta arriba sin parar, mientras se le cierra el tubo de la bencina.",
    tiempoReversibilidad: "El riesgo de vasoespasmo agudo cae inmediatamente al cesar el consumo. La remodelación cardíaca o dilatación miocárdica puede tardar 6 a 12 meses con seguimiento cardiológico.",
    perlaClinicaBox: "Ante cualquier dolor precordial en un paciente joven consumidor de estimulantes, descartar infarto de miocardio por vasoespasmo. Evitar el uso de beta-bloqueadores puros no selectivos en intoxicación aguda por estimulantes (riesgo de vasoespasmo alfa coronario sin oposición).",
    sustanciasDeMayorRiesgo: ["Cocaína", "Pasta Base / Cera PB", "Metanfetamina", "Alcohol", "Tabaco"]
  },
  {
    id: "musculoesqueletico",
    nombre: "Sistema Músculo-esquelético & Osteoarticular",
    icono: "Shield",
    color: "blue",
    resumenImpacto: "Osteopenia y osteoporosis acelerada (especialmente en mujeres), sarcopenia severa, riesgo de rabdomiólisis y atrofia postural.",
    mecanismoFisiopatologico: "La falta de estrógenos (por amenorrea), el exceso de cortisol, el sedentarismo durante los períodos de encierro, y la deficiencia severa de calcio, magnesio, vitamina D y proteínas aceleran la reabsorción ósea osteoclástica sobre la formación osteoblástica. A nivel muscular, la hipertermia y la inmovilidad post-consumo pueden desencadenar necrosis muscular (rabdomiólisis).",
    manifestacionesClinicas: [
      "Osteopenia temprana y fracturas por fragilidad ante traumatismos mínimos",
      "Sarcopenia y pérdida masiva de fuerza y volumen muscular",
      "Dolores óseos difusos y artralgias matinales",
      "Mialgias intensas y orina oscura (posible rabdomiólisis con riesgo de falla renal)",
      "Alteraciones de la marcha y postura encorvada por debilidad de la faja muscular dorsal"
    ],
    analogiaParaElPaciente: "El hueso es como un banco donde guardamos calcio. El consumo extrae todo el calcio sin depositar nada a cambio, dejando los huesos huecos y frágiles como ramas secas.",
    tiempoReversibilidad: "Masa muscular: 2 a 3 meses con ejercicio resistido y proteínas. Densidad mineral ósea: requiere 12 a 24 meses de suplementación con vitamina D3, calcio y ejercicio de impacto.",
    perlaClinicaBox: "Solicitar densitometría ósea o niveles de 25-OH-Vitamina D en mujeres jóvenes con consumo crónico y amenorrea de más de 6 meses. La osteopenia en pacientes jóvenes es una secuela silenciosa pero grave.",
    sustanciasDeMayorRiesgo: ["Pasta Base", "Alcohol crónico", "Cocaína", "Opioides"]
  }
];
