import { MicronutrienteInfo } from "../types";

export const MICRONUTRIENTES_DATA: MicronutrienteInfo[] = [
  {
    id: "b1-tiamina",
    nombre: "Vitamina B1 (Tiamina)",
    categoria: "Vitamina",
    rolEnSaludMental: "Cofactor esencial para el metabolismo cerebral de la glucosa y la síntesis de neurotransmisores (GABA, glutamato y acetilcolina). Sin B1, las neuronas sufren muerte energética.",
    mecanismoDeDeplecionPorConsumo: "El alcohol y los estimulantes destruyen los transportadores intestinales de tiamina, disminuyen su almacenamiento hepático e impiden su conversión a su forma activa (Pirofosfato de Tiamina).",
    consecuenciaClinicaDeficiencia: "Encefalopatía de Wernicke (tríada: ataxia, oftalmoplejía y confusión) que puede evolucionar al Síndrome amnésico irreversible de Korsakoff (pérdida de memoria reciente y confabulación).",
    alimentosFuentes: ["Legumbres (lentejas, garbanzos)", "Avena integral", "Frutos secos (nueces, semillas de girasol)", "Carnes magras y levadura nutricional"],
    dosisSugeridaReposicion: "100 a 300 mg/día vía oral (o parenteral en desintoxicación alcohólica aguda).",
    prioridadBox: "Crítica"
  },
  {
    id: "b6-piridoxina",
    nombre: "Vitamina B6 (Piridoxina)",
    categoria: "Vitamina",
    rolEnSaludMental: "Cofactor obligatorio de la enzima L-aminoácido aromático descarboxilasa, necesaria para sintetizar Dopamina, Serotonina y GABA a partir de sus precursores proteicos.",
    mecanismoDeDeplecionPorConsumo: "Inactivación metabólica por metabolitos tóxicos del alcohol (acetaldehído) y nula ingesta calórica durante episodios de binge.",
    consecuenciaClinicaDeficiencia: "Irritabilidad extrema, insomnio resistente, depresión refractaria, temblores musculares, neuropatía periférica y queilitis angular (boqueras).",
    alimentosFuentes: ["Plátanos", "Papas y camotes", "Pescados grasos", "Huevos de campo", "Palta"],
    dosisSugeridaReposicion: "50 a 100 mg/día junto con complejo B.",
    prioridadBox: "Alta"
  },
  {
    id: "b12-cobalamina",
    nombre: "Vitamina B12 (Cobalamina) & Ácido Fólico (B9)",
    categoria: "Vitamina",
    rolEnSaludMental: "Mantenimiento de la vaina de mielina de los axones neuronales, síntesis de S-adenosilmetionina (SAMe) para la metilación del ADN y producción de glóbulos rojos.",
    mecanismoDeDeplecionPorConsumo: "Gastritis química atrófica que anula la secreción del Factor Intrínseco gástrico necesario para absorber B12 en el íleon terminal.",
    consecuenciaClinicaDeficiencia: "Degeneración combinada subaguda de la médula espinal (parestesias en manos y pies, marcha inestable), demencia reversible, anemia megaloblástica y fatiga extrema.",
    alimentosFuentes: ["Huevos", "Pescados (atún, jurel, sardina)", "Lácteos fermentados (kéfir, yogurt natural)", "Hígado y carnes"],
    dosisSugeridaReposicion: "1.000 a 2.000 mcg/semana de B12 + 1 a 5 mg/día de Ácido Fólico.",
    prioridadBox: "Alta"
  },
  {
    id: "vitamina-c",
    nombre: "Vitamina C (Ácido Ascórbico)",
    rolEnSaludMental: "Potente antioxidante neuroprotector que neutraliza los radicales libres producidos por el metabolismo de estimulantes. Cofactor en la síntesis de Noradrenalina y colágeno.",
    categoria: "Vitamina",
    mecanismoDeDeplecionPorConsumo: "Gasto oxidativo masivo durante la tormenta metabólica del consumo y nulo consumo de frutas frescas cítricas.",
    consecuenciaClinicaDeficiencia: "Fragilidad capilar con hematomas espontáneos, sangrado de encías (gingivorragia), retraso en la cicatrización de quemaduras y piel opaca y quebradiza.",
    alimentosFuentes: ["Cítricos (naranja, limón, pomelo)", "Kiwi", "Pimientos rojos crudos", "Frutillas y bayas", "Tomates"],
    dosisSugeridaReposicion: "500 a 1.000 mg/día fraccionados en 2 tomas.",
    prioridadBox: "Alta"
  },
  {
    id: "vitamina-d3",
    nombre: "Vitamina D3 (Colecalciferol)",
    categoria: "Vitamina",
    rolEnSaludMental: "Neuroesteroide que regula más de 1.000 genes cerebrales. Estimula la expresión del Factor Neurotrófico Derivado del Cerebro (BDNF), clave para la neuroplasticidad y recuperación cognitiva.",
    mecanismoDeDeplecionPorConsumo: "Encierro prolongado en habitaciones oscuras durante los períodos de consumo (cero exposición solar) y malabsorción de grasas.",
    consecuenciaClinicaDeficiencia: "Osteopenia severa, osteoporosis prematura, debilidad muscular proximal, depresión mayor estacional y susceptibilidad a infecciones respiratorias.",
    alimentosFuentes: ["Exposición solar segura (15-20 min/día)", "Yema de huevo", "Pescados grasos (jurel, salmón)", "Hongos expuestos al sol"],
    dosisSugeridaReposicion: "2.000 a 4.000 UI/día (o dosis de carga semanal de 50.000 UI según niveles séricos de 25-OH-D3).",
    prioridadBox: "Alta"
  },
  {
    id: "magnesio",
    nombre: "Magnesio (Formas Bisglicinato o Treonato)",
    categoria: "Mineral",
    rolEnSaludMental: "El 'bloqueador natural del receptor NMDA'. Calma la excitotoxicidad del glutamato, relaja la musculatura lisa arterial y es cofactor en más de 300 enzimas de síntesis de ATP.",
    mecanismoDeDeplecionPorConsumo: "Hipercalciuria e hipomagnesemia inducida por alcohol y estimulantes debido a pérdidas renales masivas y sudoración profusa.",
    consecuenciaClinicaDeficiencia: "Hiperalgesia (dolor en todo el cuerpo), contracturas musculares dolorosas, bruxismo diurno, arritmias ventriculares, irritabilidad y temblores.",
    alimentosFuentes: ["Semillas de calabaza", "Espinacas cocidas", "Cacao amargo puro (>70%)", "Almendras", "Legumbres"],
    dosisSugeridaReposicion: "300 a 400 mg de Magnesio elemental al acostarse.",
    prioridadBox: "Crítica"
  },
  {
    id: "zinc",
    nombre: "Zinc (Bisglicinato o Picolinato)",
    categoria: "Mineral",
    rolEnSaludMental: "Modulador alostérico de receptores GABA y NMDA. Esencial para la neurogénesis en el hipocampo, cicatrización epitelial, función inmune y producción de testosterona.",
    mecanismoDeDeplecionPorConsumo: "Pérdida por sudoración, diarreas crónicas y nula ingesta de mariscos o carnes rojas.",
    consecuenciaClinicaDeficiencia: "Anosmia y ageusia (pérdida de olfato y gusto que perpetúa la falta de apetito), caída masiva de cabello, dermatitis eccematosa y depresión anhedónica.",
    alimentosFuentes: ["Semillas de zapallo", "Ostras y mariscos", "Carnes magras", "Lentejas y garbanzos"],
    dosisSugeridaReposicion: "25 a 50 mg/día junto con las comidas.",
    prioridadBox: "Alta"
  },
  {
    id: "triptofano-tirosina",
    nombre: "L-Triptófano & L-Tirosina (Aminoácidos Precursores)",
    categoria: "Aminoácido",
    rolEnSaludMental: "L-Tirosina es el sustrato directo para sintetizar Dopamina y Noradrenalina. L-Triptófano es el sustrato directo para sintetizar Serotonina y Melatonina.",
    mecanismoDeDeplecionPorConsumo: "Proteólisis muscular acelerada y ausencia total de ingesta proteica durante los días de intoxicación.",
    consecuenciaClinicaDeficiencia: "Incapacidad biológica del cerebro para 'rellenar los estanques' de neurotransmisores, prolongando indefinidamente el 'valle de la angustia' y el craving.",
    alimentosFuentes: ["Huevos enteros", "Pavo y pollo", "Tofu y soya", "Avena", "Semillas de sésamo y chía"],
    dosisSugeridaReposicion: "Ingesta dietaria de 1.2 a 1.5 g de proteína por kilo de peso corporal al día.",
    prioridadBox: "Crítica"
  },
  {
    id: "omega3",
    nombre: "Ácidos Grasos Omega-3 (EPA / DHA)",
    categoria: "AcidoGraso",
    rolEnSaludMental: "El DHA compone el 30% de los fosfolípidos de la membrana cerebral; asegura la fluidez de membrana para que los receptores D2 y 5-HT funcionen correctamente. El EPA es antiinflamatorio cerebral.",
    mecanismoDeDeplecionPorConsumo: "Peroxidación lipídica masiva inducida por tóxicos y ausencia de pescados azules en la dieta.",
    consecuenciaClinicaDeficiencia: "Neuroinflamación crónica, rigidez de membrana sináptica, labilidad emocional e impulsividad.",
    alimentosFuentes: ["Pescados azules chilenos (jurel, sardina, salmón)", "Semillas de chía y linaza molidas", "Nueces"],
    dosisSugeridaReposicion: "1.000 a 2.000 mg/día de EPA/DHA concentrado.",
    prioridadBox: "Alta"
  }
];

export const PILARES_MICRORREHABILITACION = [
  {
    pilar: 1,
    titulo: "1. Hidratación Celular & Restablecimiento Electrolítico",
    subtitulo: "Apagar la deshidratación osmótica y reponer el agua tisular",
    descripcion: "El cerebro está compuesto en un 75% por agua. La deshidratación crónica del consumo encoge el parénquima cerebral y desencadena cefaleas, irritabilidad y confusión.",
    indicacionBox: "Consumir 2.5 a 3 litros de agua al día. En los primeros 14 días, incorporar 1 vaso diario de suero de rehidratación oral o agua mineral con una pizca de sal marina y limón (aporte de sodio y potasio).",
    icono: "Droplets",
    color: "blue"
  },
  {
    pilar: 2,
    titulo: "2. Reposición de Micronutrientes y Vitaminas Esenciales",
    subtitulo: "Cargar las materias primas para fabricar neurotransmisores",
    descripcion: "No se puede curar la anhedonia si el cerebro carece de Tiamina, Piridoxina, Zinc y Magnesio para ensamblar la dopamina y la serotonina.",
    indicacionBox: "Iniciar protocolo de Complejo B de alta potencia (B1 100mg + B6 + B12) + Magnesio 400mg nocturno + Vitamina C 1g/día por al menos 60 días continuos.",
    icono: "Pill",
    color: "purple"
  },
  {
    pilar: 3,
    titulo: "3. Curva Glucémica Estable contra el Craving",
    subtitulo: "Evitar los valles de azúcar que disparan la necesidad compulsiva de consumir",
    descripcion: "Cuando la glicemia cae bruscamente (hipoglicemia reactiva), el cerebro entra en pánico y activa la amígdala, confundiendo el hambre celular con el 'deseo de fumar o beber'.",
    indicacionBox: "Comer cada 3.5 a 4 horas. Priorizar carbohidratos complejos de absorción lenta (avena, legumbres, arroz integral) combinados siempre con proteínas (huevo, frutos secos, quesillo). Prohibir azúcar refinada y bebidas energéticas en ayunas.",
    icono: "Activity",
    color: "amber"
  },
  {
    pilar: 4,
    titulo: "4. Eje Intestino-Cerebro & Dieta Antiinflamatoria",
    subtitulo: "Reparar la microbiota intestinal donde se fabrica el 90% de la serotonina",
    descripcion: "El intestino inflamado ('leaky gut') envía señales de alarma continuas al cerebro a través del nervio vago, perpetuando la niebla mental, la ansiedad y el mal humor.",
    indicacionBox: "Incorporar alimentos fermentados naturales (yogurt con probióticos, chucrut no pasteurizado), fibra prebiótica (avena, manzana cocida con canela), caldos de huesos ricos en colágeno y glutamina.",
    icono: "Heart",
    color: "emerald"
  }
];
