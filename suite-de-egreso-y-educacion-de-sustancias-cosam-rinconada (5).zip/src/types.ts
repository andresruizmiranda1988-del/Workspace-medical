export type NivelRiesgo = "Bajo" | "Medio" | "Alto" | "Extremo";

export interface NeurotransmisorInfo {
  id: string;
  nombre: string;
  rolFisiologico: string;
  alteracionEnConsumo: string;
  sintomaClinico: string;
  analogiaPaciente: string;
  icono: string;
  color: string;
  estrategiaRecuperacion: string;
}

export interface EstacionCircuito {
  id: string;
  nombre: string;
  region: string;
  funcionNormal: string;
  secuestroAdiccion: string;
  manifestacionConductual: string;
  analogiaPaciente: string;
}

export interface SistemaFisiologico {
  id: string;
  nombre: string;
  icono: string;
  color: string;
  resumenImpacto: string;
  mecanismoFisiopatologico: string;
  manifestacionesClinicas: string[];
  analogiaParaElPaciente: string;
  tiempoReversibilidad: string;
  perlaClinicaBox: string;
  sustanciasDeMayorRiesgo: string[];
}

export interface SintomaClinicoCard {
  id: string;
  titulo: string;
  categoria: "Fisico" | "Metabolico" | "Psiquico" | "Dermatologico" | "Reproductivo" | "Bucodental";
  subtitulo: string;
  descripcion: string;
  fisiopatologiaExplicada: string;
  signosDeAlarma: string[];
  comoSeRevierte: string;
  tiempoEstimado: string;
  intervencionEnBox: string;
  nutrientesClave: string[];
  icono: string;
}

export interface MicronutrienteInfo {
  id: string;
  nombre: string;
  categoria: "Vitamina" | "Mineral" | "Aminoácido" | "AcidoGraso";
  rolEnSaludMental: string;
  mecanismoDeDeplecionPorConsumo: string;
  consecuenciaClinicaDeficiencia: string;
  alimentosFuentes: string[];
  dosisSugeridaReposicion: string;
  prioridadBox: "Crítica" | "Alta" | "Media";
}

export interface AtlasFisiopatologicoItem {
  id: string;
  categoria: string;
  icono: string;
  titulo: string;
  sistema: string;
  descripcion: string;
  nutritionalCauses: string[];
  medicalManagement: {
    pharma: string;
    nonPharma: string;
  };
  recommendations: string;
  color: string;
  borderInfo: string;
}

export interface RegistroDiarioItem {
  id: string | number;
  fecha: string;
  animo: string;
  gatillante: string;
  ansiedad: number;
  craving: number;
  herramientaUsada?: string;
}

export interface Sustancia {
  id: string;
  nombre: string;
  alias: string;
  categoria: string;
  naturaleza: string;
  principioActivo: string;
  mecanismoExtraccion: string;
  perfilConsumidor: string;
  duracionEfecto: string;
  secuelaCrash: string;
  riesgoVital: NivelRiesgo;
  descripcion: string;
  sistemasImpacto: {
    sistemaNervioso: {
      nivel: NivelRiesgo;
      detalles: string;
    };
    sistemaRespiratorio: {
      nivel: NivelRiesgo;
      detalles: string;
    };
    sistemaCardiovascular: {
      nivel: NivelRiesgo;
      detalles: string;
    };
    sistemaDigestivoYOtros: {
      nivel: NivelRiesgo;
      detalles: string;
    };
  };
  impactoSocial: string;
  datosEpidemiologicos: string;
  sintomasClinicos: string[];
}

export type ClinicalModuleId =
  | "clinical_dashboard"
  | "protocolos_ingreso"
  | "ingreso_pai"
  | "evoluciones"
  | "vademecum"
  | "laboratorio"
  | "triaje_sic"
  | "derivaciones"
  | "egresos"
  | "reuniones";

export interface DrugItem {
  id: string;
  name: string;
  family: "antidepresivo" | "benzodiacepina" | "estabilizador" | "antipsicotico" | "estimulante" | "adicciones";
  brands: string;
  recipe: "simple" | "retenida" | "cheque";
  fda: "A" | "B" | "C" | "D" | "X";
  mechanism: string;
  dosing: string;
  indications: string;
  kids: string;
  addictions: string;
  adverse: string;
  toxicity: string;
  contraindications: string;
  redFlags: string;
  labs: string;
  patientInstructions: string;
}

export interface SoapRecord {
  id: string;
  patientName: string;
  rut: string;
  date: string;
  s: string;
  o: string;
  a: string;
  p: string;
  structuredResult: string;
}

export interface PaiRecord {
  id: string;
  patientName: string;
  diagnosis: string;
  motive: string;
  predisposing: string;
  precipitating: string;
  perpetuating: string;
  protective: string;
  structuredResult: string;
  date: string;
}

export interface TriageRecord {
  id: string;
  fecha: string;
  rut: string;
  nombre: string;
  edad: number;
  sexo: string;
  prevision: string;
  validacion: "Validado" | "No Validado";
  origen: string;
  fechaDerivacion: string;
  fechaValoracion: string;
  cie10: string;
  estado: "Aceptado" | "Rechazado" | "No Pertinente";
  observaciones: string;
  cartaCesfam?: string;
  diasEspera?: number;
}

export interface EgresoRecord {
  id: string;
  nombre: string;
  rut: string;
  domicilio: string;
  fechaNacimiento: string;
  edad: number;
  fechaIngreso: string;
  fechaEgreso: string;
  motivoEgreso: "Alta Terapéutica" | "Alta Administrativa" | "Abandono" | "Derivación";
  evalGeneralLogro: "Logro Alto" | "Logro Medio" | "Logro Bajo";
  evalGeneralObs: string;
  consumoPatron: "Abstinencia" | "Disminución de Consumo" | "Mantención de Consumo";
  consumoObs: string;
  familiarLogro: "Logro Alto" | "Logro Medio" | "Logro Bajo";
  familiarObs: string;
  interpersonalLogro: "Logro Alto" | "Logro Medio" | "Logro Bajo";
  interpersonalObs: string;
  normaLogro: "Logro Alto" | "Logro Medio" | "Logro Bajo";
  normaObs: string;
  ocupacionalLogro: "Logro Alto" | "Logro Medio" | "Logro Bajo";
  ocupacionalObs: string;
  pronosticoObs: string;
  documentoGenerado?: string;
}

export interface DerivacionRecord {
  id: string;
  nombre: string;
  rut: string;
  edad: string;
  sexo: string;
  direccion: string;
  telefono: string;
  correo: string;
  destino: "Alta a APS" | "Hospitalización" | "Especialidad";
  especialidad: string;
  diagnostico: string;
  tratamiento: string;
  resumenMedico: string;
  logrosEquipo: string;
  indicacionesAlta: string;
  sugerenciasAps: string;
  documentoGenerado: string;
  fecha: string;
}

export interface ReunionClinicaRecord {
  id: string;
  fecha: string;
  paciente: string;
  diagnostico: string;
  profesionalPresenta: string;
  integrantesEquipo: string;
  resumenCaso: string;
  nudosCriticos: string;
  acuerdosCompromisos: string;
  actaGenerada: string;
}

export type ReuniónClinicaRecord = ReunionClinicaRecord;

export interface ClinicalMeetingCase {
  id: number;
  titulo: string;
  fecha: string;
  contenido: string;
  tareas: { id: number; texto: string; completada?: boolean }[];
  preguntasSugeridas?: string | null;
  acuerdos?: string | null;
}

export interface LabAnalysisState {
  edad: string;
  sexo: string;
  diagnostico: string;
  farmacos: string;
  got?: string;
  gpt?: string;
  ggt?: string;
  bili?: string;
  fa?: string;
  glicemia?: string;
  trigliceridos?: string;
  colesterol?: string;
  vcm?: string;
  hemoglobina?: string;
  plaquetas?: string;
  leucocitos?: string;
  b12?: string;
  folico?: string;
  bun?: string;
  creatinina?: string;
  sodio?: string;
  potasio?: string;
  tsh?: string;
  t4l?: string;
  litemia?: string;
  reporteHtml?: string;
  explicacionPaciente?: string;
}

export interface DriveUploadedFile {
  id: string;
  name: string;
  mimeType: string;
  webViewLink?: string;
  createdTime?: string;
  size?: string;
}

export interface DriveUploadProgress {
  percent: number;
  stage: "idle" | "preparing" | "checking_folder" | "uploading" | "completed" | "error";
  message: string;
  fileName?: string;
  folderName?: string;
  fileUrl?: string;
  fileId?: string;
  error?: string;
}
