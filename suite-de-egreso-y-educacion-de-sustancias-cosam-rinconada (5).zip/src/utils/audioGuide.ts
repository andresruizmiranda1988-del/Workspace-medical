// Utilidad de síntesis de voz, tonos armónicos bioacústicos y sonido terapéutico
// Compatible con Tablets (iPad / Android), Smartphones, WebViews y Computadores de Box

let audioCtx: AudioContext | null = null;
let isAudioUnlocked = false;
let cachedVoices: SpeechSynthesisVoice[] = [];

/**
 * Inicializa y desbloquea el AudioContext y el motor de voz mediante interacción del usuario
 */
export function unlockAudioEngine(): boolean {
  if (typeof window === "undefined") return false;

  try {
    // 1. Desbloquear Web Audio API
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (AudioContextClass) {
      if (!audioCtx) {
        audioCtx = new AudioContextClass();
      }
      if (audioCtx.state === "suspended") {
        audioCtx.resume().catch(() => {});
      }
      
      // Emitir micro-tono inaudible para forzar el desbloqueo del canal de audio en iOS/Android
      try {
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        gain.gain.setValueAtTime(0.0001, audioCtx.currentTime);
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start(0);
        osc.stop(audioCtx.currentTime + 0.05);
      } catch (e) {}
    }

    // 2. Desbloquear Web Speech API si está disponible
    if ("speechSynthesis" in window) {
      window.speechSynthesis.resume();
      loadAvailableVoices();
      
      // Enviar una vocal silenciosa para despertar el motor de síntesis en Safari/Chrome mobile
      try {
        const silentUtterance = new SpeechSynthesisUtterance("");
        silentUtterance.volume = 0;
        window.speechSynthesis.speak(silentUtterance);
      } catch (e) {}
    }

    isAudioUnlocked = true;
    return true;
  } catch (err) {
    console.warn("Audio unlock warning:", err);
    return false;
  }
}

/**
 * Carga y cachea las voces del navegador
 */
function loadAvailableVoices() {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
  
  const voices = window.speechSynthesis.getVoices();
  if (voices && voices.length > 0) {
    cachedVoices = voices;
  }
}

// Escuchar evento de carga de voces en navegadores donde es asíncrono (Chrome/Safari)
if (typeof window !== "undefined" && "speechSynthesis" in window) {
  window.speechSynthesis.onvoiceschanged = () => {
    loadAvailableVoices();
  };
  loadAvailableVoices();
}

function getAudioContext(): AudioContext | null {
  if (typeof window === "undefined") return null;
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (AudioContextClass) {
      audioCtx = new AudioContextClass();
    }
  }
  if (audioCtx && audioCtx.state === "suspended") {
    audioCtx.resume().catch(() => {});
  }
  return audioCtx;
}

/**
 * Emite tonos armónicos binaurales y relajantes sintetizados en tiempo real
 * Funciona al 100% en cualquier tablet, teléfono o navegador sin necesidad de servidores
 */
export function playTherapeuticTone(type: "inhale" | "hold" | "exhale" | "bell" | "wave" | "ding" | "success") {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const osc2 = ctx.createOscillator(); // Armónico secundario cálido
    const gain = ctx.createGain();
    const gain2 = ctx.createGain();

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc2.connect(gain2);
    gain2.connect(ctx.destination);

    if (type === "inhale") {
      // Tono suave ascendente cálido (sensación de llenado y expansión)
      osc.type = "sine";
      osc.frequency.setValueAtTime(261.63, now); // Do central
      osc.frequency.exponentialRampToValueAtTime(392.0, now + 1.6); // Sol
      gain.gain.setValueAtTime(0.001, now);
      gain.gain.linearRampToValueAtTime(0.12, now + 0.4);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 2.2);

      // Armónico cálido
      osc2.type = "triangle";
      osc2.frequency.setValueAtTime(130.81, now);
      osc2.frequency.exponentialRampToValueAtTime(196.0, now + 1.6);
      gain2.gain.setValueAtTime(0.001, now);
      gain2.gain.linearRampToValueAtTime(0.06, now + 0.4);
      gain2.gain.exponentialRampToValueAtTime(0.001, now + 2.2);

      osc.start(now);
      osc.stop(now + 2.2);
      osc2.start(now);
      osc2.stop(now + 2.2);
    } else if (type === "hold") {
      // Tono de pausa y estabilidad (armonía relajante)
      osc.type = "sine";
      osc.frequency.setValueAtTime(440, now); // La
      gain.gain.setValueAtTime(0.001, now);
      gain.gain.linearRampToValueAtTime(0.07, now + 0.1);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 1.2);

      osc.start(now);
      osc.stop(now + 1.2);
    } else if (type === "exhale") {
      // Tono suave descendente (sensación de vaciado, alivio y descompresión vagal)
      osc.type = "sine";
      osc.frequency.setValueAtTime(392.0, now); // Sol
      osc.frequency.exponentialRampToValueAtTime(196.0, now + 2.0); // Sol bajo
      gain.gain.setValueAtTime(0.001, now);
      gain.gain.linearRampToValueAtTime(0.11, now + 0.3);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 2.5);

      osc2.type = "triangle";
      osc2.frequency.setValueAtTime(196.0, now);
      osc2.frequency.exponentialRampToValueAtTime(98.0, now + 2.0);
      gain2.gain.setValueAtTime(0.001, now);
      gain2.gain.linearRampToValueAtTime(0.05, now + 0.3);
      gain2.gain.exponentialRampToValueAtTime(0.001, now + 2.5);

      osc.start(now);
      osc.stop(now + 2.5);
      osc2.start(now);
      osc2.stop(now + 2.5);
    } else if (type === "bell") {
      // Cuenco tibetano terapéutico a 528 Hz (frecuencia de transformación y calma)
      osc.type = "triangle";
      osc.frequency.setValueAtTime(528, now);
      gain.gain.setValueAtTime(0.18, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 3.0);

      osc2.type = "sine";
      osc2.frequency.setValueAtTime(264, now);
      gain2.gain.setValueAtTime(0.08, now);
      gain2.gain.exponentialRampToValueAtTime(0.001, now + 3.0);

      osc.start(now);
      osc.stop(now + 3.0);
      osc2.start(now);
      osc2.stop(now + 3.0);
    } else if (type === "ding") {
      osc.type = "sine";
      osc.frequency.setValueAtTime(659.25, now); // Mi
      gain.gain.setValueAtTime(0.1, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.5);
      osc.start(now);
      osc.stop(now + 0.5);
    } else if (type === "success") {
      // Acorde armónico de logro
      [523.25, 659.25, 783.99].forEach((freq, i) => {
        const o = ctx.createOscillator();
        const g = ctx.createGain();
        o.connect(g);
        g.connect(ctx.destination);
        o.type = "sine";
        o.frequency.setValueAtTime(freq, now + i * 0.08);
        g.gain.setValueAtTime(0.001, now + i * 0.08);
        g.gain.linearRampToValueAtTime(0.1, now + i * 0.08 + 0.05);
        g.gain.exponentialRampToValueAtTime(0.001, now + i * 0.08 + 1.2);
        o.start(now + i * 0.08);
        o.stop(now + i * 0.08 + 1.2);
      });
    }
  } catch (err) {
    console.warn("Audio guide tone error:", err);
  }
}

/**
 * Habla un texto con entonación pausada y natural.
 * Incluye compatibilidad robusta para Safari iOS, Tablets Android y navegadores móviles.
 */
export function speakTherapeuticVoice(text: string, onEnd?: () => void) {
  if (typeof window === "undefined") {
    if (onEnd) onEnd();
    return;
  }

  // Si el navegador no soporta síntesis de voz, emitimos tono armónico de apoyo
  if (!("speechSynthesis" in window)) {
    playTherapeuticTone("ding");
    if (onEnd) onEnd();
    return;
  }

  try {
    // Asegurar que el audio context esté despierto
    unlockAudioEngine();

    // En navegadores móviles, pausar antes de hablar para no encimar
    window.speechSynthesis.cancel();

    // Pequeño delay de 25ms para evitar el bug de cancelación inmediata de iOS Safari
    setTimeout(() => {
      try {
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = "es-CL"; // Español chileno preferente
        utterance.rate = 0.85; // Velocidad pausada, clara y relajante
        utterance.pitch = 0.95; // Tono grave y sereno
        utterance.volume = 1.0;

        // Seleccionar la mejor voz en español disponible
        if (cachedVoices.length === 0) {
          cachedVoices = window.speechSynthesis.getVoices();
        }

        const spanishVoice =
          cachedVoices.find((v) => v.lang === "es-CL") ||
          cachedVoices.find((v) => v.lang.startsWith("es-419")) ||
          cachedVoices.find((v) => v.lang.startsWith("es-MX")) ||
          cachedVoices.find((v) => v.lang.startsWith("es-ES")) ||
          cachedVoices.find((v) => v.lang.startsWith("es"));

        if (spanishVoice) {
          utterance.voice = spanishVoice;
        }

        utterance.onend = () => {
          if (onEnd) onEnd();
        };

        utterance.onerror = (e) => {
          console.warn("Speech synthesis notice:", e);
          if (onEnd) onEnd();
        };

        window.speechSynthesis.speak(utterance);
      } catch (innerErr) {
        console.warn("Utterance error:", innerErr);
        if (onEnd) onEnd();
      }
    }, 25);
  } catch (err) {
    console.warn("Speech error:", err);
    if (onEnd) onEnd();
  }
}

/**
 * Detiene la reproducción de voz de forma segura
 */
export function stopTherapeuticVoice() {
  if (typeof window !== "undefined" && "speechSynthesis" in window) {
    try {
      window.speechSynthesis.cancel();
    } catch (e) {}
  }
}
