import { jsPDF } from "jspdf";
import html2canvas from "html2canvas";

export interface GeneratePdfOptions {
  filename?: string;
  title?: string;
}

export async function exportElementToPdf(
  elementIdOrElement: string | HTMLElement,
  options: GeneratePdfOptions = {}
): Promise<void> {
  const element =
    typeof elementIdOrElement === "string"
      ? document.getElementById(elementIdOrElement)
      : elementIdOrElement;

  if (!element) {
    throw new Error("No se encontró el elemento para generar el PDF.");
  }

  const filename = options.filename || `COSAM_Documento_${Date.now()}.pdf`;

  const container = document.createElement("div");
  container.style.position = "fixed";
  container.style.left = "-9999px";
  container.style.top = "0";
  container.style.width = "794px";
  container.style.background = "#ffffff";
  container.style.color = "#000000";
  container.style.padding = "36px 40px";
  container.style.fontFamily = "'Plus Jakarta Sans', Arial, sans-serif";
  container.style.boxSizing = "border-box";
  container.style.zIndex = "-1000";

  const clone = element.cloneNode(true) as HTMLElement;

  clone.classList.remove("hidden", "print-only");
  clone.style.display = "block";
  clone.style.visibility = "visible";
  clone.style.width = "100%";
  clone.style.margin = "0";
  clone.style.padding = "0";

  container.appendChild(clone);
  document.body.appendChild(container);

  try {
    const canvas = await html2canvas(container, {
      scale: 2,
      useCORS: true,
      logging: false,
      backgroundColor: "#ffffff",
      windowWidth: 794,
    });

    const imgData = canvas.toDataURL("image/jpeg", 0.95);
    const pdf = new jsPDF({
      orientation: "portrait",
      unit: "mm",
      format: "a4",
    });

    const pageWidth = 210;
    const pageHeight = 297;
    const margin = 10;
    const contentWidth = pageWidth - margin * 2;
    const contentHeight = (canvas.height * contentWidth) / canvas.width;

    let heightLeft = contentHeight;
    let position = margin;

    pdf.addImage(imgData, "JPEG", margin, position, contentWidth, contentHeight);
    heightLeft -= pageHeight - margin * 2;

    while (heightLeft > 0) {
      position = heightLeft - contentHeight + margin;
      pdf.addPage();
      pdf.addImage(imgData, "JPEG", margin, position, contentWidth, contentHeight);
      heightLeft -= pageHeight - margin * 2;
    }

    pdf.save(filename);
  } finally {
    document.body.removeChild(container);
  }
}
