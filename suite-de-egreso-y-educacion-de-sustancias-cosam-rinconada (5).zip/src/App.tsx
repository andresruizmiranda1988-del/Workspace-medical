import { useState, useEffect } from "react";
import DashboardCentral from "./components/DashboardCentral";
import NeurobiologiaAdiccion from "./components/NeurobiologiaAdiccion";
import SimuladorCircuitoRecompensa from "./components/SimuladorCircuitoRecompensa";
import PanelNeuroplasticidad from "./components/PanelNeuroplasticidad";
import AtlasFisiopatologia from "./components/AtlasFisiopatologia";
import TableroSistemico from "./components/TableroSistemico";
import RadarSustancias from "./components/RadarSustancias";
import SintomatologiaClinica from "./components/SintomatologiaClinica";
import NutricionMicrorrehabilitacion from "./components/NutricionMicrorrehabilitacion";
import DashboardSustancias from "./components/DashboardSustancias";
import GatillantesYAfrontamiento from "./components/GatillantesYAfrontamiento";
import ModoPsicoeducacionBox from "./components/ModoPsicoeducacionBox";
import PantallaBloqueoBox from "./components/PantallaBloqueoBox";
import PacienteAfrontamientoStandalone from "./components/PacienteAfrontamientoStandalone";
import VistaPacienteDualProyeccion from "./components/VistaPacienteDualProyeccion";
import EcosistemasCivico from "./components/EcosistemasCivico";
import ClinicalGateway from "./components/ClinicalGateway";
import WorkspaceRayen from "./components/WorkspaceRayen";
import ResumenClinicoPDF from "./components/ResumenClinicoPDF";
import { SidebarTooltip, TooltipItemInfo } from "./components/SidebarTooltip";
import { motion, AnimatePresence } from "motion/react";
import {
  LayoutDashboard,
  Brain,
  Layers,
  AlertCircle,
  Apple,
  FileSpreadsheet,
  Tv2,
  Stethoscope,
  Activity,
  CheckCircle,
  ShieldCheck,
  FileText,
  Flame,
  SlidersHorizontal,
  Moon,
  Sun,
  TrendingUp,
  Printer,
  ChevronRight,
  Menu,
  X,
  PanelLeftClose,
  PanelLeftOpen,
  HelpCircle,
  Building2,
  Sparkles,
  Lock,
  Smartphone,
  QrCode,
  Grid,
  Maximize2,
  Minimize2,
  Type,
  Battery,
  BatteryCharging
} from "lucide-react";
import { unlockAudioEngine } from "./utils/audioGuide";

// VARIANTES DE ANIMACIÓN PARA TRANSICIONES ENTRE MÓDULOS
const tabVariants: any = {
  initial: {
    opacity: 0,
    y: 12,
    scale: 0.994,
    filter: "blur(3px)",
  },
  animate: {
    opacity: 1,
    y: 0,
    scale: 1,
    filter: "blur(0px)",
    transition: {
      duration: 0.28,
      ease: "easeOut",
    },
  },
  exit: {
    opacity: 0,
    y: -8,
    scale: 0.996,
    filter: "blur(2px)",
    transition: {
      duration: 0.16,
      ease: "easeIn",
    },
  },
};

interface NavGroup {
  groupName: string;
  orderNumber: string;
  items: {
    id: string;
    label: string;
    sub: string;
    icon: any;
    badge?: string;
    isSpecial?: boolean;
    quickDesc: string;
  }[];
}

export default function App() {
  const [workspaceMode, setWorkspaceMode] = useState<"gateway" | "clinico" | "psicoeducacion">("gateway");
  const [activeTab, setActiveTab] = useState<
    | "dashboard"
    | "ecosistemas_civico"
    | "neurobiologia"
    | "simulador"
    | "neuroplasticidad"
    | "atlas"
    | "sistemas"
    | "neurometabolix"
    | "sintomas"
    | "nutricion"
    | "sustancias"
    | "gatillantes_afrontamiento"
    | "pausa_sos"
    | "proyector"
    | "workspace"
    | "resumen_pdf"
  >("dashboard");

  const [notification, setNotification] = useState<string | null>(null);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem("cosam_sidebar_collapsed");
      return saved === "true";
    } catch {
      return false;
    }
  });

  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState<boolean>(false);
  const [isBoxLocked, setIsBoxLocked] = useState<boolean>(false);
  const [hoveredNavTooltip, setHoveredNavTooltip] = useState<{
    item: TooltipItemInfo;
    position: { top: number; left: number };
  } | null>(null);

  // Detección de enlace exclusivo para el paciente (/paciente, ?modulo=afrontamiento o ?paciente=sos)
  const isPatientRoute = () => {
    if (typeof window === "undefined") return false;
    const path = window.location.pathname.toLowerCase();
    const search = window.location.search.toLowerCase();
    const hash = window.location.hash.toLowerCase();

    return (
      path === "/paciente" ||
      path.startsWith("/paciente/") ||
      path === "/afrontamiento" ||
      path.startsWith("/afrontamiento/") ||
      search.includes("modulo=afrontamiento") ||
      search.includes("paciente=sos") ||
      search.includes("paciente=afrontamiento") ||
      search.includes("vista=paciente") ||
      search.includes("modulo=gatillantes") ||
      search.includes("mode=paciente") ||
      search.includes("view=paciente") ||
      hash.includes("paciente") ||
      hash.includes("afrontamiento")
    );
  };

  const isDualProjectionRoute = () => {
    if (typeof window === "undefined") return false;
    const search = window.location.search.toLowerCase();
    const hash = window.location.hash.toLowerCase();
    return (
      search.includes("view=paciente_dual") ||
      search.includes("vista=dual_paciente") ||
      search.includes("mode=proyector_paciente") ||
      search.includes("vista=proyeccion") ||
      hash.includes("paciente_dual") ||
      hash.includes("proyeccion_dual")
    );
  };

  const [isPatientOnlyMode, setIsPatientOnlyMode] = useState<boolean>(() => {
    return isPatientRoute();
  });

  const [isDualProjectionMode, setIsDualProjectionMode] = useState<boolean>(() => {
    return isDualProjectionRoute();
  });

  // Listener para sincronización con navegación hacia adelante/atrás en el navegador
  useEffect(() => {
    const handleUrlChange = () => {
      setIsPatientOnlyMode(isPatientRoute());
      setIsDualProjectionMode(isDualProjectionRoute());
    };
    window.addEventListener("popstate", handleUrlChange);
    window.addEventListener("hashchange", handleUrlChange);
    return () => {
      window.removeEventListener("popstate", handleUrlChange);
      window.removeEventListener("hashchange", handleUrlChange);
    };
  }, []);

  const handleOpenPatientView = () => {
    try {
      window.history.pushState({}, "", "/paciente?modulo=afrontamiento");
    } catch {
      // Ignorar en entornos restringidos
    }
    setIsPatientOnlyMode(true);
  };

  const handleExitPatientView = () => {
    try {
      window.history.pushState({}, "", "/");
    } catch {
      // Ignorar en entornos restringidos
    }
    setIsPatientOnlyMode(false);
  };

  const [isNightMode, setIsNightMode] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem("cosam_night_mode");
      return saved === "true";
    } catch {
      return false;
    }
  });

  // Tamaño de texto y accesibilidad visual para visualización en tablet / box
  const [textScale, setTextScale] = useState<"normal" | "large" | "xlarge">(() => {
    try {
      const saved = localStorage.getItem("cosam_text_scale");
      if (saved === "large" || saved === "xlarge" || saved === "normal") return saved;
      return "normal";
    } catch {
      return "normal";
    }
  });

  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [isCompactTabletMode, setIsCompactTabletMode] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem("cosam_compact_tablet");
      return saved === "true";
    } catch {
      return false;
    }
  });

  // Efecto para aplicar escala de texto accesible a document.documentElement
  useEffect(() => {
    try {
      document.documentElement.classList.remove("text-scale-normal", "text-scale-large", "text-scale-xlarge");
      document.documentElement.classList.add(`text-scale-${textScale}`);
      localStorage.setItem("cosam_text_scale", textScale);
    } catch (e) {
      console.error(e);
    }
  }, [textScale]);

  // Efecto para aplicar modo compacto en body
  useEffect(() => {
    try {
      if (isCompactTabletMode) {
        document.body.classList.add("compact-tablet-mode");
      } else {
        document.body.classList.remove("compact-tablet-mode");
      }
      localStorage.setItem("cosam_compact_tablet", String(isCompactTabletMode));
    } catch (e) {
      console.error(e);
    }
  }, [isCompactTabletMode]);

  const [isBatterySaverMode, setIsBatterySaverMode] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem("cosam_battery_saver");
      return saved === "true";
    } catch {
      return false;
    }
  });

  // Efecto para aplicar modo ahorro de batería
  useEffect(() => {
    try {
      if (isBatterySaverMode) {
        document.body.classList.add("battery-saver-mode");
      } else {
        document.body.classList.remove("battery-saver-mode");
      }
      localStorage.setItem("cosam_battery_saver", String(isBatterySaverMode));
    } catch (e) {
      console.error(e);
    }
  }, [isBatterySaverMode]);

  const toggleBatterySaverMode = () => {
    setIsBatterySaverMode((prev) => {
      const next = !prev;
      showNotification(next ? "🔋 Ahorro de batería activado (Sin desenfoques ni animaciones pesadas)" : "⚡ Rendimiento estándar activado (Efectos visuales habilitados)");
      return next;
    });
  };

  // Listener para estado de pantalla completa nativo
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener("fullscreenchange", handleFullscreenChange);
    return () => document.removeEventListener("fullscreenchange", handleFullscreenChange);
  }, []);

  const toggleFullscreen = () => {
    try {
      if (!document.fullscreenElement) {
        document.documentElement.requestFullscreen().catch(() => {});
        showNotification("⛶ Modo Pantalla Completa activado (Maximiza espacio en tablet)");
      } else {
        if (document.exitFullscreen) {
          document.exitFullscreen().catch(() => {});
        }
      }
    } catch (e) {
      console.error(e);
    }
  };

  const cycleTextScale = () => {
    setTextScale((prev) => {
      if (prev === "normal") {
        showNotification("🔎 Texto ampliado a 115% (Mejor legibilidad en tablet)");
        return "large";
      }
      if (prev === "large") {
        showNotification("🔍 Texto ampliado a 130% (Máxima legibilidad y descanso visual)");
        return "xlarge";
      }
      showNotification("🔎 Tamaño de texto estándar (100%)");
      return "normal";
    });
  };

  const toggleCompactTabletMode = () => {
    setIsCompactTabletMode((prev) => {
      const next = !prev;
      showNotification(next ? "📐 Modo Compacto Tablet activado (Ahorra espacio vertical)" : "📐 Modo Estándar activado");
      return next;
    });
  };

  // Atajo de teclado global para bloquear el box (Ctrl+L o Cmd+L)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && (e.key === "l" || e.key === "L")) {
        e.preventDefault();
        setIsBoxLocked(true);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  // Desbloqueo pasivo de audio en primera interacción táctil o click
  useEffect(() => {
    const handleFirstInteraction = () => {
      unlockAudioEngine();
    };
    window.addEventListener("touchstart", handleFirstInteraction, { once: true });
    window.addEventListener("click", handleFirstInteraction, { once: true });
    return () => {
      window.removeEventListener("touchstart", handleFirstInteraction);
      window.removeEventListener("click", handleFirstInteraction);
    };
  }, []);

  useEffect(() => {
    try {
      if (isNightMode) {
        document.documentElement.classList.add("night-mode", "dark");
      } else {
        document.documentElement.classList.remove("night-mode", "dark");
      }
    } catch (e) {
      console.error(e);
    }
  }, [isNightMode]);

  const toggleNightMode = () => {
    setIsNightMode((prev) => {
      const next = !prev;
      try {
        localStorage.setItem("cosam_night_mode", String(next));
      } catch (e) {
        console.error(e);
      }
      showNotification(
        next
          ? "🌙 Modo Noche Clínico activado: Alto contraste y descanso visual"
          : "☀️ Modo Día Clínico activado"
      );
      return next;
    });
  };

  const toggleSidebar = () => {
    setIsSidebarCollapsed((prev) => {
      const next = !prev;
      try {
        localStorage.setItem("cosam_sidebar_collapsed", String(next));
      } catch (e) {
        console.error(e);
      }
      return next;
    });
  };

  const showNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => {
      setNotification(null);
    }, 4000);
  };

  const handleNavigate = (tabId: typeof activeTab) => {
    setActiveTab(tabId);
    setHoveredNavTooltip(null);
    if (tabId === "proyector") {
      setIsSidebarCollapsed(true);
    }
  };

  // NAVEGACIÓN REORGANIZADA: 3 GRUPOS CLÍNICOS LÓGICOS SIN REDUNDANCIAS
  const navGroups: NavGroup[] = [
    {
      groupName: "Atención Médica",
      orderNumber: "1",
      items: [
        {
          id: "dashboard",
          label: "Dashboard",
          sub: "Resumen y actividad",
          icon: LayoutDashboard,
          quickDesc: "Visión integral del box, atajos de consulta y métricas clínicas."
        },
        {
          id: "ecosistemas_civico",
          label: "Clínica & IA",
          sub: "SOAP, PAI, Ashton",
          icon: Building2,
          quickDesc: "Plataforma clínica unificada: SOAP, PAI, Laboratorio IA, Ashton y derivaciones."
        }
      ]
    },
    {
      groupName: "Psicoeducación",
      orderNumber: "2",
      items: [
        {
          id: "proyector",
          label: "Proyector Paciente",
          sub: "Pantalla compartida",
          icon: Tv2,
          isSpecial: true,
          quickDesc: "Diapositivas clínicas y temporizador de surfeo de ola para el paciente."
        },
        {
          id: "gatillantes_afrontamiento",
          label: "Gatillantes & SOS",
          sub: "H.A.L.T. y respiración",
          icon: ShieldCheck,
          quickDesc: "Identificación de triggers, respirador bioacústico 4-2-6 y protocolo de rescate."
        },
        {
          id: "simulador",
          label: "Simulador Dopamina",
          sub: "Dinámica de receptores",
          icon: SlidersHorizontal,
          quickDesc: "Simulación interactiva de liberación de dopamina y receptores D2."
        },
        {
          id: "neuroplasticidad",
          label: "Recuperación & BDNF",
          sub: "Líneas de tiempo",
          icon: TrendingUp,
          quickDesc: "Líneas de tiempo biológicas y estimulación de neuroplasticidad con hábitos."
        }
      ]
    },
    {
      groupName: "Fisiopatología & Guías",
      orderNumber: "3",
      items: [
        {
          id: "neurobiologia",
          label: "Bases Biológicas",
          sub: "Circuito de recompensa",
          icon: Brain,
          quickDesc: "Mecanismo neurobiológico de la adicción, dianas sinápticas y perlas médicas."
        },
        {
          id: "atlas",
          label: "Atlas Orgánico",
          sub: "Fisiopatología clínica",
          icon: Stethoscope,
          quickDesc: "Fisiopatología del daño orgánico, inflamación y pautas médicas en box."
        },
        {
          id: "sistemas",
          label: "Impacto Sistémico",
          sub: "Afectación multiorgánica",
          icon: Layers,
          quickDesc: "Afectación cardiovascular, hepática, endocrina, renal e inmune."
        },
        {
          id: "neurometabolix",
          label: "Toxicología",
          sub: "Ventanas biológicas",
          icon: Flame,
          quickDesc: "Radar de neurotoxicidad por sustancia y ventanas de reversibilidad biológica."
        },
        {
          id: "sustancias",
          label: "Sustancias",
          sub: "Cinética y toxicología",
          icon: FileSpreadsheet,
          quickDesc: "Farmacocinética, metabolitos y perlas clínicas por sustancia (PBC, alcohol, etc.)."
        },
        {
          id: "sintomas",
          label: "Banderas Rojas",
          sub: "Alertas y derivación",
          icon: AlertCircle,
          quickDesc: "Signos clínicos, banderas rojas urgentes y tiempos de resolución en COSAM."
        },
        {
          id: "nutricion",
          label: "Nutrición & Sueño",
          sub: "Protocolo micronutricional",
          icon: Apple,
          quickDesc: "Reposición con Tiamina, Bisglicinato de Magnesio y pauta micronutricional."
        }
      ]
    }
  ];

  const filteredNavGroups = navGroups;

  // SI LA RUTA ES DE PROYECCIÓN LIMPIA / PANTALLA DUAL EXCLUSIVA PARA EL PACIENTE
  if (isDualProjectionMode) {
    return (
      <VistaPacienteDualProyeccion
        onClose={() => {
          try {
            window.history.pushState({}, "", "/");
          } catch {
            // ignore
          }
          setIsDualProjectionMode(false);
        }}
      />
    );
  }

  // SI EL ENLACE ES DIRECTO PARA EL PACIENTE (MODO MÓVIL DE BOLSILLO / VISTA INDEPENDIENTE)
  if (isPatientOnlyMode) {
    return (
      <PacienteAfrontamientoStandalone
        onExitPatientMode={handleExitPatientView}
        isNightMode={isNightMode}
        onToggleNightMode={toggleNightMode}
      />
    );
  }

  // PORTAL INICIAL DE SELECCIÓN DE ENTORNO
  if (workspaceMode === "gateway") {
    return (
      <>
        <PantallaBloqueoBox
          isLocked={isBoxLocked}
          onUnlock={() => setIsBoxLocked(false)}
        />
        <ClinicalGateway
          onLockBox={() => setIsBoxLocked(true)}
          onSelectMode={(mode) => {
            if (mode === "clinico") {
              setWorkspaceMode("clinico");
              setActiveTab("ecosistemas_civico");
            } else {
              setWorkspaceMode("psicoeducacion");
              setActiveTab("proyector");
            }
          }}
        />
      </>
    );
  }

  return (
    <div className={`bg-ambient-light min-h-screen text-slate-900 flex flex-col font-sans select-none antialiased relative overflow-x-hidden ${isCompactTabletMode ? "compact-tablet-mode" : ""}`}>
      
      {/* PANTALLA DE BLOQUEO DE BOX CON PIN Y HORARIOS */}
      <PantallaBloqueoBox
        isLocked={isBoxLocked}
        onUnlock={() => setIsBoxLocked(false)}
      />

      {/* TOP HEADER GLOBAL: MINIMALISTA, SERENO Y CLÍNICO */}
      <header className="sticky top-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 px-4 lg:px-6 py-2 flex items-center justify-between gap-4 transition-colors">
        
        {/* Lado Izquierdo: Toggle Mobile + Toggle Desktop + Título */}
        <div className="flex items-center gap-3">
          {/* Botón Drawer Mobile */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="lg:hidden p-1.5 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            title="Abrir menú"
          >
            {isMobileMenuOpen ? <X size={18} strokeWidth={1.75} /> : <Menu size={18} strokeWidth={1.75} />}
          </button>

          {/* Toggle Colapsar Sidebar en Desktop */}
          <button
            onClick={toggleSidebar}
            className="hidden lg:flex p-1.5 rounded-lg text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors items-center justify-center cursor-pointer"
            title={isSidebarCollapsed ? "Expandir navegación" : "Colapsar navegación"}
          >
            {isSidebarCollapsed ? <PanelLeftOpen size={17} strokeWidth={1.75} /> : <PanelLeftClose size={17} strokeWidth={1.75} />}
          </button>

          {/* Logotipo y Título de Entorno */}
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 flex items-center justify-center font-bold text-xs tracking-tight shadow-xs shrink-0">
              CR
            </div>
            <div className="leading-tight">
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-semibold text-slate-900 dark:text-white tracking-tight">
                  COSAM Rinconada
                </span>
                <span className="text-[10px] text-slate-400 dark:text-slate-500">
                  · San Ramón
                </span>
              </div>
              <div className="text-[11px] text-slate-500 dark:text-slate-400">
                {workspaceMode === "clinico" ? "Atención Médica" : "Psicoeducación en Box"}
              </div>
            </div>
          </div>
        </div>

        {/* Lado Derecho: Acciones de Box + Accesibilidad + Perfil Médico */}
        <div className="flex items-center gap-2 sm:gap-2.5 shrink-0">
          {/* Grupo de Acciones de Box */}
          <div className="flex items-center bg-slate-100 dark:bg-slate-800/80 p-0.5 rounded-lg border border-slate-200/80 dark:border-slate-700/60">
            {/* BOTÓN PORTAL */}
            <button
              onClick={() => setWorkspaceMode("gateway")}
              className="flex items-center gap-1.5 h-7 px-2.5 rounded-md bg-white dark:bg-slate-900 text-slate-900 dark:text-white text-xs font-medium shadow-xs transition-colors cursor-pointer"
              title="Volver al Portal de Selección"
            >
              <Grid size={13} strokeWidth={1.75} className="text-slate-500 shrink-0" />
              <span className="hidden sm:inline">Portal</span>
            </button>

            {/* BOTÓN VISTA PACIENTE */}
            <button
              onClick={handleOpenPatientView}
              className="hidden md:flex items-center gap-1.5 h-7 px-2.5 rounded-md hover:bg-white/60 dark:hover:bg-slate-900/60 text-slate-600 dark:text-slate-300 text-xs font-medium transition-colors cursor-pointer"
              title="Abrir vista móvil de paciente"
            >
              <Smartphone size={13} strokeWidth={1.75} className="text-slate-500 shrink-0" />
              <span>Vista Paciente</span>
            </button>

            {/* BOTÓN BLOQUEAR BOX */}
            <button
              onClick={() => setIsBoxLocked(true)}
              className="h-7 px-2 sm:px-2.5 rounded-md hover:bg-rose-50 dark:hover:bg-rose-950/30 text-slate-600 hover:text-rose-600 dark:text-slate-300 dark:hover:text-rose-400 text-xs font-medium transition-colors flex items-center gap-1 cursor-pointer"
              title="Bloquear pantalla (Ctrl + L)"
            >
              <Lock size={12} strokeWidth={1.75} className="shrink-0 text-slate-400" />
              <span className="hidden lg:inline text-[11px]">Bloquear</span>
            </button>
          </div>

          <div className="h-4 w-px bg-slate-200 dark:bg-slate-800 hidden sm:block" />

          {/* Grupo de Accesibilidad y Pantalla */}
          <div className="flex items-center bg-slate-100 dark:bg-slate-800/80 p-0.5 rounded-lg border border-slate-200/80 dark:border-slate-700/60">
            {/* ESCALA DE TEXTO */}
            <button
              onClick={cycleTextScale}
              className="h-7 px-2 rounded-md hover:bg-white dark:hover:bg-slate-900 text-slate-600 dark:text-slate-300 text-xs font-medium transition-colors cursor-pointer flex items-center gap-1"
              title={`Tamaño de fuente actual: ${textScale === "normal" ? "100%" : textScale === "large" ? "115%" : "130%"}`}
            >
              <Type size={12} strokeWidth={1.75} className="text-slate-500" />
              <span className="text-[10px] font-semibold">
                {textScale === "normal" ? "A" : textScale === "large" ? "A+" : "A++"}
              </span>
            </button>

            {/* MODO CLARO / OSCURO */}
            <button
              onClick={toggleNightMode}
              title={isNightMode ? "Cambiar a Modo Claro" : "Cambiar a Modo Oscuro"}
              className="w-7 h-7 rounded-md hover:bg-white dark:hover:bg-slate-900 text-slate-600 dark:text-slate-300 flex items-center justify-center transition-colors cursor-pointer"
            >
              {isNightMode ? <Moon size={13} strokeWidth={1.75} /> : <Sun size={13} strokeWidth={1.75} />}
            </button>

            {/* AHORRO DE BATERÍA */}
            <button
              onClick={toggleBatterySaverMode}
              title={isBatterySaverMode ? "Ahorro de batería activo" : "Activar ahorro de batería"}
              className={`w-7 h-7 rounded-md flex items-center justify-center transition-colors cursor-pointer ${
                isBatterySaverMode
                  ? "bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900"
                  : "hover:bg-white dark:hover:bg-slate-900 text-slate-600 dark:text-slate-300"
              }`}
            >
              {isBatterySaverMode ? <BatteryCharging size={13} strokeWidth={1.75} /> : <Battery size={13} strokeWidth={1.75} />}
            </button>

            {/* PANTALLA COMPLETA */}
            <button
              onClick={toggleFullscreen}
              className="hidden sm:flex w-7 h-7 rounded-md hover:bg-white dark:hover:bg-slate-900 text-slate-600 dark:text-slate-300 items-center justify-center transition-colors cursor-pointer"
              title={isFullscreen ? "Salir de pantalla completa" : "Pantalla completa"}
            >
              {isFullscreen ? <Minimize2 size={12} strokeWidth={1.75} /> : <Maximize2 size={12} strokeWidth={1.75} />}
            </button>
          </div>

          <div className="h-4 w-px bg-slate-200 dark:bg-slate-800 hidden sm:block" />

          {/* PERFIL DEL PROFESIONAL */}
          <div className="bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200 h-7.5 px-2.5 rounded-lg flex items-center gap-2 border border-slate-200 dark:border-slate-800 shrink-0 shadow-xs">
            <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block" />
            <span className="text-xs font-medium text-slate-800 dark:text-slate-200 hidden sm:inline">
              Dr. Andrés Ruiz
            </span>
          </div>
        </div>
      </header>

      {/* CONTENEDOR PRINCIPAL: SIDEBAR + ÁREA DE CONTENIDO */}
      <div className="flex-1 flex w-full relative">
        
        {/* =====================================================================
            MENÚ LATERAL IZQUIERDO (DESKTOP) ESTILO MINIMALISTA Y SOBRIO
           ===================================================================== */}
        <motion.aside
          initial={false}
          animate={{
            width: isSidebarCollapsed ? 68 : 240,
          }}
          transition={{
            duration: 0.18,
            ease: "easeInOut",
          }}
          className="hidden lg:flex flex-col shrink-0 sticky top-[45px] h-[calc(100vh-45px)] border-r border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-950/60 p-2.5 z-20 overflow-y-auto overflow-x-hidden select-none"
          onScroll={() => setHoveredNavTooltip(null)}
        >
          <div className="space-y-4 flex-1">
            {filteredNavGroups.map((group, gIdx) => (
              <div key={gIdx} className="space-y-0.5">
                <AnimatePresence mode="wait">
                  {!isSidebarCollapsed ? (
                    <div className="px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500 mb-0.5 whitespace-nowrap">
                      {group.groupName}
                    </div>
                  ) : (
                    <div className="text-center text-[9px] font-bold text-slate-400 dark:text-slate-500 uppercase my-1">
                      {group.orderNumber}
                    </div>
                  )}
                </AnimatePresence>

                <div className="space-y-0.5">
                  {group.items.map((item) => {
                    const Icon = item.icon;
                    const isActive = activeTab === item.id;
                    return (
                      <button
                        key={item.id}
                        onMouseEnter={(e) => {
                          const rect = e.currentTarget.getBoundingClientRect();
                          setHoveredNavTooltip({
                            item: {
                              id: item.id,
                              label: item.label,
                              sub: item.sub,
                              quickDesc: item.quickDesc,
                              badge: item.badge,
                              icon: item.icon,
                              orderNumber: group.orderNumber,
                              groupName: group.groupName,
                              isSpecial: item.isSpecial,
                            },
                            position: {
                              top: rect.top + rect.height / 2,
                              left: rect.right + 10,
                            },
                          });
                        }}
                        onMouseLeave={() => setHoveredNavTooltip(null)}
                        onClick={() => {
                          setHoveredNavTooltip(null);
                          handleNavigate(item.id as any);
                        }}
                        className={`w-full py-2 px-2.5 rounded-lg transition-colors text-left flex items-center gap-2.5 relative group cursor-pointer ${
                          isActive
                            ? "bg-slate-900 dark:bg-white text-white dark:text-slate-900 shadow-xs"
                            : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-850/60"
                        }`}
                      >
                        <div className="shrink-0 flex items-center justify-center">
                          <Icon size={16} strokeWidth={isActive ? 2 : 1.75} />
                        </div>

                        {!isSidebarCollapsed && (
                          <div className="overflow-hidden flex-1 leading-tight whitespace-nowrap">
                            <div className="text-xs font-medium truncate">
                              {item.label}
                            </div>
                            <div className={`text-[10px] truncate mt-0.5 ${isActive ? "text-slate-300 dark:text-slate-600" : "text-slate-400 dark:text-slate-500"}`}>
                              {item.sub}
                            </div>
                          </div>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>

          {!isSidebarCollapsed && (
            <div className="pt-2.5 border-t border-slate-200 dark:border-slate-800 mt-2">
              <div className="px-2.5 py-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 text-[11px] text-slate-500 dark:text-slate-400">
                <div className="font-semibold text-slate-800 dark:text-slate-200">COSAM Rinconada</div>
                <div className="text-[10px] text-slate-400 dark:text-slate-500">San Ramón · Red SSMSO</div>
              </div>
            </div>
          )}
        </motion.aside>

        {/* TOOLTIP FLOTANTE PERSONALIZADO PARA ITEMS DEL SIDEBAR */}
        <SidebarTooltip
          item={hoveredNavTooltip?.item ?? null}
          position={hoveredNavTooltip?.position ?? null}
        />

        {/* =====================================================================
            DRAWER MÓVIL (PANTALLAS PEQUEÑAS)
           ===================================================================== */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <>
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setIsMobileMenuOpen(false)}
                className="lg:hidden fixed inset-0 bg-slate-950/40 backdrop-blur-xs z-40"
              />

              <motion.div
                initial={{ x: "-100%" }}
                animate={{ x: 0 }}
                exit={{ x: "-100%" }}
                transition={{ duration: 0.2, ease: "easeOut" }}
                className="lg:hidden fixed top-0 bottom-0 left-0 w-72 max-w-[80vw] bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 z-50 p-4 flex flex-col justify-between shadow-xl overflow-y-auto"
              >
                <div className="space-y-4">
                  <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
                    <div className="flex items-center gap-2.5">
                      <div className="w-7 h-7 rounded-lg bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 flex items-center justify-center font-bold text-xs">
                        CR
                      </div>
                      <div>
                        <h3 className="text-xs font-semibold text-slate-900 dark:text-white">
                          COSAM Rinconada
                        </h3>
                        <span className="text-[10px] text-slate-400 dark:text-slate-500">
                          San Ramón
                        </span>
                      </div>
                    </div>
                    <button
                      onClick={() => setIsMobileMenuOpen(false)}
                      className="p-1 rounded-md text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
                    >
                      <X size={16} />
                    </button>
                  </div>

                  <div className="space-y-3">
                    {/* BOTÓN RÁPIDO VISTA PACIENTE EN MÓVIL */}
                    <button
                      onClick={() => {
                        handleOpenPatientView();
                        setIsMobileMenuOpen(false);
                      }}
                      className="w-full p-2 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-left flex items-center gap-2 cursor-pointer border border-slate-200 dark:border-slate-700"
                    >
                      <Smartphone size={15} className="text-slate-500" />
                      <div>
                        <div className="text-xs font-semibold">Guía Móvil Paciente</div>
                        <div className="text-[10px] text-slate-500 dark:text-slate-400">
                          Vista de bolsillo en box
                        </div>
                      </div>
                    </button>

                    {filteredNavGroups.map((group, idx) => (
                      <div key={idx} className="space-y-1">
                        <div className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500 px-2 pt-1">
                          {group.groupName}
                        </div>
                        {group.items.map((item) => {
                          const Icon = item.icon;
                          const isActive = activeTab === item.id;
                          return (
                            <button
                              key={item.id}
                              onClick={() => {
                                handleNavigate(item.id as any);
                                setIsMobileMenuOpen(false);
                              }}
                              className={`w-full p-2 rounded-lg text-left flex items-center gap-2.5 cursor-pointer transition-colors ${
                                isActive
                                  ? "bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-semibold shadow-xs"
                                  : "text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 font-medium"
                              }`}
                            >
                              <Icon size={15} strokeWidth={isActive ? 2 : 1.75} />
                              <div className="leading-tight">
                                <div className="text-xs">{item.label}</div>
                                <div className="text-[10px] opacity-70">{item.sub}</div>
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-200 dark:border-slate-800 text-[10px] text-slate-400 dark:text-slate-500 text-center">
                  COSAM Rinconada · San Ramón
                </div>
              </motion.div>
            </>
          )}
        </AnimatePresence>

        {/* =====================================================================
            ÁREA DE CONTENIDO CENTRAL CON ANIMACIÓN DE TRANSICIÓN
           ===================================================================== */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 min-h-[calc(100vh-53px)] overflow-x-hidden">
          <AnimatePresence mode="wait">
            {activeTab === "dashboard" && (
              <motion.div
                key="dashboard"
                variants={tabVariants}
                initial="initial"
                animate="animate"
                exit="exit"
                className="w-full"
              >
                <DashboardCentral onNavigate={handleNavigate} />
              </motion.div>
            )}

            {activeTab === "ecosistemas_civico" && (
              <motion.div
                key="ecosistemas_civico"
                variants={tabVariants}
                initial="initial"
                animate="animate"
                exit="exit"
                className="w-full"
              >
                <EcosistemasCivico />
              </motion.div>
            )}

            {activeTab === "workspace" && (
              <motion.div
                key="workspace"
                variants={tabVariants}
                initial="initial"
                animate="animate"
                exit="exit"
                className="w-full"
              >
                <WorkspaceRayen />
              </motion.div>
            )}

            {activeTab === "resumen_pdf" && (
              <motion.div
                key="resumen_pdf"
                variants={tabVariants}
                initial="initial"
                animate="animate"
                exit="exit"
                className="w-full"
              >
                <ResumenClinicoPDF />
              </motion.div>
            )}

            {activeTab === "neurobiologia" && (
              <motion.div
                key="neurobiologia"
                variants={tabVariants}
                initial="initial"
                animate="animate"
                exit="exit"
                className="w-full"
              >
                <NeurobiologiaAdiccion />
              </motion.div>
            )}

            {activeTab === "simulador" && (
              <motion.div
                key="simulador"
                variants={tabVariants}
                initial="initial"
                animate="animate"
                exit="exit"
                className="w-full"
              >
                <SimuladorCircuitoRecompensa />
              </motion.div>
            )}

            {activeTab === "neuroplasticidad" && (
              <motion.div
                key="neuroplasticidad"
                variants={tabVariants}
                initial="initial"
                animate="animate"
                exit="exit"
                className="w-full"
              >
                <PanelNeuroplasticidad />
              </motion.div>
            )}

            {activeTab === "atlas" && (
              <motion.div
                key="atlas"
                variants={tabVariants}
                initial="initial"
                animate="animate"
                exit="exit"
                className="w-full"
              >
                <AtlasFisiopatologia />
              </motion.div>
            )}

            {activeTab === "sistemas" && (
              <motion.div
                key="sistemas"
                variants={tabVariants}
                initial="initial"
                animate="animate"
                exit="exit"
                className="w-full"
              >
                <TableroSistemico />
              </motion.div>
            )}

            {activeTab === "neurometabolix" && (
              <motion.div
                key="neurometabolix"
                variants={tabVariants}
                initial="initial"
                animate="animate"
                exit="exit"
                className="w-full"
              >
                <RadarSustancias />
              </motion.div>
            )}

            {activeTab === "sintomas" && (
              <motion.div
                key="sintomas"
                variants={tabVariants}
                initial="initial"
                animate="animate"
                exit="exit"
                className="w-full"
              >
                <SintomatologiaClinica />
              </motion.div>
            )}

            {activeTab === "nutricion" && (
              <motion.div
                key="nutricion"
                variants={tabVariants}
                initial="initial"
                animate="animate"
                exit="exit"
                className="w-full"
              >
                <NutricionMicrorrehabilitacion />
              </motion.div>
            )}

            {activeTab === "sustancias" && (
              <motion.div
                key="sustancias"
                variants={tabVariants}
                initial="initial"
                animate="animate"
                exit="exit"
                className="w-full"
              >
                <DashboardSustancias />
              </motion.div>
            )}

            {(activeTab === "gatillantes_afrontamiento" || activeTab === "pausa_sos") && (
              <motion.div
                key="gatillantes_afrontamiento"
                variants={tabVariants}
                initial="initial"
                animate="animate"
                exit="exit"
                className="w-full"
              >
                <GatillantesYAfrontamiento />
              </motion.div>
            )}

            {activeTab === "proyector" && (
              <motion.div
                key="proyector"
                variants={tabVariants}
                initial="initial"
                animate="animate"
                exit="exit"
                className="w-full"
              >
                <ModoPsicoeducacionBox
                  isSidebarCollapsed={isSidebarCollapsed}
                  onToggleSidebar={(collapsed) => setIsSidebarCollapsed(collapsed)}
                  onExitToStandard={() => {
                    setActiveTab("dashboard");
                    setIsSidebarCollapsed(false);
                    showNotification("☀️ Retornando al Modo Consulta Estándar");
                  }}
                />
              </motion.div>
            )}
          </AnimatePresence>
        </main>
      </div>

      {/* NOTIFICACIÓN FLOTANTE */}
      <AnimatePresence>
        {notification && (
          <motion.div
            initial={{ opacity: 0, y: 24, x: "-50%" }}
            animate={{ opacity: 1, y: 0, x: "-50%" }}
            exit={{ opacity: 0, y: 24, x: "-50%" }}
            className="fixed bottom-6 left-1/2 transform -translate-x-1/2 bg-slate-900/95 backdrop-blur-md text-white px-6 py-3.5 rounded-2xl text-xs font-bold shadow-2xl z-50 flex items-center gap-3 border border-slate-800 max-w-md w-11/12 sm:w-auto"
          >
            <div className="w-5 h-5 bg-emerald-500 rounded-full flex items-center justify-center text-white shrink-0">
              <CheckCircle size={12} />
            </div>
            <span className="leading-tight">{notification}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* FOOTER INSTITUCIONAL */}
      <footer className="py-4 px-6 text-center text-[10px] font-bold text-slate-500 uppercase tracking-widest border-t border-purple-100 dark:border-slate-800 flex flex-col sm:flex-row justify-between items-center gap-2 bg-white/60 dark:bg-slate-900/60 backdrop-blur-md">
        <span>COSAM Rinconada • Centro de Salud Mental Comunitario (APS)</span>
        <span>Programa de Tratamiento Integral de Adicciones • Neurobiología y Terapéutica Clínica</span>
      </footer>
    </div>
  );
}
