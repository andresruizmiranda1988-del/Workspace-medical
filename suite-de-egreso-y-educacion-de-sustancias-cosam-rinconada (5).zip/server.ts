import express from "express";
import http from "http";
import path from "path";
import { WebSocketServer, WebSocket } from "ws";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, LiveServerMessage, Modality, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: true, limit: "50mb" }));

// Helper function to lazily initialize GoogleGenAI to avoid crashing on start if key is not yet set
let aiInstance: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error("La variable de entorno GEMINI_API_KEY es requerida.");
  }
  if (!aiInstance) {
    aiInstance = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiInstance;
}

// Helper para reintentar con gemini-3.1-flash-lite si el modelo principal está bajo alta demanda (503)
async function generateContentWithFallback(ai: GoogleGenAI, params: any) {
  const primaryModel = params.model || "gemini-3.8-flash";
  try {
    return await ai.models.generateContent({
      ...params,
      model: primaryModel,
    });
  } catch (err: any) {
    if (err?.status === 503 || err?.message?.includes("503") || err?.message?.includes("demand")) {
      console.warn(`[Gemini] Modelo ${primaryModel} con alta demanda (503). Alternando a gemini-3.1-flash-lite.`);
      return await ai.models.generateContent({
        ...params,
        model: "gemini-3.1-flash-lite",
      });
    }
    throw err;
  }
}

// 1. Endpoint para generación de informe de egreso clínico
app.post("/api/generar-informe", async (req: express.Request, res: express.Response) => {
  const { borrador } = req.body;
  if (!borrador || typeof borrador !== "string" || borrador.trim() === "") {
    return res.status(400).json({ error: "El borrador o nota informal es requerido." });
  }

  try {
    const ai = getGeminiClient();
    
    const prompt = `Eres un psiquiatra clínico o psicólogo del Programa de Adicciones de COSAM Rinconada.
Analiza la siguiente nota informal o telegrama rápido de egreso escrito por un colega y redacta el informe de egreso completo formal en tercera persona en español clínico.
Deduce razonablemente los campos que falten si no están explícitamente indicados, manteniendo un tono formal, profesional, empático y clínicamente preciso.

Nota informal de egreso:
"${borrador}"

Instrucciones estrictas para campos específicos:
- "motivo_egreso" debe ser exactamente uno de los siguientes: "Alta Terapeutica", "Alta Administrativa", "Abandono", "Derivacion".
- "eval_general_logro" debe ser exactamente uno de: "Logro Alto", "Logro Medio", "Logro Bajo".
- "consumo_patron" debe ser exactamente uno de: "Abstinencia", "Disminucion de Consumo", "Mantencion de Consumo".
- Los logros de ámbitos (familiar, interpersonal, norma, ocupacional) deben ser exactamente: "Logro Alto", "Logro Medio", "Logro Bajo".
- Si no hay información para un campo de observaciones, redacta una apreciación clínica estándar positiva/esperable de acuerdo al contexto general presentado.
- Para el paciente_nombre, paciente_rut, paciente_domicilio, paciente_nacimiento, fecha_ingreso y fecha_egreso: si se mencionan en la nota informal o se pueden inferir, utilízalos. Si no se especifican en absoluto, déjalos como cadena vacía.`;

    const response = await generateContentWithFallback(ai, {
      model: "gemini-3.8-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            paciente_nombre: { type: Type.STRING },
            paciente_rut: { type: Type.STRING },
            paciente_domicilio: { type: Type.STRING },
            paciente_nacimiento: { type: Type.STRING, description: "Fecha de nacimiento en formato YYYY-MM-DD o vacío" },
            fecha_ingreso: { type: Type.STRING, description: "Fecha de ingreso en formato YYYY-MM-DD o vacío" },
            fecha_egreso: { type: Type.STRING, description: "Fecha de egreso en formato YYYY-MM-DD o vacío" },
            motivo_egreso: { type: Type.STRING, description: "Uno de: Alta Terapeutica, Alta Administrativa, Abandono, Derivacion" },
            eval_general_logro: { type: Type.STRING, description: "Uno de: Logro Alto, Logro Medio, Logro Bajo" },
            eval_general_obs: { type: Type.STRING, description: "Redacción formal de justificación clínica detallada del proceso" },
            consumo_patron: { type: Type.STRING, description: "Uno de: Abstinencia, Disminucion de Consumo, Mantencion de Consumo" },
            consumo_obs: { type: Type.STRING, description: "Observación de adherencia, controles, craving y reducción o abstinencia" },
            familiar_logro: { type: Type.STRING, description: "Uno de: Logro Alto, Logro Medio, Logro Bajo" },
            familiar_obs: { type: Type.STRING, description: "Detalles del soporte familiar, red de contención, codependencia si aplica" },
            interpersonal_logro: { type: Type.STRING, description: "Uno de: Logro Alto, Logro Medio, Logro Bajo" },
            interpersonal_obs: { type: Type.STRING, description: "Relación con el entorno, límites, amigos de consumo vs amigos de apoyo" },
            norma_logro: { type: Type.STRING, description: "Uno de: Logro Alto, Logro Medio, Logro Bajo" },
            norma_obs: { type: Type.STRING, description: "Infracciones, transgresiones, respeto por la autoridad y normas sociales" },
            ocupacional_logro: { type: Type.STRING, description: "Uno de: Logro Alto, Logro Medio, Logro Bajo" },
            ocupacional_obs: { type: Type.STRING, description: "Inserción laboral, estudios, ocupación saludable del tiempo" },
            pronostico_obs: { type: Type.STRING, description: "Recomendaciones finales, factores de riesgo, plan de prevención y derivaciones" }
          },
          required: [
            "paciente_nombre", "paciente_rut", "paciente_domicilio", "paciente_nacimiento",
            "fecha_ingreso", "fecha_egreso", "motivo_egreso", "eval_general_logro", "eval_general_obs",
            "consumo_patron", "consumo_obs", "familiar_logro", "familiar_obs", "interpersonal_logro",
            "interpersonal_obs", "norma_logro", "norma_obs", "ocupacional_logro", "ocupacional_obs",
            "pronostico_obs"
          ]
        }
      }
    });

    const textResponse = response.text;
    if (!textResponse) {
      throw new Error("No se recibió respuesta de la Inteligencia Artificial.");
    }

    const data = JSON.parse(textResponse);
    res.json(data);
  } catch (error: any) {
    console.error("Error al generar informe:", error);
    res.status(500).json({ error: error.message || "Error al comunicarse con la Inteligencia Artificial." });
  }
});

// 2. Endpoint para generación de texto clínico
app.post("/api/ai/generate", async (req: express.Request, res: express.Response) => {
  try {
    const { prompt, systemInstruction, temperature, model } = req.body;
    if (!prompt) {
      return res.status(400).json({ error: "El prompt es requerido." });
    }
    const ai = getGeminiClient();
    const response = await generateContentWithFallback(ai, {
      model: model || "gemini-3.8-flash",
      contents: prompt,
      config: {
        systemInstruction: systemInstruction || undefined,
        temperature: temperature !== undefined ? temperature : 0.2,
      },
    });
    res.json({ text: response.text || "" });
  } catch (error: any) {
    console.error("Error in /api/ai/generate:", error);
    res.status(500).json({ error: error.message || "Error al generar contenido con IA." });
  }
});

// 3. Endpoint para chat clínico asistido
app.post("/api/ai/chat", async (req: express.Request, res: express.Response) => {
  try {
    const { messages, systemInstruction, temperature, model } = req.body;
    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: "Lista de mensajes inválida." });
    }
    const ai = getGeminiClient();
    const contents = messages.map((m: any) => ({
      role: m.role === "model" ? "model" : "user",
      parts: [{ text: m.text }],
    }));
    const response = await generateContentWithFallback(ai, {
      model: model || "gemini-3.8-flash",
      contents: contents,
      config: {
        systemInstruction: systemInstruction || undefined,
        temperature: temperature !== undefined ? temperature : 0.2,
      },
    });
    res.json({ text: response.text || "" });
  } catch (error: any) {
    console.error("Error in /api/ai/chat:", error);
    res.status(500).json({ error: error.message || "Error al procesar el chat con IA." });
  }
});

// 4. Endpoint para transcripción de audio clínico
app.post("/api/ai/transcribe", async (req: express.Request, res: express.Response) => {
  try {
    const { audioData, mimeType, prompt } = req.body;
    if (!audioData) {
      return res.status(400).json({ error: "Datos de audio no proporcionados." });
    }
    const ai = getGeminiClient();
    const audioPart = {
      inlineData: {
        mimeType: mimeType || "audio/webm",
        data: audioData,
      },
    };
    const response = await ai.models.generateContent({
      model: "gemini-3.5-transcribe",
      contents: {
        parts: [
          audioPart,
          { text: prompt || "Transcribe con precisión este audio clínico en español." },
        ],
      },
    });
    res.json({ text: response.text || "" });
  } catch (error: any) {
    console.error("Error in /api/ai/transcribe:", error);
    res.status(500).json({ error: error.message || "Error al transcribir el audio clínico." });
  }
});

// 5. Endpoint para síntesis de voz clínica (Text-to-Speech con Gemini TTS)
app.post("/api/ai/tts", async (req: express.Request, res: express.Response) => {
  try {
    const { text, voiceName } = req.body;
    if (!text || typeof text !== "string") {
      return res.status(400).json({ error: "El texto es requerido para TTS." });
    }
    const ai = getGeminiClient();
    const response = await ai.models.generateContent({
      model: "gemini-3.1-flash-tts-preview",
      contents: [{ parts: [{ text: text.slice(0, 1000) }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: voiceName || "Zephyr" },
          },
        },
      },
    });
    const audioData = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data || null;
    res.json({ audio: audioData });
  } catch (error: any) {
    console.error("Error in /api/ai/tts:", error);
    res.status(500).json({ error: error.message || "Error al sintetizar voz clínica." });
  }
});

// 6. Endpoint de turno conversacional por voz (Live Voice Turn Fallback)
app.post("/api/ai/live-voice-turn", async (req: express.Request, res: express.Response) => {
  try {
    const { audioData, mimeType, text, history } = req.body;
    const ai = getGeminiClient();

    let userPrompt = (text || "").trim();

    // Si viene audio grabado en base64, transcribir con gemini-3.5-transcribe
    if (!userPrompt && audioData) {
      try {
        const audioPart = {
          inlineData: {
            mimeType: mimeType || "audio/webm",
            data: audioData,
          },
        };
        const transcribeRes = await ai.models.generateContent({
          model: "gemini-3.5-transcribe",
          contents: {
            parts: [
              audioPart,
              { text: "Transcribe exactamente en español clínico lo expresado por el profesional de salud. No agregues introducciones ni comentarios." },
            ],
          },
        });
        userPrompt = transcribeRes.text?.trim() || "";
      } catch (tErr) {
        console.warn("Live voice turn transcription error:", tErr);
      }
    }

    if (!userPrompt) {
      return res.status(400).json({ error: "No se capturó audio comprensible ni texto." });
    }

    const systemInstruction =
      "Eres un asistente clínico especialista en psiquiatría de adicciones, farmacología y neurobiología de COSAM Rinconada. Responde de forma concisa (máximo 2 oraciones breves y directas aptas para conversación fluida por voz), profesional y empática en español.";

    let contents: any = userPrompt;
    if (history && Array.isArray(history) && history.length > 0) {
      contents = [
        ...history.slice(-4).map((h: any) => ({
          role: h.role === "model" ? "model" : "user",
          parts: [{ text: h.text }],
        })),
        { role: "user", parts: [{ text: userPrompt }] },
      ];
    }

    const response = await generateContentWithFallback(ai, {
      model: "gemini-3.8-flash",
      contents,
      config: {
        systemInstruction,
        temperature: 0.2,
      },
    });

    const modelText = response.text || "Entendido, estoy atento a sus indicaciones clínicas.";

    // Generar audio TTS con gemini-3.1-flash-tts-preview
    let audioOutput: string | null = null;
    try {
      const ttsRes = await ai.models.generateContent({
        model: "gemini-3.1-flash-tts-preview",
        contents: [{ parts: [{ text: modelText }] }],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: "Zephyr" },
            },
          },
        },
      });
      audioOutput = ttsRes.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data || null;
    } catch (ttsErr) {
      console.warn("Live voice turn TTS generation warning:", ttsErr);
    }

    res.json({
      userText: userPrompt,
      modelText,
      audio: audioOutput,
    });
  } catch (error: any) {
    console.error("Error in /api/ai/live-voice-turn:", error);
    res.status(500).json({ error: error.message || "Error al procesar el turno de voz clínico." });
  }
});

// 7. Endpoint para búsqueda clínica con respaldo y citas de Google Search
app.post("/api/ai/search", async (req: express.Request, res: express.Response) => {
  try {
    const { prompt, systemInstruction } = req.body;
    if (!prompt) {
      return res.status(400).json({ error: "El término o pregunta de búsqueda es requerido." });
    }
    const ai = getGeminiClient();
    const response = await generateContentWithFallback(ai, {
      model: "gemini-3.8-flash",
      contents: prompt,
      config: {
        systemInstruction: systemInstruction || undefined,
        tools: [{ googleSearch: {} }],
      },
    });

    const candidate = response.candidates?.[0];
    const groundingChunks = candidate?.groundingMetadata?.groundingChunks || [];
    const webSearchQueries = candidate?.groundingMetadata?.webSearchQueries || [];

    res.json({
      text: response.text || "",
      groundingChunks,
      webSearchQueries,
    });
  } catch (error: any) {
    console.error("Error in /api/ai/search:", error);
    res.status(500).json({ error: error.message || "Error al realizar la búsqueda basada en evidencia médica." });
  }
});

// Servidor HTTP y WebSocket
async function startServer() {
  const server = http.createServer(app);

  // WebSocket Server para Gemini Live API de voz bidireccional
  const wss = new WebSocketServer({ noServer: true });

  wss.on("connection", async (clientWs: WebSocket) => {
    console.log("Live voice client connected via WebSocket");
    let session: any = null;

    try {
      const ai = getGeminiClient();
      session = await ai.live.connect({
        model: "gemini-3.1-flash-live-preview",
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: "Zephyr" } },
          },
          systemInstruction:
            "Eres un asistente clínico especialista en psiquiatría de adicciones, farmacología y neurobiología de COSAM Rinconada. Responde de forma clara, concisa, profesional y empática en español.",
        },
        callbacks: {
          onmessage: (message: LiveServerMessage) => {
            if (clientWs.readyState !== WebSocket.OPEN) return;

            const audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (audio) {
              clientWs.send(JSON.stringify({ type: "audio", audio }));
            }
            if (message.serverContent?.interrupted) {
              clientWs.send(JSON.stringify({ type: "interrupted", interrupted: true }));
            }
            if (message.serverContent?.turnComplete) {
              clientWs.send(JSON.stringify({ type: "turnComplete" }));
            }
          },
          onerror: (err: any) => {
            console.error("Gemini Live session error:", err);
            if (clientWs.readyState === WebSocket.OPEN) {
              clientWs.send(
                JSON.stringify({
                  type: "error",
                  error: err.message || "Error en la sesión de Gemini Live.",
                })
              );
            }
          },
          onclose: () => {
            if (clientWs.readyState === WebSocket.OPEN) {
              clientWs.send(JSON.stringify({ type: "turnComplete" }));
            }
          },
        },
      });

      clientWs.on("message", (data) => {
        try {
          const parsed = JSON.parse(data.toString());
          if (parsed.audio && session) {
            session.sendRealtimeInput({
              audio: { data: parsed.audio, mimeType: "audio/pcm;rate=16000" },
            });
          } else if (parsed.text && session) {
            session.send({
              clientContent: {
                turns: [
                  {
                    role: "user",
                    parts: [{ text: parsed.text }],
                  },
                ],
                turnComplete: true,
              },
            });
          }
        } catch (err) {
          console.error("Error parsing message from client WS:", err);
        }
      });

      clientWs.on("close", () => {
        console.log("Live voice client disconnected");
        if (session) {
          try {
            session.close();
          } catch (e) {}
        }
      });

      clientWs.on("error", (err) => {
        console.error("Client WS error:", err);
      });
    } catch (err: any) {
      console.error("Failed to initialize Gemini Live session:", err);
      if (clientWs.readyState === WebSocket.OPEN) {
        clientWs.send(
          JSON.stringify({
            type: "error",
            error: err.message || "No se pudo iniciar la sesión de voz con Gemini Live.",
          })
        );
      }
      clientWs.close();
    }
  });

  // Manejo de la actualización a WebSocket (upgrade)
  server.on("upgrade", (request, socket, head) => {
    const url = new URL(request.url || "", `http://${request.headers.host || "localhost"}`);
    if (url.pathname === "/ws/live" || url.pathname === "/live") {
      wss.handleUpgrade(request, socket, head, (ws) => {
        wss.emit("connection", ws, request);
      });
    }
  });

  // Integración de Vite / Archivos estáticos
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req: express.Request, res: express.Response) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  server.listen(PORT, "0.0.0.0", () => {
    console.log(`Server and Live WebSockets running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
